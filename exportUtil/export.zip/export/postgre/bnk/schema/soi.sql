DROP FUNCTION soi.address_process(); 
CREATE OR REPLACE FUNCTION soi.address_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 1;
  voptype smallint;
  vtr_id bigint;
  vaddrmun_id BIGINT;
BEGIN

 select c.municipality_id::BIGINT
   into vaddrmun_id
   from config c
  where c.name = 'SOI_MUN_ID';
  
IF (TG_OP = 'UPDATE') THEN
	IF (OLD.city_id != NEW.city_id OR 
    	OLD.street_id != NEW.street_id OR 
        OLD.nom != NEW.nom OR 
        OLD.block != NEW.block OR 
        OLD.entry != NEW.entry OR 
        OLD.floor != NEW.floor OR 
        OLD.apartment != NEW.apartment OR 
        OLD.admregion_id != NEW.admregion_id) THEN 
        	vtr_id := soi.tr_insert(vtr_type, NEW.address_id); 
			voptype := 2; -- XML type 2
			perform soi.tr_update(vtr_id, voptype, vaddrmun_id, NEW.address_id, vtr_type);
    END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, NEW.address_id);
    voptype := 1; -- XML type 1
	perform soi.tr_update(vtr_id, voptype, vaddrmun_id, NEW.address_id, vtr_type);

END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.debt_process(); 
CREATE OR REPLACE FUNCTION soi.debt_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 7;
  voptype smallint;
  vtr_id bigint;
BEGIN

IF (TG_OP = 'UPDATE') THEN
	IF (OLD.taxsubject_id != NEW.taxsubject_id OR 
    	OLD.taxobject_id != NEW.taxobject_id OR 
        OLD.kinddebtreg_id != NEW.kinddebtreg_id OR 
        OLD.totaltax != NEW.totaltax OR 
        OLD.taxperiod_id != NEW.taxperiod_id) THEN
			vtr_id := soi.tr_insert(vtr_type, NEW.debtsubject_id);
            voptype := 2; -- XML type 2
			perform soi.tr_update(vtr_id, voptype, NEW.municipality_id, NEW.debtsubject_id, vtr_type);
    END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, NEW.debtsubject_id);
    voptype := 1; -- XML type 1
	perform soi.tr_update(vtr_id, voptype, NEW.municipality_id, NEW.debtsubject_id, vtr_type);

END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.debtbdi_process(); 
CREATE OR REPLACE FUNCTION soi.debtbdi_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 7;
  voptype smallint;
  vtr_id bigint;
  vdebtimun_id BIGINT;
BEGIN

select c.municipality_id::BIGINT
into vdebtimun_id
from config c
where c.name = 'SOI_MUN_ID';

IF (TG_OP = 'UPDATE') THEN
	IF (OLD.instsum != NEW.instsum OR 
        OLD.interestsum != NEW.interestsum) THEN
			vtr_id := soi.tr_insert(vtr_type, NEW.debtinstalment_id);
            voptype := 2; -- XML type 2
			perform soi.tr_update(vtr_id, voptype, vdebtimun_id, NEW.debtinstalment_id, vtr_type);
    END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, NEW.debtinstalment_id);
    voptype := 2; -- XML type 2
	perform soi.tr_update(vtr_id, voptype, vdebtimun_id, NEW.debtinstalment_id, vtr_type);

ELSIF (TG_OP = 'DELETE') THEN
	vtr_id := soi.tr_insert(vtr_type, OLD.debtinstalment_id);
    voptype := 2; -- XML type 2
	perform soi.tr_update(vtr_id, voptype, vdebtimun_id, OLD.debtinstalment_id, vtr_type);
    
END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.debti_process(); 
CREATE OR REPLACE FUNCTION soi.debti_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 7;
  voptype smallint;
  vtr_id bigint;
  vdebtimun_id BIGINT;
BEGIN

select c.municipality_id::BIGINT
  into vdebtimun_id
  from config c
 where c.name = 'SOI_MUN_ID';
 
IF (TG_OP = 'UPDATE') THEN
	IF (OLD.debtsubject_id != NEW.debtsubject_id OR 
       	OLD.instsum != NEW.instsum OR 
    	OLD.termpay_date != NEW.termpay_date) THEN
		vtr_id := soi.tr_insert(vtr_type, NEW.debtinstalment_id);
       	voptype := 2; -- XML type 2
		perform soi.tr_update(vtr_id, voptype, vdebtimun_id, NEW.debtinstalment_id, vtr_type);
    END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, NEW.debtinstalment_id);
   	voptype := 1; -- XML type 1
	perform soi.tr_update(vtr_id, voptype, vdebtimun_id, NEW.debtinstalment_id, vtr_type);

END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.declaration_process(); 
CREATE OR REPLACE FUNCTION soi.declaration_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 3; 
  voptype smallint;
  vtr_id bigint;
BEGIN

IF (TG_OP = 'UPDATE') THEN
	--new.docstatus::text = '30'::text!!!
	IF (OLD.taxobject_id != NEW.taxobject_id OR 
    	OLD.doc_date != NEW.doc_date OR 
        OLD.docno != NEW.docno OR 
        OLD.partidano != NEW.partidano OR 
        OLD.documenttype_id != NEW.documenttype_id OR 
        OLD.docstatus != NEW.docstatus) THEN
			vtr_id := soi.tr_insert(vtr_type, NEW.taxdoc_id);
            voptype := 2; -- XML type 2
			perform soi.tr_update(vtr_id, voptype, NEW.municipality_id, NEW.taxdoc_id, vtr_type);
    END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, NEW.taxdoc_id);
    voptype := 1; -- XML type 1
	perform soi.tr_update(vtr_id, voptype, NEW.municipality_id, NEW.taxdoc_id, vtr_type);
    
END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.init_address(); 
CREATE OR REPLACE FUNCTION soi.init_address()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 1;
  voptype smallint;
  vtr_id bigint;
  vaddrmun_id BIGINT;
  vstatus VARCHAR = 'ERR';
  craddr CURSOR is 
  	SELECT a.* 
      FROM address a;
   --  where a.address_id >= 55481  -- samo za testvane
   --    and a.address_id < 55581; -- samo za testvane
  raddr  address%rowtype; --record;
BEGIN
 select c.municipality_id::BIGINT
   into vaddrmun_id
   from config c
  where c.name = 'SOI_MUN_ID';
  
 open craddr;
 loop
  fetch craddr
   into raddr;
  exit when not FOUND;
  vtr_id := soi.tr_insert(vtr_type, raddr.address_id);
  voptype := 1; -- XML type 1
  perform soi.tr_update(vtr_id, voptype, vaddrmun_id, raddr.address_id, vtr_type);
 end loop;
 close craddr;
    
 vstatus := 'OK';
 RETURN(vstatus);

 exception
    when others then
      vstatus := 'ERRE1'; 
 RETURN(vstatus);
 
END;
$function$
; DROP FUNCTION soi.init_debt(); 
CREATE OR REPLACE FUNCTION soi.init_debt()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 7;
  voptype smallint;
  vtr_id bigint;
  vstatus VARCHAR = 'ERR';
  crdebt CURSOR is 
  	SELECT t.* 
    	FROM debtsubject t;
    -- where t.debtsubject_id >= 5  -- samo za testvane
    --   and t.debtsubject_id < 10; -- samo za testvane
  rdebt  debtsubject%rowtype; --record;
BEGIN
/*  
 open crdebt;
 loop
  fetch crdebt
   into rdebt;
  exit when not FOUND;
  vtr_id := soi.tr_insert(vtr_type, rdebt.debtsubject_id);
  voptype := 1; -- XML type 1
  perform soi.tr_update(vtr_id, voptype, rdebt.municipality_id, rdebt.debtsubject_id, vtr_type);
 end loop;
 close crdebt;
*/
 vstatus := 'OK';
 RETURN(vstatus);

 exception
    when others then
      vstatus := 'ERRE1'; 
 RETURN(vstatus);
 
END;
$function$
; DROP FUNCTION soi.init_debti(); 
CREATE OR REPLACE FUNCTION soi.init_debti()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 7;
  voptype smallint;
  vtr_id bigint;
  vdebtmun_id BIGINT;
  vstatus VARCHAR = 'ERR';
  crdebt CURSOR is 
  	SELECT t.* 
      FROM debtinstalment t;
   --  where t.debtinstalment_id >= 100  -- samo za testvane
   --    and t.debtinstalment_id < 200; -- samo za testvane
  rdebt  debtinstalment%rowtype; --record;
BEGIN
 select c.municipality_id::BIGINT
   into vdebtmun_id
   from config c
  where c.name = 'SOI_MUN_ID';
  
 open crdebt;
 loop
  fetch crdebt
   into rdebt;
  exit when not FOUND;
  vtr_id := soi.tr_insert(vtr_type, rdebt.debtinstalment_id);
  voptype := 1; -- XML type 1
  perform soi.tr_update(vtr_id, voptype, vdebtmun_id, rdebt.debtinstalment_id, vtr_type);
 end loop;
 close crdebt;
    
 vstatus := 'OK';
 RETURN(vstatus);

 exception
    when others then
      vstatus := 'ERRE1'; 
 RETURN(vstatus);
 
END;
$function$
; DROP FUNCTION soi.init_declaration(); 
CREATE OR REPLACE FUNCTION soi.init_declaration()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 3;
  voptype smallint;
  vtr_id bigint;
  vstatus VARCHAR = 'ERR';
  crdecl CURSOR is 
  	SELECT t.* 
      FROM taxdoc t;
  --   where t.taxdoc_id >= 100  -- samo za testvane
  --     and t.taxdoc_id < 200; -- samo za testvane
  rdecl  taxdoc%rowtype; --record;
BEGIN
  
 open crdecl;
 loop
  fetch crdecl
   into rdecl;
  exit when not FOUND;
  vtr_id := soi.tr_insert(vtr_type, rdecl.taxdoc_id);
  voptype := 1; -- XML type 1
  perform soi.tr_update(vtr_id, voptype, rdecl.municipality_id, rdecl.taxdoc_id, vtr_type);
 end loop;
 close crdecl;
    
 vstatus := 'OK';
 RETURN(vstatus);

 exception
    when others then
      vstatus := 'ERRE1'; 
 RETURN(vstatus);
 
END;
$function$
; DROP FUNCTION soi.init_object(); 
CREATE OR REPLACE FUNCTION soi.init_object()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 2;
  voptype smallint;
  vtr_id bigint;
  vstatus VARCHAR = 'ERR';
  crobj CURSOR is 
  	SELECT t.* 
      FROM taxobject t;
  --   where t.taxobject_id >= 100  -- samo za testvane
  --     and t.taxobject_id < 200; -- samo za testvane
  robj  taxobject%rowtype; --record;
BEGIN
  
 open crobj;
 loop
  fetch crobj
   into robj;
  exit when not FOUND;
  vtr_id := soi.tr_insert(vtr_type, robj.taxobject_id);
  voptype := 1; -- XML type 1
  perform soi.tr_update(vtr_id, voptype, robj.municipality_id, robj.taxobject_id, vtr_type);
 end loop;
 close crobj;
    
 vstatus := 'OK';
 RETURN(vstatus);

 exception
    when others then
      vstatus := 'ERRE1'; 
 RETURN(vstatus);
 
END;
$function$
; DROP FUNCTION soi.init_partproperty(); 
CREATE OR REPLACE FUNCTION soi.init_partproperty()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 5;
  voptype smallint;
  vtr_id bigint;
  vtaxobj_id BIGINT;
  vmun_id BIGINT;
  vstatus VARCHAR = 'ERR';
  crpartp CURSOR is 
  	SELECT t.* 
      FROM partproperty t;
  --   where t.partproperty_id >= 100  -- samo za testvane
  --     and t.partproperty_id < 200; -- samo za testvane
  rpartp  partproperty%rowtype; --record;
BEGIN
  
 open crpartp;
 loop
  fetch crpartp
   into rpartp;
  exit when not FOUND;
  
  select td.taxobject_id, td.municipality_id
   into vtaxobj_id, vmun_id
   from property pr  
     join taxdoc td on pr.taxdoc_id = td.taxdoc_id
   where pr.property_id = rpartp.property_id;
   
  vtr_id := soi.tr_insert(vtr_type, vtaxobj_id);
  voptype := 1; -- XML type 1
  perform soi.tr_update(vtr_id, voptype, vmun_id, rpartp.partproperty_id, vtr_type);
 end loop;
 close crpartp;
    
 vstatus := 'OK';
 RETURN(vstatus);

 exception
    when others then
      vstatus := 'ERRE1'; 
 RETURN(vstatus);
 
END;
$function$
; DROP FUNCTION soi.init_parttransport(); 
CREATE OR REPLACE FUNCTION soi.init_parttransport()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 5;
  voptype smallint;
  vtr_id bigint;
  vtaxobj_id BIGINT;
  vmun_id BIGINT;
  vstatus VARCHAR = 'ERR';
  crpartt CURSOR is 
  	SELECT t.* 
      FROM parttransport t
    WHERE t.transport_id not in (select ptr.transport_id
								   from parttransport ptr
								   left join transport tr on ptr.transport_id = tr.transport_id
								   left join taxdoc td on tr.taxdoc_id = td.taxdoc_id
								   where td.taxobject_id is null);
  --   where t.parttransport_id >= 100  -- samo za testvane
  --     and t.parttransport_id < 200; -- samo za testvane
  rpartpt parttransport%rowtype; --record;
BEGIN
  
 open crpartt;
 loop
  fetch crpartt
   into rpartpt;
  exit when not FOUND;
  
  select td.taxobject_id, td.municipality_id
   into vtaxobj_id, vmun_id
   from parttransport ptr 
   	left join transport tr on ptr.transport_id = tr.transport_id
     left join taxdoc td on tr.taxdoc_id = td.taxdoc_id
   where tr.transport_id = rpartpt.transport_id;
  
  vtr_id := soi.tr_insert(vtr_type, vtaxobj_id);
  voptype := 1; -- XML type 1
  perform soi.tr_update(vtr_id, voptype, vmun_id, rpartpt.parttransport_id, vtr_type);
 end loop;
 close crpartt;
    
 vstatus := 'OK';
 RETURN(vstatus);

 exception
    when others then
      vstatus := 'ERRE1:'||SQLSTATE; 
 RETURN(vstatus);
 
END;
$function$
; DROP FUNCTION soi.init_payment(); 
CREATE OR REPLACE FUNCTION soi.init_payment()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 8;
  voptype smallint;
  vtr_id bigint;
  vpaymun_id BIGINT;
  vstatus VARCHAR = 'ERR';
  crpay CURSOR is 
  	SELECT t.* 
      FROM paydebt t;
  --   where t.paydebt_id >= 146934  -- samo za testvane
  --     and t.paydebt_id < 147034; -- samo za testvane
  rpay  paydebt%rowtype; --record;
BEGIN
 
 select c.municipality_id::BIGINT
  into vpaymun_id
  from config c
  where c.name = 'SOI_MUN_ID';
   
 open crpay;
 loop
  fetch crpay
   into rpay;
  exit when not FOUND;
  vtr_id := soi.tr_insert(vtr_type, rpay.paydebt_id);
  voptype := 1; -- XML type 1
  perform soi.tr_update(vtr_id, voptype, vpaymun_id, rpay.paydebt_id, vtr_type);
 end loop;
 close crpay;
    
 vstatus := 'OK';
 RETURN(vstatus);

 exception
    when others then
      vstatus := 'ERRE1'; 
 RETURN(vstatus);
 
END;
$function$
; DROP FUNCTION soi.init_subject(); 
CREATE OR REPLACE FUNCTION soi.init_subject()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 4;
  voptype smallint;
  vtr_id bigint;
  vsubjmun_id BIGINT;
  vstatus VARCHAR = 'ERR';
  crsubj CURSOR is 
  	SELECT t.* 
      FROM taxsubject t;
  --   where t.taxsubject_id >= 100  -- samo za testvane
  --     and t.taxsubject_id < 200; -- samo za testvane
  rsubj  taxsubject%rowtype; --record;
BEGIN
 select c.municipality_id::BIGINT
   into vsubjmun_id
   from config c
  where c.name = 'SOI_MUN_ID';
  
 open crsubj;
 loop
  fetch crsubj
   into rsubj;
  exit when not FOUND;
  vtr_id := soi.tr_insert(vtr_type, rsubj.taxsubject_id);
  voptype := 1; -- XML type 1
  perform soi.tr_update(vtr_id, voptype, vsubjmun_id, rsubj.taxsubject_id, vtr_type);
 end loop;
 close crsubj;
    
 vstatus := 'OK';
 RETURN(vstatus);

 exception
    when others then
      vstatus := 'ERRE1'; 
 RETURN(vstatus);
 
END;
$function$
; DROP FUNCTION soi.object_process(); 
CREATE OR REPLACE FUNCTION soi.object_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 2;
  voptype smallint;
  vtr_id bigint;
BEGIN

IF (TG_OP = 'UPDATE') THEN
	IF (OLD.kindtaxobject != NEW.kindtaxobject OR 
    	OLD.kindproperty != NEW.kindproperty OR 
        OLD.carreg_id != NEW.carreg_id OR 
        OLD.registerno != NEW.registerno OR 
        OLD.transpmeansreg_id != NEW.transpmeansreg_id OR 
        OLD.enddate != NEW.enddate OR 
        OLD.address_id != NEW.address_id) THEN
			vtr_id := soi.tr_insert(vtr_type, NEW.taxobject_id);
            voptype := 2; -- XML type 2
			perform soi.tr_update(vtr_id, voptype, NEW.municipality_id, NEW.taxobject_id, vtr_type);
    END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, NEW.taxobject_id);
    voptype := 1; -- XML type 1
	perform soi.tr_update(vtr_id, voptype, NEW.municipality_id, NEW.taxobject_id, vtr_type);

END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.partproperty_process(); 
CREATE OR REPLACE FUNCTION soi.partproperty_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 5;
  voptype smallint;
  vtr_id bigint;
  vtaxobj_id BIGINT;
  vmun_id BIGINT;
BEGIN

select td.taxobject_id, td.municipality_id
into vtaxobj_id, vmun_id
from property pr  
     join taxdoc td on pr.taxdoc_id = td.taxdoc_id
where pr.property_id = NEW.property_id
; 

IF (TG_OP = 'UPDATE') THEN
	IF (OLD.typedeclar != NEW.typedeclar OR 
    	OLD.taxsubject_id != NEW.taxsubject_id) THEN 
			vtr_id := soi.tr_insert(vtr_type, vtaxobj_id);
            voptype := 2; -- XML type 2
			perform soi.tr_update(vtr_id, voptype, vmun_id, NEW.partproperty_id, vtr_type);
    END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, vtaxobj_id);
    voptype := 1; -- XML type 1
    perform soi.tr_update(vtr_id, voptype, vmun_id, NEW.partproperty_id, vtr_type);
	
END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.parttransport_process(); 
CREATE OR REPLACE FUNCTION soi.parttransport_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 5;
  voptype smallint;
  vtr_id bigint;
  vtaxobj_id BIGINT;
  vmun_id BIGINT;
BEGIN

select td.taxobject_id, td.municipality_id
into vtaxobj_id, vmun_id
from transport tr  
     join taxdoc td on tr.taxdoc_id = td.taxdoc_id
where tr.transport_id = NEW.transport_id
; 

IF (TG_OP = 'UPDATE') THEN
	IF (OLD.taxsubject_id != NEW.taxsubject_id) THEN 
			vtr_id := soi.tr_insert(vtr_type, vtaxobj_id);
            voptype := 2; -- XML type 2
			perform soi.tr_update(vtr_id, voptype, vmun_id, NEW.parttransport_id, vtr_type);
    END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, vtaxobj_id);
    voptype := 1; -- XML type 1
    perform soi.tr_update(vtr_id, voptype, vmun_id, NEW.parttransport_id, vtr_type);
	
END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.payment_process(); 
CREATE OR REPLACE FUNCTION soi.payment_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 8;
  voptype smallint;
  vtr_id bigint;
  vpaymmun_id BIGINT;
BEGIN

 select nvl(ptr.municipality_id,-1.0) 
   into vpaymmun_id
   from paydebt pd 
   join paydocument pdoc on pd.paydocument_id = pdoc.paydocument_id 
   join paytransaction ptr on pdoc.paytransaction_id = ptr.paytransaction_id 
  where pd.paydebt_id = NEW.paydebt_id
 ;
 
IF (TG_OP = 'UPDATE') THEN
	IF (OLD.balinstsum != NEW.balinstsum OR 
    	OLD.payinstsum != NEW.payinstsum OR 
	    OLD.balinterestsum != NEW.balinterestsum OR 
	    OLD.payinterestsum != NEW.payinterestsum OR 
	    OLD.paydiscsum != NEW.paydiscsum) THEN
		vtr_id := soi.tr_insert(vtr_type, NEW.paydebt_id);
        voptype := 2; -- XML type 2
		perform soi.tr_update(vtr_id, voptype, vpaymmun_id, NEW.paydebt_id, vtr_type);
    END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, NEW.paydebt_id);
    voptype := 1; -- XML type 1
	perform soi.tr_update(vtr_id, voptype, vpaymmun_id, NEW.paydebt_id, vtr_type);
        
END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.subject_process(); 
CREATE OR REPLACE FUNCTION soi.subject_process()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
  vtr_type smallint = 4;
  voptype smallint;
  vtr_id bigint;
  vsubjmun_id BIGINT;
BEGIN

select c.municipality_id::BIGINT
into vsubjmun_id
from config c
where c.name = 'SOI_MUN_ID';

IF (TG_OP = 'UPDATE') THEN
	IF (OLD.name != NEW.name OR 
    	OLD.idn != NEW.idn OR 
        OLD.kind_idn != NEW.kind_idn OR 
        OLD.isperson != NEW.isperson) THEN 
			vtr_id := soi.tr_insert(vtr_type, NEW.taxsubject_id);
            voptype := 2; -- XML type 2
			perform soi.tr_update(vtr_id, voptype,vsubjmun_id, NEW.taxsubject_id, vtr_type);
	END IF;

ELSIF (TG_OP = 'INSERT') THEN
	vtr_id := soi.tr_insert(vtr_type, NEW.taxsubject_id);
    voptype := 1; -- XML type 1
	perform soi.tr_update(vtr_id, voptype,vsubjmun_id, NEW.taxsubject_id, vtr_type);
    
END IF;

RETURN NULL; 
END;
$function$
; DROP FUNCTION soi.tr_insert(smallint, numeric); 
CREATE OR REPLACE FUNCTION soi.tr_insert(iptr_type smallint, ipobj_id numeric)
 RETURNS bigint
 LANGUAGE plpgsql
AS $function$
DECLARE
  vtr_id bigint;
   
BEGIN

 INSERT INTO transactions (tr_type, obj_id) 
  VALUES (iptr_type, ipobj_id::bigint);
  
 vtr_id := currval('transactions_tr_id_seq');
  
 return vtr_id;

--EXCEPTION
--WHEN exception_name THEN
-- statements;
END;
$function$
; DROP FUNCTION soi.tr_update(bigint, smallint, numeric, numeric, smallint); 
CREATE OR REPLACE FUNCTION soi.tr_update(iptr_id bigint, ipoptype smallint, ipmun_id numeric, ipobject_id numeric, iptr_type smallint)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
  vtr_data xml;
  vmastobj_id BIGINT;
  
BEGIN

	select tr.obj_id
    into vmastobj_id
    from transactions tr
    where tr.tr_id = iptr_id;
    
 	vtr_data := soi.xml_create(iptr_id, ipoptype, ipmun_id::BIGINT, ipobject_id::BIGINT, iptr_type, vmastobj_id);
    
  	UPDATE transactions SET 
	  tr_data = vtr_data::text,
	  tr_status = 1,
	  tr_ts = current_timestamp
	  WHERE tr_id = iptr_id;
      
 
 return;

--EXCEPTION
--WHEN exception_name THEN
-- statements;
END;
$function$
; DROP FUNCTION soi.xml_create(bigint, smallint, bigint, bigint, smallint, bigint); 
CREATE OR REPLACE FUNCTION soi.xml_create(iptr_id bigint, ipoptype smallint, ipmun_id bigint, ipobject_id bigint, iptr_type smallint, ipmastobj_id bigint)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  vtransactionxml xml;
  vheaderxml xml;
  vbodyxml xml;
  vxml xml;
  vschemaname text;
    
BEGIN

 select xmlelement(name "header",
			xmlforest(
				iptr_id as "sequence",
				CURRENT_TIMESTAMP as "date",
				ipmun_id as "mun_id",
        		ipoptype as "type"
        	) 
        )
 into vheaderxml
 ;

 CASE 
	WHEN iptr_type = 1 THEN vbodyxml := soi.xmladdress(ipobject_id);
    						vschemaname := 'address.xsd';
    WHEN iptr_type = 2 THEN vbodyxml := soi.xmlobject(ipobject_id);
    						vschemaname := 'object.xsd';    
    WHEN iptr_type = 3 THEN vbodyxml := soi.xmldeclaration(ipobject_id);
     						vschemaname := 'declaration.xsd';   
	WHEN iptr_type = 4 THEN vbodyxml := soi.xmlsubject(ipobject_id);
    						vschemaname := 'subject.xsd';
	WHEN iptr_type = 5 THEN vbodyxml := soi.xmlrelsubjobj(ipobject_id, ipmastobj_id);
     						vschemaname := 'rel_subj_object.xsd';   
    WHEN iptr_type = 6 THEN vbodyxml := soi.xmlrelsubjred(ipobject_id);
     						vschemaname := 'rel_subj_reduction.xsd';   
    WHEN iptr_type = 7 THEN vbodyxml := soi.xmldebt(ipobject_id);
      						vschemaname := 'debt.xsd';  
    WHEN iptr_type = 8 THEN vbodyxml := soi.xmlpayment(ipobject_id);
      						vschemaname := 'payment.xsd';  
    WHEN iptr_type = 9 THEN vbodyxml := soi.xmlbankacc(ipobject_id);
      						vschemaname := 'bankaccount.xsd';  
    WHEN iptr_type = 10 THEN vbodyxml := soi.xmlbanks(ipobject_id);
      						vschemaname := 'banks.xsd';  
    --ELSE ;
    
 END CASE;

 select xmlelement(name "transaction", 
 			xmlattributes('http://www.w3.org/2001/XMLSchema' as "xmlns:xsd",
            			  vschemaname as "xsd:schemaname"),
			xmlconcat(vheaderxml, vbodyxml) 
        )
 into vtransactionxml
 ;

select xmlroot(vtransactionxml, version '1.0', standalone yes)
	into vxml;
    
 RETURN(vxml);

--EXCEPTION
--WHEN exception_name THEN
--  statements;
END;
$function$
; DROP FUNCTION soi.xmladdress(bigint); 
CREATE OR REPLACE FUNCTION soi.xmladdress(ipobj_id bigint)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  vxmldata xml;
  vaddrmun_id BIGINT;
BEGIN
 select c.municipality_id::BIGINT
   into vaddrmun_id
   from config c
  where c.name = 'SOI_MUN_ID';
 select xmlelement(name "address",
			xmlforest(     
    	vaddrmun_id as mun_id, 
    	adr.address_id as addr_id,
		cast(ci.kind_city as SMALLINT) as city_type_id,
        ci.name as city,
        str.kind_street as street_type_id,
        str.name as street,
        adr.nom as nom, 
        adr.block as block, 
        adr.entry as entry, 
        adr.floor as floor, 
        adr.apartment as apartment,
        public.getaddress(adr.address_id) as text_address,
        adr.admregion_id as dist_id
        	)         
        )
 into vxmldata
 from address adr
	join city ci on adr.city_id = ci.city_id
  	left outer join street str on adr.street_id = str.street_id
 where adr.address_id = ipobj_id --? --51193
;
RETURN (vxmldata);

--EXCEPTION
--WHEN exception_name THEN
--  statements;
END;
$function$
; DROP FUNCTION soi.xmldebt(bigint); 
CREATE OR REPLACE FUNCTION soi.xmldebt(ipobj_id bigint)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  vxmldata xml;
BEGIN
 select xmlelement(name "debt",
			xmlforest(
    	ds.municipality_id as "mun_id", 
        di.debtinstalment_id as "debt_id", 
        ds.taxsubject_id as "sub_id",
        ds.taxobject_id as "obj_id", 
        ds.kinddebtreg_id as "kdr_id",
        di.instsum as "debt",
        case 
         when (nvl(bdi.instsum,0.0)+nvl(bdi.interestsum,0.0)) = 0.0 then 1
         else 0 
        end as "status",
        to_char(di.termpay_date,'YYYY-MM-DD') as "termpay_date",
        null as "interest", 
        null as "int_date",
        ds.taxperiod_id as "period",
        kpr.parreg_name as "paragraph", 
        kdr.name as "subparagraph"
        	) 
 		)
 into vxmldata        
 from debtinstalment di
 	join debtsubject ds on di.debtsubject_id = ds.debtsubject_id
 	join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
    left join kindparreg kpr on ds.kindparreg_id = kpr.kindparreg_id
    left join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
 where di.debtinstalment_id = ipobj_id --? --5286
 ;
/*
 select xmlelement(name "debt",
			xmlforest(
		ds.municipality_id as "mun_id", 
        ds.debtsubject_id as "debt_id", 
        ds.taxsubject_id as "sub_id",
		ds.taxobject_id as "obj_id", 
        ds.kinddebtreg_id as "kdr_id",
		nvl(ds.totaltax, 0.0) as "debt",
        0 as "status",
        to_char(
        (select di.termpay_date
		 from debtinstalment di
		 where di.debtinstalment_id =
				(select di1.debtinstalment_id
    			 from debtinstalment di1
    			 where di1.debtsubject_id = ds.debtsubject_id
     			 and di1.instno =
     				(select max(di2.instno)
            		 from debtinstalment di2
            		 where di2.debtsubject_id = ds.debtsubject_id
                     )
            	)
            )
            ,'YYYY-MM-DD') as "termpay_date",
        null as "interest", 
        null as "int_date",
        ds.taxperiod_id as "period",
        kpr.parreg_name as "paragraph", 
        kdr.name as "subparagraph"
        	) 
 		)
 into vxmldata
 from debtsubject ds
 	join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
    left join kindparreg kpr on ds.kindparreg_id = kpr.kindparreg_id
 where ds.debtsubject_id = ipobj_id --? --5286
 ;
 */
 RETURN (vxmldata);
--EXCEPTION
--WHEN exception_name THEN
--  statements;
END;
$function$
; DROP FUNCTION soi.xmldeclaration(bigint); 
CREATE OR REPLACE FUNCTION soi.xmldeclaration(ipobj_id bigint)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  vxmldata xml;
BEGIN
                                
 select xmlelement(name "declaration",
			xmlforest(
				td.municipality_id as "mun_id",
				td.taxobject_id as "obj_id",
        		td.taxdoc_id as "dec_id",
				to_char(td.doc_date,'YYYY-MM-DD') as "dec_date",
        		td.docno as "doc_id",
        		td.partidano as "part_num",
        		td.documenttype_id as "doc_type_id",
        		case when td.docstatus = '30'
        				then 1
        				else 0
        		 end as "status",
        		null as "contentdcl"
        	) 
 		)
 into vxmldata
 from taxdoc td
 where td.taxdoc_id = ipobj_id --? --112
 and (td.taxobject_id is not null OR
 	  td.taxobject_id = -1) -- bez 32, 49
 ;
 RETURN (vxmldata);
--EXCEPTION
--WHEN exception_name THEN
--  statements;
END;
$function$
; DROP FUNCTION soi.xmlobject(bigint); 
CREATE OR REPLACE FUNCTION soi.xmlobject(ipobj_id bigint)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  vxmldata xml;
  vkto_id bigint;
BEGIN
 select tob.kindtaxobject::bigint
 into vkto_id
 from taxobject tob
 where tob.taxobject_id = ipobj_id
 ;
 CASE
  WHEN vkto_id = 1 THEN
 ---- imot - 1
 select xmlelement(name "object",
			xmlforest(
 		tob.municipality_id as mun_id, 
        tob.taxobject_id as obj_id,
		cast(nvl(tob.kindtaxobject,'-1') as SMALLINT) as ko_id, -- 1
		tob.kindproperty as prop_kind,
        null as car_reg,
        null as registerno,
        null as registername,
        to_char(tob.enddate,'YYYY-MM-DD') as end_date,
        tob.address_id as addr_id,
        null as assessment
        	) 
 		)
into vxmldata
from taxobject tob
where tob.taxobject_id = ipobj_id --? --729 imot s
;
  WHEN vkto_id = 2 THEN
---- mps - 2
 select xmlelement(name "object",
			xmlforest(
 		tob.municipality_id as mun_id, 
        tob.taxobject_id as obj_id,
		cast(nvl(tob.kindtaxobject,'-1') as SMALLINT) as ko_id, -- 2
		null as prop_kind,
        nvl(cmrk.mark_name,'') ||' - '|| nvl(cmod.model_name,'') as car_reg,-- carreg
        tob.registerno as registerno,
        tmr.name as registername, -- transpmeansreg
        to_char(tob.enddate,'YYYY-MM-DD') as end_date,
        tob.address_id as addr_id,
        null as assessment
        	) 
 		)
 into vxmldata
from taxobject tob
left outer join transpmeansreg tmr
	 on tmr.transpmeansreg_id = tob.transpmeansreg_id
left outer join carreg creg
	 on creg.carmodel_id = tob.carreg_id
left outer join carmodel cmod
	 on creg.carmodel_id = cmod.carmodel_id
left outer join carmark cmrk
	 on cmod.carmark_id = cmrk.carmark_id
where tob.taxobject_id = ipobj_id --?  --14464 mps
;
  WHEN vkto_id = 3 THEN
---- patent -- 3
 select xmlelement(name "object",
			xmlforest(
 		tob.municipality_id as mun_id, 
        tob.taxobject_id as obj_id,
		cast(nvl(tob.kindtaxobject,'-1') as SMALLINT) as ko_id, -- 3
		null as prop_kind,
        null as car_reg,
        null as registerno,
        null as registername,
        to_char(tob.enddate,'YYYY-MM-DD') as end_date,
        tob.address_id as addr_id,
        null as assessment
        	) 
 		)
 into vxmldata
from taxobject tob
where tob.taxobject_id = ipobj_id --? --11261 patent
;
  WHEN vkto_id = 4 THEN
---- ku4e -- 4
 select xmlelement(name "object",
			xmlforest(
 		tob.municipality_id as mun_id, 
        tob.taxobject_id as obj_id,
		cast(nvl(tob.kindtaxobject,'-1') as SMALLINT) as ko_id, -- 4
		null as prop_kind,
        null as car_reg,
        tob.registerno as registerno,
        tob.registername as registername,
        to_char(tob.enddate,'YYYY-MM-DD') as end_date,
        null as addr_id,
        null as assessment
        	) 
 		)
 into vxmldata
from taxobject tob
where tob.taxobject_id = ipobj_id --? --17770 ku4e
;
  WHEN vkto_id = 5 THEN
---- turist -- 5
 select xmlelement(name "object",
			xmlforest(
 		tob.municipality_id as mun_id, 
        tob.taxobject_id as obj_id,
		cast(nvl(tob.kindtaxobject,'-1') as SMALLINT) as ko_id, -- 5
		tob.kindproperty as prop_kind, ---?????
        null as car_reg,
        null as registerno,
        null as registername,
        to_char(tob.enddate,'YYYY-MM-DD') as end_date,
        tob.address_id as addr_id,
        null as assessment
        	) 
 		)
 into vxmldata
from taxobject tob
where tob.taxobject_id = ipobj_id --? --17389 turist
;
--  ELSE ;
END CASE;

 RETURN (vxmldata);
--EXCEPTION
--WHEN exception_name THEN
--  statements;
END;
$function$
; DROP FUNCTION soi.xmlpayment(bigint); 
CREATE OR REPLACE FUNCTION soi.xmlpayment(ipobj_id bigint)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  vxmldata xml;
BEGIN
 select xmlelement(name "payment",
			xmlforest(
		ds.municipality_id as "mun_id",
 		di.debtinstalment_id as "debt_id",
		pd.paydebt_id as "pay_id",
 		to_char(pdoc.paydate,'YYYY-MM-DD') as "act_paydate",
 		pd.balinstsum as "instsum",
 		pd.payinstsum as "paid_instsum",
 		pd.balinterestsum as "interest",
 		pd.payinterestsum as "paid_interest",
 		pd.paydiscsum as "discount",
 		kpr.parreg_name as "paragraph",
 		kdr.name as "subparagraph"
        	) 
 		)
 into vxmldata
 from paydebt pd
 	join paydocument pdoc on pd.paydocument_id = pdoc.paydocument_id
 	join debtinstalment di on pd.debtinstalment_id = di.debtinstalment_id
 	join debtsubject ds on di.debtsubject_id = ds.debtsubject_id
 	left join kinddebtreg kdr on pd.kinddebtreg_id = kdr.kinddebtreg_id
    left join kindparreg kpr on pd.kindparreg_id = kpr.kindparreg_id
 where pd.paydebt_id = ipobj_id --? --6493
 ;
 
 RETURN (vxmldata);
--EXCEPTION
--WHEN exception_name THEN
--  statements;
END;
$function$
; DROP FUNCTION soi.xmlrelsubjobj(bigint, bigint); 
CREATE OR REPLACE FUNCTION soi.xmlrelsubjobj(ipobject_id bigint, ipmastobj_id bigint)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  vxmldata xml;
  vkto_id bigint;
BEGIN

 select tob.kindtaxobject::bigint
 into vkto_id
 from taxobject tob
 where tob.taxobject_id = ipmastobj_id
 ;
 
 CASE
  WHEN vkto_id = 1 THEN
 ---- imot - 1
 select xmlelement(name "rel_subject_object",
			xmlforest(
		tob.municipality_id as mun_id, 
        tob.taxobject_id as obj_id, 
        ppr.taxsubject_id as sub_id, 
        cast(ppr.typedeclar as SMALLINT) as isowner, 
        null as part
        	) 
 		)
 into vxmldata
 from partproperty ppr
     join property pr on ppr.property_id = pr.property_id  
     join taxdoc td on pr.taxdoc_id = td.taxdoc_id
     join taxobject tob on td.taxobject_id = tob.taxobject_id
 where ppr.partproperty_id = ipobject_id --? --20
;

  WHEN vkto_id = 2 THEN
---- mps - 2
 select xmlelement(name "rel_subject_object",
			xmlforest(
		tob.municipality_id as mun_id, 
        tob.taxobject_id as obj_id, 
        ptr.taxsubject_id as sub_id, 
        1 as isowner, 
        null as part
        	) 
 		)
 into vxmldata
 from parttransport ptr
     join transport tr on ptr.transport_id = tr.transport_id  
     join taxdoc td on tr.taxdoc_id = td.taxdoc_id
     join taxobject tob on td.taxobject_id = tob.taxobject_id
 where ptr.parttransport_id = ipobject_id --? --20
;

--  ELSE ;
END CASE;

 RETURN (vxmldata);
--EXCEPTION
--WHEN exception_name THEN
--  statements;
END;
$function$
; DROP FUNCTION soi.xmlsubject(bigint); 
CREATE OR REPLACE FUNCTION soi.xmlsubject(ipobj_id bigint)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  vxmldata xml;
  vsubjmun_id BIGINT;
BEGIN
 select c.municipality_id::BIGINT
   into vsubjmun_id
   from config c
  where c.name = 'SOI_MUN_ID';
 select xmlelement(name "subject",
			xmlforest(
					vsubjmun_id as "mun_id",
					ts.taxsubject_id as "sub_id",
					nvl(ts.name,'����������') as "name",
        			nvl(ts.idn,'����������') as "idn",
        			cast(nvl(ts.kind_idn,'-1') as SMALLINT) as "kind_idn",
        			cast(nvl(ts.isperson,-1.0) as SMALLINT) as "isperson"
        	) 
 		)
 into vxmldata
 from taxsubject ts
 where ts.taxsubject_id = ipobj_id --? --21 --35754
 ;
 RETURN (vxmldata);
--EXCEPTION
--WHEN exception_name THEN
--  statements;
END;
$function$
;
