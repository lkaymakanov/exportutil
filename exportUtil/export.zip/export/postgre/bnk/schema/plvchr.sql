DROP FUNCTION plvchr._is_kind(text, integer); 
CREATE OR REPLACE FUNCTION plvchr._is_kind(str text, kind integer)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvchr_is_kind_a$function$
; DROP FUNCTION plvchr._is_kind(integer, integer); 
CREATE OR REPLACE FUNCTION plvchr._is_kind(c integer, kind integer)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvchr_is_kind_i$function$
; DROP FUNCTION plvchr.char_name(text); 
CREATE OR REPLACE FUNCTION plvchr.char_name(c text)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvchr_char_name$function$
; DROP FUNCTION plvchr.first(text); 
CREATE OR REPLACE FUNCTION plvchr.first(str text)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvchr_first$function$
; DROP FUNCTION plvchr.is_blank(integer); 
CREATE OR REPLACE FUNCTION plvchr.is_blank(c integer)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 1);$function$
; DROP FUNCTION plvchr.is_blank(text); 
CREATE OR REPLACE FUNCTION plvchr.is_blank(c text)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 1);$function$
; DROP FUNCTION plvchr.is_digit(integer); 
CREATE OR REPLACE FUNCTION plvchr.is_digit(c integer)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 2);$function$
; DROP FUNCTION plvchr.is_digit(text); 
CREATE OR REPLACE FUNCTION plvchr.is_digit(c text)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 2);$function$
; DROP FUNCTION plvchr.is_letter(integer); 
CREATE OR REPLACE FUNCTION plvchr.is_letter(c integer)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 5);$function$
; DROP FUNCTION plvchr.is_letter(text); 
CREATE OR REPLACE FUNCTION plvchr.is_letter(c text)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 5);$function$
; DROP FUNCTION plvchr.is_other(integer); 
CREATE OR REPLACE FUNCTION plvchr.is_other(c integer)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 4);$function$
; DROP FUNCTION plvchr.is_other(text); 
CREATE OR REPLACE FUNCTION plvchr.is_other(c text)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 4);$function$
; DROP FUNCTION plvchr.is_quote(integer); 
CREATE OR REPLACE FUNCTION plvchr.is_quote(c integer)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 3);$function$
; DROP FUNCTION plvchr.is_quote(text); 
CREATE OR REPLACE FUNCTION plvchr.is_quote(c text)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvchr._is_kind($1, 3);$function$
; DROP FUNCTION plvchr.last(text); 
CREATE OR REPLACE FUNCTION plvchr.last(str text)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvchr_last$function$
; DROP FUNCTION plvchr.nth(text, integer); 
CREATE OR REPLACE FUNCTION plvchr.nth(str text, n integer)
 RETURNS text
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvchr_nth$function$
; DROP FUNCTION plvchr.quoted1(text); 
CREATE OR REPLACE FUNCTION plvchr.quoted1(str text)
 RETURNS character varying
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$SELECT ''''||$1||'''';$function$
; DROP FUNCTION plvchr.quoted2(text); 
CREATE OR REPLACE FUNCTION plvchr.quoted2(str text)
 RETURNS character varying
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$SELECT '"'||$1||'"';$function$
; DROP FUNCTION plvchr.stripped(text, text); 
CREATE OR REPLACE FUNCTION plvchr.stripped(str text, char_in text)
 RETURNS character varying
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT TRANSLATE($1, 'A'||$2, 'A'); $function$
;
