DROP FUNCTION taxvaluation.taxvalland(numeric, date); 
CREATE OR REPLACE FUNCTION taxvaluation.taxvalland(OUT return_val character varying, ipland_id numeric, ipyear date, OUT vgroupe numeric, OUT opmess character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  RowLand     Land%rowtype;
  RowProperty Property%rowtype;
  vPct        numeric;
  vBS0        numeric;
  vBS         numeric;
  vKM         numeric;
  vKI         numeric;
  vKU         numeric;
  vKZ         numeric;
  vDP         numeric;
  vgr         varchar(10);
  vekatte     varchar(10);
  vki1        numeric;
  vki2        numeric;
  vki3        numeric;
  vcitycat    integer;
  --   vGroupe numeric;
  vkzone numeric [ ];
begin
  --  vGroupe := 999;
  select *
  into   RowLand
  from   land l
  where  l.land_id = ipLand_id;
  select *
  into   RowProperty
  from   property p
  where  p.property_id = rowLand.property_id;
  select min(c.ekatte)
  into   vekatte
  from   address a, city c
  where  a.address_id = RowProperty.Property_address_id
  and    c.city_id = a.city_id;
  select min(c.citycat)::integer, min(c.citygroup)
  into   vcitycat, vgr
  from   CITYCAT_NORMKM3 c
  where  c.ekatte = vekatte
  and    c.begindate = (select max(cc.begindate)
                        from   CITYCAT_NORMKM3 cc
                        where  cc.ekatte = vekatte
                        and    cc.begindate <= ipYear);
  if vcitycat is null
  then
    vcitycat := rowproperty.category_city::integer;
    if rowproperty.category_city = 0
    then
      vgr := vekatte;
    elsif rowproperty.category_city > 1
    then
      vgr := '0';
    elsif rowproperty.category_city = 1
    then
      vgr := '2';
    end if;
  end if;
  -----  BS
  vPct := 1;
  if (nvl(RowProperty.Constructionbound, '0') <> '2') or
     (nvl(RowProperty.Builder_Zone, 0.0) <> 0) or
     (nvl(RowProperty.Seezone_Cat, 0.0) <> 0)
  then
    if RowLand.Builtuparea = 0 --and rowproperty.kadastrno is not null
    then
      vPct := vPct * 1.25;
    end if;
    if RowProperty.City_Category1 = 1
    then
      vPct := vPct * 1.10;
    end if;
    if RowProperty.City_Category2 = 1
    then
      vPct := vPct * 1.05;
    end if;
  end if;
  if (RowProperty.Isseezone = 1) or (RowProperty.Isnationalresort = 1)
  then
    --   if RowProperty.Category_City > 2 then
    if vekatte not in ('10135', '07079') and vcitycat <> 1
    then
      vPct := vPct * 1.50;
    end if;
  end if;
  if RowProperty.Islocalresort = 1 and vcitycat <> 1
  then
    vPct := vPct * 1.20;
  end if;
  --  end if;
  select min(nbs.apartmentvalue)
  into   vBS0
  from   normbs nbs
  where  nbs.normyear = (select max(n.normyear)
                         from   normbs n
                         where  n.normyear <= ipYear)
  and    nbs.kindconstruction = '0';

  vBS := (vBS0 * vPct);
  ---------  KM

  select array [ n.kzone1, n.kzone2, n.kzone3, n.kzone4, n.kzone5, n.inbound,
         n.outbound, n.villazone1, n.villazone2 ]
  into   vkzone
  from   normkm3 n
  where  n.normyear = (select max(nn.normyear)
                       from   normkm3 nn
                       where  nn.normyear <= ipYear)
  and    cast(n.category_city as varchar(30)) = cast(vcitycat  as varchar(30))
  and    n.groupe = vgr;
  vKM := 1;
  if nvl(RowProperty.Builder_Zone, 0.0) > 0
  then
    vKM := vkzone [ nvl(RowProperty.Builder_Zone, 0.0) ];
  else
    if nvl(RowProperty.Seezone_Cat, 0.0) > 0
    then
      vKM := vkzone [ to_number(nvl(to_char(RowProperty.Seezone_Cat), '0')) + 7 ];
    end if;
  end if;
  if ((nvl(RowProperty.Builder_Zone, 0.0) = 0) and
     ((nvl(RowProperty.Seezone_Cat, 0.0)) = 0))
  then
    vKM := vkzone [ to_number(nvl(RowProperty.Constructionbound, '0')) + 5 ];
  end if;
  ------- KI
  vKI := 1;
  if nvl(RowProperty.Iswater, 0.0) > 0
  then
    select k.havevalue, k.haventvalue, k.haveregionvalue
    into   vki1, vki2, vki3
    from   Normki k
    where  k.normyear = (select max(n.normyear)
                         from   Normki n
                         where  n.normyear <= ipYear)
    and    k.kindelement = 1;
    if RowProperty.Iswater = 1
    then
      vKI := vKI + vki1;
    end if;
    if RowProperty.Iswater = 2
    then
      vKI := vKI + vki3;
    end if;
    if RowProperty.Iswater = 3
    then
      vKI := vKI + vki2;
    end if;
  end if;
  if nvl(RowProperty.Issewer, 0.0) > 0
  then
    select k.havevalue, k.haventvalue, k.haveregionvalue
    into   vki1, vki2, vki3
    from   Normki k
    where  k.normyear = (select max(n.normyear)
                         from   Normki n
                         where  n.normyear <= ipYear)
    and    k.kindelement = 2;
    if RowProperty.Issewer = 1
    then
      vKI := vKI + vki1;
    end if;
    if RowProperty.Issewer = 2
    then
      vKI := vKI + vki3;
    end if;
    if RowProperty.Issewer = 3
    then
      vKI := vKI + vki2;
    end if;
  end if;
  if nvl(RowProperty.Iselectro, 0.0) > 0
  then
    select k.havevalue, k.haventvalue, k.haveregionvalue
    into   vki1, vki2, vki3
    from   Normki k
    where  k.normyear = (select max(n.normyear)
                         from   Normki n
                         where  n.normyear <= ipYear)
    and    k.kindelement = 3;
    if RowProperty.Iselectro = 1
    then
      vKI := vKI + vki1;
    end if;
    if RowProperty.Iselectro = 2
    then
      vKI := vKI + vki3;
    end if;
    if RowProperty.Iselectro = 3
    then
      vKI := vKI + vki2;
    end if;
  end if;
  --if nvl(RowProperty.Isroad,0) > 0 then
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 6;
  if nvl(RowProperty.Isroad, 0.0) = 0
  then
    vKI := vKI + vki2;
  end if;
  if RowProperty.Isroad = 1
  then
    vKI := vKI + vki1;
  end if;
  --  if  RowProperty.Isroad = 3 then  vKI := vKI + vki3; end if;
  --end if;
  vKI := round(vKI, 2);
  --------- KU
  vKU := 1;
  if RowProperty.Structurezone = '1'
  then
    vKU := 1.1;
  end if; -- KONSTANTI ????
   if (nvl(Rowproperty.Constructionbound,'2') = '1') and (to_number(to_char(ipYear,'yyyy')) > 2011) then
    if RowProperty.Structurezone = '3'
    then
      vKU := 0.9;
    end if;
    if RowProperty.Structurezone = '7'
    then
      vKU := 0.8;
    end if;
   elsif (to_number(to_char(ipYear,'yyyy')) < 2012) then
     if RowProperty.Structurezone = '3'
    then
      vKU := 0.9;
    end if;
    if RowProperty.Structurezone = '5'
    then
      vKU := 0.8;
    end if;

   end if;

  --------- KZ
  vKZ := 1;
  if nvl(RowLand.Landarea, 0.0) <> 0
  then
    if RowLand.Builtuparea / RowLand.Landarea <= 0.40
    then
      vKZ := 1;
    else
      if RowLand.Builtuparea / RowLand.Landarea >= 1
      then
        vKZ := 0.1;
      else
        vKZ := 2 -
               (1.01 * ((RowLand.Builtuparea / RowLand.Landarea) * 100 - 35));
      end if;
    end if;
  end if;
  vKZ := round(vKZ, 2);
  ---------  D
  vDP := 0;
  if RowLand.Isfence = 1
  then
    vDP := vDP +
           (nvl(RowLand.Fenceheight, 0.0) * nvl(RowLand.Fencelength, 0.0) * 8);
  end if;
  if RowLand.Iscovering = 1
  then
    vDP := vDP + (nvl(RowLand.Coveringarea, 0.0) * 35);
  end if;
  if RowLand.Issportcovering = 1
  then
    vDP := vDP + (nvl(RowLand.Sportarea, 0.0) * 15);
  end if;
  if RowLand.Ispool = 1
  then
    vDP := vDP + (nvl(RowLand.Poolcapacity, 0.0) * 23);
  end if;
  if RowLand.Isgreenparking = 1
  then
    vDP := vDP + (nvl(RowLand.Greenparking, 0.0) * 8);
  end if;
  if RowLand.Isparking = 1
  then
    vDP := vDP + (nvl(RowLand.Parkingarea, 0.0) * 15);
  end if;
  ---------
  vGroupe := vBS * vKM * vKI * vKU * vKZ * nvl(RowLand.Landarea, 0.0) + vDP;
  vGroupe := round(vGroupe, 1);
   opmess  := 'BS=' || to_char(vBS,'990.999') || ' * KM=' || to_char(vKM,'990.999') || ' * KI=' ||
               to_char(vKI,'990.999') || ' * KU=' || to_char(vKU,'990.999') ||
               ' * KZ=' || to_char(vKZ,'990.999') || ' * PL=' || to_char(nvl(RowLand.Landarea, 0.0),'99990.9999') ||
               ' + DP=' || to_char(vDP,'990.999');
  return_val := 'OK';
  return;
end;
$function$
; DROP FUNCTION taxvaluation.arxdoc(numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.arxdoc(iptaxdoc_id numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
declare
    rowdoc   taxdoc%rowtype;
    vdoccode varchar(20);
    -- vreasoncode varchar(20);
    vtaxdocarx_id numeric;
  begin
    select *
    into   rowdoc
    from   taxdoc td
    where  td.taxdoc_id = iptaxdoc_id;
    select dt.doccode
    into   vdoccode
    from   documenttype dt
    where  dt.documenttype_id = rowdoc.documenttype_id;
    select nextval('s_taxdocarx')
    into   vtaxdocarx_id;
  
    update debtsubject ds
    set    taxdocarx_id = vtaxdocarx_id
    where  ds.document_id = iptaxdoc_id
    and    nvl(ds.docno, '*') = nvl(rowdoc.docno, '*')
    and    nvl(cast(ds.doc_date as date), trunc(current_date)) =
           nvl(cast(rowdoc.doc_date as date), trunc(current_date))
    and    ds.taxdocarx_id is null;
  
    if (vdoccode = '14')
    then
      insert into taxdocarx 
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate, docdata, taxobject_id, location_doc, taxobjno, documenttype_id,
         taxdocdate, docextno, doc_date, docext_date, earn_date, act_id,
         emp_taxsubject_id, empno, emp_certify, give_reasonreg_id, relief_id,
         user_id, docwork_finaldate, receiver_date, receiver_note, docinput_date,
         note, company_id, docstatus, close__reasonreg_id, close_date,
         close_taxdoc_id, isinheritance, to_user_id, user_date, user_name,
         begintaxdate, closenote, endtaxdate, isinvalid, receiver_user_id,
         receiver_user_name, last_message_id, change_date, telephone,
         ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         xmlstructure.xmltaxdoc14(iptaxdoc_id), rowdoc.taxobject_id,
         rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
         rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date, rowdoc.docext_date,
         rowdoc.earn_date, rowdoc.act_id, rowdoc.emp_taxsubject_id, rowdoc.empno,
         rowdoc.emp_certify, rowdoc.give_reasonreg_id, rowdoc.relief_id,
         rowdoc.user_id, rowdoc.docwork_finaldate, rowdoc.receiver_date,
         rowdoc.receiver_note, rowdoc.docinput_date, rowdoc.note,
         rowdoc.company_id, rowdoc.docstatus, rowdoc.close__reasonreg_id,
         rowdoc.close_date, rowdoc.close_taxdoc_id, rowdoc.isinheritance,
         rowdoc.to_user_id, rowdoc.user_date, rowdoc.user_name,
         rowdoc.begintaxdate, rowdoc.closenote, rowdoc.endtaxdate,
         rowdoc.isinvalid, rowdoc.receiver_user_id, rowdoc.receiver_user_name,
         rowdoc.last_message_id, rowdoc.change_date, rowdoc.telephone,
         rowdoc.ettaxsubject_id, rowdoc.kinddecl);
      ----commit;
    end if;
    if (vdoccode = '17')
    then
      -- and (vreasoncode <> 'df1') then
      insert into taxdocarx 
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate, docdata, taxobject_id, location_doc, taxobjno, documenttype_id,
         taxdocdate, docextno, doc_date, docext_date, earn_date, act_id,
         emp_taxsubject_id, empno, emp_certify, give_reasonreg_id, relief_id,
         user_id, docwork_finaldate, receiver_date, receiver_note, docinput_date,
         note, company_id, docstatus, close__reasonreg_id, close_date,
         close_taxdoc_id, isinheritance, to_user_id, user_date, user_name,
         begintaxdate, closenote, endtaxdate, isinvalid, receiver_user_id,
         receiver_user_name, last_message_id, change_date, telephone,
         ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         xmlstructure.xmltaxdoc17(iptaxdoc_id), rowdoc.taxobject_id,
         rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
         rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date, rowdoc.docext_date,
         rowdoc.earn_date, rowdoc.act_id, rowdoc.emp_taxsubject_id, rowdoc.empno,
         rowdoc.emp_certify, rowdoc.give_reasonreg_id, rowdoc.relief_id,
         rowdoc.user_id, rowdoc.docwork_finaldate, rowdoc.receiver_date,
         rowdoc.receiver_note, rowdoc.docinput_date, rowdoc.note,
         rowdoc.company_id, rowdoc.docstatus, rowdoc.close__reasonreg_id,
         rowdoc.close_date, rowdoc.close_taxdoc_id, rowdoc.isinheritance,
         rowdoc.to_user_id, rowdoc.user_date, rowdoc.user_name,
         rowdoc.begintaxdate, rowdoc.closenote, rowdoc.endtaxdate,
         rowdoc.isinvalid, rowdoc.receiver_user_id, rowdoc.receiver_user_name,
         rowdoc.last_message_id, rowdoc.change_date, rowdoc.telephone,
         rowdoc.ettaxsubject_id, rowdoc.kinddecl);
    end if;
    if (vdoccode = '61')
    then
      -- and (vreasoncode <> 'df1') then
      insert into taxdocarx 
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate, docdata, taxobject_id, location_doc, taxobjno, documenttype_id,
         taxdocdate, docextno, doc_date, docext_date, earn_date, act_id,
         emp_taxsubject_id, empno, emp_certify, give_reasonreg_id, relief_id,
         user_id, docwork_finaldate, receiver_date, receiver_note, docinput_date,
         note, company_id, docstatus, close__reasonreg_id, close_date,
         close_taxdoc_id, isinheritance, to_user_id, user_date, user_name,
         begintaxdate, closenote, endtaxdate, isinvalid, receiver_user_id,
         receiver_user_name, last_message_id, change_date, telephone,
         ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         xmlstructure.xmltaxdoc61(iptaxdoc_id), rowdoc.taxobject_id,
         rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
         rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date, rowdoc.docext_date,
         rowdoc.earn_date, rowdoc.act_id, rowdoc.emp_taxsubject_id, rowdoc.empno,
         rowdoc.emp_certify, rowdoc.give_reasonreg_id, rowdoc.relief_id,
         rowdoc.user_id, rowdoc.docwork_finaldate, rowdoc.receiver_date,
         rowdoc.receiver_note, rowdoc.docinput_date, rowdoc.note,
         rowdoc.company_id, rowdoc.docstatus, rowdoc.close__reasonreg_id,
         rowdoc.close_date, rowdoc.close_taxdoc_id, rowdoc.isinheritance,
         rowdoc.to_user_id, rowdoc.user_date, rowdoc.user_name,
         rowdoc.begintaxdate, rowdoc.closenote, rowdoc.endtaxdate,
         rowdoc.isinvalid, rowdoc.receiver_user_id, rowdoc.receiver_user_name,
         rowdoc.last_message_id, rowdoc.change_date, rowdoc.telephone,
         rowdoc.ettaxsubject_id, rowdoc.kinddecl);
      ----commit;
    end if;
    if (vdoccode in ('54L', '54B', '54P', '54V'))
    then
      -- and (vreasoncode <> 'df1') then
      insert into taxdocarx 
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate, docdata, taxobject_id, location_doc, taxobjno, documenttype_id,
         taxdocdate, docextno, doc_date, docext_date, earn_date, act_id,
         emp_taxsubject_id, empno, emp_certify, give_reasonreg_id, relief_id,
         user_id, docwork_finaldate, receiver_date, receiver_note, docinput_date,
         note, company_id, docstatus, close__reasonreg_id, close_date,
         close_taxdoc_id, isinheritance, to_user_id, user_date, user_name,
         begintaxdate, closenote, endtaxdate, isinvalid, receiver_user_id,
         receiver_user_name, last_message_id, change_date, telephone,
         ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         xmlstructure.xmltaxdoc54(iptaxdoc_id), rowdoc.taxobject_id,
         rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
         rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date, rowdoc.docext_date,
         rowdoc.earn_date, rowdoc.act_id, rowdoc.emp_taxsubject_id, rowdoc.empno,
         rowdoc.emp_certify, rowdoc.give_reasonreg_id, rowdoc.relief_id,
         rowdoc.user_id, rowdoc.docwork_finaldate, rowdoc.receiver_date,
         rowdoc.receiver_note, rowdoc.docinput_date, rowdoc.note,
         rowdoc.company_id, rowdoc.docstatus, rowdoc.close__reasonreg_id,
         rowdoc.close_date, rowdoc.close_taxdoc_id, rowdoc.isinheritance,
         rowdoc.to_user_id, rowdoc.user_date, rowdoc.user_name,
         rowdoc.begintaxdate, rowdoc.closenote, rowdoc.endtaxdate,
         rowdoc.isinvalid, rowdoc.receiver_user_id, rowdoc.receiver_user_name,
         rowdoc.last_message_id, rowdoc.change_date, rowdoc.telephone,
         rowdoc.ettaxsubject_id, rowdoc.kinddecl);
      ----commit;
    end if;
    if (vdoccode = '71')
    then
      -- and (vreasoncode <> 'df1') then
      insert into taxdocarx 
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate,
         --docdata, 
         taxobject_id, location_doc, taxobjno, documenttype_id, taxdocdate,
         docextno, doc_date, docext_date, earn_date, act_id, emp_taxsubject_id,
         empno, emp_certify, give_reasonreg_id, relief_id, user_id,
         docwork_finaldate, receiver_date, receiver_note, docinput_date, note,
         company_id, docstatus, close__reasonreg_id, close_date, close_taxdoc_id,
         isinheritance, to_user_id, user_date, user_name, begintaxdate,
         closenote, endtaxdate, isinvalid, receiver_user_id, receiver_user_name,
         last_message_id, change_date, telephone, ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         -- xmlstructure.xmltaxdoc71(iptaxdoc_id),
         rowdoc.taxobject_id, rowdoc.location_doc, rowdoc.taxobjno,
         rowdoc.documenttype_id, rowdoc.taxdocdate, rowdoc.docextno,
         rowdoc.doc_date, rowdoc.docext_date, rowdoc.earn_date, rowdoc.act_id,
         rowdoc.emp_taxsubject_id, rowdoc.empno, rowdoc.emp_certify,
         rowdoc.give_reasonreg_id, rowdoc.relief_id, rowdoc.user_id,
         rowdoc.docwork_finaldate, rowdoc.receiver_date, rowdoc.receiver_note,
         rowdoc.docinput_date, rowdoc.note, rowdoc.company_id, rowdoc.docstatus,
         rowdoc.close__reasonreg_id, rowdoc.close_date, rowdoc.close_taxdoc_id,
         rowdoc.isinheritance, rowdoc.to_user_id, rowdoc.user_date,
         rowdoc.user_name, rowdoc.begintaxdate, rowdoc.closenote,
         rowdoc.endtaxdate, rowdoc.isinvalid, rowdoc.receiver_user_id,
         rowdoc.receiver_user_name, rowdoc.last_message_id, rowdoc.change_date,
         rowdoc.telephone, rowdoc.ettaxsubject_id, rowdoc.kinddecl);
      ----commit;
    end if;
  exception
    when others then
      ----rollback;
end;
$function$
; DROP FUNCTION taxvaluation.arxdoc(numeric, numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.arxdoc(iptaxdoc_id numeric, ipuser_id numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
    rowdoc   taxdoc%rowtype;
    vdoccode varchar(20);
    -- vreasoncode varchar(20);
    vtaxdocarx_id numeric;
  begin
    select *
    into   rowdoc
    from   taxdoc td
    where  td.taxdoc_id = iptaxdoc_id;
    select dt.doccode
    into   vdoccode
    from   documenttype dt
    where  dt.documenttype_id = rowdoc.documenttype_id;
    /*
    select min(rr.reason_code) into vreasoncode
    from reasonreg rr
    where rr.reasonreg_id = rowdoc.give_reasonreg_id
    ;
    */
    select nextval('s_taxdocarx')
    into   vtaxdocarx_id;
  
    update debtsubject ds
    set    taxdocarx_id = vtaxdocarx_id
    where  ds.document_id = iptaxdoc_id
    and    nvl(ds.docno, '*') = nvl(rowdoc.docno, '*')
    and    coalesce(ds.doc_date, trunc(current_date)) =
           coalesce(rowdoc.doc_date, trunc(current_date))
    and    ds.taxdocarx_id is null;
  
    if (vdoccode = '14')
    then
      insert into taxdocarx
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate, docdata, taxobject_id, location_doc, taxobjno, documenttype_id,
         taxdocdate, docextno, doc_date, docext_date, earn_date, act_id,
         emp_taxsubject_id, empno, emp_certify, give_reasonreg_id, relief_id,
         user_id, docwork_finaldate, receiver_date, receiver_note, docinput_date,
         note, company_id, docstatus, close__reasonreg_id, close_date,
         close_taxdoc_id, isinheritance, to_user_id, user_date, user_name,
         begintaxdate, closenote, endtaxdate, isinvalid, receiver_user_id,
         receiver_user_name, last_message_id, change_date, telephone,
         ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         xmlstructure.xmltaxdoc14(iptaxdoc_id), rowdoc.taxobject_id,
         rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
         rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date, rowdoc.docext_date,
         rowdoc.earn_date, rowdoc.act_id, rowdoc.emp_taxsubject_id, rowdoc.empno,
         rowdoc.emp_certify, rowdoc.give_reasonreg_id, rowdoc.relief_id,
         rowdoc.user_id, rowdoc.docwork_finaldate, rowdoc.receiver_date,
         rowdoc.receiver_note, rowdoc.docinput_date, rowdoc.note,
         rowdoc.company_id, rowdoc.docstatus, rowdoc.close__reasonreg_id,
         rowdoc.close_date, rowdoc.close_taxdoc_id, rowdoc.isinheritance,
         rowdoc.to_user_id, rowdoc.user_date, rowdoc.user_name,
         rowdoc.begintaxdate, rowdoc.closenote, rowdoc.endtaxdate,
         rowdoc.isinvalid, rowdoc.receiver_user_id, rowdoc.receiver_user_name,
         rowdoc.last_message_id, rowdoc.change_date, rowdoc.telephone,
         rowdoc.ettaxsubject_id, rowdoc.kinddecl);
      --commit;
    end if;
    if (vdoccode = '17')
    then
      -- and (vreasoncode <> 'df1') then
      insert into taxdocarx 
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate, docdata, taxobject_id, location_doc, taxobjno, documenttype_id,
         taxdocdate, docextno, doc_date, docext_date, earn_date, act_id,
         emp_taxsubject_id, empno, emp_certify, give_reasonreg_id, relief_id,
         user_id, docwork_finaldate, receiver_date, receiver_note, docinput_date,
         note, company_id, docstatus, close__reasonreg_id, close_date,
         close_taxdoc_id, isinheritance, to_user_id, user_date, user_name,
         begintaxdate, closenote, endtaxdate, isinvalid, receiver_user_id,
         receiver_user_name, last_message_id, change_date, telephone,
         ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         xmlstructure.xmltaxdoc17(iptaxdoc_id), rowdoc.taxobject_id,
         rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
         rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date, rowdoc.docext_date,
         rowdoc.earn_date, rowdoc.act_id, rowdoc.emp_taxsubject_id, rowdoc.empno,
         rowdoc.emp_certify, rowdoc.give_reasonreg_id, rowdoc.relief_id,
         rowdoc.user_id, rowdoc.docwork_finaldate, rowdoc.receiver_date,
         rowdoc.receiver_note, rowdoc.docinput_date, rowdoc.note,
         rowdoc.company_id, rowdoc.docstatus, rowdoc.close__reasonreg_id,
         rowdoc.close_date, rowdoc.close_taxdoc_id, rowdoc.isinheritance,
         rowdoc.to_user_id, rowdoc.user_date, rowdoc.user_name,
         rowdoc.begintaxdate, rowdoc.closenote, rowdoc.endtaxdate,
         rowdoc.isinvalid, rowdoc.receiver_user_id, rowdoc.receiver_user_name,
         rowdoc.last_message_id, rowdoc.change_date, rowdoc.telephone,
         rowdoc.ettaxsubject_id, rowdoc.kinddecl);
    end if;
    if (vdoccode = '61')
    then
      -- and (vreasoncode <> 'df1') then
      insert into taxdocarx 
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate, docdata, taxobject_id, location_doc, taxobjno, documenttype_id,
         taxdocdate, docextno, doc_date, docext_date, earn_date, act_id,
         emp_taxsubject_id, empno, emp_certify, give_reasonreg_id, relief_id,
         user_id, docwork_finaldate, receiver_date, receiver_note, docinput_date,
         note, company_id, docstatus, close__reasonreg_id, close_date,
         close_taxdoc_id, isinheritance, to_user_id, user_date, user_name,
         begintaxdate, closenote, endtaxdate, isinvalid, receiver_user_id,
         receiver_user_name, last_message_id, change_date, telephone,
         ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         xmlstructure.xmltaxdoc61(iptaxdoc_id), rowdoc.taxobject_id,
         rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
         rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date, rowdoc.docext_date,
         rowdoc.earn_date, rowdoc.act_id, rowdoc.emp_taxsubject_id, rowdoc.empno,
         rowdoc.emp_certify, rowdoc.give_reasonreg_id, rowdoc.relief_id,
         rowdoc.user_id, rowdoc.docwork_finaldate, rowdoc.receiver_date,
         rowdoc.receiver_note, rowdoc.docinput_date, rowdoc.note,
         rowdoc.company_id, rowdoc.docstatus, rowdoc.close__reasonreg_id,
         rowdoc.close_date, rowdoc.close_taxdoc_id, rowdoc.isinheritance,
         rowdoc.to_user_id, rowdoc.user_date, rowdoc.user_name,
         rowdoc.begintaxdate, rowdoc.closenote, rowdoc.endtaxdate,
         rowdoc.isinvalid, rowdoc.receiver_user_id, rowdoc.receiver_user_name,
         rowdoc.last_message_id, rowdoc.change_date, rowdoc.telephone,
         rowdoc.ettaxsubject_id, rowdoc.kinddecl);
      --commit;
    end if;
    if (vdoccode in ('54L', '54B', '54P', '54V'))
    then
      -- and (vreasoncode <> 'df1') then
      insert into taxdocarx 
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate, docdata, taxobject_id, location_doc, taxobjno, documenttype_id,
         taxdocdate, docextno, doc_date, docext_date, earn_date, act_id,
         emp_taxsubject_id, empno, emp_certify, give_reasonreg_id, relief_id,
         user_id, docwork_finaldate, receiver_date, receiver_note, docinput_date,
         note, company_id, docstatus, close__reasonreg_id, close_date,
         close_taxdoc_id, isinheritance, to_user_id, user_date, user_name,
         begintaxdate, closenote, endtaxdate, isinvalid, receiver_user_id,
         receiver_user_name, last_message_id, change_date, telephone,
         ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         xmlstructure.xmltaxdoc54(iptaxdoc_id), rowdoc.taxobject_id,
         rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
         rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date, rowdoc.docext_date,
         rowdoc.earn_date, rowdoc.act_id, rowdoc.emp_taxsubject_id, rowdoc.empno,
         rowdoc.emp_certify, rowdoc.give_reasonreg_id, rowdoc.relief_id,
         rowdoc.user_id, rowdoc.docwork_finaldate, rowdoc.receiver_date,
         rowdoc.receiver_note, rowdoc.docinput_date, rowdoc.note,
         rowdoc.company_id, rowdoc.docstatus, rowdoc.close__reasonreg_id,
         rowdoc.close_date, rowdoc.close_taxdoc_id, rowdoc.isinheritance,
         rowdoc.to_user_id, rowdoc.user_date, rowdoc.user_name,
         rowdoc.begintaxdate, rowdoc.closenote, rowdoc.endtaxdate,
         rowdoc.isinvalid, rowdoc.receiver_user_id, rowdoc.receiver_user_name,
         rowdoc.last_message_id, rowdoc.change_date, rowdoc.telephone,
         rowdoc.ettaxsubject_id, rowdoc.kinddecl);
      --commit;
    end if;
    if (vdoccode = '71')
    then
      -- and (vreasoncode <> 'df1') then
      insert into taxdocarx 
        (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
         arxdate,
         --docdata, 
         taxobject_id, location_doc, taxobjno, documenttype_id, taxdocdate,
         docextno, doc_date, docext_date, earn_date, act_id, emp_taxsubject_id,
         empno, emp_certify, give_reasonreg_id, relief_id, user_id,
         docwork_finaldate, receiver_date, receiver_note, docinput_date, note,
         company_id, docstatus, close__reasonreg_id, close_date, close_taxdoc_id,
         isinheritance, to_user_id, user_date, user_name, begintaxdate,
         closenote, endtaxdate, isinvalid, receiver_user_id, receiver_user_name,
         last_message_id, change_date, telephone, ettaxsubject_id, kinddecl)
      values
        (vtaxdocarx_id, rowdoc.taxdoc_id, rowdoc.taxsubject_id,
         rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
         -- xmlstructure.xmltaxdoc71(iptaxdoc_id),
         rowdoc.taxobject_id, rowdoc.location_doc, rowdoc.taxobjno,
         rowdoc.documenttype_id, rowdoc.taxdocdate, rowdoc.docextno,
         rowdoc.doc_date, rowdoc.docext_date, rowdoc.earn_date, rowdoc.act_id,
         rowdoc.emp_taxsubject_id, rowdoc.empno, rowdoc.emp_certify,
         rowdoc.give_reasonreg_id, rowdoc.relief_id, rowdoc.user_id,
         rowdoc.docwork_finaldate, rowdoc.receiver_date, rowdoc.receiver_note,
         rowdoc.docinput_date, rowdoc.note, rowdoc.company_id, rowdoc.docstatus,
         rowdoc.close__reasonreg_id, rowdoc.close_date, rowdoc.close_taxdoc_id,
         rowdoc.isinheritance, rowdoc.to_user_id, rowdoc.user_date,
         rowdoc.user_name, rowdoc.begintaxdate, rowdoc.closenote,
         rowdoc.endtaxdate, rowdoc.isinvalid, rowdoc.receiver_user_id,
         rowdoc.receiver_user_name, rowdoc.last_message_id, rowdoc.change_date,
         rowdoc.telephone, rowdoc.ettaxsubject_id, rowdoc.kinddecl);
      --commit;
    end if;
  exception
    when others then
      --  dbms_output.put_line(SQLErrM);
      --rollback;
end;
$function$
; DROP FUNCTION taxvaluation.closetaxdoc(numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.closetaxdoc(iptaxdoc_id numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
    crds cursor (ipdoc_id numeric, ipcldate date) is
      select *
      from   debtsubject ds
      where  ds.document_id = ipdoc_id
      and    ds.tax_begidate >= ipcldate
      and    ds.parent_debtsubject_id is null;
    rds record;
  
    crdss cursor (iptaxdoc_Id numeric,
                 ipdate      date,
                 ipdocno     varchar,
                 ipdocdate   date,
                 vcurtime    date) is
      select ds.debtsubject_id, ds.taxsubject_id, ds.totalval, ds.totaltax,
             ds.tax_begidate, ds.tax_enddate, ds.document_id, ds.kinddebtreg_id
      from   debtsubject ds
      where  ds.document_id = iptaxdoc_Id
      and    ds.kinddoc = 1
      and    ipdate between ds.tax_begidate and ds.tax_enddate
      and    ds.userdate =
             (select min(dd.userdate)
               from   debtsubject dd
               where  dd.document_id = iptaxdoc_Id
               and    dd.taxsubject_id = ds.taxsubject_id
               and    dd.kinddebtreg_id = ds.kinddebtreg_id
               and    dd.taxperiod_id = ds.taxperiod_id
               and    ipdate between dd.tax_begidate and dd.tax_enddate
               and    dd.userdate < vcurtime);
    rdss record;
  
    rowdoc           taxdoc%rowtype;
    vdoccode         varchar(20);
    vreasonregtxt    varchar(200);
    vbegintaxdate    date;
    vreasoncode      varchar(20);
    vds_id           numeric;
    vtotaltax        numeric;
    vtotalval        numeric;
    vtbotax          numeric;
    vendtaxdate      date;
    doc_date_new     date;
    docno_new        varchar(50);
    vreasontxt       varchar(150);
    vdebtsubject_New numeric;
    vtaxbefore       numeric;
    vfrees           numeric;
    vfreeo           numeric;
    vcorrYear        numeric;
    vtaxper_id       numeric;
    vtotaltax_Old    numeric;
    flnewds          integer;
    fl1              integer;
    vcurtime         timestamp;
    vcorrtype        numeric;
    vbegobl          varchar(20);

    fprec record;
 
  begin
    opStat   := 'OK';
    vcurtime := current_timestamp - interval '1.2 minute';
    select *
    into   rowdoc
    from   taxdoc td
    where  td.taxdoc_id = iptaxdoc_id;
    if rowdoc.close_taxdoc_id = 1
    then
      vcorrtype := 1;
    else
      vcorrtype := 3;
    end if;
    select dt.doccode
    into   vdoccode
    from   documenttype dt
    where  dt.documenttype_id = rowdoc.documenttype_id;
    select min(rr.reason_code), min(rr.reason_text)
    into   vreasoncode, vreasonregtxt
    from   reasonreg rr
    where  rr.reasonreg_id = rowdoc.give_reasonreg_id;
    if rowdoc.close_date is null
    then
      return;
    end if;
    rowdoc.close_date := nvl(rowdoc.endtaxdate, rowdoc.close_date);
    fl1               := 0;
    open crds(rowdoc.taxdoc_id, rowdoc.close_date);
    loop
      fetch crds
        into rds;
      exit when not found;
      /*select public.correction(rds.Debtsubject_Id, 0.0, 0.0, 0.0, 0.0,
                                rds.tax_begidate, rds.tax_enddate, rowdoc.user_Id,
                                rowdoc.doc_date, rowdoc.docno, trunc(rowdoc.user_date), null,
                                vreasonregtxt, null, null, trunc(current_date), null,               
                                null, null, null, null, vcorrtype::character varying);*/
      opStat := public.correction(rds.Debtsubject_Id, 0.0, 0.0, 0.0, 0.0,
                                cast(rds.tax_begidate as date), cast(rds.tax_enddate as date), rowdoc.user_Id,
                                cast(rowdoc.doc_date as date), rowdoc.docno, trunc(rowdoc.user_date), null,
                                vreasonregtxt, null, null, trunc(current_date), null,               
                                null, null, null, null, vcorrtype::character varying);
      fl1 := 1;
    end loop;
    close crds;
    if fl1 = 1
    then
      if opStat <> 'OK'
      then
        ----rollback;
      end if;
      --   return;
    end if;
    vcorrYear := to_number(to_char(rowdoc.close_date, 'yyyy'));
    select max(tp.taxperiod_id)
    into   vtaxper_id
    from   taxperiod tp
    where  tp.taxperkind = '0'
    and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
  
    select max(ds.debtsubject_id)
    into   vds_id
    from   debtsubject ds
    where  ds.document_id = iptaxdoc_Id
    and    rowdoc.close_date between ds.tax_begidate and ds.tax_enddate
    and    ds.userdate =
           (select max(dd.userdate)
             from   debtsubject dd
             where  dd.document_id = iptaxdoc_Id
             and    dd.taxsubject_id = ds.taxsubject_id
             and    dd.kinddebtreg_id = ds.kinddebtreg_id
             and    dd.taxperiod_id = ds.taxperiod_id
             and    rowdoc.close_date between dd.tax_begidate and dd.tax_enddate
             and    dd.userdate < vcurtime)
    and    exists (select *
            from   debtpartproperty pp
            where  pp.debtsubject_id = ds.debtsubject_id);
     select c.configvalue into vbegobl
     from config c
     where c.name = 'BEGINOBL1' 
     and c.municipality_id = rowdoc.municipality_id
     ;       
    if (vds_id is null) or (to_char(rowdoc.close_date,'yyyy') <= vbegobl)
--    if vds_id is null
    then
      update taxdoc td
      set    docstatus = '90'
      where  td.taxdoc_id = iptaxdoc_id;
      ----commit;
      perform taxvaluation.arxdoc(iptaxdoc_id);
      return;
    end if;
    vbegintaxdate := to_date('01.' ||
                             to_char(add_months(rowdoc.close_date, 1), 'mm.yyyy'),
                             'dd.mm.yyyy');
    vendtaxdate   := to_date('31.12.' || to_char(rowdoc.close_date, 'yyyy'),
                             'dd.mm.yyyy');
    flnewds       := 1;

    if (vdoccode in ('54L', '54B', '54P', '54V'))
    then
    
      ----- nov danak !!!
      if vbegintaxdate < vendtaxdate
      then
        /*select taxtransport(iptaxdoc_Id, vbegintaxdate, vendtaxdate, rowdoc.user_id, opstat, 2); */
        opStat := taxvaluation.taxtransport(iptaxdoc_Id, vbegintaxdate, vendtaxdate, rowdoc.user_id, 2.0);
        if (opStat <> 'OK') and (opStat <> 'errNoDuty')
        then
          raise exception '%',opStat;
          --rollback;
          return;
        end if;
      else
        flnewds := 0;
      end if;
    end if;
  
    if (vdoccode = '17')
    then
    
      ----- nov danak !!!
      if vbegintaxdate < vendtaxdate
      then
        /*select firmproperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, rowdoc.user_id, 1,
                     opstat, 2, vtotalval, vtotaltax, vtbotax); */
        select into fprec *  from taxvaluation.firmproperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, rowdoc.user_id, 1,2);
        opstat := fprec.ipstatus;
        vtotalval := fprec.optotalval;
        vtotaltax:= fprec.optotaltax;
        vtbotax:= fprec.optbototaltax;
        if opStat <> 'OK'
        then
          rollback;
          return;
        end if;
      else
        flnewds := 0;
      end if;
    end if;

    if (vdoccode = '14')
    then
    
      ----- nov danak !!!
      if vbegintaxdate < vendtaxdate
      then
        /*select taxproperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, rowdoc.user_id, 2, opstat);
        taxvaluation.taxproperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, rowdoc.user_id, 2); */
         if rowdoc.decl14to17 = 2 then
           opStat := Firmprop14(iptaxdoc_Id, vbegintaxdate,
                         vendtaxdate, rowdoc.user_id, 1, opstat,2);
	else
	   opStat := taxproperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, rowdoc.user_id, 2,
                    opstat);
        end if;
        if opStat <> 'OK'
        then
          rollback;
          return;
        end if;
      else
        flnewds := 0;
      end if;
    end if;

    ----- po sobstvenici
    if (vds_id is not null) and (flnewds = 1)
    then
      open crdss(iptaxdoc_Id, vbegintaxdate, docno_new, doc_date_new, vcurtime);
      loop
        fetch crdss
          into rdss;
        exit when not found;
        select max(d.debtsubject_id), sum(d.totalval), sum(d.totaltax),
               sum(d.freesum_subj), sum(d.freesum_obj), max(td.docno),
               max(td.doc_date)
        into   vdebtsubject_New, vTotalval, vtotaltax, vfrees, vfreeo, docno_new,
               doc_date_new
        from   debtsubject d, taxdoc td
        where  d.document_id = td.taxdoc_id
        and    td.taxdoc_id = iptaxdoc_Id
        and    nvl(td.docno, '*') = nvl(d.docno, '*')
        and    nvl(td.doc_date, trunc(current_date)) =
               nvl(d.doc_date, trunc(current_date))
        and    d.taxsubject_id = rdss.taxsubject_id
        and    d.kinddebtreg_id = rdss.kinddebtreg_id
        and    d.tax_begidate =
               to_date(to_char(add_months(rowdoc.close_date, 1), 'mm.yyyy'),
                        'mm.yyyy') --- ???
        and    d.userdate > vcurtime;
        --       vtaxbefore := nvl(rdss.taxbefore,0) + round(rdss.totaltax * newper / oldper,2);
        select sum(nvl(ds.totaltax, 0.0))
        into   vtotaltax_Old
        from   debtsubject ds
        where  ds.debtsubject_id in
               (select dsb.debtsubject_id
                from   debtsubject dsb
                where  dsb.debtsubject_id = rdss.debtsubject_id
                or     dsb.parent_debtsubject_id = rdss.debtsubject_id) --ipdebtsubject_Id
        ;
        ------------------------------------------------
        vtotaltax := vtotaltax_Old - nvl(vtotaltax, 0.0);
        if vtotaltax < 0
        then
          vtotaltax := 0;
        end if;
        /*select correction(rdss.debtsubject_id, vTotalval, vtotaltax, vfrees, vfreeo,
                   vbegintaxdate, vendtaxdate, rowdoc.user_id, doc_date_new,
                   docno_new, rowdoc.close_date, null, vreasontxt, null, null,
                   trunc(current_date),
                   --iptermpay_date,
                   vdebtsubject_New, trunc(current_date), null, null, null, vcorrtype,
                   opStat); */
        opStat := public.correction(rdss.debtsubject_id, vTotalval, vtotaltax, vfrees, vfreeo,
                   vbegintaxdate, vendtaxdate, rowdoc.user_id, doc_date_new,
                   docno_new, cast(rowdoc.close_date as date), null, vreasontxt, null, null,
                   trunc(current_date),
                   --iptermpay_date,
                   vdebtsubject_New, trunc(current_date), null, null, null, vcorrtype::character varying);
        if opStat <> 'OK'
        then
          rollback;
          return;
        end if;
        if vdebtsubject_New is not null
        then
          update debtpartproperty pp
          set    taxbefore = nq.tax - nvl(pp.totaltax, 0.0),
                 totalval = 0, 
                 totaltax = 0, 
                 sumval = 0, 
                 sumtax = 0,
                 parentdebtprop_id = nq.debtpartproperty_id
          from  (select (nvl(po.totaltax, 0.0) + nvl(po.taxbefore, 0.0)) tax, po.debtpartproperty_id
                 from   debtpartproperty po, debtsubject do1
                 where  po.homeobj_id = pp.homeobj_id
                   and  do1.document_id = rdss.document_id
                   and  do1.debtsubject_id = po.debtsubject_id
                   and  do1.taxsubject_id = rdss.taxsubject_id
                   and  po.typedeclar = pp.typedeclar       
                   and  do1.tax_begidate = rdss.tax_begidate
                   and  do1.kinddebtreg_id = rdss.kinddebtreg_id
                   and  do1.tax_enddate = rdss.tax_enddate
                   and  do1.userdate =
                          (select max(dd.userdate)
                           from   debtsubject dd
                           where  dd.document_id = do1.document_id
                             and  dd.taxsubject_id = rdss.taxsubject_id
                             and  dd.tax_begidate = rdss.tax_begidate
                             and  dd.tax_enddate = rdss.tax_enddate)) nq
          where  pp.debtsubject_id = vdebtsubject_New;
          --    and pp.homeobj_id = rdss.homeobj_id;
        else
          insert into debtpartproperty
            (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
             seqnots, typedeclar, divident, divisor, part, sumval, sumtax,
             taxbegindate, taxenddate, totalval, totaltax, userdate, user_id,
             homeobj_id, taxbefore)
            select nextval('s_debtpartproperty'), d.debtsubject_id, vtaxper_id,
                   null, null, null, 0, 0, 0, 0, 0, d.tax_begidate,
                   d.tax_enddate, 0, 0, current_date, d.user_id, d.taxobject_id,
                   vtaxbefore
            from   debtsubject d, taxdoc td
            where  d.document_id = td.taxdoc_id
            and    td.taxdoc_id = iptaxdoc_Id
            and    td.docno = d.docno
            and    td.doc_date = d.doc_date
            and    d.taxsubject_id = rdss.taxsubject_id;
        end if;
      end loop;
      close crdss;
    end if;
    --   end if;
    update taxdoc td
    set    docstatus = '90'
    where  td.taxdoc_id = iptaxdoc_id;
    if (vdoccode = '17') then
      update taxdoc tdup
       set tdup.docstatus = '90'
      where tdup.taxdoc_id in 
      (select max(f.taxdoc_id_14)
        from taxdoc td, firm_1417 f
        where f.taxdoc_id_17 = iptaxdoc_id) 
      ;  
    end if;
    ----commit;
    perform taxvaluation.arxdoc(iptaxdoc_id);
    return;
end;
$function$
; DROP FUNCTION taxvaluation.counttbo(numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.counttbo(island numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
      swsum        numeric;
      cleansum     numeric;
      depotsum     numeric;
      vTBOFreeObj  numeric;
      vTBOFreeSubj numeric;
      vTBO         numeric;
      vTBOSubject  numeric;
      vSubject_id  numeric;
      vperson      numeric;
      rsubjgr      subjgrouptbo%rowtype;
      rtempprtbo   promtbo%rowtype;
      rgrouptbo            grouptbo%rowtype;
      rprtbo               promtbo%rowtype;
      vTBODebt_id          numeric;
      vdebtpartproperty_id numeric;      
      vsumtboy             numeric;
      vsumtboy_cont        numeric;
      i            integer;
      vsubjgarbtax_id      integer;
      vsubjsw_missing      integer;
      vsubjclean_missing   integer;
      vsubjdepot_missing   integer;
      vsubjtaxdoc71_id     integer;
      vdocst               varchar(20);
      recCross_Date record;
-------- ?????????? parametri ????????
      tobDate  date;
      toeDate  date;
      vDNIFreeSubj numeric;
  begin
      swsum        := 0;
      cleansum     := 0;
      depotsum     := 0;
      vTBOFreeObj  := 0;
      vTBOFreeSubj := 0;
      if isLand = 1
      then
        vSubject_id := rSubjLand.taxsubject_id;
      else
        vSubject_id := rSubject.Taxsubject_Id;
      end if;
      select min(ts.isperson)
      into   vperson
      from   taxsubject ts
      where  ts.taxsubject_id = vSubject_id;
      rtempprtbo := rprtbo;
        select count(sg.*)
        into   i
        from   subjgrouptbo sg
        where  sg.taxsubject_id = vSubject_id
        and    sg.taxdoc_id = iptaxdoc_id
        and    nvl(sg.enddate, vtdatebegin) >= vtdatebegin
        and    nvl(sg.begindate, vtdateend) =
               (select max(s.begindate)
                 from   subjgrouptbo s
                 where  s.taxsubject_id = vSubject_id
                 and    s.taxdoc_id = iptaxdoc_id
                 and    s.begindate <= vtdatebegin); 
     if i > 0 then
        select sg.*
        into   rsubjgr
        from   subjgrouptbo sg
        where  sg.taxsubject_id = vSubject_id
        and    sg.taxdoc_id = iptaxdoc_id
        and    nvl(sg.enddate, vtdatebegin) >= vtdatebegin
        and    nvl(sg.begindate, vtdateend) =
               (select max(s.begindate)
                 from   subjgrouptbo s
                 where  s.taxsubject_id = vSubject_id
                 and    s.taxdoc_id = iptaxdoc_id
                 and    s.begindate <= vtdatebegin);
        select t.*
        into   rgrouptbo
        from   grouptbo t
        where  t.grouptbo_id = rsubjgr.grouptbo_id;
      
        if ((rsubjgr.indhome1 = 0) and (rsubjgr.indtelk = 0)) or
           ((rsubjgr.indhome1 = 1) and (isLand <> 1) and
           (rsubject.isbasehome = 1) and (vsrok_bh > 182)) or
           ((rsubjgr.indtelk = 1) and (isLand <> 1) and indtelk = 1)
        then
          ----------------------
          if rgrouptbo.tbo_code <> 9
          then
            rprtbo.sw_home     := rprtbo.sw_home * nvl(rgrouptbo.isswh, 0);
            rprtbo.clean_home  := rprtbo.clean_home *
                                  nvl(rgrouptbo.iscleanh, 0);
            rprtbo.depot_home  := rprtbo.depot_home *
                                  nvl(rgrouptbo.isdepoth, 0);
            rprtbo.sw          := rprtbo.sw * nvl(rgrouptbo.issw, 0);
            rprtbo.clean       := rprtbo.clean * nvl(rgrouptbo.isclean, 0);
            rprtbo.depot       := rprtbo.depot * nvl(rgrouptbo.isdepot, 0);
            rprtbo.fsw_home    := rprtbo.fsw_home * nvl(rgrouptbo.isswh, 0);
            rprtbo.fclean_home := rprtbo.fclean_home *
                                  nvl(rgrouptbo.iscleanh, 0);
            rprtbo.fdepot_home := rprtbo.fdepot_home *
                                  nvl(rgrouptbo.isdepoth, 0);
            rprtbo.tbo_code    := rgrouptbo.tbo_code;
          else
            rprtbo.sw_home     := nvl(rgrouptbo.isswh, 0);
            rprtbo.clean_home  := nvl(rgrouptbo.iscleanh, 0);
            rprtbo.depot_home  := nvl(rgrouptbo.isdepoth, 0);
            rprtbo.sw          := nvl(rgrouptbo.issw, 0);
            rprtbo.clean       := nvl(rgrouptbo.isclean, 0);
            rprtbo.depot       := nvl(rgrouptbo.isdepot, 0);
            rprtbo.fsw_home    := nvl(rgrouptbo.isswh, 0);
            rprtbo.fclean_home := nvl(rgrouptbo.iscleanh, 0);
            rprtbo.fdepot_home := nvl(rgrouptbo.isdepoth, 0);
            rprtbo.tbo_code    := rgrouptbo.tbo_code;
          end if;
          ----------------------
        end if;
      end if;
--------------------------
--------------------------
     if  vsubjtaxdoc71_id is null then
   ------------  01.03.2012
      select max(gt.garbtax_id), decode(max(gt.sw_missing), 1.0, 0.0, 1.0),
             decode(max(gt.clean_missing), 1.0, 0.0, 1.0),
             decode(max(gt.depot_missing), 1.0, 0.0, 1.0), max(gt.taxdoc_id)
      into   vsubjgarbtax_id, vsubjsw_missing, vsubjclean_missing, vsubjdepot_missing,
             vsubjtaxdoc71_id
      from   garbtax gt, taxdoc td
      where  td.taxdoc_id = gt.taxdoc_id
      and    td.documenttype_id = (select t.documenttype_id
                                    from   documenttype t
                                    where  t.doccode = '71')
      and    gt.proptaxdoc_id = iptaxdoc_Id
      and    td.docstatus <> '70' and td.docstatus <> '90'
      and    gt.taxperiod_id = vtaxperiod_id
      and    gt.taxsubject_id = vSubject_id
      ;
      end if;
 --------------------------- 20.04.2012  edin obekt
      if  vsubjtaxdoc71_id is null then
      select max(gt.garbtax_id), decode(max(o.sw_missing), 1.0, 0.0, 1.0),
             decode(max(o.clean_missing), 1.0, 0.0, 1.0),
             decode(max(o.depot_missing), 1.0, 0.0, 1.0), max(gt.taxdoc_id)
      into   vsubjgarbtax_id, vsubjsw_missing, vsubjclean_missing, vsubjdepot_missing,
             vsubjtaxdoc71_id
      from   garbtax gt, taxdoc td, garbobject o
      where  td.taxdoc_id = gt.taxdoc_id
      and    td.documenttype_id = (select t.documenttype_id
                                    from   documenttype t
                                    where  t.doccode = '71')
      and    gt.proptaxdoc_id = iptaxdoc_Id
      and    td.docstatus <> '70' and td.docstatus <> '90'
      and    gt.taxperiod_id = vtaxperiod_id
      and    gt.isforobject = 1
      and o.garbtax_id = gt.garbtax_id 
      and ((isLand = 1 and o.land_id = rland.land_id) or 
           (island <> 1 and o.homeobj_id = rhomeobject.homeobj_id))    
      ;
      
      
---------------------------------------------
      end if;
      if  vsubjtaxdoc71_id is not null
      then
     if vsubjgarbtax_id is not null
       then
        rprtbo.sw_home     := rprtbo.sw_home * nvl(vsubjsw_missing, 0);
        rprtbo.clean_home  := rprtbo.clean_home * nvl(vsubjclean_missing, 0);
        rprtbo.depot_home  := rprtbo.depot_home * nvl(vsubjdepot_missing, 0);
        rprtbo.sw          := rprtbo.sw * nvl(vsubjsw_missing, 0);
        rprtbo.clean       := rprtbo.clean * nvl(vsubjclean_missing, 0);
        rprtbo.depot       := rprtbo.depot * nvl(vsubjdepot_missing, 0);
        rprtbo.fsw_home    := rprtbo.fsw_home * nvl(vsubjsw_missing, 0);
        rprtbo.fclean_home := rprtbo.fclean_home * nvl(vsubjclean_missing, 0);
        rprtbo.fdepot_home := rprtbo.fdepot_home * nvl(vsubjdepot_missing, 0);
       end if;
        select td.docstatus
        into   vdocst
        from   taxdoc td
        where  td.taxdoc_id = vsubjtaxdoc71_id;
        if vdocst = '10'
        then
          update taxdoc td
          set    td.docstatus = '30'
          where  td.taxdoc_id = vsubjtaxdoc71_id;
          perform taxvaluation.arxdoc(vtaxdoc71_id);
        end if;
      end if;

--------------------------
--------------------------
      if ((rhomeobject.kindhomeobjreg_id < 6) and (isLand <> 1))
      -- ??????????    and nvl(rhomeobject.isbusiness,0) <> 1 
      then
        if nvl(vperson, 1) = 1
        then
          swsum    := vDOTBOSubject * rprtbo.sw_home / 1000;
          cleansum := vDOTBOSubject * rprtbo.clean_home / 1000;
          depotsum := vDOTBOSubject * rprtbo.depot_home / 1000;
          vtbo     := rprtbo.sw_home + rprtbo.clean_home + rprtbo.depot_home;
        else
          swsum    := vDOTBOSubject * rprtbo.fsw_home / 1000;
          cleansum := vDOTBOSubject * rprtbo.fclean_home / 1000;
          depotsum := vDOTBOSubject * rprtbo.fdepot_home / 1000;
          vtbo     := rprtbo.fsw_home + rprtbo.fclean_home + rprtbo.fdepot_home;
        end if;
      else
        if (isLand = 1) -- and (rbuilding.structurezone <> '2')
           and
           ((flho = 1) or (rbuilding.structurezone in ('1', '2', '4', '6')))
        then
          if nvl(vperson, 1) = 1
          then
            swsum    := vDOTBOSubject * rprtbo.sw_home / 1000;
            cleansum := vDOTBOSubject * rprtbo.clean_home / 1000;
            depotsum := vDOTBOSubject * rprtbo.depot_home / 1000;
            vtbo     := rprtbo.sw_home + rprtbo.clean_home + rprtbo.depot_home;
          else
            swsum    := vDOTBOSubject * rprtbo.fsw_home / 1000;
            cleansum := vDOTBOSubject * rprtbo.fclean_home / 1000;
            depotsum := vDOTBOSubject * rprtbo.fdepot_home / 1000;
            vtbo     := rprtbo.fsw_home + rprtbo.fclean_home +
                        rprtbo.fdepot_home;
          end if;
        else
          if nvl(vperson, 1) = 1
          then
            swsum    := vDOTBOSubject * rprtbo.sw / 1000;
            cleansum := vDOTBOSubject * rprtbo.clean / 1000;
            depotsum := vDOTBOSubject * rprtbo.depot / 1000;
            vtbo     := rprtbo.sw + rprtbo.clean + rprtbo.depot;
          else
            swsum    := vDOTBOSubject * rprtbo.fsw_home / 1000;
            cleansum := vDOTBOSubject * rprtbo.fclean_home / 1000;
            depotsum := vDOTBOSubject * rprtbo.fdepot_home / 1000;
            vtbo     := rprtbo.fsw_home + rprtbo.fclean_home +
                        rprtbo.fdepot_home;
          end if;
        end if;
      end if;
      vtboSubject  := (vtbo * vDOTBOYear *
                      (round(months_between(vhedate, vhBdate))) / 12) / 1000;
      vtboSubject  := round(vtboSubject, 2);
      -----------  07.06.2012
         if telkbDate is not null and telkEdate is not null
                then
                  select into recCross_Date * from taxvaluation.cross_date(vhbDate, vheDate,last_day(telkbDate - interval '1 day') + interval '1 day',
                                  last_day(telkeDate), tobDate, toeDate);
                else  
                  tobDate := vhbDate;
                  toeDate := vheDate;
                end if;
        if indtelk = 1 then
                     vDNIFreeSubj := vDNIFreeSubj + round((vDNISubject *
                                                         (round(round(months_between(toeDate,
                                                                                      tobDate))) /
                                                         round(months_between(vheDate,
                                                                                vhbDate)))) / 2,
                                                         2);
      
      
      ----------- 07.06.2012

      vTBOFreeSubj := round(nvl(vTBOSubject, 0) * nvl(rprtbo.pctfree_telk, 0) *
                           (round(round(months_between(toeDate, tobDate))) /
                                 round(months_between(vheDate, vhbDate)))  
                            / 100, 2);
        end if;                    
     vtboSubject  := vtboSubject - nvl(vTBOFreeSubj, 0);
    --- 03.04.2012 --- za NE gilishta na firmi
     if (isLand <> 1) and (nvl(vperson,0) <> 1) and (rhomeobject.kindhomeobjreg_id > 5) and (rhomeobject.kindhomeobjreg_id <> 0) then
        vtboSubject := 0; vTBOFreeSubj := 0;
     end if;
    if (isLand = 1) and (nvl(vperson,0) <> 1) and 
      (flho <> 1) and (rbuilding.structurezone not in ('1', '2', '4', '6')) then
        vtboSubject := 0; vTBOFreeSubj := 0;
     end if;
      if vtbodebt_id is null
      then
        select nextval('s_debtsubject')
        into   vtbodebt_id;
        insert into debtsubject
          (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,
           taxperiod_id, doccode, tax_begidate, tax_enddate, relief_id, Totalval,
           Totaltax, calcdate, FreeSum_obj, prtdate, inst_numeric, FreeSum_Subj,
           corr_instnumeric, codetbo, corr_sumtotal, userdate, user_id,
           taxobject_id, partidano, municipality_id, kindparreg_id, paydiscsum,
           docno, doc_date, parent_debtsubject_id,admregion_id)
        values
          (vtbodebt_id, vSubject_id, iptaxdoc_Id, 1, 5, vtaxperiod_id, vdoccode,
           vTDateBegin, vTDateEnd, vrelief_id, round(vDOTBOSubject, 2),
           round(vtboSubject, 2), trunc(current_date), vTBOFreeObj, null,
           vinst_numeric, round(vTBOFreeSubj, 2), null, null, null, current_timestamp,
           ipuser_id, rdoc.taxobject_id, rdoc.partidano, rdoc.municipality_id,
           vparreg, null, rdoc.docno, rdoc.doc_date, null,vadmregion_id);
     else
        update debtsubject ds
        set    totalval = ds.totalval + round(vDOTBOSubject, 2),
               totaltax = ds.totaltax + round(vTBOSubject, 2),
               freesum_obj = ds.freesum_obj + round(vTBOFreeObj, 2),
               freesum_subj = ds.freesum_subj + round(vTBOFreeSubj, 2)
        where  ds.debtsubject_id = vtbodebt_id;
      end if;
      select nextval('s_debtpartproperty')
      into   vdebtpartproperty_id;
      if isLand = 0
      then
        insert into debtpartproperty
          (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
           seqnots, typedeclar, isbasehome, isrelief, relief_id, divident,
           divisor, part, sumval, sumtax, taxbegindate, taxenddate, totalval,
           totaltax, userdate, user_id, homeobj_id, freefrom, freemonths,
           codetbo, promiltbo, freesuma_obj, freesuma_subj, parentdebtprop_id,
           SUBJPARTVAL, fsw, fclean, fdepot)
        values
          (vdebtpartproperty_id, vtbodebt_id, vtaxperiod_id, 2,
           rSubject.Seqnots, rSubject.Typedeclar, rSubject.Isbasehome,
           decode(vrelief_id, null, 0.0, 1.0), vrelief_id, rSubject.Divident,
           rSubject.Divisor, rSubject.Part, vDOTBOYear,
           round(vTBO * vDOTBOYear / 1000, 2), vhBdate, vhedate,
           round(vDOTBOSubject, 2), round(vTBOSubject, 2), current_timestamp, ipuser_id,
           rhomeobject.homeobj_id, vTaxFreeFrom,
           (case when vTaxFreeFrom is null then 0 else
                   round(months_between(vTaxFreeTo, vTaxFreeFrom)) end),
           rprtbo.tbo_code, vtbo, vTBOFreeObj, vTBOFreeSubj, null, vDOPartSubj,
           swsum, cleansum, depotsum);
      else
        insert into debtpartproperty
          (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
           seqnots, typedeclar, isbasehome, isrelief, relief_id, divident,
           divisor, part, sumval, sumtax, taxbegindate, taxenddate, totalval,
           totaltax, userdate, user_id, homeobj_id, freefrom, freemonths,
           codetbo, promiltbo, freesuma_obj, freesuma_subj, parentdebtprop_id,
           SUBJPARTVAL, fsw, fclean, fdepot)
        values
          (vdebtpartproperty_id, vtbodebt_id, vtaxperiod_id, 1,
           rSubjLand.Seqnots, rSubjLand.Typedeclar, null,
           --rSubject.Isbasehome,
           decode(vrelief_id, null, 0.0, 1.0), vrelief_id, rSubjLand.Dividentland,
           rSubjLand.Divisorland, rSubjLand.Partland, vDOTBOYear,
           round(vTBO * vDOTBOYear / 1000, 2), vhBdate, vheDate,
           round(vDOTBOSubject, 2), round(vTBOSubject, 2), current_timestamp, ipuser_id,
           rLand.Land_Id, vTaxFreeFrom,
           (case when vTaxFreeFrom is null then 0 else
                   round(months_between(vTaxFreeTo, vTaxFreeFrom)) end),
           rprtbo.tbo_code, vtbo, vTBOFreeObj, vTBOFreeSubj, null,
           (case when rSubjLand.Typedeclar = '2' then 0 else
                   (case when rland.typedeclar = '2' then 0 else 
                           (case when rland.buildingowner = 1 then 0 else vDOPartSubj end) end) end),
           swsum, cleansum, depotsum);
      end if;
      vsumtboy := vsumtboy + round(vTBO * vDOTBOYear / 1000, 2);
      vsumtboy_cont := vsumtboy_cont + (vTBO * vDOTBOYear /1000);

      ----------------
      rprtbo := rtempprtbo;
    end;
$function$
; DROP FUNCTION taxvaluation.counttbonew(numeric, numeric, character varying, numeric, integer, numeric, numeric, date, date, integer, numeric, character varying, date, date, numeric, numeric, date, date, numeric, numeric, numeric, taxdoc, homeobj, land, partland, parthomeobj, promtbo, numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.counttbonew(island numeric, iptaxdoc_id numeric, vdoccode character varying, vparreg numeric, vinst_number integer, ipuser_id numeric, vtaxperiod_id numeric, vtdatebegin date, vtdateend date, vsrok_bh integer, flho numeric, ipstructurezone character varying, vhbdate date, vhedate date, indtelk numeric, vrelief_id numeric, vtaxfreefrom date, vtaxfreeto date, vdotboyear numeric, vdotbosubject numeric, vdopartsubj numeric, rdoc taxdoc, rhomeobject homeobj, rland land, rsubjland partland, rsubject parthomeobj, INOUT rprtbo promtbo, INOUT vtbodebt_id numeric, INOUT vdebtpartproperty_id numeric, INOUT vsumtboy numeric, INOUT vsumtboy_cont numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
  DECLARE
      swsum        numeric;
      cleansum     numeric;
      depotsum     numeric;
      vTBOFreeObj  numeric;
      vTBOFreeSubj numeric;
      vTBO         numeric;
      vTBOSubject  numeric;
      vSubject_id  numeric;
      vperson      numeric;
      rsubjgr      subjgrouptbo%rowtype;
      rtempprtbo   promtbo%rowtype;

     tobDate              date;
     toedate              date;
   
      vsubjgarbtax_id  numeric;
      vsubjsw_missing  numeric;
      vsubjclean_missing  numeric;
      vsubjdepot_missing  numeric;
      vsubjtaxdoc71_id  numeric;
      vdocst varchar(10);
      vadmregion_id        integer;
      telkBDate            date;
      telkEdate            date;

      recCross_Date record;
      -------------------------------
      rgrouptbo  grouptbo%rowtype;
      ---------------------------
    
    begin
      swsum        := 0;
      cleansum     := 0;
      depotsum     := 0;
      vTBOFreeObj  := 0;
      vTBOFreeSubj := 0;
      if isLand = 1
      then
        vSubject_id := rSubjLand.taxsubject_id;
      else
        vSubject_id := rSubject.Taxsubject_Id;
      end if;
      select min(ts.isperson)
      into   vperson
      from   taxsubject ts
      where  ts.taxsubject_id = vSubject_id;
      rtempprtbo := rprtbo;
      begin
        select  a.municipality_id into vadmregion_id 
	from   property p
	left   outer join address a
	on     p.property_address_id = a.address_id
	where  p.taxdoc_id = iptaxdoc_Id;
	       
         
        select sg.*
        into   rsubjgr
        from   subjgrouptbo sg
        where  sg.taxsubject_id = vSubject_id
        and    sg.taxdoc_id = iptaxdoc_id
        and    nvl(sg.enddate::date, vtdatebegin) >= vtdatebegin
        and    nvl(sg.begindate::date, vtdateend) =
               (select max(s.begindate)
                 from   subjgrouptbo s
                 where  s.taxsubject_id = vSubject_id
                 and    s.taxdoc_id = iptaxdoc_id
                 and    s.begindate <= vtdatebegin);
        select t.*
        into   rgrouptbo
        from   grouptbo t
        where  t.grouptbo_id = rsubjgr.grouptbo_id;
      
        if ((rsubjgr.indhome1 = 0) and (rsubjgr.indtelk = 0)) or
           ((rsubjgr.indhome1 = 1) and (isLand <> 1) and
           (rsubject.isbasehome = 1) and (vsrok_bh > 182)) or
           ((rsubjgr.indtelk = 1) and (isLand <> 1) and indtelk = 1)
        then
          ----------------------
          if rgrouptbo.tbo_code <> 9
          then
            rprtbo.sw_home     := rprtbo.sw_home * nvl(rgrouptbo.isswh, 0.0);
            rprtbo.clean_home  := rprtbo.clean_home *
                                  nvl(rgrouptbo.iscleanh, 0.0);
            rprtbo.depot_home  := rprtbo.depot_home *
                                  nvl(rgrouptbo.isdepoth, 0.0);
            rprtbo.sw          := rprtbo.sw * nvl(rgrouptbo.issw, 0.0);
            rprtbo.clean       := rprtbo.clean * nvl(rgrouptbo.isclean, 0.0);
            rprtbo.depot       := rprtbo.depot * nvl(rgrouptbo.isdepot, 0.0);
            rprtbo.fsw_home    := rprtbo.fsw_home * nvl(rgrouptbo.isswh, 0.0);
            rprtbo.fclean_home := rprtbo.fclean_home *
                                  nvl(rgrouptbo.iscleanh, 0.0);
            rprtbo.fdepot_home := rprtbo.fdepot_home *
                                  nvl(rgrouptbo.isdepoth, 0.0);
            rprtbo.tbo_code    := rgrouptbo.tbo_code;
          else
            rprtbo.sw_home     := nvl(rgrouptbo.isswh, 0.0);
            rprtbo.clean_home  := nvl(rgrouptbo.iscleanh, 0.0);
            rprtbo.depot_home  := nvl(rgrouptbo.isdepoth, 0.0);
            rprtbo.sw          := nvl(rgrouptbo.issw, 0.0);
            rprtbo.clean       := nvl(rgrouptbo.isclean, 0.0);
            rprtbo.depot       := nvl(rgrouptbo.isdepot, 0.0);
            rprtbo.fsw_home    := nvl(rgrouptbo.isswh, 0.0);
            rprtbo.fclean_home := nvl(rgrouptbo.iscleanh, 0.0);
            rprtbo.fdepot_home := nvl(rgrouptbo.isdepoth, 0.0);
            rprtbo.tbo_code    := rgrouptbo.tbo_code;
          end if;
          ----------------------
        end if;
      exception
        when no_data_found then
          null;
      end;
-------------- novo za oblekcheniq
     if  vsubjtaxdoc71_id is null then
      begin
   ------------  01.03.2012
      select max(gt.garbtax_id), decode(max(gt.sw_missing), 1.0, 0.0, 1.0),
             decode(max(gt.clean_missing), 1.0, 0.0, 1.0),
             decode(max(gt.depot_missing), 1.0, 0.0, 1.0), max(gt.taxdoc_id)
      into   vsubjgarbtax_id, vsubjsw_missing, vsubjclean_missing, vsubjdepot_missing,
             vsubjtaxdoc71_id
      from   garbtax gt, taxdoc td
      where  td.taxdoc_id = gt.taxdoc_id
      and    td.documenttype_id = (select t.documenttype_id
                                    from   documenttype t
                                    where  t.doccode = '71')
      and    gt.proptaxdoc_id = iptaxdoc_Id
      and    td.docstatus <> '70' and td.docstatus <> '90'
      and    gt.taxperiod_id = vtaxperiod_id
      and    gt.taxsubject_id = vSubject_id
      ;

  --- 01.03.2012 ????????????? ?? ???? ????
       exception
        when no_data_found then
          null;
      end;
      end if;
 --------------------------- 20.04.2012  edin obekt
      if  vsubjtaxdoc71_id is null then
      select max(gt.garbtax_id), decode(max(o.sw_missing), 1.0, 0.0, 1.0),
             decode(max(o.clean_missing), 1.0, 0.0, 1.0),
             decode(max(o.depot_missing), 1.0, 0.0, 1.0), max(gt.taxdoc_id)
      into   vsubjgarbtax_id, vsubjsw_missing, vsubjclean_missing, vsubjdepot_missing,
             vsubjtaxdoc71_id
      from   garbtax gt, taxdoc td, garbobject o
      where  td.taxdoc_id = gt.taxdoc_id
      and    td.documenttype_id = (select t.documenttype_id
                                    from   documenttype t
                                    where  t.doccode = '71')
      and    gt.proptaxdoc_id = iptaxdoc_Id
      and    td.docstatus <> '70' and td.docstatus <> '90'
      and    gt.taxperiod_id = vtaxperiod_id
      and    gt.isforobject = 1
      and o.garbtax_id = gt.garbtax_id 
      and ((isLand = 1 and o.land_id = rland.land_id) or 
           (island <> 1 and o.homeobj_id = rhomeobject.homeobj_id))    
      ;
      
      
---------------------------------------------
      end if;
      if  vsubjtaxdoc71_id is not null
      then
     if vsubjgarbtax_id is not null
       then
        rprtbo.sw_home     := rprtbo.sw_home * nvl(vsubjsw_missing, 0.0);
        rprtbo.clean_home  := rprtbo.clean_home * nvl(vsubjclean_missing, 0.0);
        rprtbo.depot_home  := rprtbo.depot_home * nvl(vsubjdepot_missing, 0.0);
        rprtbo.sw          := rprtbo.sw * nvl(vsubjsw_missing, 0.0);
        rprtbo.clean       := rprtbo.clean * nvl(vsubjclean_missing, 0.0);
        rprtbo.depot       := rprtbo.depot * nvl(vsubjdepot_missing, 0.0);
        rprtbo.fsw_home    := rprtbo.fsw_home * nvl(vsubjsw_missing, 0.0);
        rprtbo.fclean_home := rprtbo.fclean_home * nvl(vsubjclean_missing, 0.0);
        rprtbo.fdepot_home := rprtbo.fdepot_home * nvl(vsubjdepot_missing, 0.0);
       end if;
        select td.docstatus
        into   vdocst
        from   taxdoc td
        where  td.taxdoc_id = vsubjtaxdoc71_id;
        if vdocst = '10'
        then
          update taxdoc td
          set    td.docstatus = '30'
          where  td.taxdoc_id = vsubjtaxdoc71_id;
          perform taxvaluation.arxdoc(vtaxdoc71_id);
        end if;
      end if;

--------------
      /*
      select min(ds.debtsubject_id) into vdebtsubject_id
       from debtsubject ds
       where ds.taxsubject_id = vSubject_id
       and ds.document_id = iptaxdoc_Id
       and ds.taxperiod_id = vtaxperiod_id
       and ds.kinddebtreg_id = 5
       and nvl(ds.docno,'*') = nvl(rdoc.docno,'*')
       and nvl(ds.doc_date,trunc(current_date)) = nvl(rdoc.doc_date,trunc(current_date))
       ;*/
      --   if rhomeobject.isbusiness = 0 then
      if ((rhomeobject.kindhomeobjreg_id < 6) and (isLand <> 1))
      -- ??????????    and nvl(rhomeobject.isbusiness,0) <> 1 
      then
        if nvl(vperson, 1.0) = 1
        then
          swsum    := vDOTBOSubject * rprtbo.sw_home / 1000;
          cleansum := vDOTBOSubject * rprtbo.clean_home / 1000;
          depotsum := vDOTBOSubject * rprtbo.depot_home / 1000;
          vtbo     := rprtbo.sw_home + rprtbo.clean_home + rprtbo.depot_home;
        else
          swsum    := vDOTBOSubject * rprtbo.fsw_home / 1000;
          cleansum := vDOTBOSubject * rprtbo.fclean_home / 1000;
          depotsum := vDOTBOSubject * rprtbo.fdepot_home / 1000;
          vtbo     := rprtbo.fsw_home + rprtbo.fclean_home + rprtbo.fdepot_home;
        end if;
      else
        if (isLand = 1) -- and (rbuilding.structurezone <> '2')
           and
           ((flho = 1) or (ipstructurezone in ('1', '2', '4', '6')))   --(rbuilding.structurezone in ('1', '2', '4', '6')))
        then
          if nvl(vperson, 1.0) = 1
          then
            swsum    := vDOTBOSubject * rprtbo.sw_home / 1000;
            cleansum := vDOTBOSubject * rprtbo.clean_home / 1000;
            depotsum := vDOTBOSubject * rprtbo.depot_home / 1000;
            vtbo     := rprtbo.sw_home + rprtbo.clean_home + rprtbo.depot_home;
          else
            swsum    := vDOTBOSubject * rprtbo.fsw_home / 1000;
            cleansum := vDOTBOSubject * rprtbo.fclean_home / 1000;
            depotsum := vDOTBOSubject * rprtbo.fdepot_home / 1000;
            vtbo     := rprtbo.fsw_home + rprtbo.fclean_home +
                        rprtbo.fdepot_home;
          end if;
        else
          if nvl(vperson, 1.0) = 1
          then
            swsum    := vDOTBOSubject * rprtbo.sw / 1000;
            cleansum := vDOTBOSubject * rprtbo.clean / 1000;
            depotsum := vDOTBOSubject * rprtbo.depot / 1000;
            vtbo     := rprtbo.sw + rprtbo.clean + rprtbo.depot;
          else
            swsum    := vDOTBOSubject * rprtbo.fsw_home / 1000;
            cleansum := vDOTBOSubject * rprtbo.fclean_home / 1000;
            depotsum := vDOTBOSubject * rprtbo.fdepot_home / 1000;
            vtbo     := rprtbo.fsw_home + rprtbo.fclean_home +
                        rprtbo.fdepot_home;
          end if;
        end if;
      end if;
      vtboSubject  := (vtbo * vDOTBOYear *
                      (round(months_between(vhedate, vhBdate))) / 12) / 1000;
      vtboSubject  := round(vtboSubject, 2);
      -----------  07.06.2012
                if vrelief_id is not null then
                 select min(r.telk_begindate), min(r.telk_enddate) into telkbDate, telkEdate
                  from relief r where r.relief_id = vrelief_id 
                 ;
                if telkbDate is null
                then
                  telkbDate := vhbDate;
                end if;
                if telkbDate is not null and telkEdate is null
                then
                  telkEdate := vheDate;
                end if;
               end if;                 
                if telkbDate is not null and telkEdate is not null
                then
                  select into recCross_Date * from taxvaluation.cross_date(vhbDate, vheDate, last_day(telkbDate::date - interval '1 day') + interval '1 day',
                             last_day(telkeDate::date));
                  tobDate := recCross_Date.begin_date;
                  toeDate := recCross_Date.end_date;
                else  
                  tobDate := vhbDate;
                  toeDate := vheDate;
                end if;
        if indtelk = 1 then
                     vTBOFreeSubj := vTBOFreeSubj + round((vTBOSubject *
                                                         (round(round(months_between(toeDate,
                                                                                      tobDate))) /
                                                         round(months_between(vheDate,
                                                                                vhbDate)))) / 2,
                                                         2);
      
      
      ----------- 07.06.2012
      vTBOFreeSubj := round(nvl(vTBOSubject, 0.0) * nvl(rprtbo.pctfree_telk, 0.0) *
                           (round(round(months_between(toeDate, tobDate))) /
                                 round(months_between(vheDate, vhbDate)))  
                            / 100, 2);
        end if;                    
      vtboSubject  := vtboSubject - nvl(vTBOFreeSubj, 0.0);
    --- 03.04.2012 --- za NE gilishta na firmi
     if (isLand <> 1) and (nvl(vperson,0.0) <> 1.0) 
        and (rhomeobject.kindhomeobjreg_id > 5.0) 
        and (rhomeobject.kindhomeobjreg_id <> 0.0) and rSubject.Typedeclar = '1' then
        vtboSubject := 0.0; vTBOFreeSubj := 0.0;
     end if;
    if (isLand = 1) and (nvl(vperson,0.0) <> 1.0) and 
      (flho <> 1) and (ipstructurezone not in ('1', '2', '4', '6')) 
       and rSubject.Typedeclar = '1'  then
        vtboSubject := 0.0; vTBOFreeSubj := 0.0;
     end if;
      if vtbodebt_id is null
      then
        select nextval('s_debtsubject')
        into   vtbodebt_id;
        insert into debtsubject
          (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,
           taxperiod_id, doccode, tax_begidate, tax_enddate, relief_id, Totalval,
           Totaltax, calcdate, FreeSum_obj, prtdate, inst_number, FreeSum_Subj,
           corr_instnumber, codetbo, corr_sumtotal, userdate, user_id,
           taxobject_id, partidano, municipality_id, kindparreg_id, paydiscsum,
           docno, doc_date, parent_debtsubject_id,admregion_id)
        values
          (vtbodebt_id, vSubject_id, iptaxdoc_Id, 1, 5, vtaxperiod_id, vdoccode,
           vTDateBegin, vTDateEnd, vrelief_id, round(vDOTBOSubject, 2),
           round(vtboSubject, 2), trunc(current_date), vTBOFreeObj, null,
           vinst_number, round(vTBOFreeSubj, 2), null, null, null, current_timestamp,
           ipuser_id, rdoc.taxobject_id, rdoc.partidano, rdoc.municipality_id,
           vparreg, null, rdoc.docno, rdoc.doc_date, null,vadmregion_id);
      else
        update debtsubject 
        set    totalval = totalval + round(vDOTBOSubject, 2),
               totaltax = totaltax + round(vTBOSubject, 2),
               freesum_obj = freesum_obj + round(vTBOFreeObj, 2),
               freesum_subj = freesum_subj + round(vTBOFreeSubj, 2)
        where  debtsubject_id = vtbodebt_id;
      end if;
      select nextval('s_debtpartproperty')
      into   vdebtpartproperty_id;
      if isLand = 0
      then
        insert into debtpartproperty
          (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
           seqnots, typedeclar, isbasehome, isrelief, relief_id, divident,
           divisor, part, sumval, sumtax, taxbegindate, taxenddate, totalval,
           totaltax, userdate, user_id, homeobj_id, freefrom, freemonths,
           codetbo, promiltbo, freesuma_obj, freesuma_subj, parentdebtprop_id,
           SUBJPARTVAL, fsw, fclean, fdepot)
        values
          (vdebtpartproperty_id, vtbodebt_id, vtaxperiod_id, 2,
           rSubject.Seqnots, rSubject.Typedeclar, rSubject.Isbasehome,
           decode(vrelief_id, null, 0.0, 1.0), vrelief_id, rSubject.Divident,
           rSubject.Divisor, rSubject.Part, vDOTBOYear,
           round(vTBO * vDOTBOYear / 1000, 2), vhBdate, vhedate,
           round(vDOTBOSubject, 2), round(vTBOSubject, 2), current_timestamp, ipuser_id,
           rhomeobject.homeobj_id, vTaxFreeFrom,
           (case when vTaxFreeFrom is null then 0 else
                   round(months_between(vTaxFreeTo, vTaxFreeFrom)) end),
           rprtbo.tbo_code, vtbo, vTBOFreeObj, vTBOFreeSubj, null, vDOPartSubj,
           swsum, cleansum, depotsum);
      else
        insert into debtpartproperty
          (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
           seqnots, typedeclar, isbasehome, isrelief, relief_id, divident,
           divisor, part, sumval, sumtax, taxbegindate, taxenddate, totalval,
           totaltax, userdate, user_id, homeobj_id, freefrom, freemonths,
           codetbo, promiltbo, freesuma_obj, freesuma_subj, parentdebtprop_id,
           SUBJPARTVAL, fsw, fclean, fdepot)
        values
          (vdebtpartproperty_id, vtbodebt_id, vtaxperiod_id, 1,
           rSubjLand.Seqnots, rSubjLand.Typedeclar, null,
           --rSubject.Isbasehome,
           decode(vrelief_id, null, 0.0, 1.0), vrelief_id, rSubjLand.Dividentland,
           rSubjLand.Divisorland, rSubjLand.Partland, vDOTBOYear,
           round(vTBO * vDOTBOYear / 1000, 2), vhBdate, vheDate,
           round(vDOTBOSubject, 2), round(vTBOSubject, 2), current_timestamp, ipuser_id,
           rLand.Land_Id, vTaxFreeFrom,
           (case when vTaxFreeFrom is null then 0 else
                   round(months_between(vTaxFreeTo, vTaxFreeFrom)) end),
           rprtbo.tbo_code, vtbo, vTBOFreeObj, vTBOFreeSubj, null,
           (case when rSubjLand.Typedeclar = '2' then 0 else
                   (case when rland.typedeclar = '2' then 0 else
                           (case when rland.buildingowner = 1.0 then 0.0 else vDOPartSubj end) end) end),
           swsum, cleansum, depotsum);
      end if;
      vsumtboy := vsumtboy + round(vTBO * vDOTBOYear / 1000, 2);
      vsumtboy_cont := vsumtboy_cont + (vTBO * vDOTBOYear /1000);
      ----------------
      rprtbo := rtempprtbo;
    end;
$function$
; DROP FUNCTION taxvaluation.cross_date(date, date, date, date); 
CREATE OR REPLACE FUNCTION taxvaluation.cross_date(int1_date1 date, int1_date2 date, int2_date1 date, int2_date2 date, OUT begin_date date, OUT end_date date)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
begin
  if int1_date1 between int2_date1 and int2_date2
  then
    begin_date := int1_date1;
  end if;
  if int2_date1 between int1_date1 and int1_date2
  then
    begin_date := int2_date1;
  end if;
  if int1_date2 between int2_date1 and int2_date2
  then
    end_date := int1_date2;
  end if;
  if int2_date2 between int1_date1 and int1_date2
  then
    end_date := int2_date2;
  end if;

end;
$function$
; DROP FUNCTION taxvaluation.patentval(numeric, numeric, numeric, integer); 
CREATE OR REPLACE FUNCTION taxvaluation.patentval(iptaxdoc_id numeric, ipuser_id numeric, ipfl numeric, ipoblwr integer, OUT opstatus character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare       

           

    crPatent cursor  is

      select *

      from   patent p

      where  p.taxdoc_id = iptaxdoc_Id;



    rpatent record;

  

    crPatentact cursor (vpatent_id numeric) is

	select to_number(r.tableno) tableno, a.*

	from   patentactivity a

	left   outer join patentactivityreg r

	on     a.patentactivityreg_id = r.patentactivityreg_id

	where  a.patent_id = vpatent_id

	order  by to_number(r.tableno);



    rpatentact record;

    

    crpatentactobj cursor (vpatentactivity_id numeric) is

      select *

      from   patentactivityobj o

      where  o.patentactivity_id = vpatentactivity_id;



    rpatentactobj record;

  

    crmaxtax cursor (vpatent_id numeric, vdebtsubject_id numeric) is

      select patentactivityreg_id, totaltax -- tableno,totaltax,

      from   (select min(r.tableno) tableno, sum(pp.totaltax) totaltax,

                      o.patentactivityreg_id

               from   debtpartproperty pp, patentactivityobj o,

                      patentactivityreg r, patentactivity a, debtsubject ds

               where  pp.homeobj_id = o.patentactivityobj_id

               and    o.patentactivityreg_id = r.patentactivityreg_id

               and    r.tableno not in ('13', '14', '15', '16', '17')

               and    o.patentactivity_id = a.patentactivity_id

               and    a.ispersonalwork = 1 --and a.isworkalone = 1

               and    ds.debtsubject_id = pp.debtsubject_id

               and    ds.kinddebtreg_id = 1

               and    a.patent_id = vpatent_id

               and    ds.debtsubject_id = vdebtsubject_id

               group  by o.patentactivityreg_id

               union

               select min(r.tableno), sum(pp.totaltax), o.patentactivityreg_id

               from   debtpartproperty pp, patentactivityobj o,

                      patentactivityreg r, patentactivity a, debtsubject ds

               where  pp.homeobj_id = o.patentactivityobj_id

               and    o.patentactivityreg_id = r.patentactivityreg_id

               and    r.tableno = '17'

               and    o.patentactivity_id = a.patentactivity_id

               and    o.quantity1 = 1

               and    ds.debtsubject_id = pp.debtsubject_id

               and    ds.kinddebtreg_id = 1

               and    a.patent_id = vpatent_id

               and    ds.debtsubject_id = vdebtsubject_id

               group  by o.patentactivityreg_id) sub

      order  by 2 desc;

    -------

    brtrim           numeric;

    vtableno         varchar(6);

    vactivityno      varchar(6);

    vtaxper_id       numeric;

    vtaxprice        numeric;

    vtaxvalobj       numeric;

    vtaxvalact       numeric;

    vtaxvalpat       numeric;

    vfreetaxvalobj   numeric;

    vfreetaxvalact   numeric;

    vfreetaxvalpat   numeric;

    vrelief_id       numeric;

    vbdate           date;

    telkdate         date;

    retdate          date;

    ind1             integer; -- telk

    ind2             integer; -- retired

    ind3             integer; -- more then 1 activity

    ind31            integer; --numeric;

    maxtax           numeric; -- 

    maxact_id        numeric;

    vretfree         numeric;

    vdebtsubject_id  numeric;

    vtaxsubject_id   numeric;

    vTDateBegin      date;

    vTDateEnd        date;

    i                numeric;

    vmunicipality_id numeric;

    flerr            integer;

    bract1           integer;

    rdoc             taxdoc%rowtype;

    vdebinst_id      numeric;

    vvv              numeric;

    brtrimo          numeric;

    vdpproperty_id   numeric;

    vodateb          date;

    vbrmesfree       numeric;

    vrcode           varchar(10);

    messb            varchar(10);

    messe            varchar(10);

    vCurYear         varchar(10);

    vparreg          numeric;

    pom1             numeric;

    pom2             numeric;

    vpdate           date;

    vreasoncode      varchar(20);

    -----------------

    vtelk_decisionno varchar(50);

    visretired       numeric; --varchar(2);

    vactsum          numeric;

    vmaxtaxreg_id    numeric;
    vadmregion_id    numeric;

  begin

  opStatus:='Init';    


    select min(ds.debtsubject_id)

    into   vdebtsubject_id

    from   debtsubject ds, taxdoc td

    where  ds.document_id = iptaxdoc_Id

    and    td.taxdoc_id = ds.document_id

    --and nvl(ds.docno,'*') = nvl(td.docno,'*')

    --and nvl(ds.doc_date, trunc(current_date)) = nvl(td.doc_date, trunc(current_date))

    ;

    select *

    into   rdoc

    from   taxdoc td

    where  td.taxdoc_id = iptaxdoc_Id;
    select c.configvalue
    into   vCurYear
    from   config c
    where  name = 'TAXYEAR'
    and c.municipality_id = rdoc.municipality_id;

      if (vdebtsubject_id is not null) and (ipfl = 0) and
     (coalesce(rdoc.close_taxdoc_id, 0) <> 1)
      then
        opStatus := 'errEndProcess'; -- '���� �������� �������� ' || iptaxdoc_Id ;
        return;
      end if;


      select max(a.admregion_id) into vadmregion_id
       from address a, taxsubject ts
       where ts.taxsubject_id = rdoc.taxsubject_id
       and a.address_id = ts.permanent_clientaddr_id
       and a.municipality_id = rdoc.municipality_id
       ;
    
    select min(rr.reason_code)

    into   vreasoncode

    from   reasonreg rr

    where  rr.reasonreg_id = rdoc.give_reasonreg_id;

    if to_char(rdoc.begintaxdate::date, 'YYYY')::numeric < vcuryear::numeric

    then

      vparreg := 3;

    else

      vparreg := 2;

    end if;

  

    select r.reason_code

    into   vrcode

    from   reasonreg r

    where  r.reasonreg_id = rdoc.give_reasonreg_id

    -- and r.municipality_id = rdoc.municipality_id

    ;

    vrelief_id := rdoc.relief_id;

    if rdoc.change_date is not null

    then

      vbdate := rdoc.change_date;

    else

      vbdate := rdoc.begintaxdate;

    end if;

    vtaxsubject_id   := coalesce(rdoc.taxsubject_id, rdoc.ettaxsubject_id);

    vmunicipality_id := rdoc.municipality_id;

    select min(tp.taxperiod_id)

    into   vtaxper_id

    from   taxperiod tp

    where  to_char(tp.begin_date, 'yyyy') = to_char(rdoc.begintaxdate::date, 'yyyy')

    and    tp.taxperkind = '0';

    if vtaxper_id is null

    then

      opStatus := 'errMissPer'; --'������ ������� ������';

      return;

    end if;

    open crPatent;

    loop

      -- patent

      fetch crpatent

        into rpatent;

      exit when not FOUND;

      if ((rpatent.isactivityappl4 <> 1) or (rpatent.isturnover <> 0) or

         (rpatent.isdds <> 0))

      then

        opStatus := 'errNoDuty'; --'�� ������� �� ��������';

        exit;

      end if;

      vtaxvalobj     := 0;

      vfreetaxvalobj := 0;

      vtaxvalact     := 0;

      vfreetaxvalact := 0;

      vtaxvalpat     := 0;

      brtrim         := 4;

      vTDateBegin    := to_date('01.01.' || to_char(vbdate, 'yyyy'),

                                'dd.mm.yyyy');

      --  if rpatent.begindate is not null then

      --    if to_char(rpatent.begindate,'mm') in ('01','02','03') then

      if to_char(vbdate, 'mm') in ('01', '02', '03')

      then

        brtrim      := 4;

        vTDateBegin := to_date('01.01.' || to_char(vbdate, 'yyyy'), 'dd.mm.yyyy');

      end if;

      if to_char(vbdate, 'mm') in ('04', '05', '06')

      then

        brtrim      := 3;

        vTDateBegin := to_date('01.04.' || to_char(vbdate, 'yyyy'), 'dd.mm.yyyy');

      end if;

      if to_char(vbdate, 'mm') in ('07', '08', '09')

      then

        brtrim      := 2;

        vTDateBegin := to_date('01.07.' || to_char(vbdate, 'yyyy'), 'dd.mm.yyyy');

      end if;

      if to_char(vbdate, 'mm') in ('10', '11', '12')

      then

        brtrim      := 1;

        vTDateBegin := to_date('01.10.' || to_char(vbdate, 'yyyy'), 'dd.mm.yyyy');

      end if;

      --  end if;

      vTDateEnd := to_date('31.12.' || to_char(vbdate, 'yyyy'), 'dd.mm.yyyy');

      --- Oblekcheniq

      telkdate := null;

      retdate  := null;

      ind1     := 0;

      ind2     := 0;

      ind3     := 0;

      ind31    := 0;

      if vrelief_id is not null

      then

        select max(r.telk_enddate), max(r.retired_begindate),

               max(r.telk_decisionno), max(r.isretired)

        into   telkdate, retdate, vtelk_decisionno, visretired

        from   relief r

        where  r.relief_id = vrelief_id;

        if (telkdate is not null and to_number(to_char(telkdate, 'yyyy')) >=

           to_number(to_char(vbdate, 'yyyy'))) or

           ((telkdate is null) and (vtelk_decisionno is not null))

        then

          ind1    := 1;

          vodateb := vTDateBegin;

        end if;

        if retdate is not null and visretired = 1

        then

          ind2    := 1;

          vodateb := retdate;

        end if;

      end if;

      if vodateb is not null

      then

        vbrmesfree := round(months_between(vTDateEnd, vodateb));

      end if;

      if coalesce(rpatent.ispersonalwork, 0.0) = 1

      then

        select count(*)

        into   ind3

        from   (select r.patentactivityreg_id

                 from   patentactivity a, patentactivityreg r, patentactivityobj o

                 where  a.patent_id = rpatent.patent_id

                 and    o.patentactivity_id = a.patentactivity_id

                 and    o.patentactivityreg_id = r.patentactivityreg_id

     --            and    coalesce(a.ispersonalwork, 0.0) = 1

                 and    r.tableno not in ('13', '14', '15', '16', '17')

                 group  by r.patentactivityreg_id) sub;

        select count(*)

        into   ind31

        from   (select o.patentactivityreg_id

                 from   patentactivity a, patentactivityobj o, patentactivityreg r

                 where  a.patent_id = rpatent.patent_id

                 and    o.patentactivity_id = a.patentactivity_id

                 and    o.patentactivityreg_id = r.patentactivityreg_id

                 and    coalesce(o.quantity1, 0.0) = 1

                 and    r.tableno = '17'

                 and    ((o.enddate is null) or (o.enddate > vTDateBegin))

                 group  by o.patentactivityreg_id) sub;

        ind3 := ind3 + ind31;

      else

        ind3 := 0;

      end if;

      maxtax    := 0;

      maxact_id := 0;

      flerr     := 0;

      bract1    := 0;

      ------ DebtSubject bez sumi

      select nextval('s_debtsubject')

      into   vdebtsubject_id;

      insert into debtsubject

        (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,

         taxperiod_id, doccode, tax_begidate, tax_enddate, relief_id, Totalval,

         Totaltax, calcdate, FreeSum_obj, prtdate, inst_number, FreeSum_Subj,

         corr_instnumber, codetbo, corr_sumtotal, userdate, user_id, partidano,

         MUNICIPALITY_ID, KINDPARREG_ID, PAYDISCSUM, DOCNO, DOC_DATE,
         PARENT_DEBTSUBJECT_ID, taxobject_id,admregion_id)

      values

        (vdebtsubject_id, vTaxsubject_Id, iptaxdoc_Id, 1, 1, vtaxper_id, '61',

         vTDateBegin, vTDateEnd, vrelief_id, (vtaxvalpat + vfreetaxvalpat),

         vtaxvalpat, trunc(current_date), null, null, brtrim, vfreetaxvalpat, null,

         null, null, CURRENT_TIMESTAMP, ipuser_id, rdoc.partidano, vmunicipality_id,
         vparreg, null, rdoc.docno, rdoc.doc_date, null, rdoc.taxobject_id,vadmregion_id);

      open crPatentact(rpatent.patent_id);

      loop

        -- patent act

        vtaxvalact := 0;

        fetch crPatentact

          into rpatentact;

        exit when not FOUND;

        bract1 := bract1 + 1;

        open crpatentactobj(rpatentact.patentactivity_id);

        loop

          -- patentactobj

          fetch crpatentactobj

            into rpatentactobj;

          exit when not FOUND;

          --------

          messb := to_char(vTDateBegin, 'mm');

          messe := to_char(vTDateend, 'mm');

          if rpatentactobj.begindate is not null and

             rpatentactobj.begindate > vTDateBegin and

             rpatentactobj.begindate < vTDateEnd

          then

            messb := to_char(rpatentactobj.begindate, 'mm');

          end if;

          if rpatentactobj.enddate is not null

          then

            if rpatentactobj.enddate > vTDateBegin and

               rpatentactobj.enddate < vTDateEnd

            then

              messe := to_char(rpatentactobj.enddate, 'mm');

            end if;

            if rpatentactobj.enddate <= vTDateBegin

            then

              messe := '-2';

            end if;

          end if;

          brtrimo := trunc((to_number(messe) - 1) / 3) + 1 -

                     trunc((to_number(messb) - 1) / 3);

          if brtrimo < 0

          then

            brtrimo := 0;

          end if;

          vtaxvalobj := 0;

          select pr.tableno, pr.isretiredfree, pr.activityno

          into   vtableno, vretfree, vactivityno

          from   patentactivityreg pr

          where  pr.patentactivityreg_id = rpatentactobj.patentactivityreg_id;

          if vtableno not in ('13', '14', '15', '16')

          then

            select max(pp.taxprice)

            into   vtaxprice

            from   patenttaxprice pp, municipality m --,address a

            where  pp.patentactivityreg_id = rpatentactobj.patentactivityreg_id

            and    coalesce(pp.patentzone_id, 0.0) =

                   coalesce(rpatentactobj.patentzone_id, 0.0)

                  --   and a.address_id = rpatentactobj.address_id

            and    pp.taxperiod_id = vtaxper_id

                  --  and pp.categoryno = rpatentactobj.category

            and    pp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
            and    m.municipality_id = vmunicipality_id

            --     and pp.city_id = a.city_id

            --     and nvl(pp.admregion_id,0) = nvl(a.admregion_id,0)

            ;

          else

            select max(pp.taxprice)

            into   vtaxprice

            from   patenttaxprice pp, municipality m -- ,address a, taxsubject ts

            where  pp.patentactivityreg_id = rpatentactobj.patentactivityreg_id

            and    coalesce(pp.patentzone_id, 0.0) =

                   coalesce(rpatentactobj.patentzone_id, 0.0)

--            and    ts.taxsubject_id = vtaxsubject_id

--            and    a.address_id = ts.permanent_clientaddr_id

            and    pp.taxperiod_id = vtaxper_id

                  --     and z.city_id = a.city_id

                  --  and pp.categoryno = rpatentactobj.category

            and    pp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)

            and    m.municipality_id = vmunicipality_id

            --     and pp.city_id = a.city_id

            --     and nvl(pp.admregion_id,0) = nvl(a.admregion_id,0)

            --     and nvl(z.street_id,0) = nvl(a.street_id,0)

            ;

          end if;

          vtaxprice := coalesce(vtaxprice, 0.0);

          if vtableno not in ('01', '02', '03', '06', '09', '17')

          then

            vtaxvalobj := round((rpatentactobj.quantity1 +

                                rpatentactobj.quantity2) * vtaxprice * brtrimo / 4,

                                2);
           if coalesce(rpatentact.isapprenticereg, 0) = 1 then                                
            rpatentact.isworkalone := 0;   --- 28.05.2012  Ako ima chirak ne raboti sam ? 
           end if;                             

          elsif vtableno = '06'

          then

            rpatentactobj.quantity2 := coalesce(rpatentact.isapprenticereg, 0.0) *

                                       rpatentactobj.quantity2;

            vtaxvalobj              := round((((rpatentactobj.quantity1 -

                                             rpatentactobj.quantity2) *

                                             vtaxprice) + (rpatentactobj.quantity2 *

                                             vtaxprice * 0.5)) * brtrimo / 4, 2);

          elsif vtableno = '09'

          then

            vtaxvalobj := 0;

            if coalesce(rpatentactobj.quantity1, 0.0) > 0

            then

              select pp.taxprice

              into   vtaxprice

              from   patenttaxprice pp, municipality m, patentactivityreg r

              where  r.tableno = '09'

              and    r.activityno = '01'

              and    pp.patentactivityreg_id = r.patentactivityreg_id

              and    pp.patentzone_id = rpatentactobj.patentzone_id

              and    pp.taxperiod_id = vtaxper_id

                    --  and pp.categoryno = rpatentactobj.category

            and    pp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)

            and    m.municipality_id = vmunicipality_id

              --       and pp.city_id = (select a.city_id from address a where a.address_id = rpatentactobj.address_id)

              ;

              vtaxvalobj := vtaxvalobj +

                            ((rpatentactobj.quantity1 * vtaxprice) * brtrimo / 4);

            end if;

            if coalesce(rpatentactobj.quantity2, 0.0) > 0

            then

              select pp.taxprice

              into   vtaxprice

              from   patenttaxprice pp, municipality m, patentactivityreg r

              where  r.tableno = '09'

              and    r.activityno = '02'

              and    pp.patentactivityreg_id = r.patentactivityreg_id

              and    pp.patentzone_id = rpatentactobj.patentzone_id

              and    pp.taxperiod_id = vtaxper_id

                    --  and pp.categoryno = rpatentactobj.category

            and    pp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)

            and    m.municipality_id = vmunicipality_id

              --       and pp.city_id = (select a.city_id from address a where a.address_id = rpatentactobj.address_id)

              ;

              vtaxvalobj := vtaxvalobj +

                            ((rpatentactobj.quantity2 * vtaxprice) * brtrimo / 4);

            end if;

            vtaxvalobj := round(vtaxvalobj, 2);

          elsif vtableno = '17'

          then

            if to_char(rdoc.begintaxdate::date, 'yyyy')::numeric > 2008

            then

              select min(po.patentactivityobj_id)

              into   vvv

              from   patentactivity pa, patentactivityobj po,

                     patentactivityreg r

              where  po.patentactivity_id = pa.patentactivity_id

              and    po.patentactivityreg_id = r.patentactivityreg_id

              and    r.tableno = '04'

              and    r.activityno = '01'

              and    po.address_id = rpatentactobj.address_id

              and    pa.patent_id = rpatentact.patent_id;

              if vvv is not null and vactivityno = '31'

              then

                vtaxvalobj := 0;

              else

                vtaxvalobj := round(vtaxprice * brtrimo / 4, 2);

              end if;

            else

              vtaxvalobj := round(vtaxprice * brtrimo / 4, 2);

            end if;

          elsif vtableno in ('01', '02')

          then

            vtaxvalobj := rpatentactobj.quantity1 * vtaxprice;

          elsif vtableno in ('03')

          then

            if brtrimo = 0

            then

              vtaxvalobj := 0;

            else

            vtaxvalobj := vtaxprice;

            end if;

          end if;

          --- Oblekcheniq

          if vtableno = '17'

          then

            vfreetaxvalobj := vtaxvalobj;

            if rpatentactobj.quantity1 = 1 and rpatentactobj.quantity2 = 0 and

               ind1 = 1

            then

              --        vtaxvalobj := vfreetaxvalobj/2 ;

              vtaxvalobj := vtaxvalobj / 2;

            end if;

            if rpatentactobj.quantity1 = 1 and rpatentactobj.quantity2 = 0 and

               ind2 = 1 and coalesce(vretfree, 0.0) = 1

            then

              --        vtaxvalobj := vfreetaxvalobj/2 ;

              vtaxvalobj := vtaxvalobj / 2;

            end if;

            if (rpatentactobj.quantity1 = 1) and (ind3 > 1)

            then

              if to_char(rdoc.begintaxdate::date, 'yyyy')::numeric < 2011

              then

                --    vtaxvalobj := vfreetaxvalobj/2 ;

                vtaxvalobj := vtaxvalobj / 2;

              end if;

            end if;

          else

            vfreetaxvalobj := vtaxvalobj;

            if rpatentact.ispersonalwork = 1 and rpatentact.isworkalone = 1 and

               ind1 = 1

            then

              --         vtaxvalobj := vfreetaxvalobj/2 ;

              vtaxvalobj := vtaxvalobj / 2;

            end if;

            if rpatentact.isworkalone = 1 --rpatentact.ispersonalwork = 1 and 

               and ind2 = 1 and coalesce(vretfree, 0.0) = 1

            then

              --         vtaxvalobj := vfreetaxvalobj/2 ;

              vtaxvalobj := vtaxvalobj / 2;

            end if;

            if to_char(rdoc.begintaxdate::date, 'yyyy')::numeric < 2011

            then

              if rpatentact.ispersonalwork = 1 -- and rpatentact.isworkalone = 1

                 and ind3 > 1 and vtableno not in ('13', '14', '15', '16')

              then

                --         vtaxvalobj := vfreetaxvalobj/2 ;

                vtaxvalobj := vtaxvalobj / 2;

              end if;

            end if;

          end if;

          vtaxvalobj     := round(vtaxvalobj, 2);

          vfreetaxvalobj := coalesce(vfreetaxvalobj, 0.0) - vtaxvalobj;

          vtaxvalact     := coalesce(vtaxvalact, 0.0) + vtaxvalobj;

          vfreetaxvalact := coalesce(vfreetaxvalact, 0.0) + vfreetaxvalobj;
          if brtrimo <> 0 then 
           perform taxvaluation.updpat(1, vtaxvalobj, rpatentactobj.patentactivityobj_id, rpatentactobj.taxvalue_decl, rpatentact.patentactivity_id);
          end if;

          if (vtaxvalobj <> rpatentactobj.taxvalue_decl) and

             (coalesce(ipfl, 0.0) <> 2)

          then

            flerr := 1;

            --    opStatus := opStatus || ' ' || vtableno ;

          end if;

          -------- insert DebtPartProperty

          if to_number(messe) > 0

          then

            messe := lpad(to_char((trunc((to_number(messe) - 1) / 3) + 1) * 3),

                          2, '0');

            select nextval('s_debtpartproperty')

            into   vdpproperty_id;

          

            insert into debtpartproperty

              (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,

               seqnots, typedeclar, isbasehome, isrelief, relief_id, divident,

               divisor, part, sumval, sumtax, taxbegindate, taxenddate, totalval,

               totaltax, userdate, user_id, homeobj_id, freefrom, freemonths,

               codetbo, promiltbo, freesuma_obj, freesuma_subj,

               parentdebtprop_id, SUBJPARTVAL)

            values

              (vdpproperty_id, vdebtsubject_id, vtaxper_id,

               (select r.tableno||r.activityno

                 from   patentactivityreg r

                 where  r.patentactivityreg_id = rpatentactobj.patentactivityreg_id)::numeric ,

               rpatentactobj.objno, 1, null, decode(vrelief_id, null, null, 1),

               vrelief_id, 1, 1, 1, round(vtaxvalobj + vfreetaxvalobj, 2),

               round(vtaxvalobj + vfreetaxvalobj, 2), vTDateBegin,

               last_day(to_date(to_char(vTDateEnd, 'yyyy') || messe, 'yyyymm')),

               round(vtaxvalobj, 2), round(vtaxvalobj, 2), CURRENT_TIMESTAMP, ipuser_id,

               rpatentactobj.patentactivityobj_id, vodateb, vbrmesfree, null,

               null, null, round(vfreetaxvalobj, 2), null, null);

          end if;

        end loop; -- patentactobj

        close crpatentactobj;

        perform taxvaluation.updpat(0, vtaxvalact, rpatentact.patentactivity_id, rpatentactobj.taxvalue_decl, rpatentact.patentactivity_id);

      

      

      

        if (vtaxvalact <> rpatentact.taxvalue_decl)

        then

          flerr := 1;

        end if;

        vtaxvalpat     := coalesce(vtaxvalpat, 0.0) + vtaxvalact;

        vfreetaxvalpat := coalesce(vfreetaxvalpat, 0.0) + vfreetaxvalact;

      end loop; -- patentact

      close crPatentact;

      if (flerr = 1) and (coalesce(ipoblwr, 0) <> 1) and (vrcode in ('611', '612'))

      then

        --rollback;

       opStatus := 'errDiferData'; --'������� � ����������� � ���������' || opStatus;

        return;

      end if;

      if bract1 = 0

      then

        --rollback;

        opStatus := 'errMissPatAct'; --'������� �������� ��� �������';

        return;

      end if;

      ---------------------------------

      if (to_char(rdoc.begintaxdate::date, 'yyyy')::numeric >= 2011) and

         (ind3 in (2, 3))

      then

      

        open crmaxtax(rpatent.patent_id, vdebtsubject_id);

        fetch crmaxtax

          into vmaxtaxreg_id, vactsum;

        loop

          fetch crmaxtax

            into vmaxtaxreg_id, vactsum;

          exit when not FOUND;

          vtaxvalpat     := vtaxvalpat - vactsum;

          vfreetaxvalpat := vfreetaxvalpat + vactsum;

          update debtpartproperty pp

          set    freesuma_subj = pp.freesuma_subj + pp.totaltax,

                 totaltax = 0

          where  pp.homeobj_id in

                 (select o.patentactivityobj_id

                  from   patentactivityobj o, patentactivity a

                  where  o.patentactivity_id = a.patentactivity_id

                  and    a.patent_id = rpatent.patent_id

                  and    o.patentactivityreg_id = vmaxtaxreg_id)

          and    pp.debtsubject_id = vdebtsubject_id;

        end loop;

        close crmaxtax;

      end if;

      -----------------------

    

      update debtsubject ds

      set    tax_begidate = vTDateBegin, tax_enddate = tax_enddate,

             relief_id = vrelief_id, totalval = vtaxvalpat,

             totaltax = vtaxvalpat, freesum_subj = vfreetaxvalpat

      where  ds.debtsubject_id = vdebtsubject_id;

      if ipfl <> 2

      then

        i := trunc((to_number(to_char(vTDateEnd, 'mm')) + 2) / 3);

        ---brtrim;

        pom1 := 0;

        pom2 := 0;

        while i >

              (trunc((to_number(to_char(vTDateEnd, 'mm')) + 2) / 3) - brtrim)

        loop

          if i =

             ((trunc((to_number(to_char(vTDateEnd, 'mm')) + 2) / 3) - brtrim) + 1)

          then

            pom1 := vtaxvalpat - pom2;

          else

            pom1 := round(vtaxvalpat / brtrim, 2);

            pom2 := pom2 + round(vtaxvalpat / brtrim, 2);

          end if;

          if (i = (5 - brtrim)) and

             (rdoc.begintaxdate >

             to_date('01.01.' || to_char(vTDateBegin, 'yyyy'), 'dd.mm.yyyy'))

            --    (to_number(to_char(rdoc.begintaxdate,'mm'))) > 1 

             and (vreasoncode in ('612', '611'))

          then

            vpdate := public.getWorkingDay(rdoc.doc_date::date + 7, 1);

          else

            vpdate := null;

          end if;

          select nextval('s_debtinstalment')

          into   vdebinst_id;

          insert into debtinstalment

            (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,

             intbegindate)

            select vdebinst_id, vdebtsubject_id, tp.instalmentnumber,

                   getWorkingDay(coalesce(vpdate, tp.termpaydate::date), 1), pom1,

                   getWorkingDay(coalesce(vpdate, tp.termpaydate::date), 1) + 1

            from   taxperiodpay tp, documenttype dt

            where  tp.taxperiod_id = vtaxper_id

            and    tp.instalmentnumber = i

            and    tp.documenttype_id = dt.documenttype_id

            and    dt.doccode = '61'

            --    and dt.municipality_id = vmunicipality_id

            ;

          insert into baldebtinst

            (debtinstalment_id, instsum, interestsum, discsum)

          values

            (vdebinst_id, pom1, 0, 0);

          i := i - 1;

        end loop;

      end if;

    end loop; -- patent

    close crPatent;

    --commit;

    opStatus := 'OK';

  exception

    when others then

      opStatus := 'errOrclDB' || sqlerrm;  --SQLErrM;

      --rollback;

end;
$function$
; DROP FUNCTION taxvaluation.per_basehome(numeric, numeric, date); 
CREATE OR REPLACE FUNCTION taxvaluation.per_basehome(iphomeobj_id numeric, iptaxsubj_id numeric, ipdate date)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
DECLARE
  
    cr cursor is
      select ds.taxsubject_id, ds.tax_begidate::date, ds.tax_enddate::date, pp.*
      from   debtpartproperty pp, debtsubject ds
      where  pp.homeobj_id = iphomeobj_id
      and    ds.taxsubject_id = iptaxsubj_id
      and    pp.taxbegindate <= ipdate
      and    pp.debtsubject_id = ds.debtsubject_id
      and    ds.kinddebtreg_id = 2
      order  by pp.taxbegindate desc, pp.debtpartproperty_id desc;
    r   record;
    per integer;
  begin
    per := 0;
    open cr;
    loop
      fetch cr
        into r;
      exit when not FOUND;
      if r.isbasehome = 1
      then
        per := ipdate - r.taxbegindate::date;
        --dbms_output.put_line(per);
      else
        exit;
      end if;
      if per > 181
      then
        exit;
      end if;
    end loop;
    close cr;
    --dbms_output.put_line(per);
    return per;
  end;
$function$
; DROP FUNCTION taxvaluation.tax17obj(numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.tax17obj(OUT return_val character varying, ipfirmpropobj_id numeric, OUT optaxvalue_decl numeric, OUT optaxvalue_calc numeric, OUT opisfalse_taxvalue numeric, OUT opearntaxvalue_decl numeric, OUT opearntaxvalue_calc numeric, OUT opisearnfalse numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
  begin
    select nvl(o.taxvalue_decl, 0.0), nvl(o.taxvalue_calc, 0.0),
           nvl(o.isfalse_taxvalue, 0.0), nvl(o.earntaxvalue_decl, 0.0),
           nvl(o.earntaxvalue_calc, 0.0), nvl(o.isfalse_earntaxvalue, 0.0)
    into   opTaxvalue_Decl, opTaxvalue_Calc, opIsFalse_TaxValue,
           opEarnTaxvalue_Decl, opEarnTaxvalue_Calc, opIsEarnFalse
    from   firmpropobj o
    where  o.firmpropobj_id = ipFirmPropObj_id;
    return_val := 'OK';
    return;
  
  exception
    when others then
      return_val := '������� �����';
      return;
    
end;
$function$
; DROP FUNCTION taxvaluation.taxdocval(numeric, numeric, integer, character varying, date, date); 
CREATE OR REPLACE FUNCTION taxvaluation.taxdocval(iptaxdoc_id numeric, ipuser_id numeric, ipoblwr integer DEFAULT 0, OUT opstatus character varying, ipkindcorr character varying DEFAULT NULL::character varying, iptermpay_date date DEFAULT NULL::date, ipinterestbegdate date DEFAULT NULL::date)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
  DECLARE                      
    crdpp CURSOR(vds_id numeric) IS
      select *
      from   debtpartproperty dp
      where  dp.debtsubject_id = vds_id;
    rdpp record;
  
    crds cursor (iptaxdoc_Id numeric,
                ipdate      date,
                ipdocno     varchar,
                ipdocdate   date,
                vcurtime    date) is
      select ds.debtsubject_id, ds.taxsubject_id, pp.totalval, pp.totaltax,
       pp.debtpartproperty_id, ds.taxperiod_id, pp.taxbefore, ds.tax_begidate::date,
       ds.tax_enddate::date, pp.homeobj_id
from   debtsubject ds
left   outer join debtpartproperty pp
on     ds.debtsubject_id = pp.debtsubject_id
where  ds.document_id = iptaxdoc_Id
and    ds.kinddoc = '1'
and    ipdate between ds.tax_begidate and ds.tax_enddate
and    ds.userdate = (select max(dd.userdate)
                      from   debtsubject dd
                      where  dd.document_id = ds.document_id
                      and    dd.kinddoc = '1'
                      and    dd.taxperiod_id = ds.taxperiod_id
                      and    dd.kinddebtreg_id = ds.kinddebtreg_id
                      and    dd.taxsubject_id = ds.taxsubject_id
                      and    ipdate between dd.tax_begidate and dd.tax_enddate
                      and    dd.userdate < vcurtime);
    rds record;
    crds14 cursor (iptaxdoc_Id numeric, ipdate date, vcurtime date) is
      select ds.debtsubject_id, ds.taxsubject_id, ds.tax_begidate::date,
             ds.tax_enddate::date, ds.kinddebtreg_id, ds.totalval, ds.totaltax,
             ds.docno, ds.doc_date::date, ds.taxperiod_id
      from   debtsubject ds, taxdoc t
      where  ds.document_id = iptaxdoc_Id
      and    ds.kinddoc = '1'
      and    t.taxdoc_id = ds.document_id
      and    nvl(t.docno, '*') = nvl(ds.docno, '*')
      and    ipdate between ds.tax_begidate and ds.tax_enddate
      and    ds.userdate =
             (select max(dd.userdate)
               from   debtsubject dd
               where  dd.document_id = iptaxdoc_Id
               and    dd.taxperiod_id = ds.taxperiod_id
               and    dd.taxsubject_id = ds.taxsubject_id
               and    dd.kinddebtreg_id = ds.kinddebtreg_id
               and    ipdate between dd.tax_begidate and dd.tax_enddate
               and    dd.userdate > vcurtime);
  
    rds14 record;
  
    crdsn cursor (iptaxdoc_id numeric, vtaxper_id numeric) is
      select pl.taxsubject_id
      from   property p, land l, partland pl
      where  p.taxdoc_id = iptaxdoc_id
      and    l.property_id = p.property_id
      and    pl.land_id = l.land_id
      and    not exists (select *
              from   debtsubject ds
              where  ds.taxsubject_id = pl.taxsubject_id
              and    ds.document_id = p.taxdoc_id
              and    ds.taxperiod_id = vtaxper_id)
      union
      select ph.taxsubject_id
      from   property p, building b, homeobj h, parthomeobj ph
      where  p.taxdoc_id = iptaxdoc_Id
      and    b.property_id = p.property_id
      and    h.building_id = b.building_id
      and    ph.homeobj_id = h.homeobj_id
      and    not exists (select *
              from   debtsubject ds
              where  ds.taxsubject_id = ph.taxsubject_id
              and    ds.document_id = p.taxdoc_id
              and    ds.taxperiod_id = vtaxper_id);
    rdsn record;
  
    rTaxDoc           record;
    vdoccode          varchar(10);
    mymunicipality_id numeric;
    vTaxYear          varchar(10);
    vStatus           varchar(256);
    --  opStatus varchar(256);
    vbegintaxdate    date;
    vpartno          varchar(50);
    vdocumenttype_id numeric;
    vreasoncode      varchar(20);
    vchange_date     date;
    vds_id           numeric;
    vtbods_id        numeric;
    vtotaltax        numeric;
    vtotalval        numeric;
    vtbotax          numeric;
    vendtaxdate      date;
    doc_date_new     date;
    docno_new        varchar(50);
    vreasontxt       varchar(150);
    vdebtsubject_New numeric;
    vtaxbefore       numeric;
    oldper           integer;
    newper           integer;
    vfrees           numeric;
    vfreeo           numeric;
    vcorrYear        numeric;
    vtaxper_id       numeric;
    vpds_id          numeric;
    vptbods_id       numeric;
    vold_begindate   date;
    vold_enddate     date;
    vtableno         varchar(50);
    vkindcorr        varchar(10);
    vcurtime         timestamp;
    vdebtsubject_old numeric;
    vBEGINOBL2       varchar(10);
    vobjenddate      date;
    firmPropertyRec record;
    i                integer;

  begin
    vcurtime := statement_timestamp() - interval'1 second';
    select u.municipality_id
    into   mymunicipality_id
    from   users u
    where  u.user_id = ipuser_id;
  
    select d.doccode, td.begintaxdate, td.partidano, td.documenttype_id,
           td.change_date, td.docno, td.doc_date
    into   vdoccode, vbegintaxdate, vpartno, vdocumenttype_id, vchange_date,
           docno_new, doc_date_new
    from   taxdoc td, documenttype d
    where  td.taxdoc_id = iptaxdoc_Id
    and    td.documenttype_id = d.documenttype_id;
  
    select min(rr.reason_code), min(rr.reason_text)
    into   vreasoncode, vreasontxt
    from   reasonreg rr, taxdoc td
    where  rr.reasonreg_id = td.give_reasonreg_id
    and    td.taxdoc_id = iptaxdoc_Id;
  
    -----------------------
    if vdoccode = '14'
    then
      select *
      into   rtaxdoc
      from   taxdoc t
      where  t.taxdoc_id = iptaxdoc_Id;

      if (vreasoncode = 'd1') and (nvl(ipkindcorr, '0') <> '1')
      then
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR14';
        if rtaxdoc.earn_date is not null
        then
          rtaxdoc.earn_date := to_date('01.' ||
                                       to_char(add_months(rtaxdoc.earn_date, 1),
                                               'mm.yyyy'), 'dd.mm.yyyy');
          if vbegintaxdate is null
          then
            vbegintaxdate := rtaxdoc.earn_date;
          else
            vbegintaxdate := to_date('01.' || to_char(vbegintaxdate, 'mm.yyyy'),
                                     'dd.mm.yyyy');
          end if;
        end if;
        if vbegintaxdate is null
        then
          opStatus := 'errMissBD'; ---'TaxProperty - ?????? ??????? ???? !';
          return;
        end if;
        if (vbegintaxdate < to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'))
        then
        
         /*select Taxproperty(iptaxdoc_Id, vbegintaxdate,
                      to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id, 1,
                      vStatus);*/
          if rtaxdoc.decl14to17 = 2
          then
            vStatus := Firmprop14(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id,
                       ipoblwr, 0);
          else
           vStatus := taxvaluation.Taxproperty(iptaxdoc_Id, vbegintaxdate,
                      to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id, 1);
          end if;

          if vStatus <> 'OK'
          then
            opStatus := vStatus; --- 'TaxProperty - ' ||
            --rollback;
            --   return (opStatus);
          else
            opStatus := vStatus;
            update taxdoc td
            set    docstatus = '30'
            where  td.taxdoc_id = iptaxdoc_id;
            if vpartno is null
            then
              --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
              vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
              if vpartno <> '-1'
              then
                if rtaxdoc.decl14to17 = 2
                then
                  vpartno := replace(vpartno, 'H', 'F');
                end if;

                update taxdoc td
                set    partidano = vpartno
                where  td.taxdoc_id = iptaxdoc_id;
                update debtsubject ds
                set    partidano = vpartno
                where  ds.document_id = iptaxdoc_id
                and    ds.partidano is null;
              end if;
            end if;
            perform taxvaluation.arxdoc(iptaxdoc_id);
            --commit;
          end if;
        else
          opStatus := 'errNoActPer';
          --        opStatus := 'OK';
          select tp.taxperiod_id
          into   vtaxper_id
          from   taxperiod tp
          where  tp.taxperkind = 0
          and    to_char(tp.begin_date, 'yyyy') = vtaxyear;
          open crdsn(iptaxdoc_Id, vtaxper_id);
          loop
            fetch crdsn
              into rdsn;
            exit when not FOUND;
            select nextval('s_debtsubject')
            into   vdebtsubject_New;
          
            insert into debtsubject
              (debtsubject_id, taxsubject_id, document_id, kinddoc,
               kinddebtreg_id, taxperiod_id, doccode, tax_begidate, tax_enddate,
               totalval, totaltax, calcdate, inst_number, userdate, user_id,
               taxobject_id, partidano, municipality_id, kindparreg_id, docno,
               doc_date)
            values
              (vdebtsubject_New, rdsn.taxsubject_id, iptaxdoc_Id, 1, 2,
               vtaxper_id, '14', to_date('01.12.' || vtaxyear, 'dd.mm.yyyy'),
               to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), 0, 0, trunc(current_date),
               1, CURRENT_TIMESTAMP, ipuser_id, rtaxdoc.taxobject_id, rTaxDoc.Partidano,
               rtaxdoc.municipality_id, 2, rtaxdoc.docno, rtaxdoc.doc_date);
            insert into debtinstalment
              (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
               intbegindate, paysum)
            values
              (nextval('s_debtinstalment'), vdebtsubject_New, 1, current_date, 0,
               null, 0);
          
          end loop;
          close crdsn;
          
          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = iptaxdoc_id;
          if vpartno is null
          then
            --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
            vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
            if vpartno <> '-1'
            then
              if rtaxdoc.decl14to17 = 2
              then
                vpartno := replace(vpartno, 'H', 'F');
              end if;

              update taxdoc td
              set    partidano = vpartno
              where  td.taxdoc_id = iptaxdoc_id;
              update debtsubject ds
              set    partidano = vpartno
              where  ds.document_id = iptaxdoc_id
              and    ds.partidano is null;
            end if;
          end if;
          perform taxvaluation.arxdoc(iptaxdoc_id);
          --commit;
          --'???????????? ?? ?? ?? ????????? ?????? <' ||
          -- to_char(vbegintaxdate,'dd.mm.yyyy') || '>' ;
        end if;
        ------------------
      else
        if nvl(ipkindcorr, '0') = '1'
        then
          vkindcorr := '1';
        else
          vkindcorr := '3';
        end if;
        opStatus     := 'OK'; -- 'errOrclNoData';  ---'??????????? ?? ? ?????? !!!';
        if vchange_date is null
        then
          vchange_date := add_months(rtaxdoc.begintaxdate, -1);
        end if;

        vchange_date := to_date('01' ||
                                to_char(add_months(vchange_date, 1), 'mmyyyy'),
                                'ddmmyyyy');
      
        select min(c.configvalue)
        into   vBEGINOBL2
        from   config c
        where  c.name = 'BEGINOBL2'
        and    c.municipality_id = mymunicipality_id;
        if vbegintaxdate is null
        then
          vbegintaxdate := nvl(to_date(vBEGINOBL2, 'yyyy'),
                               to_date('01.01.2004', 'dd.mm.yyyy'));
        end if;
        --     if  vchange_date < nvl(to_date(vBEGINOBL2,'yyyy'),to_date('01.01.2004','dd.mm.yyyy')) then
        --      vchange_date := nvl(to_date(vBEGINOBL2,'yyyy'),to_date('01.01.2004','dd.mm.yyyy'));
        --      end if;
        if vchange_date < vbegintaxdate
        then
          vchange_date := vbegintaxdate;
        end if;
      
        vcorrYear := to_number(to_char(vchange_date, 'yyyy'));
        select max(tp.taxperiod_id)
        into   vtaxper_id
        from   taxperiod tp
        where  tp.taxperkind = '0'
        and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
        select max(ds.debtsubject_id)
        into   vds_id
        from   debtsubject ds, kinddebtreg dr
        where  ds.document_id = iptaxdoc_Id
        and    ds.kinddebtreg_id = dr.kinddebtreg_id
        and    dr.code = '2100'
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate)
        
        ;
        select max(ds.debtsubject_id)
        into   vtbods_id
        from   debtsubject ds, kinddebtreg dr
        where  ds.document_id = iptaxdoc_Id
        and    ds.kinddebtreg_id = dr.kinddebtreg_id
        and    dr.code = '2400'
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate);
        --  vbegintaxdate := to_date('01.' || to_char(add_months(vchange_date,1),'mm.yyyy'),'dd.mm.yyyy');
        vbegintaxdate := vchange_date;
        vendtaxdate   := to_date('31.12.' || to_char(vchange_date, 'yyyy'),
                                 'dd.mm.yyyy');
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR14';
        if vbegintaxdate > to_date('31.12.' || vtaxyear, 'dd.mm.yyyy')
        then
          opStatus := 'errNoActPer';
        else
          loop
            --- po taxperiod
          
            if (vds_id is not null) or (vtbods_id is not null)
            then
              /*select TaxProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id, 2,
                          opstatus);*/
              if rtaxdoc.decl14to17 = 2
              then
                opstatus :=  Firmprop14(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                           ipoblwr, 2);
              else
	              opstatus :=  taxvaluation.TaxProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id, 2);
              end if;

              if opStatus <> 'OK'
              then
                --rollback;
                raise exception 'ROLLBACK';
                return;
              end if;
            else
              if vcorrYear = to_number(vTaxYear)
              then
                if rtaxdoc.decl14to17 = 2
                then
                  opstatus :=  Firmprop14(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                             ipoblwr, 0);
                else
	                /*select TaxProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                            1, opstatus);*/
    	            opstatus :=  taxvaluation.TaxProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
        	                    1);
                end if;

                if opStatus <> 'OK'
                then
                  --rollback;
                  raise exception 'ROLLBACK';
                  return;
                else
                  --commit;
                  exit;
                end if;
              end if;
            end if;
            ------------------>>>>>
            open crds14(iptaxdoc_Id, vbegintaxdate, vcurtime);
            loop
              fetch crds14
                into rds14;
              exit when not FOUND;
              select max(d.debtsubject_id), sum(d.totalval), sum(d.totaltax),
                     sum(d.freesum_subj), sum(d.freesum_obj),
                     max(d.tax_begidate), max(d.tax_enddate)
              into   vdebtsubject_New, vTotalval, vtotaltax, vfrees, vfreeo,
                     vold_begindate, vold_enddate
              from   debtsubject d
              where  d.document_id = iptaxdoc_Id
              and    d.taxsubject_id = rds14.taxsubject_id
              and    d.kinddebtreg_id = rds14.kinddebtreg_id
              and    d.taxperiod_id = rds14.taxperiod_id
              and    vbegintaxdate between d.tax_begidate and d.tax_enddate
              and    d.userdate = (select max(dd.userdate)
                                   from   debtsubject dd, taxdoc td
                                   where  dd.document_id = iptaxdoc_Id
                                   and    dd.taxsubject_id = d.taxsubject_id
                                   and    dd.kinddebtreg_id = d.kinddebtreg_id
                                   and    vbegintaxdate between dd.tax_begidate and
                                          dd.tax_enddate
                                   and    dd.userdate < vcurtime);
              if vdebtsubject_New is not null
              then
                newper := round(months_between(vold_enddate, vold_begindate));
                if coalesce(newper, 0) < 0
                then
                  newper := 0;
                end if;
                oldper := round(months_between(rds14.tax_begidate,
                                               vold_begindate));
                if coalesce(oldper, 0) <= 0
                then
                  oldper := 1;
                end if;
              
                --    vtaxbefore := nvl(rds14.taxbefore,0) + round(rds14.totaltax * newper / oldper,2);
                --    if vdebtsubject_New is null then
                --    vTotalval := round(rds14.totalval * newper / oldper,2);
                --    end if;
                --    vtotaltax := nvl(vtotaltax,0) + vtaxbefore;
              
                -----  danak do data na promjana !!!!
                vtaxbefore := 0;
                --      vtotaltax  := 0;
                --      open crdpp(rds14.debtsubject_id);
                open crdpp(vdebtsubject_New);
                loop
                  fetch crdpp
                    into rdpp;
                  exit when not FOUND;
                  --    oldper := round(months_between(vold_enddate, vold_begindate));
                  oldper := round(months_between(rdpp.taxenddate::date,
                                                 rdpp.taxbegindate::date));
                  if coalesce(oldper, 0) <= 0
                  then
                    oldper := 1;
                  end if;
                 if  rds14.tax_begidate > rdpp.taxenddate then 
                  newper := round(months_between(rdpp.taxenddate::date,
                                                 rdpp.taxbegindate::date));
                  else
                  newper := round(months_between(rds14.tax_begidate::date,
                                                 rdpp.taxbegindate::date));
                 end if;                                
                  if coalesce(newper, 0) < 0
                  then
                    newper := 0;
                  end if;
                  vtaxbefore := vtaxbefore + nvl(rdpp.taxbefore, 0.0) +
                                round(rdpp.totaltax * newper / oldper, 2);
                  select count(*) into i
                  from debtpartproperty pp
                  where  pp.debtsubject_id = rds14.debtsubject_id
                  and    pp.homeobj_id = rdpp.homeobj_id;
                  if i > 0 then                  
                  update debtpartproperty pp
                  set    taxbefore = nvl(rdpp.taxbefore, 0.0) +
                                         round(rdpp.totaltax * newper / oldper, 2),
                         parentdebtprop_id = rdpp.debtpartproperty_id
                  where  pp.debtsubject_id = rds14.debtsubject_id
                  and    pp.homeobj_id = rdpp.homeobj_id;
                  else 
             
                    insert into debtpartproperty 
                    (debtpartproperty_id, debtsubject_id, taxperiod_id, 
                    kindproperty, seqnots, typedeclar, isbasehome, 
                    isrelief, relief_id, divident, divisor, part, 
                    sumval, sumtax, taxbegindate, taxenddate, totalval, 
                    totaltax, userdate, user_id, homeobj_id, freefrom, 
                    freemonths, codetbo, promiltbo, freesuma_obj, 
                    freesuma_subj, parentdebtprop_id, subjpartval, 
                    proporgobj_id, kindobligation, fsw, fclean, fdepot, 
                    koeff, taxbefore)
                    select s_debtpartproperty.nextval, rds14.debtsubject_id, rdpp.taxperiod_id, 
                    rdpp.kindproperty, rdpp.seqnots, rdpp.typedeclar, rdpp.isbasehome, 
                    rdpp.isrelief, rdpp.relief_id, rdpp.divident, rdpp.divisor, rdpp.part, 
                    rdpp.sumval, rdpp.sumtax, rdpp.taxbegindate, rdpp.taxenddate, rdpp.totalval, 
                    0, rdpp.userdate, rdpp.user_id, rdpp.homeobj_id, rdpp.freefrom, 
                    rdpp.freemonths, rdpp.codetbo, rdpp.promiltbo, rdpp.freesuma_obj, 
                    rdpp.freesuma_subj, rdpp.parentdebtprop_id, rdpp.subjpartval, 
                    rdpp.proporgobj_id, rdpp.kindobligation,rdpp.fsw, rdpp.fclean, rdpp.fdepot, 
                    rdpp.koeff, rdpp.taxbefore + rdpp.totaltax
                    from dual;
                  end if;
                end loop;
                close crdpp;
                vtotaltax := nvl(rds14.totaltax, 0.0) + nvl(vtaxbefore, 0.0);
                select round(sum(nvl(pp.sumval, 0.0)), 2)
                into   vtotalval
                from   debtpartproperty pp
                where  pp.debtsubject_id = rds14.debtsubject_id;
                select coalesce(ds.parent_debtsubject_id, ds.debtsubject_id)
                into   vdebtsubject_New
                from   debtsubject ds
                where  ds.debtsubject_id = vdebtsubject_New;
                
                /*select corroldds(vdebtsubject_New, vtotalval, vtotaltax, null, null,
                          vbegintaxdate, vendtaxdate, ipuser_Id, rds14.doc_date,
                          rds14.docno, vchange_date, null, vreasontxt, null,
                          null, trunc(current_date),
                          --iptermpay_date,
                          rds14.debtsubject_id, ipInterestBegdate,
                          rds14.taxsubject_id, rds14.kinddebtreg_id, null,
                          vkindcorr, opStatus);*/
                opStatus := public.corroldds(vdebtsubject_New, vtotalval, vtotaltax, null, null,
                          vbegintaxdate, vendtaxdate, ipuser_Id, rds14.doc_date,
                          rds14.docno, vchange_date, null, vreasontxt, null,
                          null, trunc(current_date),
                          --iptermpay_date,
                          rds14.debtsubject_id, ipInterestBegdate,
                          rds14.taxsubject_id, rds14.kinddebtreg_id, null,
                          vkindcorr);
                --commit; ---- !!!!!
              end if;
            end loop;
            close crds14;
            --------- sledvasht period !!!
            vcorryear := vcorryear + 1;
            select max(tp.taxperiod_id)
            into   vtaxper_id
            from   taxperiod tp
            where  tp.taxperkind = '0'
            and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
            if vtaxper_id is null
            then
              exit;
            end if;
            vbegintaxdate := to_date('01.01.' || vcorrYear, 'dd.mm.yyyy');
            vendtaxdate   := to_date('31.12.' || vcorrYear, 'dd.mm.yyyy');
            select max(ds.debtsubject_id)
            into   vds_id
            from   debtsubject ds, kinddebtreg dr
            where  ds.document_id = iptaxdoc_Id
            and    ds.kinddebtreg_id = dr.kinddebtreg_id
            and    dr.code = '2100'
            and    ds.taxperiod_id = vtaxper_id
            and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate;
          
            select max(ds.debtsubject_id)
            into   vtbods_id
            from   debtsubject ds, kinddebtreg dr
            where  ds.document_id = iptaxdoc_Id
            and    ds.kinddebtreg_id = dr.kinddebtreg_id
            and    dr.code = '2400'
            and    ds.taxperiod_id = vtaxper_id
            and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate;
            if (vds_id is null) and (vtbods_id is null) and
               (vcorrYear <> to_number(vTaxYear))
            then
              exit;
            end if;
          end loop;
        end if;
        update taxdoc td
        set    docstatus = '30'
        where  td.taxdoc_id = iptaxdoc_id;
        --commit;
        perform taxvaluation.arxdoc(iptaxdoc_id);
      end if;
    end if;
    --------------------------
    if vdoccode = '17'
    then
      if (vreasoncode = 'df1') and (nvl(ipkindcorr, '0') <> '1')
      then
        select *
        into   rtaxdoc
        from   taxdoc t
        where  t.taxdoc_id = iptaxdoc_Id;
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR17';
        if rtaxdoc.earn_date is not null
        then
          rtaxdoc.earn_date := to_date('01.' ||
                                       to_char(add_months(rtaxdoc.earn_date, 1),
                                               'mm.yyyy'), 'dd.mm.yyyy');
          vbegintaxdate     := coalesce(vbegintaxdate, rtaxdoc.earn_date::date);
        elsif rtaxdoc.begintaxdate is not null
        then
          vbegintaxdate := to_date('01.' ||
                                   to_char(rtaxdoc.begintaxdate, 'mm.yyyy'),
                                   'dd.mm.yyyy');
        end if;
        if vbegintaxdate is null
        then
          opStatus := 'errMissBD'; -- 'TaxProperty - ?????? ??????? ???? !';
          return;
        end if;
        if vbegintaxdate < to_date('31.12.' || vtaxyear, 'dd.mm.yyyy')
        then
          /*select FirmProperty(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id,
                       ipoblwr, vStatus, 0, vtotalval, vtotaltax, vtbotax);*/
          select into firmPropertyRec * from taxvaluation.FirmProperty(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id,
                       ipoblwr, 0);
          vStatus := firmPropertyRec.ipstatus;
          vtotalval := firmPropertyRec.optotalval;
          vtotaltax := firmPropertyRec.optotaltax;
          vtbotax := firmPropertyRec.optbototaltax;
          if vStatus <> 'OK'
          then
            if ipoblwr = 2 and vStatus = 'errDiferData'
            then
              opStatus := 'OK';
            else
              opStatus := vStatus; ---'firmProperty - ' ||
            end if;
            --rollback;
            --    return (opStatus);
          else
            opStatus := vStatus;
            update taxdoc td
            set    docstatus = '30'
            where  td.taxdoc_id = iptaxdoc_id;
            if vpartno is null
            then
             --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
             vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
              if vpartno <> '-1'
              then
                update taxdoc td
                set    partidano = vpartno
                where  td.taxdoc_id = iptaxdoc_id;
                update debtsubject ds
                set    partidano = vpartno
                where  ds.document_id = iptaxdoc_id
                and    ds.partidano is null;
              end if;
            end if;
            perform taxvaluation.upd_doc14(iptaxdoc_id);
            perform taxvaluation.arxdoc(iptaxdoc_id);
            --commit;
          end if;
        else
          opStatus := 'errNoActPer';
       select tp.taxperiod_id into vtaxper_id from taxperiod tp
       where tp.taxperkind = 0
       and to_char(tp.begin_date,'yyyy') =  vtaxyear
       ;
-----------
      select nextval('s_debtsubject') into vdebtsubject_New;
       insert into debtsubject
       (debtsubject_id, taxsubject_id, document_id,
       kinddoc, kinddebtreg_id, taxperiod_id, doccode,
       tax_begidate, tax_enddate, totalval,
       totaltax, calcdate,inst_number, userdate,
       user_id, taxobject_id, partidano,
       municipality_id, kindparreg_id, docno, doc_date
       )
      values(vdebtsubject_New,rtaxdoc.taxsubject_id,iptaxdoc_Id,
        1,2, vtaxper_id, '17',to_date('01.12.'||vtaxyear,'dd.mm.yyyy'),
        to_date('31.12.'||vtaxyear,'dd.mm.yyyy'),0,0,
        current_date, 1, CURRENT_TIMESTAMP, ipuser_id,rtaxdoc.taxobject_id,
        rTaxDoc.Partidano,rtaxdoc.municipality_id, 2,rtaxdoc.docno,
        rtaxdoc.doc_date
        );
       insert into debtinstalment
       (debtinstalment_id, debtsubject_id, instno,
       termpay_date, instsum, intbegindate, paysum)
       values (nextval('s_debtinstalment'), vdebtsubject_New,
       1,current_date, 0,null,0);

          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = iptaxdoc_id;
          if vpartno is null
          then
            --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
            vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
            if vpartno <> '-1'
            then
              update taxdoc td
              set    partidano = vpartno
              where  td.taxdoc_id = iptaxdoc_id;
              update debtsubject ds
              set    partidano = vpartno
              where  ds.document_id = iptaxdoc_id
              and    ds.partidano is null;
            end if;
          end if;
          --'???????????? ?? ?? ?? ????????? ?????? <' ||
          -- to_char(vbegintaxdate,'dd.mm.yyyy') || '>' ;
          perform taxvaluation.upd_doc14(iptaxdoc_id);
          --commit;
          perform taxvaluation.arxdoc(iptaxdoc_id);
          --commit;
        end if;
        ------------------
      else
        opStatus := 'OK';
        if nvl(ipkindcorr, '0') = '1'
        then
          vkindcorr := '1';
        else
          vkindcorr := '3';
        end if;
        ----------
        vchange_date := to_date('01.' ||
                                to_char(add_months(vchange_date, 1), 'mm.yyyy'),
                                'dd.mm.yyyy');
      
        select min(c.configvalue)
        into   vBEGINOBL2
        from   config c
        where  c.name = 'BEGINOBL2'
        and    c.municipality_id = mymunicipality_id;
        if vbegintaxdate is null
        then
          vbegintaxdate := nvl(to_date(vBEGINOBL2, 'yyyy'),
                               to_date('01.01.2004', 'dd.mm.yyyy'));
        end if;
        --      if  vchange_date < nvl(to_date(vBEGINOBL2,'yyyy'),to_date('01.01.2004','dd.mm.yyyy')) then
        --       vchange_date := nvl(to_date(vBEGINOBL2,'yyyy'),to_date('01.01.2004','dd.mm.yyyy'));
        --      end if;
        if vchange_date < vbegintaxdate
        then
          vchange_date := vbegintaxdate;
        end if;
      
        vcorrYear := to_number(to_char(vchange_date, 'yyyy'));
        select max(tp.taxperiod_id)
        into   vtaxper_id
        from   taxperiod tp
        where  tp.taxperkind = '0'
        and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
        select max(ds.debtsubject_id)
        into   vds_id
        from   debtsubject ds, kinddebtreg dr
        where  ds.document_id = iptaxdoc_Id
        and    ds.kinddebtreg_id = dr.kinddebtreg_id
        and    dr.code = '2100'
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    dd.taxsubject_id = ds.taxsubject_id
                 and    dd.taxperiod_id = ds.taxperiod_id
                 and    dd.kinddebtreg_id = ds.kinddebtreg_id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate);
        select max(ds.debtsubject_id)
        into   vtbods_id
        from   debtsubject ds, kinddebtreg dr
        where  ds.document_id = iptaxdoc_Id
        and    ds.kinddebtreg_id = dr.kinddebtreg_id
        and    dr.code = '2400'
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    dd.taxsubject_id = ds.taxsubject_id
                 and    dd.taxperiod_id = ds.taxperiod_id
                 and    dd.kinddebtreg_id = ds.kinddebtreg_id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate);
        vbegintaxdate := vchange_date; --to_date('01.' || to_char(add_months(vchange_date,1),'mm.yyyy'),'dd.mm.yyyy');
        vendtaxdate   := to_date('31.12.' || to_char(vchange_date, 'yyyy'),
                                 'dd.mm.yyyy');
      
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR17';
        loop
          --- po taxperiod
          if (vds_id is null) and (vtbods_id is null) and
             (to_number(vTaxYear) = vcorryear)
          then
            /*select FirmProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                         ipoblwr, opstatus, 0, vtotalval, vtotaltax, vtbotax);*/
            select into firmPropertyRec * from taxvaluation.FirmProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                         ipoblwr, 0);
          opstatus := firmPropertyRec.ipstatus;
          vtotalval := firmPropertyRec.optotalval;
          vtotaltax := firmPropertyRec.optotaltax;
          vtbotax := firmPropertyRec.optbototaltax;
            if opstatus <> 'OK'
            then
              if ipoblwr = 2 and vStatus = 'errDiferData'
              then
                opStatus := 'OK';
              end if;
              --rollback;
              --    return (opStatus);
            else
              exit;
            end if;
          end if;
          /*select FirmProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                       ipoblwr, opstatus, 2, vtotalval, vtotaltax, vtbotax);*/
          select into firmPropertyRec * from taxvaluation.FirmProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                       ipoblwr, 2);
          opstatus := firmPropertyRec.ipstatus;
          vtotalval := firmPropertyRec.optotalval;
          vtotaltax := firmPropertyRec.optotaltax;
          vtbotax := firmPropertyRec.optbototaltax;
          if opStatus <> 'OK'
          then
            if ipoblwr = 2 and opStatus = 'errDiferData'
            then
              opStatus := 'OK';
              --       else
              --         opStatus := vStatus;   ---'firmProperty - ' ||
            end if;
            --rollback;
            raise exception 'ROLLBACK'; 
            return;
          end if;
          if vds_id is not null
          then
            select max(ds.debtsubject_id)
            into   vdebtsubject_New
            from   debtsubject ds, kinddebtreg dr
            where  ds.document_id = iptaxdoc_Id
            and    ds.kinddebtreg_id = dr.kinddebtreg_id
            and    dr.code = '2100'
            and    ds.taxperiod_id = vtaxper_id
            and    ds.userdate > vcurtime;
            -----  danak do data na promjana !!!!
            vtaxbefore := 0;
            --      vtotaltax  := 0;
            open crdpp(vds_id);
            loop
              fetch crdpp
                into rdpp;
              exit when not FOUND;
              oldper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
              if vbegintaxdate > rdpp.taxenddate then
               newper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
              else
               newper := round(months_between(vbegintaxdate::date, rdpp.taxbegindate::date));
              end if;
              if newper < 0
              then
                newper := 0;
              end if;
              if oldper <= 0
              then
                oldper := 1;
              end if;
              vtaxbefore := vtaxbefore + nvl(rdpp.taxbefore, 0.0) +
                            round(rdpp.totaltax * newper / oldper, 2);
              select count(*) into i
              from  debtpartproperty pp
              where  pp.debtsubject_id = vdebtsubject_New
              and    pp.homeobj_id = rdpp.homeobj_id;
              if i > 0 then             
              update debtpartproperty pp
              set    taxbefore = nvl(rdpp.taxbefore, 0.0) +
                                     round(rdpp.totaltax * newper / oldper, 2),
                     parentdebtprop_id = rdpp.debtpartproperty_id
              where  pp.debtsubject_id = vdebtsubject_New
              and    pp.homeobj_id = rdpp.homeobj_id;
              else
                    insert into debtpartproperty 
                    (debtpartproperty_id, debtsubject_id, taxperiod_id, 
                    kindproperty, seqnots, typedeclar, isbasehome, 
                    isrelief, relief_id, divident, divisor, part, 
                    sumval, sumtax, taxbegindate, taxenddate, totalval, 
                    totaltax, userdate, user_id, homeobj_id, freefrom, 
                    freemonths, codetbo, promiltbo, freesuma_obj, 
                    freesuma_subj, parentdebtprop_id, subjpartval, 
                    proporgobj_id, kindobligation, fsw, fclean, fdepot, 
                    koeff, taxbefore)
                    select s_debtpartproperty.nextval, vdebtsubject_New, rdpp.taxperiod_id, 
                    rdpp.kindproperty, rdpp.seqnots, rdpp.typedeclar, rdpp.isbasehome, 
                    rdpp.isrelief, rdpp.relief_id, rdpp.divident, rdpp.divisor, rdpp.part, 
                    rdpp.sumval, rdpp.sumtax, rdpp.taxbegindate, rdpp.taxenddate, rdpp.totalval, 
                    0, rdpp.userdate, rdpp.user_id, rdpp.homeobj_id, rdpp.freefrom, 
                    rdpp.freemonths, rdpp.codetbo, rdpp.promiltbo, rdpp.freesuma_obj, 
                    rdpp.freesuma_subj, rdpp.parentdebtprop_id, rdpp.subjpartval, 
                    rdpp.proporgobj_id, rdpp.kindobligation,rdpp.fsw, rdpp.fclean, rdpp.fdepot, 
                    rdpp.koeff, rdpp.taxbefore + rdpp.totaltax
                    from dual;
              end if;
            end loop;
            close crdpp;
            vtotaltax := vtotaltax + vtaxbefore;
            select ds.parent_debtsubject_id
            into   vpds_id
            from   debtsubject ds
            where  ds.debtsubject_id = vds_id;
            /*select corroldds(nvl(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                      vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                      docno_new, vchange_date, null, vreasontxt, null, null,
                      trunc(current_date),
                      --iptermpay_date,
                      vdebtsubject_New, ipInterestBegdate, null, null, null,
                      vkindcorr, opStatus);*/
            opStatus := public.corroldds(coalesce(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                      vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                      docno_new, vchange_date, null, vreasontxt, null, null,
                      trunc(current_date),
                      --iptermpay_date,
                      vdebtsubject_New, ipInterestBegdate, null, null, null,
                      vkindcorr);
          end if;
          if opStatus <> 'OK'
          then
            raise exception 'ROLLBACK'; 
            --rollback;
            return;
          end if;
          ----- TBO -----
          if vtbods_id is not null
          then
            select max(ds.debtsubject_id)
            into   vdebtsubject_New
            from   debtsubject ds, kinddebtreg dr
            where  ds.document_id = iptaxdoc_Id
            and    ds.kinddebtreg_id = dr.kinddebtreg_id
            and    dr.code = '2400'
            and    ds.taxperiod_id = vtaxper_id
            and    ds.userdate > vcurtime;
            -----  danak do data na promjana !!!!
            vtaxbefore := 0;
            --      vtotaltax  := 0;
          
            open crdpp(vtbods_id);
            loop
              fetch crdpp
                into rdpp;
              exit when not FOUND;
              oldper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
              if vbegintaxdate > rdpp.taxenddate then
               newper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
              else
               newper := round(months_between(vbegintaxdate::date, rdpp.taxbegindate::date));
              end if;
              if newper < 0
              then
                newper := 0;
              end if;
              if oldper <= 0
              then
                oldper := 1;
              end if;
              vtaxbefore := vtaxbefore + nvl(rdpp.taxbefore, 0.0) +
                            round(rdpp.totaltax * newper / oldper, 2);
              select count(*) into i
              from  debtpartproperty pp
              where  pp.debtsubject_id = vdebtsubject_New
              and    pp.homeobj_id = rdpp.homeobj_id;
              if i > 0 then             
              update debtpartproperty pp
              set    taxbefore = nvl(rdpp.taxbefore, 0.0) +
                                     round(rdpp.totaltax * newper / oldper, 2),
                     parentdebtprop_id = rdpp.debtpartproperty_id
              where  pp.debtsubject_id = vdebtsubject_New
              and    pp.homeobj_id = rdpp.homeobj_id;
              else
                    insert into debtpartproperty 
                    (debtpartproperty_id, debtsubject_id, taxperiod_id, 
                    kindproperty, seqnots, typedeclar, isbasehome, 
                    isrelief, relief_id, divident, divisor, part, 
                    sumval, sumtax, taxbegindate, taxenddate, totalval, 
                    totaltax, userdate, user_id, homeobj_id, freefrom, 
                    freemonths, codetbo, promiltbo, freesuma_obj, 
                    freesuma_subj, parentdebtprop_id, subjpartval, 
                    proporgobj_id, kindobligation, fsw, fclean, fdepot, 
                    koeff, taxbefore)
                    select s_debtpartproperty.nextval, vdebtsubject_New, rdpp.taxperiod_id, 
                    rdpp.kindproperty, rdpp.seqnots, rdpp.typedeclar, rdpp.isbasehome, 
                    rdpp.isrelief, rdpp.relief_id, rdpp.divident, rdpp.divisor, rdpp.part, 
                    rdpp.sumval, rdpp.sumtax, rdpp.taxbegindate, rdpp.taxenddate, rdpp.totalval, 
                    0, rdpp.userdate, rdpp.user_id, rdpp.homeobj_id, rdpp.freefrom, 
                    rdpp.freemonths, rdpp.codetbo, rdpp.promiltbo, rdpp.freesuma_obj, 
                    rdpp.freesuma_subj, rdpp.parentdebtprop_id, rdpp.subjpartval, 
                    rdpp.proporgobj_id, rdpp.kindobligation,rdpp.fsw, rdpp.fclean, rdpp.fdepot, 
                    rdpp.koeff, rdpp.taxbefore + rdpp.totaltax
                    from dual;
              end if;
            end loop;
            close crdpp;
            vtbotax := nvl(vtbotax, 0.0) + vtaxbefore;
            select ds.parent_debtsubject_id
            into   vptbods_id
            from   debtsubject ds
            where  ds.debtsubject_id = vtbods_id;
            /*select corroldds(nvl(vptbods_id, vtbods_id), vTotalval, vtbotax, null,
                      null, vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                      docno_new, vchange_date, null, vreasontxt, null, null,
                      trunc(current_date),
                      --iptermpay_date,
                      vdebtsubject_New, ipInterestBegdate, null, null, null,
                      vkindcorr, opStatus);*/
            opStatus := public.corroldds(coalesce(vptbods_id, vtbods_id), vTotalval, vtbotax, null,
                      null, vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                      docno_new, vchange_date, null, vreasontxt, null, null,
                      trunc(current_date),
                      --iptermpay_date,
                      vdebtsubject_New, ipInterestBegdate, null, null, null,
                      vkindcorr);
          end if;
          if opStatus <> 'OK'
          then
            raise exception 'ROLLBACK';
            --rollback;
            return;
          end if;
        
          --commit; ---- !!!!!
          --------- sledvasht period !!!
          vcorryear := vcorryear + 1;
          select max(tp.taxperiod_id)
          into   vtaxper_id
          from   taxperiod tp
          where  tp.taxperkind = '0'
          and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
          if vtaxper_id is null
          then
            exit;
          end if;
          vbegintaxdate := to_date('01.01.' || vcorrYear, 'dd.mm.yyyy');
          vendtaxdate   := to_date('31.12.' || vcorrYear, 'dd.mm.yyyy');
          select max(ds.debtsubject_id)
          into   vds_id
          from   debtsubject ds, kinddebtreg dr
          where  ds.document_id = iptaxdoc_Id
          and    ds.kinddebtreg_id = dr.kinddebtreg_id
          and    dr.code = '2100'
          and    ds.taxperiod_id = vtaxper_id
          and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate
          and    ds.userdate = (select max(dd.userdate)
                                from   debtsubject dd
                                where  dd.document_id = iptaxdoc_Id
                                and    dd.taxsubject_id = ds.taxsubject_id
                                and    dd.taxperiod_id = ds.taxperiod_id
                                and    dd.kinddebtreg_id = ds.kinddebtreg_id
                                and    vbegintaxdate between dd.tax_begidate and
                                       dd.tax_enddate);
          
          select max(ds.debtsubject_id)
          into   vtbods_id
          from   debtsubject ds, kinddebtreg dr
          where  ds.document_id = iptaxdoc_Id
          and    ds.kinddebtreg_id = dr.kinddebtreg_id
          and    dr.code = '2400'
          and    ds.taxperiod_id = vtaxper_id
          and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate
          and    ds.userdate = (select max(dd.userdate)
                                from   debtsubject dd
                                where  dd.document_id = iptaxdoc_Id
                                and    dd.taxsubject_id = ds.taxsubject_id
                                and    dd.taxperiod_id = ds.taxperiod_id
                                and    dd.kinddebtreg_id = ds.kinddebtreg_id
                                and    vbegintaxdate between dd.tax_begidate and
                                       dd.tax_enddate);
          if (vds_id is null) and (vtbods_id is null) and
             (to_number(vTaxYear) <> vcorryear)
          then
            exit;
          end if;
        end loop;
        update taxdoc td
        set    docstatus = '30'
        where  td.taxdoc_id = iptaxdoc_id;
        perform taxvaluation.upd_doc14(iptaxdoc_id);
        --commit;
        perform taxvaluation.arxdoc(iptaxdoc_id);
      end if;
    end if;
    --------------------
    if substr(vdoccode, 1, 2) = '54'
    then
      select c.configvalue
      into   vTaxYear
      from   config c
      where  c.municipality_id = mymunicipality_id
      and    c.name = 'TAXYEAR54';
      if ((vreasoncode = 'ps11') or (vreasoncode = 'ps21') or
         (vreasoncode = 'ps31') or (vreasoncode = 'ps41')) and
         (nvl(ipkindcorr, '0') <> '1')
      then
        select *
        into   rtaxdoc
        from   taxdoc t
        where  t.taxdoc_id = iptaxdoc_Id;
        if vbegintaxdate is null
        then
          opStatus := 'errMissBD'; --'TaxProperty - ?????? ??????? ???? !';
          return;
        end if;
        if vbegintaxdate < to_date('31.12.' || vtaxyear, 'dd.mm.yyyy')
        then
          vStatus := taxvaluation.Taxtransport(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id, 0.0);

          /*select Taxtransport(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id,
                       vStatus, 0);*/
          if (vStatus <> 'OK') and (vStatus <> 'errNoDuty')
          then
            opStatus := vStatus;
            --rollback;
            --    return (opStatus);
          else
            opStatus := vStatus;
            update taxdoc td
            set    docstatus = '30'
            where  td.taxdoc_id = iptaxdoc_id;
            if vpartno is null
            then
              --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
              vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
              if vpartno <> '-1'
              then
                update taxdoc td
                set    partidano = vpartno
                where  td.taxdoc_id = iptaxdoc_id;
                update debtsubject ds
                set    partidano = vpartno
                where  ds.document_id = iptaxdoc_id
                and    ds.partidano is null;
              end if;
            end if;
            perform taxvaluation.arxdoc(iptaxdoc_id);
            --commit;
          end if;
        else
          opStatus := 'errNoActPer';
          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = iptaxdoc_id;
          if vpartno is null
          then
            --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
            vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
            --       end if;
            if vpartno <> '-1'
            then
              update taxdoc td
              set    partidano = vpartno
              where  td.taxdoc_id = iptaxdoc_id;
              update debtsubject ds
              set    partidano = vpartno
              where  ds.document_id = iptaxdoc_id
              and    ds.partidano is null;
            end if;
          end if;
          --'???????????? ?? ?? ?? ????????? ?????? <' ||
          -- to_char(vbegintaxdate,'dd.mm.yyyy') || '>' ;
          perform taxvaluation.arxdoc(iptaxdoc_id);
          --commit;
        end if;
        ------------------
      else
        if nvl(ipkindcorr, '0') = '1'
        then
          vkindcorr := '1';
        else
          vkindcorr := '3';
        end if;
        if vbegintaxdate > vchange_date
        then
          vchange_date := vbegintaxdate;
        end if;
        vcorrYear := to_number(to_char(vchange_date, 'yyyy'));
        select max(tp.taxperiod_id)
        into   vtaxper_id
        from   taxperiod tp
        where  tp.taxperkind = '0'
        and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
      
        select max(ds.debtsubject_id)
        into   vds_id
        from   debtsubject ds
        where  ds.document_id = iptaxdoc_Id
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd, taxdoc td
                 where  dd.document_id = iptaxdoc_Id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate
                 and    dd.userdate < vcurtime);
        if nvl(ipkindcorr, '0') = '1' and
           ((vreasoncode = 'ps11') or (vreasoncode = 'ps21') or
            (vreasoncode = 'ps31') or (vreasoncode = 'ps41'))
        then
          vbegintaxdate := to_date('01.' || to_char(vchange_date, 'mm.yyyy'),
                                   'dd.mm.yyyy');
        else
          --        vbegintaxdate := to_date('01.' || to_char(add_months(vchange_date,1),'mm.yyyy'),'dd.mm.yyyy');
          vbegintaxdate := to_date('01.' || to_char(vchange_date, 'mm.yyyy'),
                                   'dd.mm.yyyy');
        end if;
        vendtaxdate := to_date('31.12.' || to_char(vchange_date, 'yyyy'),
                               'dd.mm.yyyy');
      
        ----- nov danak !!!
        loop
          if vbegintaxdate < vendtaxdate
          then
             opstatus := taxvaluation.taxtransport(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id, 2.0);
           /*select taxtransport(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                         opstatus, 2);*/

            if opStatus <> 'OK' and (opStatus <> 'errNoDuty')
            then
              --rollback;
              raise exception 'ROLLBACK'; 
              return;
            end if;
          
            if vds_id is not null
            then
              open crds(iptaxdoc_Id, vbegintaxdate, docno_new, doc_date_new,
                        vcurtime);
              loop
                fetch crds
                  into rds;
                exit when not FOUND;
                select max(d.debtsubject_id), sum(d.totalval), sum(d.totaltax),
                       sum(d.freesum_subj), sum(d.freesum_obj)
                into   vdebtsubject_New, vTotalval, vtotaltax, vfrees, vfreeo
                from   debtsubject d, taxdoc td
                where  d.document_id = td.taxdoc_id
                and    td.taxdoc_id = iptaxdoc_Id
                and    td.docno = d.docno
                and    td.doc_date = d.doc_date
                and    d.taxperiod_id = rds.taxperiod_id
                and    d.taxsubject_id = rds.taxsubject_id
                and    d.userdate > vcurtime;
                select min(d.debtsubject_id)
                into   vdebtsubject_old
                from   debtsubject d
                where  d.document_id = iptaxdoc_id
                and    d.taxsubject_id = rds.taxsubject_id
                and    d.taxperiod_id = rds.taxperiod_id
                and    d.userdate < vcurtime
                and    d.parent_debtsubject_id is null;
                oldper     := round(months_between(rds.tax_enddate,
                                                   rds.tax_begidate));
                newper     := round(months_between(vbegintaxdate,
                                                   rds.tax_begidate));
                vtaxbefore := nvl(rds.taxbefore, 0.0) +
                              round(nvl(rds.totaltax, 0.0) * newper / oldper, 2);
                if vdebtsubject_New is null
                then
                  vTotalval := round(rds.totalval * newper / oldper, 2);
                end if;
                vtotaltax := nvl(vtotaltax, 0.0) + vtaxbefore;
                /*select corroldds(vdebtsubject_old, vTotalval, vtotaltax, vfrees,
                          vfreeo, vbegintaxdate, vendtaxdate, ipuser_Id,
                          doc_date_new, docno_new, vchange_date, null,
                          vreasontxt, null, null, trunc(current_date),
                          --iptermpay_date,
                          vdebtsubject_New, ipInterestBegdate, null, null, null,
                          vkindcorr, opStatus);*/
                opStatus := public.corroldds(vdebtsubject_old, vTotalval, vtotaltax, vfrees,
                          vfreeo, vbegintaxdate, vendtaxdate, ipuser_Id,
                          doc_date_new, docno_new, vchange_date, null,
                          vreasontxt, null, null, trunc(current_date),
                          --iptermpay_date,
                          vdebtsubject_New, ipInterestBegdate, null, null, null,
                          vkindcorr);
                if opStatus <> 'OK'
                then
                  --rollback;
                  raise exception 'ROLLBACK'; 
                  return;
                end if;
                if vdebtsubject_New is not null
                then
                  update debtpartproperty pp
                  set    taxbefore = nvl(rds.taxbefore, 0.0) +
                                         round(rds.totaltax * newper / oldper, 2),
                         parentdebtprop_id = rds.debtpartproperty_id
                  where  pp.debtsubject_id = vdebtsubject_New
                  and    pp.homeobj_id = rds.homeobj_id;
                else
                  insert into debtpartproperty
                    (debtpartproperty_id, debtsubject_id, taxperiod_id,
                     kindproperty, seqnots, typedeclar, divident, divisor, part,
                     sumval, sumtax, taxbegindate, taxenddate, totalval,
                     totaltax, userdate, user_id, homeobj_id, taxbefore)
                    select nextval('s_debtpartproperty'), d.debtsubject_id,
                           vtaxper_id, null, null, null, 0, 0, 0, null, null,
                           d.tax_begidate, d.tax_enddate, 0, 0, CURRENT_TIMESTAMP,
                           d.user_id, d.taxobject_id, vtaxbefore
                    from   debtsubject d, taxdoc td
                    where  d.document_id = td.taxdoc_id
                    and    td.taxdoc_id = iptaxdoc_Id
                    and    td.docno = d.docno
                    and    td.doc_date = d.doc_date
                    and    d.taxsubject_id = rds.taxsubject_id;
                end if;
                --commit;
              end loop;
              close crds;
            end if;
          else
            if vcorrYear = vTaxYear
            then
              opStatus := 'errNoDuty';
              exit;
            end if;
          end if;
          vcorrYear     := vcorrYear + 1;
          vbegintaxdate := to_date('01.01.' || to_char(vcorrYear), 'dd.mm.yyyy');
          vendtaxdate   := to_date('31.12.' || to_char(vcorrYear), 'dd.mm.yyyy');
        
          select max(tp.taxperiod_id)
          into   vtaxper_id
          from   taxperiod tp
          where  tp.taxperkind = '0'
          and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
          select max(ds.debtsubject_id)
          into   vds_id
          from   debtsubject ds
          where  ds.document_id = iptaxdoc_Id
          and    ds.taxperiod_id = vtaxper_id
          and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate;
          if vds_id is null
          then
            exit;
          end if;
        end loop;
        update taxdoc td
        set    docstatus = '30'
        where  td.taxdoc_id = iptaxdoc_id;
        --commit;
        perform taxvaluation.arxdoc(iptaxdoc_id);
      end if;
    
    end if;
    ----------------------------
    if vdoccode = '61'
    then
      select *
      into   rtaxdoc
      from   taxdoc t
      where  t.taxdoc_id = iptaxdoc_Id;
      if ((vreasoncode = '611') or (vreasoncode = '612')) and
         (nvl(ipkindcorr, '0') <> '1')
      then
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR61';
        if vbegintaxdate is null
        then
          opStatus := 'errMissBD'; --'TaxProperty - ?????? ??????? ???? !';
          return;
        end if;
        if vbegintaxdate < to_date('31.12.' || vtaxyear, 'dd.mm.yyyy')
        then
          vStatus := taxvaluation.patentval(iptaxdoc_Id, ipuser_id, 0, ipoblwr);
          if vStatus <> 'OK'
          then
            opStatus := vStatus;
            --rollback;
            --    return (opStatus);
          else
            opStatus := vStatus;
            update taxdoc td
            set    docstatus = '30'
            where  td.taxdoc_id = iptaxdoc_id;
            if vpartno is null
            then
              --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
              vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
              if vpartno <> '-1'
              then
                update taxdoc td
                set    partidano = vpartno
                where  td.taxdoc_id = iptaxdoc_id;
                update debtsubject ds
                set    partidano = vpartno
                where  ds.document_id = iptaxdoc_id
                and    ds.partidano is null;
              end if;
            end if;
            --commit;
            perform taxvaluation.arxdoc(iptaxdoc_id);
          end if;
        else
          opStatus := 'errNoActPer';
          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = iptaxdoc_id;
          if vpartno is null
          then
            --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
            vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
            if vpartno <> '-1'
            then
              update taxdoc td
              set    partidano = vpartno
              where  td.taxdoc_id = iptaxdoc_id;
              update debtsubject ds
              set    partidano = vpartno
              where  ds.document_id = iptaxdoc_id
              and    ds.partidano is null;
            end if;
          end if;
          --'???????????? ?? ?? ?? ????????? ?????? <' ||
          -- to_char(vbegintaxdate,'dd.mm.yyyy') || '>' ;
          --commit;
          perform taxvaluation.arxdoc(iptaxdoc_id);
        end if;
        ------------------
        --       return (opStatus);
      else
        --   opStatus :='??????????? ?? ? ?????? !!!';
        if nvl(ipkindcorr, '0') = '1'
        then
          vkindcorr := '1';
        else
          vkindcorr := '3';
        end if;
        if vchange_date < rTaxDoc.Begintaxdate then
          vchange_date := rTaxDoc.Begintaxdate;
        end if;
        vcorrYear := to_number(to_char(vchange_date, 'yyyy'));
        select max(tp.taxperiod_id)
        into   vtaxper_id
        from   taxperiod tp
        where  tp.taxperkind = '0'
        and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
      
        select max(ds.debtsubject_id)
        into   vds_id
        from   debtsubject ds
        where  ds.document_id = iptaxdoc_Id
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate
                 and    dd.taxperiod_id = ds.taxperiod_id
                 and    dd.taxsubject_id = ds.taxsubject_id
                 and    dd.kinddebtreg_id = ds.kinddebtreg_id
                 and    dd.userdate < vcurtime);
        --------------------
        --------------------
        vbegintaxdate := to_date('01.' ||
                                 (to_char(vchange_date, 'mm')::numeric -
                                 mod(to_char(vchange_date, 'mm')::numeric - 1, 3)) || '.' ||
                                 to_char(vchange_date, 'yyyy'), 'dd.mm.yyyy');
        vendtaxdate   := to_date('31.12.' || to_char(vchange_date, 'yyyy'),
                                 'dd.mm.yyyy');
        -------- >>>>>>>>
        opstatus := taxvaluation.patentval(iptaxdoc_Id, ipuser_id, 2, ipoblwr);
        if opStatus <> 'OK'
        then
          --rollback;
          raise exception 'ROLLBACK';
          return;
        end if;
        -----------------
        select max(d.debtsubject_id), sum(d.totalval), sum(d.totaltax),
               sum(d.freesum_subj), sum(d.freesum_obj)
        into   vdebtsubject_New, vTotalval, vtotaltax, vfrees, vfreeo
        from   debtsubject d, taxdoc td
        where  d.document_id = td.taxdoc_id
        and    td.taxdoc_id = iptaxdoc_Id
        and    td.docno = d.docno
        and    td.doc_date = d.doc_date
        and    d.taxsubject_id = coalesce(td.taxsubject_id, td.ettaxsubject_id)
        and    d.userdate = (select max(dd.userdate)
                             from   debtsubject dd
                             where  dd.document_id = iptaxdoc_Id);
        ------------
        vtaxbefore := 0;
        open crdpp(vds_id);
        loop
          fetch crdpp
            into rdpp;
          exit when not FOUND;
          oldper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
          select min(o.enddate)
          into   vobjenddate
          from   patentactivityobj o
          where  o.patentactivityobj_id = rdpp.homeobj_id;
          if (vobjenddate is not null)
          then
            vobjenddate := to_date('01.' ||
                                   (to_char(vobjenddate, 'mm') -
                                   mod(to_char(vobjenddate, 'mm') - 1, 3)) || '.' ||
                                   to_char(vobjenddate, 'yyyy'), 'dd.mm.yyyy');
          end if;
          if (vobjenddate is not null) and (vobjenddate < vbegintaxdate)
          then
            newper := round(months_between(vobjenddate, rdpp.taxbegindate::date));
          else
          newper := round(months_between(vbegintaxdate, rdpp.taxbegindate::date));
          end if;
          if newper < 0
          then
            newper := 0;
          end if;
          if oldper <= 0
          then
            oldper := 3;
          end if;
          select r.tableno
          into   vtableno
          from   patentactivityreg r, patentactivityobj o
          where  r.patentactivityreg_id = o.patentactivityreg_id
          and    rdpp.homeobj_id = o.patentactivityobj_id;
          if vtableno in ('01', '02', '03')
          then
            newper := 0;
          end if;
          vtaxbefore := vtaxbefore + nvl(rdpp.taxbefore, 0.0) +
                        round(rdpp.totaltax * newper / oldper, 2);
          select count(*) into i
          from debtpartproperty pp              
          where  pp.debtsubject_id = vdebtsubject_New
          and    pp.homeobj_id = rdpp.homeobj_id;
          
          if i > 0 then
          update debtpartproperty pp
          set    taxbefore = nvl(rdpp.taxbefore, 0.0) +
                                 round(rdpp.totaltax * newper / oldper, 2),
                 parentdebtprop_id = rdpp.debtpartproperty_id
          where  pp.debtsubject_id = vdebtsubject_New
          and    pp.homeobj_id = rdpp.homeobj_id;
          update patentactivityobj o
          set    taxvalue_calc = o.taxvalue_calc + nvl(rdpp.taxbefore, 0.0) +
                                    round(rdpp.totaltax * newper / oldper, 2)
          where  o.patentactivityobj_id = rdpp.homeobj_id;
          update patentactivity a
          set    taxvalue_calc = a.taxvalue_calc + nvl(rdpp.taxbefore, 0.0) +
                                    round(rdpp.totaltax * newper / oldper, 2)
          where  a.patentactivity_id in
                 (select o.patentactivity_id
                  from   patentactivityobj o
                  where  o.patentactivityobj_id = rdpp.homeobj_id);
          else
                    insert into debtpartproperty 
                    (debtpartproperty_id, debtsubject_id, taxperiod_id, 
                    kindproperty, seqnots, typedeclar, isbasehome, 
                    isrelief, relief_id, divident, divisor, part, 
                    sumval, sumtax, taxbegindate, taxenddate, totalval, 
                    totaltax, userdate, user_id, homeobj_id, freefrom, 
                    freemonths, codetbo, promiltbo, freesuma_obj, 
                    freesuma_subj, parentdebtprop_id, subjpartval, 
                    proporgobj_id, kindobligation, fsw, fclean, fdepot, 
                    koeff, taxbefore)
                    select s_debtpartproperty.nextval, vdebtsubject_New, rdpp.taxperiod_id, 
                    rdpp.kindproperty, rdpp.seqnots, rdpp.typedeclar, rdpp.isbasehome, 
                    rdpp.isrelief, rdpp.relief_id, rdpp.divident, rdpp.divisor, rdpp.part, 
                    rdpp.sumval, rdpp.sumtax, rdpp.taxbegindate, rdpp.taxenddate, rdpp.totalval, 
                    0, rdpp.userdate, rdpp.user_id, rdpp.homeobj_id, rdpp.freefrom, 
                    rdpp.freemonths, rdpp.codetbo, rdpp.promiltbo, rdpp.freesuma_obj, 
                    rdpp.freesuma_subj, rdpp.parentdebtprop_id, rdpp.subjpartval, 
                    rdpp.proporgobj_id, rdpp.kindobligation,rdpp.fsw, rdpp.fclean, rdpp.fdepot, 
                    rdpp.koeff, rdpp.taxbefore + rdpp.totaltax
                    from dual;
          end if;        
        end loop;
        close crdpp;
        --     if vdebtsubject_New is null then
        --       vTotalval := round(rds.totalval * newper / oldper,2);
        --     end if;
        select (ds.parent_debtsubject_id)
        into   vpds_id
        from   debtsubject ds
        where  ds.debtsubject_id = vds_id;
        if vreasoncode in ('614', '615')
        then
          /*select corroldds(nvl(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                    vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                    docno_new, vchange_date, null, vreasontxt, null, null,
                    trunc(current_date),
                    --iptermpay_date,
                    vdebtsubject_New, ipInterestBegdate, null, null, null,
                    vkindcorr, opStatus, '1');*/
          opStatus := public.corroldds(coalesce(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                    vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                    docno_new, vchange_date, null, vreasontxt, null, null,
                    trunc(current_date),
                    --iptermpay_date,
                    vdebtsubject_New, ipInterestBegdate, null, null, null,
                    vkindcorr);
        else
        vtotaltax := nvl(vtotaltax, 0.0) + nvl(vtaxbefore, 0.0);
         /*select corroldds(nvl(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                    vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                    docno_new, vchange_date, null, vreasontxt, null, null,
                    trunc(current_date),
                    --iptermpay_date,
                    vdebtsubject_New, ipInterestBegdate, null, null, null,
                    vkindcorr, opStatus);*/
         opStatus := public.corroldds(coalesce(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                    vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                    docno_new, vchange_date, null, vreasontxt, null, null,
                    trunc(current_date),
                    --iptermpay_date,
                    vdebtsubject_New, ipInterestBegdate, null, null, null,
                    vkindcorr);
        end if;
        ------------
        if opStatus <> 'OK'
        then
          raise exception 'ROLLBACK';          
          --rollback;
          return;
        end if;
        if vdebtsubject_New is null
        then
          insert into debtpartproperty
            (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
             seqnots, typedeclar, divident, divisor, part, sumval, sumtax,
             taxbegindate, taxenddate, totalval, totaltax, userdate, user_id,
             homeobj_id, taxbefore)
            select nextval('s_debtpartproperty'), d.debtsubject_id, vtaxper_id,
                   null, null, null, 0, 0, 0, null, null, d.tax_begidate,
                   d.tax_enddate, 0, 0, CURRENT_TIMESTAMP, d.user_id, d.taxobject_id,
                   vtaxbefore
            from   debtsubject d, taxdoc td
            where  d.document_id = td.taxdoc_id
            and    td.taxdoc_id = iptaxdoc_Id
            and    td.docno = d.docno
            and    td.doc_date = d.doc_date;
        end if;
        update taxdoc td
        set    docstatus = '30'
        where  td.taxdoc_id = iptaxdoc_id;
        --commit;
        perform taxvaluation.arxdoc(iptaxdoc_id);
        -----------------
        -----------------
      end if;
    end if;
  
  
end;
$function$
; DROP FUNCTION taxvaluation.taxdocval(numeric, numeric, integer, character varying, date, date, integer); 
CREATE OR REPLACE FUNCTION taxvaluation.taxdocval(iptaxdoc_id numeric, ipuser_id numeric, ipoblwr integer DEFAULT 0, OUT opstatus character varying, ipkindcorr character varying DEFAULT NULL::character varying, iptermpay_date date DEFAULT NULL::date, ipinterestbegdate date DEFAULT NULL::date, ipclause19 integer DEFAULT 0)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
  DECLARE                      
    crdpp CURSOR(vds_id numeric) IS
      select *
      from   debtpartproperty dp
      where  dp.debtsubject_id = vds_id;
    rdpp record;
  
    crds cursor (iptaxdoc_Id numeric,
                ipdate      date,
                ipdocno     varchar,
                ipdocdate   date,
                vcurtime    date) is
      select ds.debtsubject_id, ds.taxsubject_id, pp.totalval, pp.totaltax,
       pp.debtpartproperty_id, ds.taxperiod_id, pp.taxbefore, ds.tax_begidate::date,
       ds.tax_enddate::date, pp.homeobj_id, ds.kinddebtreg_id
from   debtsubject ds
left   outer join debtpartproperty pp
on     ds.debtsubject_id = pp.debtsubject_id
where  ds.document_id = iptaxdoc_Id
and    ds.kinddoc = '1'
and    ipdate between ds.tax_begidate and ds.tax_enddate
and    ds.userdate = (select max(dd.userdate)
                      from   debtsubject dd
                      where  dd.document_id = ds.document_id
                      and    dd.kinddoc = '1'
                      and    dd.taxperiod_id = ds.taxperiod_id
                      and    dd.kinddebtreg_id = ds.kinddebtreg_id
                      and    dd.taxsubject_id = ds.taxsubject_id
                      and    ipdate between dd.tax_begidate and dd.tax_enddate
                      and    dd.userdate < vcurtime);
    rds record;
    crds14 cursor (iptaxdoc_Id numeric, ipdate date, vcurtime date) is
      select ds.debtsubject_id, ds.taxsubject_id, ds.tax_begidate::date,
             ds.tax_enddate::date, ds.kinddebtreg_id, ds.totalval, ds.totaltax,
             ds.docno, ds.doc_date::date, ds.taxperiod_id
      from   debtsubject ds, taxdoc t
      where  ds.document_id = iptaxdoc_Id
      and    ds.kinddoc = '1'
      and    t.taxdoc_id = ds.document_id
      and    nvl(t.docno, '*') = nvl(ds.docno, '*')
      and    ipdate between ds.tax_begidate and ds.tax_enddate
      and    ds.userdate =
             (select max(dd.userdate)
               from   debtsubject dd
               where  dd.document_id = iptaxdoc_Id
               and    dd.taxperiod_id = ds.taxperiod_id
               and    dd.taxsubject_id = ds.taxsubject_id
               and    dd.kinddebtreg_id = ds.kinddebtreg_id
               and    ipdate between dd.tax_begidate and dd.tax_enddate
               and    dd.userdate > vcurtime);
  
    rds14 record;
  
    crdsn cursor (iptaxdoc_id numeric, vtaxper_id numeric) is
      select pl.taxsubject_id
      from   property p, land l, partland pl
      where  p.taxdoc_id = iptaxdoc_id
      and    l.property_id = p.property_id
      and    pl.land_id = l.land_id
      and    not exists (select *
              from   debtsubject ds
              where  ds.taxsubject_id = pl.taxsubject_id
              and    ds.document_id = p.taxdoc_id
              and    ds.taxperiod_id = vtaxper_id)
      union
      select ph.taxsubject_id
      from   property p, building b, homeobj h, parthomeobj ph
      where  p.taxdoc_id = iptaxdoc_Id
      and    b.property_id = p.property_id
      and    h.building_id = b.building_id
      and    ph.homeobj_id = h.homeobj_id
      and    not exists (select *
              from   debtsubject ds
              where  ds.taxsubject_id = ph.taxsubject_id
              and    ds.document_id = p.taxdoc_id
              and    ds.taxperiod_id = vtaxper_id);
    rdsn record;
  
    rTaxDoc           record;
    vdoccode          varchar(10);
    mymunicipality_id numeric;
    vTaxYear          varchar(10);
    vStatus           varchar(256);
    --  opStatus varchar(256);
    vbegintaxdate    date;
    vpartno          varchar(50);
    vdocumenttype_id numeric;
    vreasoncode      varchar(20);
    vchange_date     date;
    vds_id           numeric;
    vtbods_id        numeric;
    vtotaltax        numeric;
    vtotalval        numeric;
    vtbotax          numeric;
    vendtaxdate      date;
    doc_date_new     date;
    docno_new        varchar(50);
    vreasontxt       varchar(150);
    vdebtsubject_New numeric;
    vtaxbefore       numeric;
    oldper           integer;
    newper           integer;
    vfrees           numeric;
    vfreeo           numeric;
    vcorrYear        numeric;
    vtaxper_id       numeric;
    vpds_id          numeric;
    vptbods_id       numeric;
    vold_begindate   date;
    vold_enddate     date;
    vtableno         varchar(50);
    vkindcorr        varchar(10);
    vcurtime         timestamp;
    vdebtsubject_old numeric;
    vkinddebtreg_id  numeric;
    vBEGINOBL2       varchar(10);
    vobjenddate      date;
    firmPropertyRec record;
    i                integer;
    vmaxtax          numeric;
    vpaidpodate      date;
  begin
    vcurtime := statement_timestamp() - interval'1 second';
    select u.municipality_id
    into   mymunicipality_id
    from   users u
    where  u.user_id = ipuser_id;
  
    select d.doccode, td.begintaxdate, td.partidano, td.documenttype_id,
           td.change_date, td.docno, td.doc_date
    into   vdoccode, vbegintaxdate, vpartno, vdocumenttype_id, vchange_date,
           docno_new, doc_date_new
    from   taxdoc td, documenttype d
    where  td.taxdoc_id = iptaxdoc_Id
    and    td.documenttype_id = d.documenttype_id;
  
    select min(rr.reason_code), min(rr.reason_text)
    into   vreasoncode, vreasontxt
    from   reasonreg rr, taxdoc td
    where  rr.reasonreg_id = td.give_reasonreg_id
    and    td.taxdoc_id = iptaxdoc_Id;
  
    -----------------------
    if vdoccode = '14'
    then
      select *
      into   rtaxdoc
      from   taxdoc t
      where  t.taxdoc_id = iptaxdoc_Id;

      if (vreasoncode = 'd1') and (nvl(ipkindcorr, '0') <> '1')
      then
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR14';
        if rtaxdoc.earn_date is not null
        then
          rtaxdoc.earn_date := to_date('01.' ||
                                       to_char(add_months(rtaxdoc.earn_date, 1),
                                               'mm.yyyy'), 'dd.mm.yyyy');
          if vbegintaxdate is null
          then
            vbegintaxdate := rtaxdoc.earn_date;
          else
            vbegintaxdate := to_date('01.' || to_char(vbegintaxdate, 'mm.yyyy'),
                                     'dd.mm.yyyy');
          end if;
        end if;
        if vbegintaxdate is null
        then
          opStatus := 'errMissBD'; ---'TaxProperty - ?????? ??????? ???? !';
          return;
        end if;
        if (vbegintaxdate < to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'))
        then
        
         /*select Taxproperty(iptaxdoc_Id, vbegintaxdate,
                      to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id, 1,
                      vStatus);*/
          if rtaxdoc.decl14to17 = 2
          then
            vStatus := Firmprop14(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id,
                       ipoblwr, 0);
          else
           vStatus := taxvaluation.Taxproperty(iptaxdoc_Id, vbegintaxdate,
                      to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id, 1);
          end if;

          if (vStatus <> 'OK') and (vStatus <> 'errNoDuty')
          then
            opStatus := vStatus; --- 'TaxProperty - ' ||
            --rollback;
            --   return (opStatus);
          else
            opStatus := vStatus;
            update taxdoc td
            set    docstatus = '30'
            where  td.taxdoc_id = iptaxdoc_id;
            if vpartno is null
            then
              --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
              vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
              if vpartno <> '-1'
              then
                if rtaxdoc.decl14to17 = 2
                then
                  vpartno := replace(vpartno, 'H', 'F');
                end if;

                update taxdoc td
                set    partidano = vpartno
                where  td.taxdoc_id = iptaxdoc_id;
                update debtsubject ds
                set    partidano = vpartno
                where  ds.document_id = iptaxdoc_id
                and    ds.partidano is null;
              end if;
            end if;
            perform taxvaluation.arxdoc(iptaxdoc_id);
            --commit;
          end if;
        else
          opStatus := 'errNoActPer';
          --        opStatus := 'OK';
          select tp.taxperiod_id
          into   vtaxper_id
          from   taxperiod tp
          where  tp.taxperkind = 0
          and    to_char(tp.begin_date, 'yyyy') = vtaxyear;
          open crdsn(iptaxdoc_Id, vtaxper_id);
          loop
            fetch crdsn
              into rdsn;
            exit when not FOUND;
            select nextval('s_debtsubject')
            into   vdebtsubject_New;
          
            insert into debtsubject
              (debtsubject_id, taxsubject_id, document_id, kinddoc,
               kinddebtreg_id, taxperiod_id, doccode, tax_begidate, tax_enddate,
               totalval, totaltax, calcdate, inst_number, userdate, user_id,
               taxobject_id, partidano, municipality_id, kindparreg_id, docno,
               doc_date)
            values
              (vdebtsubject_New, rdsn.taxsubject_id, iptaxdoc_Id, 1, 2,
               vtaxper_id, '14', to_date('01.12.' || vtaxyear, 'dd.mm.yyyy'),
               to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), 0, 0, trunc(current_date),
               1, CURRENT_TIMESTAMP, ipuser_id, rtaxdoc.taxobject_id, rTaxDoc.Partidano,
               rtaxdoc.municipality_id, 2, rtaxdoc.docno, rtaxdoc.doc_date);
       /*     insert into debtinstalment
              (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
               intbegindate, paysum)
            values
              (nextval('s_debtinstalment'), vdebtsubject_New, 1, current_date, 0,
               null, 0);
         */ 
          end loop;
          close crdsn;
          
          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = iptaxdoc_id;
          if vpartno is null
          then
            --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
            vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
            if vpartno <> '-1'
            then
              if rtaxdoc.decl14to17 = 2
              then
                vpartno := replace(vpartno, 'H', 'F');
              end if;

              update taxdoc td
              set    partidano = vpartno
              where  td.taxdoc_id = iptaxdoc_id;
              update debtsubject ds
              set    partidano = vpartno
              where  ds.document_id = iptaxdoc_id
              and    ds.partidano is null;
            end if;
          end if;
          perform taxvaluation.arxdoc(iptaxdoc_id);
          --commit;
          --'???????????? ?? ?? ?? ????????? ?????? <' ||
          -- to_char(vbegintaxdate,'dd.mm.yyyy') || '>' ;
        end if;
        ------------------
      else
        if nvl(ipkindcorr, '0') = '1'
        then
          vkindcorr := '1';
        else
          vkindcorr := '3';
        end if;
        opStatus     := 'OK'; -- 'errOrclNoData';  ---'??????????? ?? ? ?????? !!!';
        if vchange_date is null
        then
          vchange_date := add_months(rtaxdoc.begintaxdate, -1);
        end if;

        vchange_date := to_date('01' ||
                                to_char(add_months(vchange_date, 1), 'mmyyyy'),
                                'ddmmyyyy');
      
        select min(c.configvalue)
        into   vBEGINOBL2
        from   config c
        where  c.name = 'BEGINOBL2'
        and    c.municipality_id = mymunicipality_id;
        if vbegintaxdate is null
        then
          vbegintaxdate := nvl(to_date(vBEGINOBL2, 'yyyy'),
                               to_date('01.01.2004', 'dd.mm.yyyy'));
        end if;
        --     if  vchange_date < nvl(to_date(vBEGINOBL2,'yyyy'),to_date('01.01.2004','dd.mm.yyyy')) then
        --      vchange_date := nvl(to_date(vBEGINOBL2,'yyyy'),to_date('01.01.2004','dd.mm.yyyy'));
        --      end if;
        if vchange_date < vbegintaxdate
        then
          vchange_date := vbegintaxdate;
        end if;
      
        vcorrYear := to_number(to_char(vchange_date, 'yyyy'));
        if (coalesce(ipClause19,0) = 1) and (rTaxDoc.Change_Date > to_date('31.12.2009','dd.mm.yyyy'))
             and to_char(rTaxDoc.Change_Date,'mm') <> '12' then
         vcorrYear := vcorrYear + 1;
        end if;
        select max(tp.taxperiod_id)
        into   vtaxper_id
        from   taxperiod tp
        where  tp.taxperkind = '0'
        and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
        select max(ds.debtsubject_id)
        into   vds_id
        from   debtsubject ds, kinddebtreg dr
        where  ds.document_id = iptaxdoc_Id
        and    ds.kinddebtreg_id = dr.kinddebtreg_id
        and    dr.code = '2100'
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate)
        
        ;
        select max(ds.debtsubject_id)
        into   vtbods_id
        from   debtsubject ds, kinddebtreg dr
        where  ds.document_id = iptaxdoc_Id
        and    ds.kinddebtreg_id = dr.kinddebtreg_id
        and    dr.code = '2400'
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate);
        --  vbegintaxdate := to_date('01.' || to_char(add_months(vchange_date,1),'mm.yyyy'),'dd.mm.yyyy');
        vbegintaxdate := vchange_date;
        vendtaxdate   := to_date('31.12.' || to_char(vchange_date, 'yyyy'),
                                 'dd.mm.yyyy');
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR14';
        if vbegintaxdate > to_date('31.12.' || vtaxyear, 'dd.mm.yyyy')
        then
          opStatus := 'errNoActPer';
        else
          loop
            --- po taxperiod
          
            if (vds_id is not null) or (vtbods_id is not null)
            then
              /*select TaxProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id, 2,
                          opstatus);*/
              if rtaxdoc.decl14to17 = 2
              then
                 if (coalesce(ipClause19,0) = 1) and (rTaxDoc.Change_Date > to_date('31.12.2009','dd.mm.yyyy'))
                    and to_char(rTaxDoc.Change_Date,'mm') <> '12' then
                   vbegintaxdate := to_date('01.01.' || to_char(vcorrYear),'dd.mm.yyyy');
                   vendtaxdate  := to_date('31.12.' || to_char(vcorrYear),'dd.mm.yyyy');
                 end if;
                opstatus :=  Firmprop14(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                           ipoblwr, 2);
              else
	              opstatus :=  taxvaluation.TaxProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id, 2);
              end if;

               if (opstatus <> 'OK') and (opstatus <> 'errNoDuty')
              then
                --rollback;
                raise exception '%',opstatus;
                return;
              end if;
            else
              if vcorrYear = to_number(vTaxYear)
              then
                if rtaxdoc.decl14to17 = 2
                then
                  opstatus :=  Firmprop14(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                             ipoblwr, 0);
                else
	                /*select TaxProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                            1, opstatus);*/
    	            opstatus :=  taxvaluation.TaxProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
        	                    1);
                end if;

                 if (opstatus <> 'OK') and (opstatus <> 'errNoDuty')
                then
                  --rollback;
                  raise exception 'ROLLBACK';
                  return;
                else
                  --commit;
                  exit;
                end if;
              end if;
            end if;
            ------------------>>>>>
            open crds14(iptaxdoc_Id, vbegintaxdate, vcurtime);
            loop
              fetch crds14
                into rds14;
              exit when not FOUND;
              select max(d.debtsubject_id), sum(d.totalval), sum(d.totaltax),
                     sum(d.freesum_subj), sum(d.freesum_obj),
                     max(d.tax_begidate), max(d.tax_enddate)
              into   vdebtsubject_New, vTotalval, vtotaltax, vfrees, vfreeo,
                     vold_begindate, vold_enddate
              from   debtsubject d
              where  d.document_id = iptaxdoc_Id
              and    d.taxsubject_id = rds14.taxsubject_id
              and    d.kinddebtreg_id = rds14.kinddebtreg_id
              and    d.taxperiod_id = rds14.taxperiod_id
              and    vbegintaxdate between d.tax_begidate and d.tax_enddate
              and    d.userdate = (select max(dd.userdate)
                                   from   debtsubject dd, taxdoc td
                                   where  dd.document_id = iptaxdoc_Id
                                   and    dd.taxsubject_id = d.taxsubject_id
                                   and    dd.kinddebtreg_id = d.kinddebtreg_id
                                   and    vbegintaxdate between dd.tax_begidate and
                                          dd.tax_enddate
                                   and    dd.userdate < vcurtime);
              if vdebtsubject_New is not null
              then
                newper := round(months_between(vold_enddate, vold_begindate));
                if coalesce(newper, 0) < 0
                then
                  newper := 0;
                end if;
                oldper := round(months_between(rds14.tax_begidate,
                                               vold_begindate));
                if coalesce(oldper, 0) <= 0
                then
                  oldper := 1;
                end if;
              
                --    vtaxbefore := nvl(rds14.taxbefore,0) + round(rds14.totaltax * newper / oldper,2);
                --    if vdebtsubject_New is null then
                --    vTotalval := round(rds14.totalval * newper / oldper,2);
                --    end if;
                --    vtotaltax := nvl(vtotaltax,0) + vtaxbefore;
              
                -----  danak do data na promjana !!!!
                vtaxbefore := 0;
                --      vtotaltax  := 0;
                --      open crdpp(rds14.debtsubject_id);
                open crdpp(vdebtsubject_New);
                loop
                  fetch crdpp
                    into rdpp;
                  exit when not FOUND;
                  --    oldper := round(months_between(vold_enddate, vold_begindate));
                  oldper := round(months_between(rdpp.taxenddate::date,
                                                 rdpp.taxbegindate::date));
                  if coalesce(oldper, 0) <= 0
                  then
                    oldper := 1;
                  end if;
                 if  rds14.tax_begidate > rdpp.taxenddate then 
                  newper := round(months_between(rdpp.taxenddate::date,
                                                 rdpp.taxbegindate::date));
                  else
                  newper := round(months_between(rds14.tax_begidate::date,
                                                 rdpp.taxbegindate::date));
                 end if;                                
                  if coalesce(newper, 0) < 0
                  then
                    newper := 0;
                  end if;
                  vtaxbefore := vtaxbefore + nvl(rdpp.taxbefore, 0.0) +
                                round(rdpp.totaltax * newper / oldper, 2);
                  select count(*) into i
                  from debtpartproperty pp
                  where  pp.debtsubject_id = rds14.debtsubject_id
                  and    pp.homeobj_id = rdpp.homeobj_id;
                  if i > 0 then                  
                  update debtpartproperty pp
                  set    taxbefore = nvl(rdpp.taxbefore, 0.0) +
                                         round(rdpp.totaltax * newper / oldper, 2),
                         parentdebtprop_id = rdpp.debtpartproperty_id
                  where  pp.debtsubject_id = rds14.debtsubject_id
                  and    pp.homeobj_id = rdpp.homeobj_id;
                  else 
             
                    insert into debtpartproperty 
                    (debtpartproperty_id, debtsubject_id, taxperiod_id, 
                    kindproperty, seqnots, typedeclar, isbasehome, 
                    isrelief, relief_id, divident, divisor, part, 
                    sumval, sumtax, taxbegindate, taxenddate, totalval, 
                    totaltax, userdate, user_id, homeobj_id, freefrom, 
                    freemonths, codetbo, promiltbo, freesuma_obj, 
                    freesuma_subj, parentdebtprop_id, subjpartval, 
                    proporgobj_id, kindobligation, fsw, fclean, fdepot, 
                    koeff, taxbefore)
                    select s_debtpartproperty.nextval, rds14.debtsubject_id, rdpp.taxperiod_id, 
                    rdpp.kindproperty, rdpp.seqnots, rdpp.typedeclar, rdpp.isbasehome, 
                    rdpp.isrelief, rdpp.relief_id, rdpp.divident, rdpp.divisor, rdpp.part, 
                    rdpp.sumval, rdpp.sumtax, rdpp.taxbegindate, rdpp.taxenddate, rdpp.totalval, 
                    0, rdpp.userdate, rdpp.user_id, rdpp.homeobj_id, rdpp.freefrom, 
                    rdpp.freemonths, rdpp.codetbo, rdpp.promiltbo, rdpp.freesuma_obj, 
                    rdpp.freesuma_subj, rdpp.parentdebtprop_id, rdpp.subjpartval, 
                    rdpp.proporgobj_id, rdpp.kindobligation,rdpp.fsw, rdpp.fclean, rdpp.fdepot, 
                    rdpp.koeff, rdpp.taxbefore + rdpp.totaltax
                    from dual;
                  end if;
                end loop;
                close crdpp;
                vtotaltax := nvl(rds14.totaltax, 0.0) + nvl(vtaxbefore, 0.0);
                select round(sum(nvl(pp.sumval, 0.0)), 2)
                into   vtotalval
                from   debtpartproperty pp
                where  pp.debtsubject_id = rds14.debtsubject_id;
                select coalesce(ds.parent_debtsubject_id, ds.debtsubject_id)
                into   vdebtsubject_New
                from   debtsubject ds
                where  ds.debtsubject_id = vdebtsubject_New;
                
                /*select corroldds(vdebtsubject_New, vtotalval, vtotaltax, null, null,
                          vbegintaxdate, vendtaxdate, ipuser_Id, rds14.doc_date,
                          rds14.docno, vchange_date, null, vreasontxt, null,
                          null, trunc(current_date),
                          --iptermpay_date,
                          rds14.debtsubject_id, ipInterestBegdate,
                          rds14.taxsubject_id, rds14.kinddebtreg_id, null,
                          vkindcorr, opStatus);*/
                opStatus := public.corroldds(vdebtsubject_New, vtotalval, vtotaltax, null, null,
                          vbegintaxdate, vendtaxdate, ipuser_Id, rds14.doc_date,
                          rds14.docno, vchange_date, null, vreasontxt, null,
                          null, trunc(current_date),
                          --iptermpay_date,
                          rds14.debtsubject_id, ipInterestBegdate,
                          rds14.taxsubject_id, rds14.kinddebtreg_id, null,
                          vkindcorr);
                --commit; ---- !!!!!
              end if;
            end loop;
            close crds14;
            --------- sledvasht period !!!
            vcorryear := vcorryear + 1;
            select max(tp.taxperiod_id)
            into   vtaxper_id
            from   taxperiod tp
            where  tp.taxperkind = '0'
            and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
            if vtaxper_id is null
            then
              exit;
            end if;
            vbegintaxdate := to_date('01.01.' || vcorrYear, 'dd.mm.yyyy');
            vendtaxdate   := to_date('31.12.' || vcorrYear, 'dd.mm.yyyy');
            select max(ds.debtsubject_id)
            into   vds_id
            from   debtsubject ds, kinddebtreg dr
            where  ds.document_id = iptaxdoc_Id
            and    ds.kinddebtreg_id = dr.kinddebtreg_id
            and    dr.code = '2100'
            and    ds.taxperiod_id = vtaxper_id
            and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate;
          
            select max(ds.debtsubject_id)
            into   vtbods_id
            from   debtsubject ds, kinddebtreg dr
            where  ds.document_id = iptaxdoc_Id
            and    ds.kinddebtreg_id = dr.kinddebtreg_id
            and    dr.code = '2400'
            and    ds.taxperiod_id = vtaxper_id
            and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate;
            if (vds_id is null) and (vtbods_id is null) and
               (vcorrYear <> to_number(vTaxYear))
            then
              exit;
            end if;
          end loop;
        end if;
        update taxdoc td
        set    docstatus = '30'
        where  td.taxdoc_id = iptaxdoc_id;
        --commit;
        perform taxvaluation.arxdoc(iptaxdoc_id);
      end if;
    end if;
    --------------------------
    if vdoccode = '17'
    then
      if (vreasoncode = 'df1') and (nvl(ipkindcorr, '0') <> '1')
      then
        select *
        into   rtaxdoc
        from   taxdoc t
        where  t.taxdoc_id = iptaxdoc_Id;
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR17';
        if rtaxdoc.earn_date is not null
        then
          rtaxdoc.earn_date := to_date('01.' ||
                                       to_char(add_months(rtaxdoc.earn_date, 1),
                                               'mm.yyyy'), 'dd.mm.yyyy');
          vbegintaxdate     := coalesce(vbegintaxdate, rtaxdoc.earn_date::date);
        elsif rtaxdoc.begintaxdate is not null
        then
          vbegintaxdate := to_date('01.' ||
                                   to_char(rtaxdoc.begintaxdate, 'mm.yyyy'),
                                   'dd.mm.yyyy');
        end if;
        if vbegintaxdate is null
        then
          opStatus := 'errMissBD'; -- 'TaxProperty - ?????? ??????? ???? !';
          return;
        end if;
        if vbegintaxdate < to_date('31.12.' || vtaxyear, 'dd.mm.yyyy')
        then
          /*select FirmProperty(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id,
                       ipoblwr, vStatus, 0, vtotalval, vtotaltax, vtbotax);*/
          select into firmPropertyRec * from taxvaluation.FirmProperty(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id,
                       ipoblwr, 0);
          vStatus := firmPropertyRec.ipstatus;
          vtotalval := firmPropertyRec.optotalval;
          vtotaltax := firmPropertyRec.optotaltax;
          vtbotax := firmPropertyRec.optbototaltax;
          if vStatus <> 'OK'
          then
            if ipoblwr = 2 and vStatus = 'errDiferData'
            then
              opStatus := 'OK';
            else
              opStatus := vStatus; ---'firmProperty - ' ||
            end if;
            --rollback;
            --    return (opStatus);
          else
            opStatus := vStatus;
            update taxdoc td
            set    docstatus = '30'
            where  td.taxdoc_id = iptaxdoc_id;
            if vpartno is null
            then
             --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
             vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
              if vpartno <> '-1'
              then
                update taxdoc td
                set    partidano = vpartno
                where  td.taxdoc_id = iptaxdoc_id;
                update debtsubject ds
                set    partidano = vpartno
                where  ds.document_id = iptaxdoc_id
                and    ds.partidano is null;
              end if;
            end if;
            perform taxvaluation.upd_doc14(iptaxdoc_id);
            perform taxvaluation.arxdoc(iptaxdoc_id);
            --commit;
          end if;
        else
          opStatus := 'errNoActPer';
       select tp.taxperiod_id into vtaxper_id from taxperiod tp
       where tp.taxperkind = 0
       and to_char(tp.begin_date,'yyyy') =  vtaxyear
       ;
-----------
      select nextval('s_debtsubject') into vdebtsubject_New;
       insert into debtsubject
       (debtsubject_id, taxsubject_id, document_id,
       kinddoc, kinddebtreg_id, taxperiod_id, doccode,
       tax_begidate, tax_enddate, totalval,
       totaltax, calcdate,inst_number, userdate,
       user_id, taxobject_id, partidano,
       municipality_id, kindparreg_id, docno, doc_date
       )
      values(vdebtsubject_New,rtaxdoc.taxsubject_id,iptaxdoc_Id,
        1,2, vtaxper_id, '17',to_date('01.12.'||vtaxyear,'dd.mm.yyyy'),
        to_date('31.12.'||vtaxyear,'dd.mm.yyyy'),0,0,
        current_date, 1, CURRENT_TIMESTAMP, ipuser_id,rtaxdoc.taxobject_id,
        rTaxDoc.Partidano,rtaxdoc.municipality_id, 2,rtaxdoc.docno,
        rtaxdoc.doc_date
        );
       insert into debtinstalment
       (debtinstalment_id, debtsubject_id, instno,
       termpay_date, instsum, intbegindate, paysum)
       values (nextval('s_debtinstalment'), vdebtsubject_New,
       1,current_date, 0,null,0);

          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = iptaxdoc_id;
          if vpartno is null
          then
            --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
            vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
            if vpartno <> '-1'
            then
              update taxdoc td
              set    partidano = vpartno
              where  td.taxdoc_id = iptaxdoc_id;
              update debtsubject ds
              set    partidano = vpartno
              where  ds.document_id = iptaxdoc_id
              and    ds.partidano is null;
            end if;
          end if;
          --'???????????? ?? ?? ?? ????????? ?????? <' ||
          -- to_char(vbegintaxdate,'dd.mm.yyyy') || '>' ;
          perform taxvaluation.upd_doc14(iptaxdoc_id);
          --commit;
          perform taxvaluation.arxdoc(iptaxdoc_id);
          --commit;
        end if;
        ------------------
      else
        opStatus := 'OK';
        if coalesce(ipkindcorr, '0') = '1'
        then
          vkindcorr := '1';
        else
          vkindcorr := '3';
        end if;
        ----------
        vchange_date := to_date('01.' ||
                                to_char(add_months(vchange_date, 1), 'mm.yyyy'),
                                'dd.mm.yyyy');
      
        select min(c.configvalue)
        into   vBEGINOBL2
        from   config c
        where  c.name = 'BEGINOBL2'
        and    c.municipality_id = mymunicipality_id;
        if vbegintaxdate is null
        then
          vbegintaxdate := coalesce(to_date(vBEGINOBL2, 'yyyy'),
                               to_date('01.01.2004', 'dd.mm.yyyy'));
        end if;
        --      if  vchange_date < nvl(to_date(vBEGINOBL2,'yyyy'),to_date('01.01.2004','dd.mm.yyyy')) then
        --       vchange_date := nvl(to_date(vBEGINOBL2,'yyyy'),to_date('01.01.2004','dd.mm.yyyy'));
        --      end if;
        if vchange_date < vbegintaxdate
        then
          vchange_date := vbegintaxdate;
        end if;
      
        vcorrYear := to_number(to_char(vchange_date, 'yyyy'));
        select max(tp.taxperiod_id)
        into   vtaxper_id
        from   taxperiod tp
        where  tp.taxperkind = '0'
        and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
        select max(ds.debtsubject_id)
        into   vds_id
        from   debtsubject ds, kinddebtreg dr
        where  ds.document_id = iptaxdoc_Id
        and    ds.kinddebtreg_id = dr.kinddebtreg_id
        and    dr.code = '2100'
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    dd.taxsubject_id = ds.taxsubject_id
                 and    dd.taxperiod_id = ds.taxperiod_id
                 and    dd.kinddebtreg_id = ds.kinddebtreg_id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate);
        select max(ds.debtsubject_id)
        into   vtbods_id
        from   debtsubject ds, kinddebtreg dr
        where  ds.document_id = iptaxdoc_Id
        and    ds.kinddebtreg_id = dr.kinddebtreg_id
        and    dr.code = '2400'
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    dd.taxsubject_id = ds.taxsubject_id
                 and    dd.taxperiod_id = ds.taxperiod_id
                 and    dd.kinddebtreg_id = ds.kinddebtreg_id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate);
        vbegintaxdate := vchange_date; --to_date('01.' || to_char(add_months(vchange_date,1),'mm.yyyy'),'dd.mm.yyyy');
        vendtaxdate   := to_date('31.12.' || to_char(vchange_date, 'yyyy'),
                                 'dd.mm.yyyy');
      
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR17';
        loop
          --- po taxperiod
          if (vds_id is null) and (vtbods_id is null) and
             (to_number(vTaxYear) = vcorryear)
          then
            /*select FirmProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                         ipoblwr, opstatus, 0, vtotalval, vtotaltax, vtbotax);*/
            select into firmPropertyRec * from taxvaluation.FirmProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                         ipoblwr, 0);
          opstatus := firmPropertyRec.ipstatus;
          vtotalval := firmPropertyRec.optotalval;
          vtotaltax := firmPropertyRec.optotaltax;
          vtbotax := firmPropertyRec.optbototaltax;
            if opstatus <> 'OK'
            then
              if ipoblwr = 2 and vStatus = 'errDiferData'
              then
                opStatus := 'OK';
              end if;
              --rollback;
              --    return (opStatus);
            else
              exit;
            end if;
          end if;
          /*select FirmProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                       ipoblwr, opstatus, 2, vtotalval, vtotaltax, vtbotax);*/
          select into firmPropertyRec * from taxvaluation.FirmProperty(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                       ipoblwr, 2);
          opstatus := firmPropertyRec.ipstatus;
          vtotalval := firmPropertyRec.optotalval;
          vtotaltax := firmPropertyRec.optotaltax;
          vtbotax := firmPropertyRec.optbototaltax;
          if opStatus <> 'OK'
          then
            if ipoblwr = 2 and opStatus = 'errDiferData'
            then
              opStatus := 'OK';
              --       else
              --         opStatus := vStatus;   ---'firmProperty - ' ||
            end if;
            --rollback;
      --      raise exception '%', opStatus; 
            return;
          end if;
          if vds_id is not null
          then
            select max(ds.debtsubject_id)
            into   vdebtsubject_New
            from   debtsubject ds, kinddebtreg dr
            where  ds.document_id = iptaxdoc_Id
            and    ds.kinddebtreg_id = dr.kinddebtreg_id
            and    dr.code = '2100'
            and    ds.taxperiod_id = vtaxper_id
            and    ds.userdate > vcurtime;
            -----  danak do data na promjana !!!!
            vtaxbefore := 0;
            --      vtotaltax  := 0;
            open crdpp(vds_id);
            loop
              fetch crdpp
                into rdpp;
              exit when not FOUND;
              oldper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
              if vbegintaxdate > rdpp.taxenddate then
               newper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
              else
               newper := round(months_between(vbegintaxdate::date, rdpp.taxbegindate::date));
              end if;
              if newper < 0
              then
                newper := 0;
              end if;
              if oldper <= 0
              then
                oldper := 1;
              end if;
              vtaxbefore := vtaxbefore + nvl(rdpp.taxbefore, 0.0) +
                            round(rdpp.totaltax * newper / oldper, 2);
              select count(*) into i
              from  debtpartproperty pp
              where  pp.debtsubject_id = vdebtsubject_New
              and    pp.homeobj_id = rdpp.homeobj_id;
              if i > 0 then             
              update debtpartproperty pp
              set    taxbefore = nvl(rdpp.taxbefore, 0.0) +
                                     round(rdpp.totaltax * newper / oldper, 2),
                     parentdebtprop_id = rdpp.debtpartproperty_id
              where  pp.debtsubject_id = vdebtsubject_New
              and    pp.homeobj_id = rdpp.homeobj_id;
              else
                    insert into debtpartproperty 
                    (debtpartproperty_id, debtsubject_id, taxperiod_id, 
                    kindproperty, seqnots, typedeclar, isbasehome, 
                    isrelief, relief_id, divident, divisor, part, 
                    sumval, sumtax, taxbegindate, taxenddate, totalval, 
                    totaltax, userdate, user_id, homeobj_id, freefrom, 
                    freemonths, codetbo, promiltbo, freesuma_obj, 
                    freesuma_subj, parentdebtprop_id, subjpartval, 
                    proporgobj_id, kindobligation, fsw, fclean, fdepot, 
                    koeff, taxbefore)
                    select s_debtpartproperty.nextval, vdebtsubject_New, rdpp.taxperiod_id, 
                    rdpp.kindproperty, rdpp.seqnots, rdpp.typedeclar, rdpp.isbasehome, 
                    rdpp.isrelief, rdpp.relief_id, rdpp.divident, rdpp.divisor, rdpp.part, 
                    rdpp.sumval, rdpp.sumtax, rdpp.taxbegindate, rdpp.taxenddate, rdpp.totalval, 
                    0, rdpp.userdate, rdpp.user_id, rdpp.homeobj_id, rdpp.freefrom, 
                    rdpp.freemonths, rdpp.codetbo, rdpp.promiltbo, rdpp.freesuma_obj, 
                    rdpp.freesuma_subj, rdpp.parentdebtprop_id, rdpp.subjpartval, 
                    rdpp.proporgobj_id, rdpp.kindobligation,rdpp.fsw, rdpp.fclean, rdpp.fdepot, 
                    rdpp.koeff, nvl(rdpp.taxbefore,0) + round(rdpp.totaltax * newper / oldper, 2)
                    from dual;
              end if;
            end loop;
            close crdpp;
            vtotaltax := vtotaltax + vtaxbefore;
            select ds.parent_debtsubject_id
            into   vpds_id
            from   debtsubject ds
            where  ds.debtsubject_id = vds_id;
            /*select corroldds(nvl(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                      vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                      docno_new, vchange_date, null, vreasontxt, null, null,
                      trunc(current_date),
                      --iptermpay_date,
                      vdebtsubject_New, ipInterestBegdate, null, null, null,
                      vkindcorr, opStatus);*/
            opStatus := public.corroldds(coalesce(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                      vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                      docno_new, vchange_date, null, vreasontxt, null, null,
                      trunc(current_date),
                      --iptermpay_date,
                      vdebtsubject_New, ipInterestBegdate, null, 2, null,
                      vkindcorr);
          end if;
          if opStatus <> 'OK'
          then
            raise exception 'ROLLBACK'; 
            --rollback;
            return;
          end if;
          ----- TBO -----
          if vtbods_id is not null
          then
            select max(ds.debtsubject_id)
            into   vdebtsubject_New
            from   debtsubject ds, kinddebtreg dr
            where  ds.document_id = iptaxdoc_Id
            and    ds.kinddebtreg_id = dr.kinddebtreg_id
            and    dr.code = '2400'
            and    ds.taxperiod_id = vtaxper_id
            and    ds.userdate > vcurtime;
            -----  danak do data na promjana !!!!
            vtaxbefore := 0;
            --      vtotaltax  := 0;
          
            open crdpp(vtbods_id);
            loop
              fetch crdpp
                into rdpp;
              exit when not FOUND;
              oldper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
              if vbegintaxdate > rdpp.taxenddate then
               newper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
              else
               newper := round(months_between(vbegintaxdate::date, rdpp.taxbegindate::date));
              end if;
              if newper < 0
              then
                newper := 0;
              end if;
              if oldper <= 0
              then
                oldper := 1;
              end if;
              vtaxbefore := vtaxbefore + nvl(rdpp.taxbefore, 0.0) +
                            round(rdpp.totaltax * newper / oldper, 2);
              select count(*) into i
              from  debtpartproperty pp
              where  pp.debtsubject_id = vdebtsubject_New
              and    pp.homeobj_id = rdpp.homeobj_id;
              if i > 0 then             
              update debtpartproperty pp
              set    taxbefore = nvl(rdpp.taxbefore, 0.0) +
                                     round(rdpp.totaltax * newper / oldper, 2),
                     parentdebtprop_id = rdpp.debtpartproperty_id
              where  pp.debtsubject_id = vdebtsubject_New
              and    pp.homeobj_id = rdpp.homeobj_id;
              else
                    insert into debtpartproperty 
                    (debtpartproperty_id, debtsubject_id, taxperiod_id, 
                    kindproperty, seqnots, typedeclar, isbasehome, 
                    isrelief, relief_id, divident, divisor, part, 
                    sumval, sumtax, taxbegindate, taxenddate, totalval, 
                    totaltax, userdate, user_id, homeobj_id, freefrom, 
                    freemonths, codetbo, promiltbo, freesuma_obj, 
                    freesuma_subj, parentdebtprop_id, subjpartval, 
                    proporgobj_id, kindobligation, fsw, fclean, fdepot, 
                    koeff, taxbefore)
                    select s_debtpartproperty.nextval, vdebtsubject_New, rdpp.taxperiod_id, 
                    rdpp.kindproperty, rdpp.seqnots, rdpp.typedeclar, rdpp.isbasehome, 
                    rdpp.isrelief, rdpp.relief_id, rdpp.divident, rdpp.divisor, rdpp.part, 
                    rdpp.sumval, rdpp.sumtax, rdpp.taxbegindate, rdpp.taxenddate, rdpp.totalval, 
                    0, rdpp.userdate, rdpp.user_id, rdpp.homeobj_id, rdpp.freefrom, 
                    rdpp.freemonths, rdpp.codetbo, rdpp.promiltbo, rdpp.freesuma_obj, 
                    rdpp.freesuma_subj, rdpp.parentdebtprop_id, rdpp.subjpartval, 
                    rdpp.proporgobj_id, rdpp.kindobligation,rdpp.fsw, rdpp.fclean, rdpp.fdepot, 
                    rdpp.koeff, nvl(rdpp.taxbefore,0.0) + round(rdpp.totaltax * newper / oldper, 2) --rdpp.totaltax
                    from dual;
              end if;
            end loop;
            close crdpp;
            vtbotax := nvl(vtbotax, 0.0) + vtaxbefore;
            select ds.parent_debtsubject_id
            into   vptbods_id
            from   debtsubject ds
            where  ds.debtsubject_id = vtbods_id;
            /*select corroldds(nvl(vptbods_id, vtbods_id), vTotalval, vtbotax, null,
                      null, vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                      docno_new, vchange_date, null, vreasontxt, null, null,
                      trunc(current_date),
                      --iptermpay_date,
                      vdebtsubject_New, ipInterestBegdate, null, null, null,
                      vkindcorr, opStatus);*/
            opStatus := public.corroldds(coalesce(vptbods_id, vtbods_id), vTotalval, vtbotax, null,
                      null, vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                      docno_new, vchange_date, null, vreasontxt, null, null,
                      trunc(current_date),
                      --iptermpay_date,
                      vdebtsubject_New, ipInterestBegdate, null, 5, null,
                      vkindcorr);
          end if;
          if opStatus <> 'OK'
          then
            raise exception 'ROLLBACK';
            --rollback;
            return;
          end if;
        
          --commit; ---- !!!!!
          --------- sledvasht period !!!
          vcorryear := vcorryear + 1;
          select max(tp.taxperiod_id)
          into   vtaxper_id
          from   taxperiod tp
          where  tp.taxperkind = '0'
          and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
          if vtaxper_id is null
          then
            exit;
          end if;
          vbegintaxdate := to_date('01.01.' || vcorrYear, 'dd.mm.yyyy');
          vendtaxdate   := to_date('31.12.' || vcorrYear, 'dd.mm.yyyy');
          select max(ds.debtsubject_id)
          into   vds_id
          from   debtsubject ds, kinddebtreg dr
          where  ds.document_id = iptaxdoc_Id
          and    ds.kinddebtreg_id = dr.kinddebtreg_id
          and    dr.code = '2100'
          and    ds.taxperiod_id = vtaxper_id
          and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate
          and    ds.userdate = (select max(dd.userdate)
                                from   debtsubject dd
                                where  dd.document_id = iptaxdoc_Id
                                and    dd.taxsubject_id = ds.taxsubject_id
                                and    dd.taxperiod_id = ds.taxperiod_id
                                and    dd.kinddebtreg_id = ds.kinddebtreg_id
                                and    vbegintaxdate between dd.tax_begidate and
                                       dd.tax_enddate);
          
          select max(ds.debtsubject_id)
          into   vtbods_id
          from   debtsubject ds, kinddebtreg dr
          where  ds.document_id = iptaxdoc_Id
          and    ds.kinddebtreg_id = dr.kinddebtreg_id
          and    dr.code = '2400'
          and    ds.taxperiod_id = vtaxper_id
          and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate
          and    ds.userdate = (select max(dd.userdate)
                                from   debtsubject dd
                                where  dd.document_id = iptaxdoc_Id
                                and    dd.taxsubject_id = ds.taxsubject_id
                                and    dd.taxperiod_id = ds.taxperiod_id
                                and    dd.kinddebtreg_id = ds.kinddebtreg_id
                                and    vbegintaxdate between dd.tax_begidate and
                                       dd.tax_enddate);
          if (vds_id is null) and (vtbods_id is null) and
             (to_number(vTaxYear) <> vcorryear)
          then
            exit;
          end if;
        end loop;
        update taxdoc td
        set    docstatus = '30'
        where  td.taxdoc_id = iptaxdoc_id;
        perform taxvaluation.upd_doc14(iptaxdoc_id);
        --commit;
        perform taxvaluation.arxdoc(iptaxdoc_id);
      end if;
    end if;
    --------------------
    if substr(vdoccode, 1, 2) = '54'
    then
      select c.configvalue
      into   vTaxYear
      from   config c
      where  c.municipality_id = mymunicipality_id
      and    c.name = 'TAXYEAR54';
      if ((vreasoncode = 'ps11') or (vreasoncode = 'ps21') or
         (vreasoncode = 'ps31') or (vreasoncode = 'ps41')) and
         (nvl(ipkindcorr, '0') <> '1')
      then
        select *
        into   rtaxdoc
        from   taxdoc t
        where  t.taxdoc_id = iptaxdoc_Id;
        if vbegintaxdate is null
        then
          opStatus := 'errMissBD'; --'TaxProperty - ?????? ??????? ???? !';
          return;
        end if;
        if vbegintaxdate < to_date('31.12.' || vtaxyear, 'dd.mm.yyyy')
        then
          vStatus := taxvaluation.Taxtransport(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id, 0.0);

          /*select Taxtransport(iptaxdoc_Id, vbegintaxdate,
                       to_date('31.12.' || vtaxyear, 'dd.mm.yyyy'), ipuser_id,
                       vStatus, 0);*/
          if (vStatus <> 'OK') and (vStatus <> 'errNoDuty')
          then
            opStatus := vStatus;
            --rollback;
            --    return (opStatus);
          else
            opStatus := vStatus;
            update taxdoc td
            set    docstatus = '30'
            where  td.taxdoc_id = iptaxdoc_id;
            if vpartno is null
            then
              --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
              vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
              if vpartno <> '-1'
              then
                update taxdoc td
                set    partidano = vpartno
                where  td.taxdoc_id = iptaxdoc_id;
                update debtsubject ds
                set    partidano = vpartno
                where  ds.document_id = iptaxdoc_id
                and    ds.partidano is null;
              end if;
            end if;
            perform taxvaluation.arxdoc(iptaxdoc_id);
            --commit;
          end if;
        else
          opStatus := 'errNoActPer';
          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = iptaxdoc_id;
          if vpartno is null
          then
            --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
            vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
            --       end if;
            if vpartno <> '-1'
            then
              update taxdoc td
              set    partidano = vpartno
              where  td.taxdoc_id = iptaxdoc_id;
              update debtsubject ds
              set    partidano = vpartno
              where  ds.document_id = iptaxdoc_id
              and    ds.partidano is null;
            end if;
          end if;
          --'???????????? ?? ?? ?? ????????? ?????? <' ||
          -- to_char(vbegintaxdate,'dd.mm.yyyy') || '>' ;
          perform taxvaluation.arxdoc(iptaxdoc_id);
          --commit;
        end if;
        ------------------
      else
        if nvl(ipkindcorr, '0') = '1'
        then
          vkindcorr := '1';
        else
          vkindcorr := '3';
        end if;
        ----- 19.07.2012 
        ----- plateno do po-kasna data ????
        select min(t.paidpodate) into vpaidpodate from transport t
        where t.taxdoc_id = iptaxdoc_Id;
    /*    if vpaidpodate is not null and vpaidpodate > vbegintaxdate then
          vbegintaxdate := add_months(vpaidpodate,1);
        end if;  */
        if vbegintaxdate > vchange_date
        then
          vchange_date := vbegintaxdate;
        end if;
        vcorrYear := to_number(to_char(vchange_date, 'yyyy'));
        select max(tp.taxperiod_id)
        into   vtaxper_id
        from   taxperiod tp
        where  tp.taxperkind = '0'
        and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
      
        select max(ds.debtsubject_id)
        into   vds_id
        from   debtsubject ds
        where  ds.document_id = iptaxdoc_Id
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd, taxdoc td
                 where  dd.document_id = iptaxdoc_Id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate
                 and    dd.userdate < vcurtime);
        if nvl(ipkindcorr, '0') = '1' and
           ((vreasoncode = 'ps11') or (vreasoncode = 'ps21') or
            (vreasoncode = 'ps31') or (vreasoncode = 'ps41'))
        then
          vbegintaxdate := to_date('01.' || to_char(vchange_date, 'mm.yyyy'),
                                   'dd.mm.yyyy');
        else
          --        vbegintaxdate := to_date('01.' || to_char(add_months(vchange_date,1),'mm.yyyy'),'dd.mm.yyyy');
          vbegintaxdate := to_date('01.' || to_char(vchange_date, 'mm.yyyy'),
                                   'dd.mm.yyyy');
        end if;
        vendtaxdate := to_date('31.12.' || to_char(vchange_date, 'yyyy'),
                               'dd.mm.yyyy');
      
        ----- nov danak !!!
        loop
          if vbegintaxdate < vendtaxdate ---and (vcorrYear <= vTaxYear)
          then
             opstatus := taxvaluation.taxtransport(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id, 2.0);
           /*select taxtransport(iptaxdoc_Id, vbegintaxdate, vendtaxdate, ipuser_id,
                         opstatus, 2);*/

            if opStatus <> 'OK' and (opStatus <> 'errNoDuty')
            then
              --rollback;
              raise exception 'ROLLBACK'; 
              return;
            end if;
          
            if vds_id is not null
            then
              open crds(iptaxdoc_Id, vbegintaxdate, docno_new, doc_date_new,
                        vcurtime);
              loop
                fetch crds
                  into rds;
                exit when not FOUND;
                select max(d.debtsubject_id), sum(d.totalval), sum(d.totaltax),
                       sum(d.freesum_subj), sum(d.freesum_obj)
                into   vdebtsubject_New, vTotalval, vtotaltax, vfrees, vfreeo
                from   debtsubject d, taxdoc td
                where  d.document_id = td.taxdoc_id
                and    td.taxdoc_id = iptaxdoc_Id
                and    td.docno = d.docno
                and    td.doc_date = d.doc_date
                and    d.taxperiod_id = rds.taxperiod_id
                and    d.taxsubject_id = rds.taxsubject_id
                and    d.userdate > vcurtime;
                select min(d.debtsubject_id)
                into   vdebtsubject_old
                from   debtsubject d
                where  d.document_id = iptaxdoc_id
                and    d.taxsubject_id = rds.taxsubject_id
                and    d.taxperiod_id = rds.taxperiod_id
                and    d.userdate < vcurtime
                and    d.parent_debtsubject_id is null;
                oldper     := round(months_between(rds.tax_enddate,
                                                   rds.tax_begidate));
                newper     := round(months_between(vbegintaxdate,
                                                   rds.tax_begidate));
                vtaxbefore := nvl(rds.taxbefore, 0.0) +
                              round(nvl(rds.totaltax, 0.0) * newper / oldper, 2);
                if vdebtsubject_New is null
                then
                  vTotalval := round(rds.totalval * newper / oldper, 2);
                end if;
                vtotaltax := nvl(vtotaltax, 0.0) + vtaxbefore;
                /*select corroldds(vdebtsubject_old, vTotalval, vtotaltax, vfrees,
                          vfreeo, vbegintaxdate, vendtaxdate, ipuser_Id,
                          doc_date_new, docno_new, vchange_date, null,
                          vreasontxt, null, null, trunc(current_date),
                          --iptermpay_date,
                          vdebtsubject_New, ipInterestBegdate, null, null, null,
                          vkindcorr, opStatus);*/
                opStatus := public.corroldds(vdebtsubject_old, vTotalval, vtotaltax, vfrees,
                          vfreeo, vbegintaxdate, vendtaxdate, ipuser_Id,
                          doc_date_new, docno_new, vchange_date, null,
                          vreasontxt, null, null, trunc(current_date),
                          --iptermpay_date,
                          vdebtsubject_New, ipInterestBegdate, null, rds.kinddebtreg_id, null,
                          vkindcorr);
                if opStatus <> 'OK'
                then
                  --rollback;
                  raise exception 'ROLLBACK'; 
                  return;
                end if;
                if vdebtsubject_New is not null
                then
                  update debtpartproperty pp
                  set    taxbefore = nvl(rds.taxbefore, 0.0) +
                                         round(rds.totaltax * newper / oldper, 2),
                         parentdebtprop_id = rds.debtpartproperty_id
                  where  pp.debtsubject_id = vdebtsubject_New
                  and    pp.homeobj_id = rds.homeobj_id;
                else
                  insert into debtpartproperty
                    (debtpartproperty_id, debtsubject_id, taxperiod_id,
                     kindproperty, seqnots, typedeclar, divident, divisor, part,
                     sumval, sumtax, taxbegindate, taxenddate, totalval,
                     totaltax, userdate, user_id, homeobj_id, taxbefore)
                    select nextval('s_debtpartproperty'), d.debtsubject_id,
                           vtaxper_id, null, null, null, 0, 0, 0, null, null,
                           d.tax_begidate, d.tax_enddate, 0, 0, CURRENT_TIMESTAMP,
                           d.user_id, d.taxobject_id, vtaxbefore
                    from   debtsubject d, taxdoc td
                    where  d.document_id = td.taxdoc_id
                    and    td.taxdoc_id = iptaxdoc_Id
                    and    td.docno = d.docno
                    and    td.doc_date = d.doc_date
                    and    d.taxsubject_id = rds.taxsubject_id;
                end if;
                --commit;
              end loop;
              close crds;
            end if;
          else
            if vcorrYear = vTaxYear
            then
              opStatus := 'errNoDuty';
              exit;
            end if;
          end if;
          vcorrYear     := vcorrYear + 1;
          vbegintaxdate := to_date('01.01.' || to_char(vcorrYear), 'dd.mm.yyyy');
          vendtaxdate   := to_date('31.12.' || to_char(vcorrYear), 'dd.mm.yyyy');
        
          select max(tp.taxperiod_id)
          into   vtaxper_id
          from   taxperiod tp
          where  tp.taxperkind = '0'
          and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
          select max(ds.debtsubject_id)
          into   vds_id
          from   debtsubject ds
          where  ds.document_id = iptaxdoc_Id
          and    ds.taxperiod_id = vtaxper_id
          and    vbegintaxdate between ds.tax_begidate and ds.tax_enddate;
          if vds_id is null
          then
            exit;
          end if;
        end loop;
        update taxdoc td
        set    docstatus = '30'
        where  td.taxdoc_id = iptaxdoc_id;
        --commit;
        perform taxvaluation.arxdoc(iptaxdoc_id);
      end if;
    
    end if;
    ----------------------------
    if vdoccode = '61'
    then
      select *
      into   rtaxdoc
      from   taxdoc t
      where  t.taxdoc_id = iptaxdoc_Id;
      if ((vreasoncode = '611') or (vreasoncode = '612')) and
         (nvl(ipkindcorr, '0') <> '1')
      then
        select c.configvalue
        into   vTaxYear
        from   config c
        where  c.municipality_id = mymunicipality_id
        and    c.name = 'TAXYEAR61';
        if vbegintaxdate is null
        then
          opStatus := 'errMissBD'; --'TaxProperty - ?????? ??????? ???? !';
          return;
        end if;
        if vbegintaxdate < to_date('31.12.' || vtaxyear, 'dd.mm.yyyy')
        then
          vStatus := taxvaluation.patentval(iptaxdoc_Id, ipuser_id, 0, ipoblwr);
          if vStatus <> 'OK'
          then
            opStatus := vStatus;
            --rollback;
            --    return (opStatus);
          else
            opStatus := vStatus;
            update taxdoc td
            set    docstatus = '30'
            where  td.taxdoc_id = iptaxdoc_id;
            if vpartno is null
            then
              --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
              vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
              if vpartno <> '-1'
              then
                update taxdoc td
                set    partidano = vpartno
                where  td.taxdoc_id = iptaxdoc_id;
                update debtsubject ds
                set    partidano = vpartno
                where  ds.document_id = iptaxdoc_id
                and    ds.partidano is null;
              end if;
            end if;
            --commit;
            perform taxvaluation.arxdoc(iptaxdoc_id);
          end if;
        else
          opStatus := 'errNoActPer';
          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = iptaxdoc_id;
          if vpartno is null
          then
            --perform getpartidano(mymunicipality_id, vdocumenttype_id, vpartno);
            vpartno := public.getpartidano(mymunicipality_id, vdocumenttype_id);
            if vpartno <> '-1'
            then
              update taxdoc td
              set    partidano = vpartno
              where  td.taxdoc_id = iptaxdoc_id;
              update debtsubject ds
              set    partidano = vpartno
              where  ds.document_id = iptaxdoc_id
              and    ds.partidano is null;
            end if;
          end if;
          --'???????????? ?? ?? ?? ????????? ?????? <' ||
          -- to_char(vbegintaxdate,'dd.mm.yyyy') || '>' ;
          --commit;
          perform taxvaluation.arxdoc(iptaxdoc_id);
        end if;
        ------------------
        --       return (opStatus);
      else
        --   opStatus :='??????????? ?? ? ?????? !!!';
        if nvl(ipkindcorr, '0') = '1'
        then
          vkindcorr := '1';
        else
          vkindcorr := '3';
        end if;
        if vchange_date < rTaxDoc.Begintaxdate then
          vchange_date := rTaxDoc.Begintaxdate;
        end if;
        vcorrYear := to_number(to_char(vchange_date, 'yyyy'));
        select max(tp.taxperiod_id)
        into   vtaxper_id
        from   taxperiod tp
        where  tp.taxperkind = '0'
        and    to_number(to_char(tp.begin_date, 'yyyy')) = vcorrYear;
      
        select max(ds.debtsubject_id)
        into   vds_id
        from   debtsubject ds
        where  ds.document_id = iptaxdoc_Id
        and    vchange_date between ds.tax_begidate and ds.tax_enddate
        and    ds.userdate =
               (select max(dd.userdate)
                 from   debtsubject dd
                 where  dd.document_id = iptaxdoc_Id
                 and    vchange_date between dd.tax_begidate and dd.tax_enddate
                 and    dd.taxperiod_id = ds.taxperiod_id
                 and    dd.taxsubject_id = ds.taxsubject_id
                 and    dd.kinddebtreg_id = ds.kinddebtreg_id
                 and    dd.userdate < vcurtime);
        --------------------
        --------------------
        vbegintaxdate := to_date('01.' ||
                                 (to_char(vchange_date, 'mm')::numeric -
                                 mod(to_char(vchange_date, 'mm')::numeric - 1, 3)) || '.' ||
                                 to_char(vchange_date, 'yyyy'), 'dd.mm.yyyy');
        vendtaxdate   := to_date('31.12.' || to_char(vchange_date, 'yyyy'),
                                 'dd.mm.yyyy');
        -------- >>>>>>>>
        opstatus := taxvaluation.patentval(iptaxdoc_Id, ipuser_id, 2, ipoblwr);
        if opStatus <> 'OK'
        then
          --rollback;
          raise exception 'ROLLBACK';
          return;
        end if;
        -----------------
        select max(d.debtsubject_id), sum(d.totalval), sum(d.totaltax),
               sum(d.freesum_subj), sum(d.freesum_obj)
        into   vdebtsubject_New, vTotalval, vtotaltax, vfrees, vfreeo
        from   debtsubject d, taxdoc td
        where  d.document_id = td.taxdoc_id
        and    td.taxdoc_id = iptaxdoc_Id
        and    td.docno = d.docno
        and    td.doc_date = d.doc_date
        and    d.taxsubject_id = coalesce(td.taxsubject_id, td.ettaxsubject_id)
        and    d.userdate = (select max(dd.userdate)
                             from   debtsubject dd
                             where  dd.document_id = iptaxdoc_Id);
        ------------
        vtaxbefore := 0;
        open crdpp(vds_id);
        loop
          fetch crdpp
            into rdpp;
          exit when not FOUND;
          oldper := round(months_between(rdpp.taxenddate::date, rdpp.taxbegindate::date));
          select min(o.enddate)
          into   vobjenddate
          from   patentactivityobj o
          where  o.patentactivityobj_id = rdpp.homeobj_id;
          if (vobjenddate is not null)
          then
            vobjenddate := to_date('01.' ||
                                   (to_char(vobjenddate, 'mm') -
                                   mod(to_char(vobjenddate, 'mm') - 1, 3)) || '.' ||
                                   to_char(vobjenddate, 'yyyy'), 'dd.mm.yyyy');
          end if;
          if (vobjenddate is not null) and (vobjenddate < vbegintaxdate)
          then
            newper := round(months_between(vobjenddate, rdpp.taxbegindate::date));
          else
          newper := round(months_between(vbegintaxdate, rdpp.taxbegindate::date));
          end if;
          if newper < 0
          then
            newper := 0;
          end if;
          if oldper <= 0
          then
            oldper := 3;
          end if;
          select r.tableno
          into   vtableno
          from   patentactivityreg r, patentactivityobj o
          where  r.patentactivityreg_id = o.patentactivityreg_id
          and    rdpp.homeobj_id = o.patentactivityobj_id;
         if vtableno in ('01', '02', '03') and (nvl(ipkindcorr, '0') <> '1')
          then
	    ------ Samo uwelichenie ????
            select max(pp.totaltax) into vmaxtax
             from debtpartproperty pp
             where  pp.debtsubject_id = vdebtsubject_New
             and    pp.homeobj_id = rdpp.homeobj_id
             ;
            if rdpp.totaltax > vmaxtax then
             rdpp.taxbefore := rdpp.totaltax - vmaxtax;
            end if;
            
            newper := 0;
          end if;
          vtaxbefore := vtaxbefore + nvl(rdpp.taxbefore, 0.0) +
                        round(rdpp.totaltax * newper / oldper, 2);
          select count(*) into i
          from debtpartproperty pp              
          where  pp.debtsubject_id = vdebtsubject_New
          and    pp.homeobj_id = rdpp.homeobj_id;
          
          if i > 0 then
           if ((newper <> 0) or (nvl(rdpp.taxbefore, 0) <> 0)) then
          update debtpartproperty pp
          set    taxbefore = nvl(rdpp.taxbefore, 0.0) +
                                 round(rdpp.totaltax * newper / oldper, 2),
                 parentdebtprop_id = rdpp.debtpartproperty_id
          where  pp.debtsubject_id = vdebtsubject_New
          and    pp.homeobj_id = rdpp.homeobj_id;
          update patentactivityobj o
          set    taxvalue_calc = o.taxvalue_calc + nvl(rdpp.taxbefore, 0.0) +
                                    round(rdpp.totaltax * newper / oldper, 2)
          where  o.patentactivityobj_id = rdpp.homeobj_id;
          update patentactivity a
          set    taxvalue_calc = a.taxvalue_calc + nvl(rdpp.taxbefore, 0.0) +
                                    round(rdpp.totaltax * newper / oldper, 2)
          where  a.patentactivity_id in
                 (select o.patentactivity_id
                  from   patentactivityobj o
                  where  o.patentactivityobj_id = rdpp.homeobj_id);
          end if;            
          else
                    insert into debtpartproperty 
                    (debtpartproperty_id, debtsubject_id, taxperiod_id, 
                    kindproperty, seqnots, typedeclar, isbasehome, 
                    isrelief, relief_id, divident, divisor, part, 
                    sumval, sumtax, taxbegindate, taxenddate, totalval, 
                    totaltax, userdate, user_id, homeobj_id, freefrom, 
                    freemonths, codetbo, promiltbo, freesuma_obj, 
                    freesuma_subj, parentdebtprop_id, subjpartval, 
                    proporgobj_id, kindobligation, fsw, fclean, fdepot, 
                    koeff, taxbefore)
                    select s_debtpartproperty.nextval, vdebtsubject_New, rdpp.taxperiod_id, 
                    rdpp.kindproperty, rdpp.seqnots, rdpp.typedeclar, rdpp.isbasehome, 
                    rdpp.isrelief, rdpp.relief_id, rdpp.divident, rdpp.divisor, rdpp.part, 
                    rdpp.sumval, rdpp.sumtax, rdpp.taxbegindate, rdpp.taxenddate, rdpp.totalval, 
                    0, CURRENT_TIMESTAMP, rdpp.user_id, rdpp.homeobj_id, rdpp.freefrom,
                    rdpp.freemonths, rdpp.codetbo, rdpp.promiltbo, rdpp.freesuma_obj, 
                    rdpp.freesuma_subj, rdpp.parentdebtprop_id, rdpp.subjpartval, 
                    rdpp.proporgobj_id, rdpp.kindobligation,rdpp.fsw, rdpp.fclean, rdpp.fdepot, 
                    rdpp.koeff, rdpp.taxbefore + rdpp.totaltax
                    from dual;
            vtaxbefore := vtaxbefore  + rdpp.totaltax; --+ rdpp.taxbefore; -- ????????
         end if;        
        end loop;
        close crdpp;
        --     if vdebtsubject_New is null then
        --       vTotalval := round(rds.totalval * newper / oldper,2);
        --     end if;

        select min(ds.parent_debtsubject_id), min(ds.kinddebtreg_id)
        into   vpds_id, vkinddebtreg_id
        from   debtsubject ds
        where  ds.debtsubject_id = vds_id;
        if vreasoncode in ('614', '615')
        then
          /*select corroldds(nvl(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                    vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                    docno_new, vchange_date, null, vreasontxt, null, null,
                    trunc(current_date),
                    --iptermpay_date,
                    vdebtsubject_New, ipInterestBegdate, null, null, null,
                    vkindcorr, opStatus, '1');*/
          opStatus := public.corroldds(coalesce(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                    vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                    docno_new, vchange_date, null, vreasontxt, null, null,
                    trunc(current_date),
                    --iptermpay_date,
                    vdebtsubject_New, ipInterestBegdate, null, vkinddebtreg_id, null,
                    vkindcorr);
        else
        vtotaltax := nvl(vtotaltax, 0.0) + nvl(vtaxbefore, 0.0);
         /*select corroldds(nvl(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                    vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                    docno_new, vchange_date, null, vreasontxt, null, null,
                    trunc(current_date),
                    --iptermpay_date,
                    vdebtsubject_New, ipInterestBegdate, null, null, null,
                    vkindcorr, opStatus);*/
         opStatus := public.corroldds(coalesce(vpds_id, vds_id), vTotalval, vtotaltax, null, null,
                    vbegintaxdate, vendtaxdate, ipuser_Id, doc_date_new,
                    docno_new, vchange_date, null, vreasontxt, null, null,
                    trunc(current_date),
                    --iptermpay_date,
                    vdebtsubject_New, ipInterestBegdate, null, vkinddebtreg_id, null,
                    vkindcorr);
        end if;
        ------------
        if opStatus <> 'OK'
        then
          raise exception 'ROLLBACK';          
          --rollback;
          return;
        end if;
        if vdebtsubject_New is null
        then
          insert into debtpartproperty
            (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
             seqnots, typedeclar, divident, divisor, part, sumval, sumtax,
             taxbegindate, taxenddate, totalval, totaltax, userdate, user_id,
             homeobj_id, taxbefore)
            select nextval('s_debtpartproperty'), d.debtsubject_id, vtaxper_id,
                   null, null, null, 0, 0, 0, null, null, d.tax_begidate,
                   d.tax_enddate, 0, 0, CURRENT_TIMESTAMP, d.user_id, d.taxobject_id,
                   vtaxbefore
            from   debtsubject d, taxdoc td
            where  d.document_id = td.taxdoc_id
            and    td.taxdoc_id = iptaxdoc_Id
            and    td.docno = d.docno
            and    td.doc_date = d.doc_date;
        end if;
        update taxdoc td
        set    docstatus = '30'
        where  td.taxdoc_id = iptaxdoc_id;
        --commit;
        perform taxvaluation.arxdoc(iptaxdoc_id);
        -----------------
        -----------------
      end if;
    end if;
  
  
end;
$function$
; DROP FUNCTION taxvaluation.taxforyear(numeric, numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.taxforyear(ipdocumenttype_id numeric, ipuser_id numeric, OUT opstat character varying, OUT operrn numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                       
    docs cursor (iptaxper_id numeric) is
      select *
      from   taxdoc td
      where  td.documenttype_id = ipdocumenttype_id
      and    (td.docstatus = '30')
      and    not exists (select *
              from   debtsubject ds
              where  ds.document_id = td.taxdoc_id
              and    ds.taxperiod_id = iptaxper_id)
      --  and exists (select * from transport t where t.taxdoc_id = td.taxdoc_id)
      ;
    tdrow taxdoc%rowtype;
    docs30 cursor (iptaxper_id numeric) is
      select *
      from   taxdoc td
      where  td.documenttype_id = 30
      and    td.close_date is null
      and    td.docstatus = '30'
      and    td.taxobject_id =
             (select min(o.taxobject_id)
               from   taxobject o
               where  o.kindtaxobject = '3'
               and    o.taxperiod_id = iptaxper_id)
      and    not exists (select *
              from   debtsubject ds
              where  ds.document_id = td.taxdoc_id
              and    ds.taxperiod_id = iptaxper_id)
      --  and exists (select * from transport t where t.taxdoc_id = td.taxdoc_id)
      ;
  
    cyear         varchar(10);
    msg           varchar(300);
    vbegintaxdate date;
    vtotalval     numeric;
    vtotaltax     numeric;
    vtbotax       numeric;
    countrec      numeric;
    vtaxper_id    numeric;

    vcity_id      numeric;
    firmpropertyrec record;

  begin
    opstat := 'OK';
    operrn := 0;
    cyear  := null;
    if ipdocumenttype_id in (26, 27, 28, 29)
    then
      select c.configvalue
      into   cyear
      from   config c
      where  c.name = 'TAXYEAR54';
    elsif ipdocumenttype_id = 21
    then
      update taxdoc td
       set td.secpassdate = null
      where td.documenttype_id = 21;
      select c.configvalue
      into   cyear
      from   config c
      where  c.name = 'TAXYEAR14';
    elsif ipdocumenttype_id = 22
    then
      select c.configvalue
      into   cyear
      from   config c
      where  c.name = 'TAXYEAR17';
    elsif ipdocumenttype_id = 30
    then
      select c.configvalue
      into   cyear
      from   config c
      where  c.name = 'TAXYEAR61';
    elsif ipdocumenttype_id = 32
    then
      select c.configvalue
      into   cyear
      from   config c
      where  c.name = 'TAXYEAR'; ---- ?????
    end if;
    if cyear is null
    then
      return;
    end if;
    select p.taxperiod_id
    into   vtaxper_id
    from   taxperiod p
    where  to_char(p.begin_date, 'yyyy') = cyear;
    select count(pp.taxperiodpay_id)
    into   countrec
    from   taxperiodpay pp
    where  pp.documenttype_id = ipdocumenttype_id
    and    pp.taxperiod_id = vtaxper_id;
    if nvl(countrec, 0.0) = 0
    then
      opstat := '������� ������� �� �������';
      return;
    end if;
  
    if ipdocumenttype_id <> 30
    then
      open docs(vtaxper_id);
      loop
        fetch docs
          into tdrow;
        exit when not FOUND;
        begin
          if (tdrow.begintaxdate is not null) and
             (to_char(tdrow.begintaxdate, 'yyyy') = cyear)
          then
            vbegintaxdate := tdrow.begintaxdate;
          else
            vbegintaxdate := to_date('01.01.' || cyear, 'dd.mm.yyyy');
          end if;
        
          -- if vdoccode = '54L' then
          if tdrow.documenttype_id in (26, 27, 28, 29)
          then
            /*select Taxtransport(tdrow.taxdoc_id, vbegintaxdate,
                         nvl(tdrow.close_date,
                              to_date('31.12.' || cyear, 'dd.mm.yyyy')),
                         ipuser_id, msg, 0);*/
            msg := taxvaluation.Taxtransport(tdrow.taxdoc_id, vbegintaxdate,
                         nvl(tdrow.close_date,
                              to_date('31.12.' || cyear, 'dd.mm.yyyy')),
                         ipuser_id, 0);
            --commit;
            if msg <> 'OK'
            then
              -- dbms_output.put_line(tdrow.taxdoc_id || ' ' || msg);
              operrn := operrn + 1;
            end if;
          end if;
          if tdrow.documenttype_id = 21
          then
            select count(pt.promtbo_id)
            into   countrec
            from   promtbo pt
            where  pt.taxperiod_id = vtaxper_id;
            if nvl(countrec, 0.0) = 0
            then
              opstat := '������� ��������� �� �������';
              return;
            end if;
            select count(n.normdni_id)
            into   countrec
            from   normdni n
            where  n.taxperiod_id = vtaxper_id
            --  and n.municipality_id = 
            ;
            if nvl(countrec, 0.0) = 0
            then
              opstat := '������� ��������� �� �������';
              return;
            end if;
            if nvl(tdrow.decl14to17, 0.0) <> 1
            then
              /*select Taxproperty(tdrow.taxdoc_id, vbegintaxdate,
                          nvl(tdrow.close_date,
                               to_date('31.12.' || cyear, 'dd.mm.yyyy')),
                          ipuser_id, 1, msg);*/
              msg := taxvaluation.Taxproperty(tdrow.taxdoc_id, vbegintaxdate,
                          nvl(tdrow.close_date,
                               to_date('31.12.' || cyear, 'dd.mm.yyyy')),
                          ipuser_id, 1);
              --commit;
              if msg <> 'OK'
              then
                --dbms_output.put_line(tdrow.taxdoc_id || ' ' || msg);
                operrn := operrn + 1;
              end if;
            end if;
          end if;
          if tdrow.documenttype_id = 22
          then
            select count(pt.promtbo_id)
            into   countrec
            from   promtbo pt
            where  pt.taxperiod_id = vtaxper_id;
            if nvl(countrec, 0.0) = 0
            then
              opstat := '������� ��������� �� �������';
              return;
            end if;
            select count(n.normdni_id)
            into   countrec
            from   normdni n
            where  n.taxperiod_id = vtaxper_id
            --  and n.municipality_id = 
            ;
            if nvl(countrec, 0.0) = 0
            then
              opstat := '������� ��������� �� �������';
              return;
            end if;
          
            /*perform taxvaluation.Firmproperty(tdrow.taxdoc_id, vbegintaxdate,
                         nvl(tdrow.close_date,
                              to_date('31.12.' || cyear, 'dd.mm.yyyy')),
                         ipuser_id, 1, msg, 0, vtotalval, vtotaltax, vtbotax);*/
            select into firmpropertyrec * from taxvaluation.Firmproperty(tdrow.taxdoc_id, vbegintaxdate,
                         nvl(tdrow.close_date,
                              to_date('31.12.' || cyear, 'dd.mm.yyyy')),
                         ipuser_id, 1, 0);
            msg := firmpropertyrec.ipstatus;
            vtotalval := firmpropertyrec.optotalval;
            vtotaltax := firmpropertyrec.optotaltax;
            vtbotax := firmpropertyrec.optbototaltax;
            --commit;
            if msg <> 'OK'
            then
              operrn := operrn + 1;
            else
              perform taxvaluation.upd_doc14(tdrow.taxdoc_id);
            end if;
          end if;
          if tdrow.documenttype_id = 32
          then
            select count(pt.promtbo_id)
            into   countrec
            from   promtbo pt
            where  pt.taxperiod_id = vtaxper_id;
            -------------------
            select min(a.city_id) into vcity_id
             from address a
             where a.address_id = tdrow.decl_perm_addr
             ;
            select count(*)
            into  countrec
            from ChargeReg cr, ChargePrice cp
            where cr.DocumentType_Id = 32
            and coalesce(cp.city_id, -1) in
                 (case when
                  (select count(cp1.city_id)
                     from ChargePrice cp1
                    where cp1.TaxPeriod_Id = vtaxper_id
                      and coalesce(cp1.city_id, -1) = coalesce(vcity_id, -1)
                      ) = 1 then
                  vcity_id else - 1 end)
             and cr.ChargeReg_Id = cp.ChargeReg_Id
             and cp.TaxPeriod_Id = vtaxper_id;
            ------------------------
            if coalesce(countrec, 0) = 0
            then
              opstat := '������� ��������� �� �������';
              return;
            end if;
            msg := ivan_valuations.DogValuation(tdrow.taxdoc_id,ipuser_id,msg);
            --commit;
            if msg <> 'OK'
            then
              operrn := operrn + 1;
            end if;
          end if;
        exception
          when others then
            return;
        end;
      end loop;
      close docs;
      if operrn = 0
      then
        if ipdocumenttype_id = 21
        then
          update config c
          set    configvalue = cyear
          where  c.name = 'TAXYEAR14END';
        elsif ipdocumenttype_id = 22
        then
          update config c
          set    configvalue = cyear
          where  c.name = 'TAXYEAR17END';
        elsif (ipdocumenttype_id in (26, 27, 28, 29))
        then
          null;
        end if;
      else
        if ipdocumenttype_id = 21
        then
          update config c
          set    configvalue = null
          where  c.name = 'TAXYEAR14END';
        elsif ipdocumenttype_id = 22
        then
          update config c
          set    configvalue = null
          where  c.name = 'TAXYEAR17END';
        elsif (ipdocumenttype_id in (26, 27, 28, 29))
        then
          update config c
          set    configvalue = null
          where  c.name = 'TAXYEAR54END';
        end if;
      end if;
    else
      open docs30(vtaxper_id);
      loop
        fetch docs30
          into tdrow;
        exit when not FOUND;
        begin
          --   if tdrow.documenttype_id = 30 then
          select count(p.patenttaxprice_id)
          into   countrec
          from   patenttaxprice p
          where  p.taxperiod_id = vtaxper_id
          -- and p.municipality_id = 
          ;
          if nvl(countrec, 0.0) = 0
          then
            opstat := '������� ��������� �� �������';
            return;
          end if;
        
         --perform taxvaluation.patentval(tdrow.taxdoc_id, ipuser_id, 0, 1, msg);
         msg := taxvaluation.patentval(tdrow.taxdoc_id, ipuser_id, 0, 1);
          --commit;
          if msg <> 'OK'
          then
            operrn := operrn + 1;
          end if;
        exception
          when others then
            return;
        end;
      end loop;
      close docs30;
      
      if operrn = 0
      then
        update config c
        set    configvalue = cyear
        where  c.name = 'TAXYEAR61END';
      else
        update config c
        set    configvalue = null
        where  c.name = 'TAXYEAR61END';
      end if;
    end if;
  
end;
$function$
; DROP FUNCTION taxvaluation.taxproperty(numeric, date, date, numeric, integer); 
CREATE OR REPLACE FUNCTION taxvaluation.taxproperty(iptaxdoc_id numeric, ipfromdate date, iptodate date, ipuser_id numeric, ipflrec integer, OUT ipstatus character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                        
    crbuilding cursor  is
      select p.structurezone, p.seezone_cat, b.*
      from   property p
      left   outer join building b
      on     p.property_id = b.property_id
      where  p.taxdoc_id = iptaxdoc_Id;
    rBuilding record;
  
    crhomeobject cursor (vbuilding_id numeric) is
      select *
      from   homeobj h
      where  h.building_id = vbuilding_id;
    rhomeobject homeobj%rowtype; --record;
  
    crSubject cursor (vhobj_id numeric) is
      select *
      from   Parthomeobj ho
      where  ho.homeobj_id = vhobj_id  and ho.taxsubject_id > 0
      and    ((ho.end_date is null) or (ho.end_date >= ipfromdate))
      --  and (coalesce(ho.divident,0) + coalesce(ho.part,0)+ coalesce(ho.area,0)) <> 0
      order  by ho.typedeclar desc;
    rSubject Parthomeobj%rowtype; --record;
  
    crLand cursor is
      select l.*
      from   Land l, property p
      where  l.property_id = p.property_id
      and    p.taxdoc_id = iptaxdoc_Id;
    rLand Land%rowtype; --record;
  
    crSubjLand cursor (vhobj_id numeric) is
      select *
      from   Partland pl
      where  pl.land_id = vhobj_id  and pl.taxsubject_id > 0
      and    ((pl.end_date is null) or (pl.end_date > ipfromdate))
      --   and (coalesce(pl.dividentland,0) + coalesce(pl.partland,0)+ coalesce(pl.area,0)) <> 0
      order  by pl.typedeclar desc;
    rSubjLand Partland%rowtype; --record;
  
    crDebtSubj cursor (vper_id   numeric,
                      vdocno    varchar,
                      vdoc_date date,
                      vcurtime  date) is
      select *
      from   debtsubject ds
      where  ds.document_id = iptaxdoc_Id
      and    ds.taxperiod_id = vper_id
      and    coalesce(ds.docno, '*') = coalesce(vdocno, '*')
      and    coalesce(ds.doc_date::date, trunc(current_date)) = coalesce(vdoc_date, trunc(current_date))
      and    ds.userdate > vcurtime;

    crDNI cursor (vcity_id         numeric,
                 vtaxperiod_id    numeric,
                 vmunicipality_id numeric) is
      select nd.calctype, nd.code, nd.homeprom, nd.nohomeprom
      from   normdni nd, municipality m
      where  nd.municipality_id =
             coalesce(m.parentmunicipality_id, m. municipality_id)
      and    m.municipality_id = vmunicipality_id
      and    nd.city_id = vcity_id
      and    nd.taxperiod_id = vtaxperiod_id;
    rowDNI record;

    crpartp cursor (ipdebts_id numeric) is
      select *
      from   debtpartproperty pp
      where  pp.debtsubject_id = ipdebts_id;
    rpartp record;
  
    rDebtSubj            record;
    rgrouptbo            record;
    userspart            numeric;
    vuskoef              numeric;
    vTDateBegin          date;
    vTDateEnd            date;
    osv0                 integer;
    osv1                 integer;
    osv2                 integer;
    osv3                 integer;
    vTaxYear             numeric;
    vTaxFreeFrom         date;
    vTaxFreeTo           date;
    vDOHomeObj           numeric;
    vDOTBOHomeObj        numeric;
    ErrTxt               varchar(256);
    vDOUsers             numeric;
    vDOYear              numeric;
    vDOSubject           numeric;
    vDOTBOSubject        numeric;
    vDOTBOYear           numeric;
    vDOPartSubj          numeric;
    vTBOLandVal          numeric;
    vDNIYear             numeric;
    vDNISubject          numeric;
    vPRM                 numeric;
    telkBDate            date;
    telkEdate            date;
    tobDate              date;
    toedate              date;
    vdebtsubject_id      numeric;
    vtaxperiod_id        numeric;
    vrelief_id           numeric;
    vdoctype_id          numeric;
    vdoccode             varchar(20);
    vinst_number         integer;
    vDNIFreeObj          numeric;
    vDNIFreeSubj         numeric;
    vdebtpartproperty_id numeric;
    vLandVal             numeric;
    v2From               date;
    v2To                 date;
    vnoski               integer;
    i                    integer;
    nv                   integer;
    sumzad               numeric;
    brzap                numeric;
    ownerpart            numeric;
    DOSum                numeric;
    vproperty_id         numeric;
    vcity_id             numeric;
    vcity0_id            numeric;
    vcity_name           varchar(100);
    vgrouptbo_id         numeric;
    rprtbo               promtbo%rowtype; --record;
    vgarbtax_id          numeric;
    vmunicipality_id     numeric;
    vconstructionbound   varchar(10);
    vseqnoproperty       numeric;
    flho                 numeric;
    indtelk              numeric;
    DNI                  dnipar[];
    brnom                integer;
    vcalctype            varchar(10);
    vperson              numeric; --integer;
    vminhobj_id          numeric;
    vmindo               numeric;
    rdoc                 taxdoc%rowtype;--record;
    vhbDate              date;
    vheDate              date;
    koefobj              varchar(200);
    koefobjtbo           varchar(200);
    vusernum             integer;
    vdi                  numeric;
    vsw_missing          integer;
    vclean_missing       integer;
    vdepot_missing       integer;
    vsumdo               numeric;
    vCurYear             varchar(10);
    vparreg              numeric;
    vTBODebt_id          numeric;
    vtboyear             varchar(10);
    oldds_id             numeric;
    vcurtime             date;
    invsum               numeric;
    vminp                integer;
    vsrok_bh             integer;
    vsumtboy             numeric;
    vsumtboy_cont 	 numeric;
    vmintbo              numeric;
    vnewtbods            numeric;
    vnorminst            numeric;
    vdiv                 numeric;
    vgarbtax19           numeric;
    vtaxdoc19_id         numeric;
    vtaxdoc71_id         numeric;
    vdocst               varchar(10);
    vdecltbo             numeric;
    vktbo                numeric;
    vtermpaydate         timestamp;
    vstructurezone       varchar(10);
    nullsubj             integer;
    vper                 integer;
    vadmregion_id        integer;
    jj 					 integer;
   ----------------------------------
    recCountTBO record;
    recTaxValHome record;
    recTaxValLand record;
    recCross_Date record;

    crSubject_row_cnt integer;

    ------ main function
  begin
    vcurtime := statement_timestamp() - interval'1 second';
    -----------------------
    select min(ts.taxsubject_id) into nullsubj
    from taxsubject ts where ts.idn = '9999990000001';
    if nullsubj is null then nullsubj := 0; end if;
    -----------------------
    select *
    into   rdoc
    from   taxdoc td
    where  td.taxdoc_id = iptaxdoc_Id;
    select c.configvalue
    into   vCurYear
    from   config c
    where  name = 'TAXYEAR' and c.municipality_id = rdoc.municipality_id;
    select min(ds.debtsubject_id)
    into   vdebtsubject_id
    from   debtsubject ds
    where  ds.document_id = iptaxdoc_Id
    and    coalesce(ds.docno, '*') = coalesce(rdoc.docno, '*')
    and    coalesce(ds.doc_date::date, trunc(current_date)) =
           coalesce(rdoc.doc_date::date, trunc(current_date))
    and    ds.taxperiod_id =
           (select tp.taxperiod_id
             from   taxperiod tp
             where  to_char(tp.begin_date, 'yyyy') = to_char(ipFromDate, 'yyyy')
             and    tp.taxperkind = '0');
  
    if vdebtsubject_id is not null and (ipflrec <> 2) and
       (coalesce(rdoc.close_taxdoc_id, 0.0) <> 1)
    then
      ipStatus := 'errEndProcess'; --'���� �������� �������� ' || iptaxdoc_Id ;
      return;
    end if;
    vTaxYear := to_number(to_char(ipFromDate, 'yyyy'));
    while vTaxYear <= to_number(to_char(ipToDate, 'yyyy'))
    loop
      if vTaxYear < to_number(vcuryear)
      then
        vparreg := 3;
      else
        vparreg := 2;
      end if;
      flho        := 0;
      vsumdo      := 0;
      vsumtboy    := 0;
      vsumtboy_cont := 0;

      vTDateBegin := to_date('01.01.' || to_char(vTaxYear), 'dd.mm.yyyy');
      if vTDateBegin < ipFromDate
      then
        vTDateBegin := ipFromDate;
      end if;
      vTDateEnd := to_date('31.12.' || to_char(vTaxYear), 'dd.mm.yyyy');
      if vTDateEnd > ipToDate
      then
        vTDateEnd := ipToDate;
      end if;
      select min(tp.taxperiod_id)
      into   vtaxperiod_id
      from   taxperiod tp
      where  tp.taxperkind = '0'
      and    tp.begin_date <= vTDateBegin
      and    tp.end_date >= vTDateEnd;
      if vtaxperiod_id is null
      then
        exit;
      end if;
    
      --- danni za TBO ----
      select p.property_id, a.city_id, a.city_name, a.municipality_id,
             coalesce(p.constructionbound,'1'), p.seqnoproperty,p.structurezone, a.admregion_id
      into   vproperty_id, vcity_id, vcity_name, vmunicipality_id,
             vconstructionbound, vseqnoproperty, vstructurezone, vadmregion_id
from   property p
left   outer join address a
on     p.property_address_id = a.address_id
where  p.taxdoc_id = iptaxdoc_Id;
      if coalesce(vcity_id, 0.0) = 0
      then
        rollback;
        ipStatus := 'errMissAddr';
        return;
      end if;
      select max(gt.garbtax_id), case max(gt.sw_missing)
                                  when 1.0 then 0
                                   else  1
                                 end,
             case max(gt.clean_missing)
              when 1.0 then 0
               else 1
             end,
             case max(gt.depot_missing)
              when 1 then 0
               else 1
             end, max(gt.taxdoc_id)
      into   vgarbtax_id, vsw_missing, vclean_missing, vdepot_missing, vtaxdoc71_id
      from   garbtax gt, taxdoc td --, taxdoc md
      where  td.taxdoc_id = gt.taxdoc_id
      and    td.documenttype_id =
             (select t.documenttype_id
               from   documenttype t
               where  t.doccode = '71') --and t.municipality_id = md.municipality_id)
            --     and td.partidano = md.partidano
            --     and md.taxdoc_id = iptaxdoc_Id
      and    gt.proptaxdoc_id = iptaxdoc_Id
      and    gt.taxperiod_id = vtaxperiod_id
      and    coalesce(gt.taxsubject_id,0) = 0  ---- 01.03.2012 
      and    coalesce(gt.isforobject,0) <> 1   ---- 20.04.2012
      ;

      select max(g.grouptbo_id)
      into   vgrouptbo_id
      from   propgrouptbo g
      where  g.taxdoc_id = iptaxdoc_Id
      and    coalesce(g.enddate::date, vTDateBegin) >= vTDateBegin
            ----- ????? ----------
      and    g.begindate = (select max(pg.begindate)
                            from   propgrouptbo pg
                            where  pg.begindate <= vTDateBegin
                            and    pg.taxdoc_id = iptaxdoc_Id);
      ------------------------
      if vtaxdoc71_id is not null
      then
        select td.docstatus
        into   vdocst
        from   taxdoc td
        where  td.taxdoc_id = vtaxdoc71_id;
        if vdocst = '10'
        then
          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = vtaxdoc71_id;
          perform taxvaluation.arxdoc(vtaxdoc71_id, ipuser_id);
        end if;
      end if;
      ------------------------
      select max(gt.garbtax_id), max(td.taxdoc_id)
      into   vgarbtax19, vtaxdoc19_id
      from   garbtax gt, taxdoc td
      where  td.taxdoc_id = gt.taxdoc_id
      and    td.documenttype_id =
             (select t.documenttype_id
               from   documenttype t
               where  t.doccode = '19')
      and    gt.proptaxdoc_id = iptaxdoc_Id
      and    gt.taxperiod_id = vtaxperiod_id
      and    td.docstatus <> '70' and td.docstatus <> '90';
     if vtaxdoc19_id is not null
      then
        select td.docstatus
        into   vdocst
        from   taxdoc td
        where  td.taxdoc_id = vtaxdoc19_id;
        if vdocst = '10'
        then
          update taxdoc td
          set    docstatus = '30'
          where  td.taxdoc_id = vtaxdoc19_id;
          perform taxvaluation.arxdoc(vtaxdoc19_id);
        end if;
      end if;
      ------------------------   
    
      if vcity_id <> 0
      then
        vcity0_id := vcity_id;
        select count(*) into i
        from promtbo t, municipality m
        where m.municipality_id = vmunicipality_id
        and t.municipality_id = coalesce(m.parentmunicipality_id, m.municipality_id)
        and t.taxperiod_id = vtaxperiod_id
        and t.city_id = 0;
        if i > 0
        then
          vcity0_id := 0;
        end if;

        select pt.*
        into   rprtbo
        from   promtbo pt
        where  pt.city_id = vcity0_id
        and    pt.taxperiod_id = vtaxperiod_id
        and    pt.calctype in ('0', '6')
        and    pt.code = '1'
        union
        select pt.*
        from   promtbo pt
        where  pt.city_id = vcity0_id
        and    pt.taxperiod_id = vtaxperiod_id
        and    pt.calctype in ('3', '5')
        and    pt.code =
               case vgrouptbo_id
                when null then case vconstructionbound
                                when '2' then '2'
                                 else '1'
                               end
                 else '1'
               end
        union
        select pt.*
        from   promtbo pt
        where  pt.city_id = vcity0_id
        and    pt.taxperiod_id = vtaxperiod_id
        and    pt.calctype in ('1', '2', '4', '7')
        and    pt.code =
               (select case coalesce(vgrouptbo_id,0.0)
                        when 0.0 then (2 - count(l.land_id))::character varying
                         else '2'
                       end
                 from   land l, property p
                 where  coalesce(l.builtuparea, 0.0) = 0
                 and    l.property_id = p.property_id
                 and    p.taxdoc_id = iptaxdoc_Id
                 and    p.kindproperty = '1')
        union
        select pt.*
        from   promtbo pt
        where  pt.city_id = vcity0_id
        and    pt.taxperiod_id = vtaxperiod_id
        and    pt.calctype in ('8')
        and    pt.code = case when vgrouptbo_id is null then
        (select (case when ((count(l.land_id) = 1) and ( vconstructionbound = '2')) then '4'  --  nezastroen
                     when count(l.land_id) <> 1 and  vconstructionbound = '2' then '3'         -- v izvan regulaciq            
                     when count(l.land_id) = 1 and vconstructionbound <> '2' then '2' 
                     when count(l.land_id) <> 1 and vconstructionbound <> '2' then '1' end) 
                 from   land l, property p
                 where  coalesce(l.builtuparea, 0) = 0
                 and    l.property_id = p.property_id
                 and    p.taxdoc_id = iptaxdoc_Id
                 and    p.kindproperty = '1')
                 when vgrouptbo_id is not null then '1' end;
      else
        rprtbo.sw_home         := 0;
        rprtbo.clean_home      := 0;
        rprtbo.depot_home      := 0;
        rprtbo.sw              := 0;
        rprtbo.clean           := 0;
        rprtbo.depot           := 0;
        rprtbo.tbo_code        := 0;
        rprtbo.pctfree_telk    := 0;
        rprtbo.calctype        := 0;
        rprtbo.code            := 0;
        rprtbo.fsw_home        := 0;
        rprtbo.fclean_home     := 0;
        rprtbo.fdepot_home     := 0;
        rprtbo.fsw             := 0;
        rprtbo.fclean          := 0;
        rprtbo.fdepot          := 0;
        rprtbo.municipality_id := 0;
      end if;
      if vgrouptbo_id is not null
      then
        select *
        into   rgrouptbo
        from   grouptbo gt
        where  gt.grouptbo_id = vgrouptbo_id;
        if rgrouptbo.tbo_code <> 9
        then
          rprtbo.sw_home     := rprtbo.sw_home * coalesce(rgrouptbo.isswh, 0.0);
          rprtbo.clean_home  := rprtbo.clean_home * coalesce(rgrouptbo.iscleanh, 0.0);
          rprtbo.depot_home  := rprtbo.depot_home * coalesce(rgrouptbo.isdepoth, 0.0);
          rprtbo.sw          := rprtbo.sw * coalesce(rgrouptbo.issw, 0.0);
          rprtbo.clean       := rprtbo.clean * coalesce(rgrouptbo.isclean, 0.0);
          rprtbo.depot       := rprtbo.depot * coalesce(rgrouptbo.isdepot, 0.0);
          rprtbo.fsw_home    := rprtbo.fsw_home * coalesce(rgrouptbo.isswh, 0.0);
          rprtbo.fclean_home := rprtbo.fclean_home * coalesce(rgrouptbo.iscleanh, 0.0);
          rprtbo.fdepot_home := rprtbo.fdepot_home * coalesce(rgrouptbo.isdepoth, 0.0);
          rprtbo.tbo_code    := rgrouptbo.tbo_code;
        else
          rprtbo.sw_home     := coalesce(rgrouptbo.isswh, 0.0);
          rprtbo.clean_home  := coalesce(rgrouptbo.iscleanh, 0.0);
          rprtbo.depot_home  := coalesce(rgrouptbo.isdepoth, 0.0);
          rprtbo.sw          := coalesce(rgrouptbo.issw, 0.0);
          rprtbo.clean       := coalesce(rgrouptbo.isclean, 0.0);
          rprtbo.depot       := coalesce(rgrouptbo.isdepot, 0.0);
          rprtbo.fsw_home    := coalesce(rgrouptbo.isswh, 0.0);
          rprtbo.fclean_home := coalesce(rgrouptbo.iscleanh, 0.0);
          rprtbo.fdepot_home := coalesce(rgrouptbo.isdepoth, 0.0);
          rprtbo.tbo_code    := rgrouptbo.tbo_code;
        end if;
      end if;
      if vgarbtax_id is not null
      then
        
        rprtbo.sw_home     := rprtbo.sw_home * coalesce(vsw_missing, 0);
        rprtbo.clean_home  := rprtbo.clean_home * coalesce(vclean_missing, 0);
        rprtbo.depot_home  := rprtbo.depot_home * coalesce(vdepot_missing, 0);
        rprtbo.sw          := rprtbo.sw * coalesce(vsw_missing, 0);
        rprtbo.clean       := rprtbo.clean * coalesce(vclean_missing, 0);
        rprtbo.depot       := rprtbo.depot * coalesce(vdepot_missing, 0);
        rprtbo.fsw_home    := rprtbo.fsw_home * coalesce(vsw_missing, 0);
        rprtbo.fclean_home := rprtbo.fclean_home * coalesce(vclean_missing, 0);
        rprtbo.fdepot_home := rprtbo.fdepot_home * coalesce(vdepot_missing, 0);
      end if;
      if vgarbtax19 is not null
      then
        if ((vgrouptbo_id is null) or (coalesce(rgrouptbo.tbo_code, '0') <> '9'))
        then
          rprtbo.sw_home     := 0;
          rprtbo.depot_home  := 0;
          rprtbo.sw          := 0;
          rprtbo.depot       := 0;
          rprtbo.fsw_home    := 0;
          rprtbo.fdepot_home := 0;
        end if;
      end if;
      ---------------------  end danni za TBO
      ---------------------   danni za DNI
      select count(nd.normdni_id)
      into   brnom
      from   normdni nd
      where  nd.municipality_id = vmunicipality_id
      and    nd.city_id = vcity_id
      and    nd.taxperiod_id = vtaxperiod_id;
      if brnom = 0
      then
        open crdni(0, vtaxperiod_id, vmunicipality_id);
      else
        open crdni(vcity_id, vtaxperiod_id, vmunicipality_id);
      end if;
      loop
        fetch crdni
          into rowDNI;
        exit when not FOUND;
        DNI[rowdni.code] := row(rowdni.calctype, rowdni.code, rowdni.homeprom, rowdni.nohomeprom);

      end loop;
      close crdni;
    
      open crbuilding;
      loop
        osv0         := 0;
        osv1         := 0;
        osv2         := 0;
        vTaxFreeFrom := null; --to_date('01.01.1900','dd.mm.yyyy');
        vTaxFreeTo   := null; --to_date('01.01.3000','dd.mm.yyyy');
      
        fetch crBuilding
          into rBuilding;
        exit when((not FOUND) or (rBuilding.Building_Id is null));
      
      
        if rBuilding.Kindfunction::integer < 5
        then
          --     vPRM := coalesce(vhomeprom,0);
          flho := 1;
          --    else
          --     vPRM := coalesce(vnohomeprom,0);
        end if;
      
        --- Osvobozdavane za godini
      if rbuilding.zeesertificat = '1' then
       if (rBuilding.Zeecategory = 'A') or (rBuilding.Zeecategory = '�')
        then
          if --(rBuilding.Buildyear < to_date('01.01.2005', 'dd.mm.yyyy')) and
             (rBuilding.Zeeactivity = 1) and
             vTDateBegin between
             to_date('01.01.' ||
                     to_char(to_number(to_char(rBuilding.Zeesertdate - 1, 'yyyy')) + 1),
                     'dd.mm.yyyy') and
             to_date('01.01.' ||
                     to_char(to_number(to_char(rBuilding.Zeesertdate - 1, 'yyyy')) + 10),
                     'dd.mm.yyyy')
          then
            osv0 := 1;
          end if;
        end if;
        if (rBuilding.Zeecategory = 'A') or (rBuilding.Zeecategory = '�')
        then
          if --(rBuilding.Buildyear < to_date('01.01.2005', 'dd.mm.yyyy')) and
             (rBuilding.Zeeactivity <> 1) and
             vTDateBegin between
             to_date('01.01.' ||
                     to_char(to_number(to_char(rBuilding.Zeesertdate - 1, 'yyyy')) + 1),
                     'dd.mm.yyyy') and
             to_date('01.01.' ||
                     to_char(to_number(to_char(rBuilding.Zeesertdate - 1, 'yyyy')) + 7),
                     'dd.mm.yyyy')
          then
            osv0 := 1;
          end if;
        end if;
        if (rBuilding.Zeecategory = 'B') or (rBuilding.Zeecategory = '�')
        then
          if --(rBuilding.Buildyear < to_date('01.01.2005', 'dd.mm.yyyy')) and
             (rBuilding.Zeeactivity = 1) and
             vTDateBegin between
             to_date('01.01.' ||
                     to_char(to_number(to_char(rBuilding.Zeesertdate - 1, 'yyyy')) + 1),
                     'dd.mm.yyyy') and
             to_date('01.01.' ||
                     to_char(to_number(to_char(rBuilding.Zeesertdate - 1, 'yyyy')) + 5),
                     'dd.mm.yyyy')
          then
            osv0 := 1;
          end if;
        end if;
        if (rBuilding.Zeecategory = 'B') or (rBuilding.Zeecategory = '�')
        then
          if --(rBuilding.Buildyear < to_date('01.01.2005', 'dd.mm.yyyy')) and
             (rBuilding.Zeeactivity <> 1) and
             vTDateBegin between
             to_date('01.01.' ||
                     to_char(to_number(to_char(rBuilding.Zeesertdate - 1, 'yyyy')) + 1),
                     'dd.mm.yyyy') and
             to_date('01.01.' ||
                     to_char(to_number(to_char(rBuilding.Zeesertdate - 1, 'yyyy')) + 3),
                     'dd.mm.yyyy')
          then
            osv0 := 1;
          end if;
        end if;
       end if;
     
        open crhomeobject(rbuilding.building_id);
        loop
          fetch crhomeobject
            into rhomeobject;
          exit when not FOUND;
          select into recTaxValHome * from taxvaluation.TaxValHome(rhomeobject.homeobj_id,
                     to_date('01.01.' || to_char(vTaxYear), 'dd.mm.yyyy'),
                     rbuilding.kindfunction);
          ErrTxt := recTaxValHome.return_val;
          vDOHomeObj := recTaxValHome.vgroupe;
          koefobj := recTaxValHome.opmess;
          if ErrTxt <> 'OK'
          then
            exit;
          end if;
          vhbDate := vTDateBegin;
        
          if to_date('01.' ||
                     to_char(add_months(coalesce(rhomeobject.earn_date::date,
                                            to_date('19000101', 'yyyymmdd')), 1),
                             'mm.yyyy'), 'dd.mm.yyyy') > vhbDate
          then
            vhbDate := to_date('01.' ||
                               to_char(add_months(coalesce(rhomeobject.earn_date::date,
                                                      to_date('19000101',
                                                               'yyyymmdd')), 1),
                                       'mm.yyyy'), 'dd.mm.yyyy');
          end if;
          if to_date('01.' ||
                     to_char(coalesce(rhomeobject.taxbegindate::date,
                                 to_date('19000101', 'yyyymmdd')), 'mm.yyyy'),
                     'dd.mm.yyyy') > vhbDate
          then
            vhbDate := to_date('01.' ||
                               to_char(coalesce(rhomeobject.taxbegindate::date,
                                           to_date('19000101', 'yyyymmdd')),
                                       'mm.yyyy'), 'dd.mm.yyyy');
          end if;
          vheDate := vTDateEnd;
          if rhomeobject.taxenddate < vTDateEnd
          then
            vheDate := rhomeobject.taxenddate;
          end if;
          if vheDate >= vhbDate
          then
            vsumDO       := vsumDO + vDOHomeObj;
           if coalesce(trunc(rhomeobject.builddate),'1900') < '2005' then
            osv3 := osv0; else       osv3 := 0;
           end if; 
--            osv1         := osv0;
            osv2         := 0;
            vTaxFreeFrom := null; --to_date('01.01.1900','dd.mm.yyyy');
            vTaxFreeTo   := null; --to_date('01.01.3000','dd.mm.yyyy');
          
            if ((rBuilding.Monument = 1) and (rhomeobject.isbusiness = 0)) or
               (rBuilding.Publictransport = 1) or
               ((rBuilding.Farm = 1) and (rhomeobject.isbusiness = 1) and
               (vhbDate < to_date('01.01.2010', 'dd.mm.yyyy'))) or
               (rBuilding.Istemporary = 1) or
               ((rBuilding.Bck = 1) and (rhomeobject.isbusiness = 0)) or
               (rBuilding.Outland = 1) or (rBuilding.Dutyfree = 1)
            then
              osv1 := 1;
            end if;
            -------- Osvobozdavane po meseci
            if (osv1 = 0) and (osv3 = 0)
--            if osv1 = 0
            then
              if rBuilding.Restorebuild = 1
              then
                /*select cross_date(vhbDate, vheDate,
                           last_day(rBuilding.Restorebuild_Date - 1) + 1,
                           last_day(add_months(rBuilding.Restorebuild_Date - 1,
                                                60)), v2From, v2To);*/
                select into recCross_Date * from taxvaluation.cross_date(vhbDate, vheDate,
                           last_day(rBuilding.Restorebuild_Date - interval '1 day') + interval '1 day',
                           last_day(add_months(rBuilding.Restorebuild_Date::date - interval '1 day',60)));
                v2From := recCross_Date.begin_date;
                v2To := recCross_Date.end_date;
                if v2From is not null and v2To is not null
                then
                  osv2 := 1;
                  if vTaxFreeFrom is not null and vTaxFreeFrom > v2From
                  then
                    vTaxFreeFrom := v2From;
                  end if;
                  if vTaxFreeFrom is null
                  then
                    vTaxFreeFrom := v2From;
                  end if;
                  if vTaxFreeTo is not null and vTaxFreeTo < v2to
                  then
                    vTaxFreeTo := v2to;
                  end if;
                  if vTaxFreeTo is null
                  then
                    vTaxFreeTo := v2to;
                  end if;
                end if;
              
              end if;
            end if;
            select count(ho.parthomeobj_id)
            into   brzap
            from   Parthomeobj ho
            where  ho.homeobj_id = rhomeobject.homeobj_id
            and    ho.typedeclar = '2';
            crSubject_row_cnt :=0;
            open crSubject(rhomeobject.homeobj_id);
            vDOUsers    := 0;
            ownerpart   := 0;
            DOSum       := 0;
            userspart   := 0;
            vDOPartSubj := 0;
            loop
              ------  ����� � ��� � ��������/���������� ��� � Part
              fetch crSubject
                into rSubject;
              exit when not FOUND;
              crSubject_row_cnt := crSubject_row_cnt +1;
              vDNIFreeObj  := 0;
              vDNIFreeSubj := 0;
              vcalctype    := DNI[1].calctype;
              select ts.isperson
              into   vperson
              from   taxsubject ts
              where  ts.taxsubject_id = rsubject.taxsubject_id;
              vdebtsubject_id := null;
              if (coalesce(rdoc.close_taxdoc_id, 0.0) <> 1)
              then
                select min(ds.debtsubject_id)
                into   vdebtsubject_id
                from   debtsubject ds
                where  ds.taxsubject_id = rSubject.Taxsubject_Id
                and    ds.document_id = iptaxdoc_Id
                and    ds.taxperiod_id = vtaxperiod_id
                and    ds.kinddebtreg_id = 2
                and    coalesce(ds.docno, '*') = coalesce(rdoc.docno, '*')
                and    coalesce(ds.doc_date::date, trunc(current_date)) =
                       coalesce(rdoc.doc_date::date, trunc(current_date));
              else
                select min(ds.debtsubject_id)
                into   vdebtsubject_id
                from   debtsubject ds
                where  ds.taxsubject_id = rSubject.Taxsubject_Id
                and    ds.document_id = iptaxdoc_Id
                and    ds.taxperiod_id = vtaxperiod_id
                and    ds.kinddebtreg_id = 2
                and    coalesce(ds.docno, '*') = coalesce(rdoc.docno, '*')
                and    coalesce(ds.doc_date::date, trunc(current_date)) =
                       coalesce(rdoc.doc_date::date, trunc(current_date))
                and    ds.userdate > vcurtime;
              end if;
              vtbodebt_id := null;
              if (coalesce(rdoc.close_taxdoc_id, 0.0) <> 1)
              then
                select min(ds.debtsubject_id)
                into   vtbodebt_id
                from   debtsubject ds
                where  ds.taxsubject_id = rSubject.Taxsubject_Id
                and    ds.document_id = iptaxdoc_Id
                and    ds.taxperiod_id = vtaxperiod_id
                and    ds.kinddebtreg_id = 5
                and    coalesce(ds.docno, '*') = coalesce(rdoc.docno, '*')
                and    coalesce(ds.doc_date::date, trunc(current_date)) =
                       coalesce(rdoc.doc_date::date, trunc(current_date));
              else
                select min(ds.debtsubject_id)
                into   vtbodebt_id
                from   debtsubject ds
                where  ds.taxsubject_id = rSubject.Taxsubject_Id
                and    ds.document_id = iptaxdoc_Id
                and    ds.taxperiod_id = vtaxperiod_id
                and    ds.kinddebtreg_id = 5
                and    coalesce(ds.docno, '*') = coalesce(rdoc.docno, '*')
                and    coalesce(ds.doc_date::date, trunc(current_date)) =
                       coalesce(rdoc.doc_date::date, trunc(current_date))
                and    ds.userdate > vcurtime;
              end if;
            
              if vcalctype = '0'
              then
                if vperson = 1
                then
                  if rhomeobject.kindhomeobjreg_id < 6
                  then
                    vPRM := coalesce(DNI[1].homeprom, 0.0);
                  else
                    vPRM := coalesce(DNI[1].nohomeprom, 0.0);
                  end if;
                else
                  if rhomeobject.kindhomeobjreg_id < 6
                  then
                    vPRM := coalesce(DNI[99].homeprom, 0.0);
                  else
                    vPRM := coalesce(DNI[99].nohomeprom, 0.0);
                  end if;
                end if;
              elsif vcalctype = '1'
              then
                if vperson = 1
                then
                  if rhomeobject.kindhomeobjreg_id < 6
                  then
                    if coalesce(vconstructionbound, '0') = '2'
                    then
                      vPRM := coalesce(DNI[2].homeprom, 0.0);
                    else
                      vPRM := coalesce(DNI[1].homeprom, 0.0);
                    end if;
                  else
                    if coalesce(vconstructionbound, '0') = '2'
                    then
                      vPRM := coalesce(DNI[2].nohomeprom, 0.0);
                    else
                      vPRM := coalesce(DNI[1].nohomeprom, 0.0);
                    end if;
                  end if;
                else
                  if rhomeobject.kindhomeobjreg_id < 6
                  then
                    vPRM := coalesce(DNI[99].homeprom, 0.0);
                  else
                    vPRM := coalesce(DNI[99].nohomeprom, 0.0);
                  end if;
                end if;
              elsif vcalctype = '2'
              then
                if vperson = 1
                then
                  if rhomeobject.kindhomeobjreg_id < 6
                  then
                    if coalesce(rsubject.isbasehome, 0.0) = 1
                    then
                      vPRM := coalesce(DNI[1].homeprom, 0.0);
                    else
                      select min(homeobj_id)
                      into   vminhobj_id
                      from   (select ho.homeobj_id, td.taxdoc_id, ho.earn_date,
                                      td.doc_date
                               from   parthomeobj ph, homeobj ho, taxdoc td,
                                      building b, property p, taxsubject ts
                               where  ph.taxsubject_id = rSubject.Taxsubject_Id
                               and    ho.homeobj_id = ph.homeobj_id
                               and    coalesce(ph.isbasehome, 0.0) <> 1
                               and    ho.kindhomeobjreg_id < 6 --- ??? Samo zili6ta ????
                               and    ts.taxsubject_id = ph.taxsubject_id
                               and    ts.isperson = 1
                               and    ho.building_id = ho.building_id
                               and    b.property_id = p.property_id
                               and    p.taxdoc_id = td.taxdoc_id
                               order  by ho.earn_date, td.doc_date) t
                      where  rownum = 1;
                      if coalesce(vminhobj_id, 0.0) = rhomeobject.homeobj_id
                      then
                        vPRM := coalesce(DNI[2].homeprom, 0.0);
                      else
                        vPRM := coalesce(DNI[3].homeprom, 0.0);
                      end if;
                      --             vPRM := coalesce(DNI(decode(coalesce(vconstructionbound,0),2,2,1)).homeprom,0);
                    end if;
                  else
                    vPRM := coalesce(DNI[1].nohomeprom, 0.0);
                  end if;
                else
                  if rhomeobject.kindhomeobjreg_id < 6
                  then
                    vPRM := coalesce(DNI[99].homeprom, 0.0);
                  else
                    vPRM := coalesce(DNI[99].nohomeprom, 0.0);
                  end if;
                end if;
              end if;
              if coalesce(rSubject.Area, 0.0) > 0 and
                 coalesce(rhomeobject.totalarea, 0.0) > 0
              then
                rSubject.Part := round(coalesce(rSubject.Area, 0.0) /
                                       rhomeobject.totalarea, 2);
              else
                if coalesce(rSubject.Part, 0.0) = 0 and coalesce(rSubject.Divisor, 0.0) <> 0
                then
                  rSubject.Part := rSubject.Divident / rSubject.Divisor;
                end if;
              end if;
              if rSubject.Typedeclar = '2'
              then
                userspart := userspart + rSubject.Part;
                vuskoef   := 1;
              else
                select count(*)
                into   vusernum
                from   parthomeusers ph, parthomeobj h
                where  ph.userparthome_id = h.parthomeobj_id
                and    ((coalesce(h.part, 0.0) > 0) or (coalesce(h.divident, 0.0) > 0)) ---- 15.09
                and    h.homeobj_id = rhomeobject.homeobj_id;
                if vusernum > 0
                then
                  select sum(decode(coalesce(ph.part, 0.0), 0.0,
                                     coalesce(ph.divident, 0.0) /
                                      decode(coalesce(ph.divisor, 0.0), 0.0, 1.0, ph.divisor),
                                     ph.part))
                  into   userspart
                  from   parthomeusers ph
                  where  ph.ownerparthome_id = rSubject.Parthomeobj_Id;
                  vuskoef := 1 - coalesce(userspart, 0.0);
                else
                  vuskoef   := 1 - userspart;
                  ownerpart := ownerpart + rSubject.Part;
                end if;
              end if;
              vDOYear := round(vuskoef * rSubject.Part * vDOHomeObj, 1);
              DOSum   := DOSum + vDOYear;
              ---- ????? -----crSubject_row_cnt
              --------if crSubject%rowcount = brzap and rSubject.Typedeclar = '2' and
              if crSubject_row_cnt = brzap and rSubject.Typedeclar = '2' and
                 round(ownerpart, 2) = 1
              then
                vDOYear := vDOYear + vDOHomeObj - DOSum;
              end if;
              vDNIYear    := round(vDOYear * vPRM / 1000, 2);
              vDOSubject  := round(vDOYear *
                                   (round(months_between(vheDate, vhbDate))) / 12,
                                   1);
              vDNISubject := round((vPRM * vDOYear *
                                   (round(months_between(vheDate, vhbDate))) / 12) / 1000,
                                   2);
              if rSubject.Typedeclar = '2'
              then
                vDOPartSubj := 0;
              else
                vDOPartSubj := round(rSubject.Part * vDOHomeObj, 1);
              end if;
               if (osv1 = 1) or  (osv3 = 1)
 --            if osv1 = 1
              then
                vDNISubject := 0;
                vDNIFreeObj := round((vPRM * vDOYear *
                                     (round(months_between(vheDate, vhbDate))) / 12) / 1000,
                                     2);
              else
                if osv2 = 1
                then
                  vDNISubject := round((vPRM * vDOYear *
                                       (round(months_between(vheDate, vhbDate)) -
                                       round(months_between(vTaxFreeTo,
                                                              vTaxFreeFrom))) / 12) / 1000,
                                       2);
                  vDNIFreeObj := round((vPRM * vDOYear *
                                       (round(months_between(vTaxFreeTo,
                                                              vTaxFreeFrom))) / 12) / 1000,
                                       2);
                end if;
              end if;
              indtelk  := 0;
              vsrok_bh := vheDate - vhbDate;
              if (vsrok_bh <= 182)
              then
                vsrok_bh := taxvaluation.per_basehome(rSubject.Homeobj_Id,
                                         rSubject.Taxsubject_Id, vheDate);
              end if;
              telkbDate  := null;
              telkEdate  := null;
              vrelief_id := null;
              if (rSubject.Isbasehome = 1) and (vsrok_bh > 182)
              then
                vDNIFreeSubj := round(vDNISubject / 2, 2);
                vDNISubject  := vDNISubject - vDNIFreeSubj;
                select min(r.telk_begindate), min(r.telk_enddate),
                       min(r.relief_id)
                into   telkbDate, telkEdate, vrelief_id
                from   relief r, partproperty pp
                where  r.relief_id = pp.relief_id
                and    pp.property_id = rBuilding.Property_Id
                and    pp.taxsubject_id = rSubject.Taxsubject_Id;
                if vrelief_id is not null and telkbDate is null
                then
                  telkbDate := vhbDate;
                end if;
                if telkbDate is not null and telkEdate is null
                then
                  telkEdate := vheDate;
                end if;
                if telkbDate is not null and telkEdate is not null
                then
                  /*select cross_date(vhbDate, vheDate, last_day(telkbDate - 1) + 1,
                             last_day(telkeDate), tobDate, toeDate);*/
                  select into recCross_Date * from taxvaluation.cross_date(vhbDate, vheDate, last_day(telkbDate::date - interval '1 day') + interval '1 day',
                             last_day(telkeDate::date));
                  tobDate := recCross_Date.begin_date;
                  toeDate := recCross_Date.end_date;
                  --- Dali e osvoboden v drug interval ?????
                  --   vDNISubject :=  vDNISubject - (vDNISubject * (round(months_between(vTDateEnd, vTDateBegin)) - round(months_between(toeDate, tobDate))) / round(months_between(vTDateEnd, vTDateBegin))) / 2;
                  if tobDate is not null and toeDate is not null and tobDate <> toeDate
                  then
                    vDNIFreeSubj := vDNIFreeSubj + round((vDNISubject *
                                                         (round(round(months_between(toeDate,
                                                                                      tobDate))) /
                                                         round(months_between(vheDate,
                                                                                vhbDate)))) / 2,
                                                         2);
                    vDNISubject  := vDNISubject - round((vDNISubject *
                                                        (round(round(months_between(toeDate,
                                                                                     tobDate))) /
                                                        round(months_between(vheDate,
                                                                               vhbDate)))) / 2,
                                                        2);
                    indtelk      := 1;
                  end if;
                end if;
              end if;
              --- 03.04.2012 --- za NE gilishta na firmi
               if (coalesce(vperson,0) <> 1) and (rhomeobject.kindhomeobjreg_id > 5) 
                  and (rhomeobject.kindhomeobjreg_id <> 0) and rSubject.Typedeclar = '1' then
                  vDNISubject := 0; vDNIFreeSubj := 0;
               end if;
              ---  Zapis v tablicite za obj i subj
              vinst_number := round(months_between(vheDate, vhbDate) + 1 / 3);
              select min(tp.taxperiod_id)
              into   vtaxperiod_id
              from   taxperiod tp
              where  tp.taxperkind = '0'
              and    tp.begin_date <= vhbDate
              and    tp.end_date >= vheDate;
              if vtaxperiod_id is null
              then
                exit;
              end if;
              select min(td.documenttype_id), min(t.doccode)
              into   vdoctype_id, vdoccode
              from   taxdoc td, documenttype t
              where  td.taxdoc_id = iptaxdoc_Id
              and    td.documenttype_id = t.documenttype_id;
              if vdebtsubject_id is null
              then
                select nextval('s_debtsubject')
                into   vdebtsubject_id;
                insert into debtsubject
                  (debtsubject_id, taxsubject_id, document_id, kinddoc,
                   kinddebtreg_id, taxperiod_id, doccode, tax_begidate,
                   tax_enddate, relief_id, Totalval, Totaltax, calcdate,
                   FreeSum_obj, prtdate, inst_number, FreeSum_Subj,
                   corr_instnumber, codetbo, corr_sumtotal, userdate, user_id,
                   -----------
                   taxobject_id, partidano, municipality_id, kindparreg_id,
                   paydiscsum, docno, doc_date, parent_debtsubject_id, admregion_id
                   -----------
                   )
                values
                  (vdebtsubject_id, rSubject.Taxsubject_Id, iptaxdoc_Id, 1, 2,
                   vtaxperiod_id, vdoccode, vTDateBegin, vTDateEnd, vrelief_id,
                   round(vDOSubject, 2), round(vDNISubject, 2), trunc(current_date),
                   vDNIFreeObj, null, vinst_number, round(vDNIFreeSubj, 2), null,
                   null, null, CURRENT_TIMESTAMP, ipuser_id, rdoc.taxobject_id,
                   rdoc.partidano, rdoc.municipality_id, vparreg, null,
                   rdoc.docno, rdoc.doc_date, null,vadmregion_id);
             else
                update debtsubject 
                set    totalval = totalval + round(vDOSubject, 2),
                       totaltax = totaltax + round(vDNISubject, 2),
                       freesum_obj = freesum_obj + round(vDNIFreeObj, 2),
                       freesum_subj = freesum_subj +
                                          round(vDNIFreeSubj, 2)
                where  debtsubject_id = vdebtsubject_id;
              end if;
              select nextval('s_debtpartproperty')
              into   vdebtpartproperty_id;
              insert into debtpartproperty 
                (debtpartproperty_id, debtsubject_id, taxperiod_id,
                 kindproperty, seqnots, typedeclar, isbasehome, isrelief,
                 relief_id, divident, divisor, part, sumval, sumtax,
                 taxbegindate, taxenddate, totalval, totaltax, userdate, user_id,
                 homeobj_id, freefrom, freemonths, codetbo, promiltbo,
                 freesuma_obj, freesuma_subj, parentdebtprop_id, SUBJPARTVAL,
                 koeff)
              values
                (vdebtpartproperty_id, vdebtsubject_id, vtaxperiod_id, 2,
                 rSubject.Seqnots, rSubject.Typedeclar, rSubject.Isbasehome,
                 decode(vrelief_id, null, 0, 1), vrelief_id, rSubject.Divident,
                 rSubject.Divisor, rSubject.Part, vDOYear, vDNIYear, vhbDate,
                 vheDate, round(vDOSubject, 2), round(vDNISubject, 2), CURRENT_TIMESTAMP,
                 ipuser_id, rhomeobject.homeobj_id, vTaxFreeFrom,
                 decode(vTaxFreeFrom, null, 0,
                         round(months_between(vTaxFreeTo, vTaxFreeFrom))), null,
                 null, vDNIFreeObj, vDNIFreeSubj, null, vDOPartSubj, koefobj);
              -------- TBO
              -- ???? Uslovie pri koeto se pravi ????
              select min(c.configvalue)
              into   vtboyear
              from   config c
              where  c.municipality_id = rdoc.municipality_id
              and    c.name = 'TBOYEAR' || vTaxYear;
              if coalesce(vtboyear, vTaxYear::character varying)::numeric <> vTaxYear
              then
                --  if vTaxYear = '2009' then
                /*select taxvaluation.TaxValHome(ErrTxt, rhomeobject.homeobj_id,
                           to_date('01.01.' || vtboyear, 'dd.mm.yyyy'),
                           rBuilding.Kindfunction, vDOTBOHomeObj, koefobjtbo);*/
                select into recTaxValHome * from taxvaluation.TaxValHome(rhomeobject.homeobj_id,
                           to_date('01.01.' || vtboyear, 'dd.mm.yyyy'),
                           rBuilding.Kindfunction);
                ErrTxt := recTaxValHome.return_val;
                vDOTBOHomeObj := recTaxValHome.vgroupe;
                koefobjtbo := recTaxValHome.opmess;
                if ErrTxt <> 'OK'
                then
                  exit;
                end if;
                if vDOHomeObj <> 0
                then
                  vDOTBOYear    := vDOYear * vDOTBOHomeObj / vDOHomeObj;
                  vDOTBOSubject := vDOSubject * vDOTBOHomeObj / vDOHomeObj;
                else
                  vDOTBOYear    := 0;
                  vDOTBOSubject := 0;
                end if;
              else
                vDOTBOYear    := vDOYear;
                vDOTBOSubject := vDOSubject;
              end if;
              --perform taxvaluation.countTBO(0);
              select into recCountTBO * from taxvaluation.countTBOnew(0
                                      , iptaxdoc_Id , vdoccode 
                                      , vparreg , vinst_number 
                                      , ipuser_id 
                                      , vtaxperiod_id 
                                      , vTDateBegin , vTDateEnd 
                                      , vsrok_bh , flho 
                                      , rBuilding.structurezone /*rBuilding crbuilding%Rowtype*/  
                                      , vhbDate , vheDate 
                                      , indtelk , vrelief_id 
                                      , vTaxFreeFrom , vTaxFreeTo 
                                      , vDOTBOYear , vDOTBOSubject 
                                      , vDOPartSubj 
                                      ----------------------------
                                      , rdoc 
                                      , rhomeobject 
                                      , rLand 
                                      , rSubjLand 
                                      , rSubject 
                                      ---------------------------- 
                                      , rprtbo , vTBODebt_id 
                                      , vdebtpartproperty_id , vsumtboy, vsumtboy_cont); 
              rprtbo := recCountTBO.rprtbo;
              vTBODebt_id := recCountTBO.vTBODebt_id;
              vdebtpartproperty_id := recCountTBO.vdebtpartproperty_id;
              vsumtboy := recCountTBO.vsumtboy;
              vsumtboy_cont := recCountTBO.vsumtboy_cont;
            end loop;
            close crSubject;
          end if; --- s period w godinata
        end loop;
        close crhomeobject;
      end loop; -- Building
      ---
      close crbuilding;
      select min(p.kindproperty)
      into   i
      from   property p
      where  p.property_id = rBuilding.Property_Id;
      open crLand;
      loop
        indtelk := 0;
        fetch crLand
          into rLand;
        exit when not FOUND;
        select into recTaxValLand * from taxvaluation.TaxValLand(rLand.Land_id,
                   to_date('01.01.' || vTaxYear, 'dd.mm.yyyy'));
        ErrTxt := recTaxValLand.return_val;
        vLandVal := recTaxValLand.vgroupe;
        koefobj := recTaxValLand.opmess;
        if ErrTxt <> 'OK'
        then
          return; --(ErrTxt);
        end if;
        vhbDate := vTDateBegin;
        rland.earn_date := coalesce(rland.earn_date::date, to_date('01.01.1900', 'dd.mm.yyyy'));
        if to_date('01.' ||
                   to_char(add_months(coalesce(rland.earn_date::date,
                                          to_date('01.01.1900', 'dd.mm.yyyy')), 1),
                           'mm.yyyy'), 'dd.mm.yyyy') > vhbDate
        then
          vhbDate := to_date('01.' ||
                             to_char(add_months(rland.earn_date::date, 1), 'mm.yyyy'),
                             'dd.mm.yyyy');
        end if;
        if rland.taxbegindate > vhbDate
        then
          vhbDate := to_date('01.' || to_char(rland.taxbegindate, 'mm.yyyy'),
                             'dd.mm.yyyy');
        end if;
        vheDate := vTDateEnd;
        if rland.taxenddate < vTDateEnd
        then
          vheDate := rland.taxenddate;
        end if;
      
        if vhbDate <= vheDate
        then
          vsumDO := vsumDO + vLandVal;
          osv1   := 0;
          if rLand.Ispark = 1
          then
            osv1 := 1;
          end if;
          if rLand.Issport = 1
          then
            osv1 := 1;
          end if;
          if rLand.Ispublic = 1
          then
            osv1 := 1;
          end if;
          if rLand.Dutyfree = 1
          then
            osv1 := 1;
          end if;
          if osv1 = 1
          then
            vTaxFreeFrom := vTDateBegin;
            vTaxFreeTo   := vTDateEnd;
          else
            if (coalesce(rLand.Restoreland, 0.0)) <> 0.0 and (rLand.Restorelanddate is not null)
            then
              /*select cross_date(vTDateBegin, vTDateEnd,
                         last_day(to_date(rLand.Restorelanddate, 'dd.mm.yyyy') - 1) + 1,
                         last_day(add_months(to_date(rLand.Restorelanddate,
                                                      'dd.mm.yyyy') - 1, 60)),
                         vTaxFreeFrom, vTaxFreeTo);*/
              select into recCross_Date * from taxvaluation.cross_date(vTDateBegin, vTDateEnd,
                         last_day(rLand.Restorelanddate - interval '1 day') + interval '1 day',
                         last_day(add_months(rLand.Restorelanddate::date,
                                                      - interval '1 day', 60)));
               vTaxFreeFrom := recCross_Date.begin_date;
              vTaxFreeTo := recCross_Date.end_date;
              if vTaxFreeFrom is not null and vTaxFreeTo is not null
              then
                osv1 := 1;
              end if;
            end if;
          end if;
          vDOUsers  := 0;
          userspart := 0;
          open crSubjLand(rLand.Land_Id);
          loop
            fetch crSubjLand
              into rSubjLand;
            exit when not FOUND;
            select ts.isperson
            into   vperson
            from   taxsubject ts
            where  ts.taxsubject_id = rSubjLand.taxsubject_id;
            vdebtsubject_id := null;
            if (coalesce(rdoc.close_taxdoc_id, 0.0) <> 1)
            then
              select min(ds.debtsubject_id)
              into   vdebtsubject_id
              from   debtsubject ds
              where  ds.taxsubject_id = rSubjLand.Taxsubject_Id
              and    ds.document_id = iptaxdoc_Id
              and    ds.taxperiod_id = vtaxperiod_id
              and    ds.kinddebtreg_id = 2
              and    coalesce(ds.docno, '*') = coalesce(rdoc.docno, '*')
              and    coalesce(ds.doc_date::date, trunc(current_date)) =
                     coalesce(rdoc.doc_date::date, trunc(current_date));
            else
              select min(ds.debtsubject_id)
              into   vdebtsubject_id
              from   debtsubject ds
              where  ds.taxsubject_id = rSubjLand.Taxsubject_Id
              and    ds.document_id = iptaxdoc_Id
              and    ds.taxperiod_id = vtaxperiod_id
              and    ds.kinddebtreg_id = 2
              and    coalesce(ds.docno, '*') = coalesce(rdoc.docno, '*')
              and    coalesce(ds.doc_date::date, trunc(current_date)) =
                     coalesce(rdoc.doc_date::date, trunc(current_date))
              and    ds.userdate > vcurtime;
            end if;
            vtbodebt_id := null;
            if (coalesce(rdoc.close_taxdoc_id, 0.0) <> 1)
            then
              select min(ds.debtsubject_id)
              into   vtbodebt_id
              from   debtsubject ds
              where  ds.taxsubject_id = rSubjLand.Taxsubject_Id
              and    ds.document_id = iptaxdoc_Id
              and    ds.taxperiod_id = vtaxperiod_id
              and    ds.kinddebtreg_id = 5
              and    coalesce(ds.docno, '*') = coalesce(rdoc.docno, '*')
              and    coalesce(ds.doc_date::date, trunc(current_date)) =
                     coalesce(rdoc.doc_date::date, trunc(current_date));
            else
              select min(ds.debtsubject_id)
              into   vtbodebt_id
              from   debtsubject ds
              where  ds.taxsubject_id = rSubjLand.Taxsubject_Id
              and    ds.document_id = iptaxdoc_Id
              and    ds.taxperiod_id = vtaxperiod_id
              and    ds.kinddebtreg_id = 5
              and    coalesce(ds.docno, '*') = coalesce(rdoc.docno, '*')
              and    coalesce(ds.doc_date::date, trunc(current_date)) =
                     coalesce(rdoc.doc_date::date, trunc(current_date))
              and    ds.userdate > vcurtime;
            end if;
          
            if (vperson = 1)
            then
              if flho = 1  or ( vstructurezone in ('1', '2', '4', '6'))
              then
                --   if ((flho = 1) or (rBuilding.Structurezone in ('4','6'))) then
                vPRM := coalesce(DNI[1].homeprom, 0.0);
              else
                vPRM := coalesce(DNI[1].nohomeprom, 0.0);
              end if;
            else
              if flho = 1
              then
                vPRM := coalesce(DNI[99].homeprom, 0.0);
              else
                vPRM := coalesce(DNI[99].nohomeprom, 0.0);
              end if;
            end if;
            if coalesce(rSubjLand.Area, 0.0) > 0 and coalesce(rLand.Landarea, 0.0) > 0
            then
              rSubjLand.Partland := round(coalesce(rSubjLand.Area, 0.0) /
                                          rLand.Landarea, 2);
            else
              if coalesce(rSubjLand.Partland, 0.0) = 0 and
                 coalesce(rSubjland.Divisorland, 0.0) <> 0
              then
                rSubjLand.Partland := rSubjLand.Dividentland /
                                      rSubjLand.Divisorland;
              end if;
            end if;
            if rSubjLand.Typedeclar = '2'
            then
              userspart := userspart + rSubjLand.Partland;
              vuskoef   := 1;
            else
              select count(*)
              into   vusernum
              from   partlandusers pl, partland l
              where  pl.userpartland_id = l.part_land_id
              and    ((coalesce(l.partland, 0.0) > 0) or (coalesce(l.dividentland, 0.0) > 0)) --- 15.09
              and    l.land_id = rLand.Land_Id;
              if vusernum > 0
              then
                select sum((case when coalesce(pl.part, 0.0) = 0.0 then
                                   coalesce(pl.divident, 0.0) /
                                    (case when coalesce(pl.divisor, 0.0) = 0.0 then 1.0 else pl.divisor end) else
                                   pl.part end))
                into   userspart
                from   partlandusers pl
                where  pl.ownerpartland_id = rSubjLand.Part_Land_Id;
                vuskoef := 1 - coalesce(userspart, 0.0);
              else
            --    vuskoef   := 1 - userspart;
                 select (sum((case when coalesce(pl.area,0.0) = 0.0 then (case when coalesce(pl.partland, 0.0) =  0.0 then
                             coalesce(pl.dividentland, 0.0) /
                              (case when coalesce(pl.divisorland, 0.0) =  0.0 then 1.0 else pl.divisorland end)
                           else  pl.partland end) else coalesce(pl.area,0.0)/coalesce(rLand.Landarea,1.0) end) - userspart)) ,
                         sum((case when coalesce(pl.area,0.0) =  0.0 then (case when coalesce(pl.partland, 0.0) = 0.0 then
                             coalesce(pl.dividentland, 0.0) /
                              (case when coalesce(pl.divisorland, 0.0) = 0.0 then 1 else pl.divisorland end) 
                             else pl.partland end) else coalesce(pl.area,0)/rLand.Landarea end))
                into vuskoef  , vDNIFreeSubj
                from partland pl
                where pl.land_id = rSubjLand.Land_Id
                and pl.typedeclar = '1'
                ;
                if coalesce(vDNIFreeSubj,0) <> 0 then
                  vuskoef := vuskoef / vDNIFreeSubj;
                else   vuskoef := 1;
                end if;
                vDNIFreeSubj := 0;
                ownerpart := ownerpart + rSubjLand.Partland;
              end if;
            end if;
            vDNIFreeSubj := 0;
            vDNIFreeObj  := 0;
            vDOPartSubj  := 0;
            vDOYear      := round(vuskoef * vLandVal * rSubjLand.Partland, 1);
            vDNIYear     := round(vDOYear * vPRM / 1000, 2);
            vDOSubject   := round(vDOYear *
                                  (round(months_between(vheDate, vhbDate))) / 12,
                                  1);
            vDNISubject  := round((vPRM * vDOYear *
                                  (round(months_between(vheDate, vhbDate))) / 12) / 1000,
                                  2);
            if rSubjLand.Typedeclar = '2'
            then
              vDOPartSubj := 0;
            else
              vDOPartSubj := round(vLandVal * rSubjLand.Partland, 1);
            end if;
            if osv1 = 1
            then
              vDNISubject := round((vPRM * vDOYear *
                                   (round(months_between(vTDateEnd, vTDateBegin)) -
                                   round(months_between(vTaxFreeTo,
                                                          vTaxFreeFrom))) / 12) / 1000,
                                   2);
              vDNIFreeObj := round((vPRM * vDOYear *
                                   (round(months_between(vTaxFreeTo,
                                                          vTaxFreeFrom))) / 12) / 1000,
                                   2);
            end if;
             ------ 03.04.2012        
            select count(*) into jj
            from homeobj h, building b
            where b.property_id = rLand.Property_Id
            and h.building_id = b.building_id
            and h.kindhomeobjreg_id between 1 and 5
            ;      
            if   (coalesce(vperson,0) <> 1) 
            and (((flho <> 1) and ( vstructurezone not in ('1', '2', '4', '6'))) or ((flho <> 1) and (jj = 0)))
            and rSubject.Typedeclar = '1'  then
                 vDNISubject := 0; vDNIFreeObj := 0;
             end if;
            
            select min(td.documenttype_id), min(t.doccode)
            into   vdoctype_id, vdoccode
            from   taxdoc td, documenttype t
            where  td.taxdoc_id = iptaxdoc_Id
            and    td.documenttype_id = t.documenttype_id;
            vinst_number := mod(round(months_between(vheDate, vhbDate)) + 2, 3);
            if vdebtsubject_id is null
            then
              select nextval('s_debtsubject')
              into   vdebtsubject_id;
              insert into debtsubject
                (debtsubject_id, taxsubject_id, document_id, kinddoc,
                 kinddebtreg_id, taxperiod_id, doccode, tax_begidate,
                 tax_enddate, relief_id, Totalval, Totaltax, calcdate,
                 FreeSum_obj, prtdate, inst_number, FreeSum_Subj,
                 corr_instnumber, codetbo, corr_sumtotal, userdate, user_id,
                 taxobject_id, partidano, municipality_id, kindparreg_id,
                 paydiscsum, docno, doc_date, parent_debtsubject_id, admregion_id)
              values
                (vdebtsubject_id, rSubjLand.Taxsubject_Id, iptaxdoc_Id, 1, 2,
                 vtaxperiod_id, vdoccode, vTDateBegin, vTDateEnd, null,
                 round(vDOSubject, 2), round(vDNISubject, 2), trunc(current_date),
                 round(vDNIFreeObj, 2), null, vinst_number,
                 round(vDNIFreeSubj, 2), null, null, null, CURRENT_TIMESTAMP, ipuser_id,
                 rdoc.taxobject_id, rdoc.partidano, rdoc.municipality_id,
                 vparreg, null, rdoc.docno, rdoc.doc_date, null, vadmregion_id);
            else
              update debtsubject 
              set    totalval = totalval + round(vDOSubject, 2),
                     totaltax = totaltax + round(vDNISubject, 2),
                     freesum_obj = freesum_obj + round(vDNIFreeObj, 2),
                     freesum_subj = freesum_subj + round(vDNIFreeSubj, 2)
              where  debtsubject_id = vdebtsubject_id;
            end if;
            select nextval('s_debtpartproperty')
            into   vdebtpartproperty_id;
            insert into debtpartproperty
              (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
               seqnots, typedeclar, isbasehome, isrelief, relief_id, divident,
               divisor, part, sumval, sumtax, taxbegindate, taxenddate, totalval,
               totaltax, userdate, user_id, homeobj_id, freefrom, freemonths,
               codetbo, promiltbo, freesuma_obj, freesuma_subj,
               parentdebtprop_id, SUBJPARTVAL, koeff)
            values
              (vdebtpartproperty_id, vdebtsubject_id, vtaxperiod_id, 1,
               rSubjLand.Seqnots, rSubjLand.Typedeclar, null,
               (case when vrelief_id is null then 0 else 1 end), vrelief_id,
               rSubjLand.Dividentland, rSubjLand.Divisorland, rSubjLand.Partland,
               round(vDOYear, 2), round(vDNIYear, 2), vhbDate, vheDate,
               round(vDOSubject, 2), round(vDNISubject, 2), CURRENT_TIMESTAMP, ipuser_id,
               rLand.Land_Id, vTaxFreeFrom,
               (case when vTaxFreeFrom is null then 0 else round(months_between(vTaxFreeTo, vTaxFreeFrom)) end), null,
               null, vDNIFreeObj, vDNIFreeSubj, null,
               --vLandVal * rSubjLand.Partland,
               (case when rSubjLand.Typedeclar =  '2'then 0 else
                       (case when rland.typedeclar =  2.0 then 0.0 else
                               (case when rland.buildingowner = 1.0 then 0.0 else
                                       vLandVal * rSubjLand.Partland end ) end ) end), koefobj);
            select min(c.configvalue)
            into   vtboyear
            from   config c
            where  c.municipality_id = rdoc.municipality_id
            and    c.name = 'TBOYEAR' || vTaxYear;
            if coalesce(vtboyear, vTaxYear::character varying)::numeric <> vTaxYear
            then
              -- if vTaxYear = '2009' then
              /*select TaxValLand(ErrTxt, rLand.Land_id,
                         to_date('01.01.' || to_char(vTaxYear - 1), 'dd.mm.yyyy'),
                         vTBOLandVal, koefobjtbo);*/
              select into recTaxValLand * from taxvaluation.TaxValLand(rLand.Land_id,
                         to_date('01.01.' || vtboyear , 'dd.mm.yyyy'));
              ErrTxt := recTaxValLand.return_val;
              vTBOLandVal := recTaxValLand.vgroupe;
              koefobjtbo := recTaxValLand.opmess;
              if ErrTxt <> 'OK'
              then
                exit;
              end if;
              if vLandVal <> 0
              then
                vDOTBOYear    := vDOYear * vTBOLandVal / vLandVal;
                vDOTBOSubject := vDOSubject * vTBOLandVal / vLandVal;
              else
                vDOTBOYear    := vDOYear;
                vDOTBOSubject := vDOSubject;
              end if;
            else
              vDOTBOYear    := vDOYear;
              vDOTBOSubject := vDOSubject;
            end if;
           -- perform taxvaluation.countTBO(1);
            select into recCountTBO * from taxvaluation.countTBOnew(1
                                      , iptaxdoc_Id , vdoccode 
                                      , vparreg , vinst_number 
                                      , ipuser_id 
                                      , vtaxperiod_id 
                                      , vTDateBegin , vTDateEnd 
                                      , vsrok_bh , flho 
                                      , rBuilding.structurezone /*rBuilding crbuilding%Rowtype*/  
                                      , vhbDate , vheDate 
                                      , indtelk , vrelief_id 
                                      , vTaxFreeFrom , vTaxFreeTo 
                                      , vDOTBOYear , vDOTBOSubject 
                                      , vDOPartSubj 
                                      ----------------------------
                                      , rdoc 
                                      , rhomeobject 
                                      , rLand 
                                      , rSubjLand 
                                      , rSubject 
                                      ---------------------------- 
                                      , rprtbo , vTBODebt_id 
                                      , vdebtpartproperty_id , vsumtboy, vsumtboy_cont);
              rprtbo := recCountTBO.rprtbo;
              vTBODebt_id := recCountTBO.vTBODebt_id;
              vdebtpartproperty_id := recCountTBO.vdebtpartproperty_id;
              vsumtboy := recCountTBO.vsumtboy;
              vsumtboy_cont := recCountTBO.vsumtboy_cont;
          end loop;
          close crSubjLand;
        end if;
      end loop; -- crLand
      close crland;
      --end if;
      --- s min stojnost na TBO ???
      if (coalesce(rprtbo.minvalue, 0.0) <> 0) and
         (vsumtboy < coalesce(rprtbo.minvalue, 0.0))
      then
        vmintbo := coalesce(rprtbo.minvalue, 0.0) - vsumtboy;
        --  vmintbo := vmintbo * round(months_between(vTDateEnd,vTDateBegin))/ 12;
        open crDebtSubj(vtaxperiod_id, rdoc.docno, rdoc.doc_date, vcurtime);
        loop
          fetch crDebtSubj
            into rDebtSubj;
          exit when not FOUND;
          if rDebtSubj.Kinddebtreg_Id = 5
          then
            vnewtbods := 0;
            open crpartp(rDebtSubj.Debtsubject_Id);
            loop
              fetch crpartp
                into rpartp;
              exit when not FOUND;
              vnewtbods       := vnewtbods +
                                 round(vmintbo * rpartp.totaltax / vsumtboy, 2);
              rpartp.totaltax := rpartp.totaltax;
              update debtpartproperty pp
              set    sumtax = sumtax +
                                  round(vmintbo * sumtax / vsumtboy, 2),
                     totaltax = totaltax +
                                    round(vmintbo * totaltax / vsumtboy, 2),
                     --       pp.fsw = pp.koeff - pp.fclean - pp.fdepot
                     promiltbo = round(round((rpartp.sumtax +
                                                 round(vmintbo * sumtax /
                                                        vsumtboy, 2)) * 1000 /
                                                 sumval, 2), 2)
              where  pp.debtpartproperty_id = rpartp.debtpartproperty_id;
            end loop;
            close crpartp;
            update debtsubject 
            set    totaltax = totaltax + vnewtbods
            where  debtsubject_id = rDebtSubj.Debtsubject_Id;
          end if;
        end loop;
        close crDebtSubj;
      
      end if;
      if vgarbtax19 is not null
      then
        select sum(gt.container_number * coalesce(gt.frequency, 1.0) *
                    (select coalesce(min(cn.value), 0.0) *
                             (case when min(cn.kindvalue) = '2' then 12 else 1 end)
                     from   containernorm cn
                     where  cn.containernorm_id = gt.containernorm_id
                     and    cn.taxperiod_id = vtaxperiod_id))
        into   vdecltbo
        from   garbtax gt
        where  gt.taxdoc_id = vtaxdoc19_id;
        open crDebtSubj(vtaxperiod_id, rdoc.docno, rdoc.doc_date, vcurtime);
        loop
          fetch crDebtSubj
            into rDebtSubj;
          exit when not FOUND;
          if rDebtSubj.Kinddebtreg_Id = 5
          then
       if to_char(rdoc.begintaxdate,'yyyy') =  to_char(rDebtSubj.Tax_Begidate,'yyyy') then
         vper := round(months_between(to_date('31.12.' || to_char(rDebtSubj.Tax_Begidate,'yyyy'),'dd.mm.yyyy'), rdoc.begintaxdate) +0.4);
       else
         vper := 12;
       end if;
          select sum(coalesce(pp.fsw,0) + coalesce(pp.fclean,0) + coalesce(pp.fdepot,0)) into rDebtSubj.Totaltax
             from debtpartproperty pp where pp.debtsubject_id = rDebtSubj.Debtsubject_Id;
           vktbo := vper * ((rDebtSubj.Totaltax ) / vsumtboy_cont)/round(months_between(rDebtSubj.Tax_Enddate::date, rDebtSubj.Tax_Begidate::date));
 --          vktbo := 12 * (rDebtSubj.Totaltax / vsumtboy_cont) / round(months_between(rDebtSubj.Tax_Enddate::date, rDebtSubj.Tax_Begidate::date));
           update debtsubject 
            set    totaltax = totaltax + round(vktbo * vdecltbo *
                                                      round(months_between(rDebtSubj.Tax_Enddate::date,
 --                                                                          rDebtSubj.Tax_Begidate::date)) / 12,
                                                                            rDebtSubj.Tax_Begidate::date)) / vper,
                                                     2)
            where  debtsubject_id = rDebtSubj.Debtsubject_Id;
            --------------------
            select nextval('s_debtpartproperty')
            into   vdebtpartproperty_id;
            insert into debtpartproperty 
              (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
               seqnots, typedeclar, isbasehome, isrelief, relief_id, divident,
               divisor, part, sumval, sumtax, taxbegindate, taxenddate, totalval,
               totaltax, userdate, user_id, homeobj_id, freefrom, freemonths,
               codetbo, promiltbo, freesuma_obj, freesuma_subj,
               parentdebtprop_id, SUBJPARTVAL, FSW, FCLEAN, FDEPOT)
            values
              (vdebtpartproperty_id, rDebtSubj.Debtsubject_Id, vtaxperiod_id, 1,
               0, null, null, null, null, 1, 1, 1, 0, round(vktbo * vdecltbo, 2),
               rDebtSubj.Tax_Begidate, rDebtSubj.Tax_Enddate, 0,
               round(vktbo * vdecltbo *
                      round(months_between(rDebtSubj.Tax_Enddate::date,
 --                                          rDebtSubj.Tax_Begidate::date)) / 12, 2),
                                            rDebtSubj.Tax_Begidate::date)) / vper, 2),
          CURRENT_TIMESTAMP, ipuser_id, 0, null, 0, rprtbo.tbo_code, 0, 0, null, null,
               round(vdecltbo, 2), 0, 0, 0);
            --------------------      
          end if;
        end loop;
        close crDebtSubj;
      end if;
      ---  Vnoski -----
      select min(n.minvalue)
      into   vmindo
      from   legalnorm n
      where  n.name = 'mindo'
      and    n.begindate = (select max(nn.begindate)
                            from   legalnorm nn
                            where  to_char(nn.begindate, 'yyyy')::numeric <= vTaxYear
                            and    nn.name = 'mindo');
      open crDebtSubj(vtaxperiod_id, rdoc.docno, rdoc.doc_date, vcurtime);
      loop
        fetch crDebtSubj
          into rDebtSubj;
        exit when not FOUND;
        -----------
        if ((vsumdo < vmindo) and (rDebtSubj.Kinddebtreg_Id = 2)) or
           ((vsumdo < vmindo) and (rDebtSubj.Kinddebtreg_Id = 5) and
           (coalesce(rprtbo.istbotax, 0.0) <> 1))
        then
          update debtsubject 
          set    freesum_obj = freesum_obj + totaltax + freesum_subj,
                 totaltax = 0.0, 
                 freesum_subj = 0.0
          where  debtsubject_id = rDebtSubj.Debtsubject_Id;
        /*  update debtsubject ds
          set    freesum_obj = ds.freesum_obj + ds.totaltax + ds.freesum_subj,
                 totaltax = 0, 
                 freesum_subj = 0
          where  ds.debtsubject_id = rDebtSubj.Debtsubject_Id;*/
          update debtpartproperty 
          set    freesuma_obj = freesuma_obj + totaltax,
                 totaltax = 0.0
          where  debtsubject_id = rDebtSubj.Debtsubject_Id;
          rDebtSubj.Totaltax := 0;
        end if;
        -----------------------
        if rDebtSubj.Taxsubject_Id = nullsubj then     ---- drugi sysobstvenici ?????  17.05.2012
          update debtsubject 
          set    freesum_obj = 0.0,
                 totaltax = 0.0, freesum_subj = 0.0
          where  debtsubject_id = rDebtSubj.Debtsubject_Id;
          update debtpartproperty 
          set    freesuma_obj = 0.0,
                 totaltax = 0.0
          where  debtsubject_id = rDebtSubj.Debtsubject_Id;
          rDebtSubj.Totaltax := 0.0;        
        end if;
        ------------------------
        ------------------------
        select min(ds.debtsubject_id)
        into   oldds_id
        from   debtsubject ds
        where  ds.debtsubject_id <> rDebtSubj.debtsubject_id
        and    ds.kinddebtreg_id = rDebtSubj.Kinddebtreg_Id
        and    ds.taxperiod_id = vtaxperiod_id
        and    ds.document_id = iptaxdoc_Id
        and    ds.taxsubject_id = rDebtSubj.Taxsubject_Id;
        ------------------------
        select count(*)
        into   vnorminst
        from   taxperiodpay p
        where  p.documenttype_id = 21
        and ((p.kinddebtreg_id = rDebtSubj.Kinddebtreg_Id) or (p.kinddebtreg_id is null))
        and    p.taxperiod_id = vtaxperiod_id;
        if vnorminst = 0
        then
          vdiv      := 1;
          vnorminst := 2;
        else
          vdiv := round(12 / vnorminst);
        end if;
        if rDebtSubj.Totaltax > 0 and ((ipflrec <> 2) or (oldds_id is null))
        then
          vminp  := round(months_between(rDebtSubj.Tax_Enddate::date,
                                         rDebtSubj.Tax_Begidate::date) + 0.5);
          vnoski := round((vminp / vdiv) + 0.4); --- 0.3
          if vnoski = 0
          then
            vnoski := 1;
          end if;
          update debtsubject 
            set inst_number = vnoski
          where debtsubject_id = rDebtSubj.Debtsubject_Id;
          i      := vnoski;
          invsum := 0;
          while i > 0
          loop
            nv := vnorminst - vnoski + i;
        /*    if i = 0
            then
              sumzad := rDebtSubj.Totaltax - invsum;
            else
              sumzad := round(rDebtSubj.Totaltax / vnoski, 2);
              invsum := invsum + sumzad;
            end if;
         */ 
            if i = vnoski then
              sumzad := rDebtSubj.Totaltax - ((vnoski - 1) * round(rDebtSubj.Totaltax / vnoski, 2));
              invsum := invsum + sumzad;
            else
              sumzad := round(rDebtSubj.Totaltax / vnoski, 2);
              invsum := invsum + sumzad;
            end if;
            i  := i - 1;
           select nextval('s_debtinstalment')
            into   vdi;
             select getWorkingDay(tp.termpaydate::date, 1.0)
              into vtermpaydate
            from   taxperiodpay tp, documenttype dt
            where  tp.taxperiod_id = vtaxperiod_id
            and    tp.instalmentnumber = nv
            and    tp.documenttype_id = dt.documenttype_id
            and ((tp.kinddebtreg_id = rDebtSubj.Kinddebtreg_Id) or (tp.kinddebtreg_id is null))
            and    dt.doccode = '14'
            ;
            if getWorkingDay(vtermpaydate::date, 1.0) < getWorkingDay(vTDateBegin::date, 1.0) then
              vtermpaydate := vTDateBegin;
            end if;
            insert into debtinstalment
              (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
               intbegindate)
                values
             (vdi, rDebtSubj.debtsubject_id, nv, getWorkingDay(vtermpaydate::date, 1.0),
              sumzad,getWorkingDay(vtermpaydate::date, 1.0)+1)
            --  select vdi, rDebtSubj.debtsubject_id, tp.instalmentnumber,
             --        getWorkingDay(tp.termpaydate::date, 1), sumzad,
             --        getWorkingDay(tp.termpaydate::date, 1) + 1
             -- from   taxperiodpay tp, documenttype dt
             -- where  tp.taxperiod_id = vtaxperiod_id
             -- and    tp.instalmentnumber = nv
             -- and    tp.documenttype_id = dt.documenttype_id
             -- and    dt.doccode = '14'
              --    and dt.municipality_id = vmunicipality_id
              ;
            insert into baldebtinst
              (debtinstalment_id, instsum, interestsum, discsum)
            values
              (vdi, sumzad, 0, 0);
          end loop;
        end if;
        -----------
      end loop;
      close crDebtSubj;
      --commit;
      vTaxYear := vTaxYear + 1;
    end loop;
    ipStatus := 'OK';
  exception
    when others then
      ipStatus := sqlerrm;
end;
$function$
; DROP FUNCTION taxvaluation.taxsubject(numeric, numeric, character varying); 
CREATE OR REPLACE FUNCTION taxvaluation.taxsubject(OUT return_val character varying, iptaxdoc_id numeric, iptaxsubject_id numeric, iptaxyear character varying, OUT opfromdate date, OUT optodate date, OUT opdototal numeric, OUT opdnitotal numeric, OUT opfreesum_subj numeric, OUT opfreesum_prop numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
DECLARE
  begin
    select ds.tax_begidate, ds.tax_enddate, ds.totalval, ds.totaltax,
           ds.freesum_subj, ds.freesum_obj
    into   opFromdate, opToDate, opDOTotal, opDNITotal, opFreesum_subj,
           opFreesum_Prop
    from   debtsubject ds, taxperiod tp, kinddebtreg t
    where  ds.document_id = iptaxdoc_Id
    and    ds.taxsubject_id = ipTaxSubject_id
    and    ds.taxperiod_id = tp.taxperiod_id
          --   and ds.kinddebtreg_id = 2 ????
    and    to_char(tp.begin_date, 'yyyy') = ipTaxYear
    and    ds.kinddebtreg_id = t.kinddebtreg_id
    and    t.code in ('2100', '2300', '1400')
    and    tp.taxperkind::integer = 0;
    return_val := 'OK';
  exception
    when no_data_found then
      return_val := '������� �����';
    when others then
      return_val := '������';
end;
$function$
; DROP FUNCTION taxvaluation.taxtbo(numeric, numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.taxtbo(iptaxdoc_id numeric, iptaxperiod_id numeric, OUT optbo numeric, OUT opstat character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
  begin
  
    select sum(ds.totaltax)
    into   opTBO
    from   debtsubject ds, kinddebtreg r
    where  ds.document_id = ipTaxDoc_id
    and    ds.taxperiod_id = ipTaxPeriod_id
    and    ds.kinddebtreg_id = r.kinddebtreg_id
    and    r.code = '2400';
    opstat := 'OK';
  exception
    when no_data_found then
      opTBO  := 0;
      opstat := '������� �����';
    when others then
      opTBO  := 0;
      opstat := '������';
end;
$function$
; DROP FUNCTION taxvaluation.taxtbos(numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.taxtbos(iptaxdoc_id numeric, iptaxsubject numeric, iptaxperiod_id numeric, OUT optbo numeric, OUT opstat character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
  begin
  
    select sum(ds.totaltax)
    into   opTBO
    from   debtsubject ds, kinddebtreg r
    where  ds.document_id = ipTaxDoc_id
    and    ds.taxperiod_id = ipTaxPeriod_id
    and    ds.kinddebtreg_id = r.kinddebtreg_id
    and    ds.taxsubject_id = ipTaxSubject
    and    r.code = '2400';
    opstat := 'OK';
  exception
    when no_data_found then
      opTBO  := 0;
      opstat := '������� �����';
    when others then
      opTBO  := 0;
      opstat := '������';
end;
$function$
; DROP FUNCTION taxvaluation.taxtransport(numeric, date, date, numeric, numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.taxtransport(iptaxdoc_id numeric, ipfromdate date, iptodate date, ipuser_id numeric, OUT ipstatus character varying, ipfl numeric DEFAULT 0)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                         
    crTaxSubject cursor (vtrans_id numeric, vchangedate date) is
      select *
      from   parttransport pt
      where  pt.transport_id = vtrans_id
      and    coalesce(pt.enddate, vchangedate + integer '1') >= vchangedate;
    rTaxSubject        record;
    rtaxdoc            record;
    rtransport         record;
    carage             numeric;
    vTaxYear           numeric;
    vTDateBegin        date;
    vTDateEnd          date;
    vdoccode           varchar(20); -- numeric;
    vtcode             numeric;
    vttype             numeric;
    vprice             numeric;
    vtaxval            numeric;
    vtaxper            numeric;
    vrelief_id         numeric;
    telkbdate          date;
    telkedate          date;
    vdebtsubject_id    numeric;
    vinst_number       integer;
    vtaxperiod_id      numeric;
    vtaxfreeO          numeric;
    vtaxfreeS          numeric;
    vDublTransp        numeric;
    vTaxFreeFrom       date;
    vTaxFreeTo         date;
    vtaxvals           numeric;
    vtaxpers           numeric;
    vtaxfreeOs         numeric;
    vper               numeric;
    vmeasur            numeric;
    instnum            numeric;
    vnoski             numeric;
    i                  numeric;
    nv                 numeric;
    sumzad             numeric;
    vdebtinstalment_id numeric;
    vtrmins_id         numeric;
    vdebtpp_id         numeric;
    vfreemonths        numeric;
    voldds_id          numeric;
    vkatalnorm         numeric;
    vtelk_mcap         numeric;
    vtelk_power        numeric;
    vtermpaydate       date;
    vCurYear           varchar(10);
    vparreg            numeric;
    vxxdate            date;
    vadmregion_id      numeric;
 begin
    ipStatus := 'OK';
 
    select *
    into   rtaxdoc
    from   taxdoc td
    where  td.taxdoc_id = iptaxdoc_Id;
    select c.configvalue
    into   vCurYear
    from   config c
    where  name = 'TAXYEAR' and c.municipality_id = rtaxdoc.municipality_id;
    vTaxYear := to_number(to_char(ipFromDate, 'yyyy'));
    while vTaxYear <= to_number(to_char(ipToDate, 'yyyy'))
    loop
      if vTaxYear < to_number(vcuryear)
      then
        vparreg := 3;
      else
        vparreg := 2;
      end if;
    
      vTDateBegin := to_date('01.01.' || to_char(vTaxYear), 'dd.mm.yyyy');
      if vTDateBegin < ipFromDate
      then
        vTDateBegin := ipFromDate;
      end if;
      vTDateEnd := to_date('31.12.' || to_char(vTaxYear), 'dd.mm.yyyy');
      if vTDateEnd > ipToDate
      then
        vTDateEnd := ipToDate;
      end if;
      ------------
      select min(ds.debtsubject_id)
      into   vdebtsubject_id
      from   debtsubject ds, taxdoc td
      where  ds.document_id = iptaxdoc_Id
      and    td.taxdoc_id = ds.document_id
      and    nvl(ds.docno, '*') = nvl(td.docno, '*')
      and    coalesce(ds.doc_date, trunc(current_date)) =
             coalesce(td.doc_date, trunc(current_date))
      and    ds.taxperiod_id =
             (select tp.taxperiod_id
               from   taxperiod tp
               where  tp.taxperkind = '0'
               and    to_char(tp.begin_date, 'yyyy') = to_char(vTaxYear));
    
      if (vdebtsubject_id is not null) and (ipfl = 0) and
         (nvl(rtaxdoc.close_taxdoc_id, 0.0) <> 1)
      then
        --     null;
        ipStatus := 'errEndProcess'; -- '���� �������� �������� '  || iptaxdoc_Id ;
        exit; -- return;
        -- else -- novo nachislenie 
      end if;
      ------------
      select min(tp.taxperiod_id)
      into   vtaxperiod_id
      from   taxperiod tp
      where  tp.taxperkind = '0'
      and    tp.begin_date <= vTDateBegin
      and    tp.end_date >= vTDateEnd;
    
      select dt.doccode
      into   vdoccode
      from   documenttype dt
      where  dt.documenttype_id = rtaxdoc.documenttype_id
      -- and dt.municipality_id = rtaxdoc.municipality_id
      ;
      select *
      into   rtransport
      from   transport t
      where  t.taxdoc_id = iptaxdoc_Id;
      rtransport.GAIN_DATE := coalesce(rtransport.GAIN_DATE, vTDateBegin);
      if rtransport.GAIN_DATE > vTDateBegin
      then
        vTDateBegin := rtransport.GAIN_DATE;
      end if;
      --- !!!!!
      vTDateBegin := to_date('01.' || to_char(vTDateBegin, 'mm.yyyy'),
                             'dd.mm.yyyy');
      vxxdate     := vTDateBegin;
      if rtransport.paidpodate is not null and
          rtransport.paidpodate > vTDateBegin  -- and ipfl = 0
-----
     and ((rtaxdoc.give_reasonreg_id = 5) or (rtaxdoc.give_reasonreg_id = 8) or
         (rtaxdoc.give_reasonreg_id = 11) or (rtaxdoc.give_reasonreg_id = 14))
     then
        vTDateBegin := to_date('01' || to_char(add_months(rtransport.paidpodate::Date,
                                                          1), 'mmyyyy'),
                               'ddmmyyyy');
      end if;
      if vTDateEnd < vTDateBegin
      then
        if rtransport.paidpodate is not null
        then
          ipStatus := 'errNoDuty';
        end if;
        --  return;
        ----------------------------------
        select max(a.admregion_id) into vadmregion_id
         from address a, taxsubject ts
         where ts.taxsubject_id = rtaxdoc.taxsubject_id
         and a.address_id = ts.permanent_clientaddr_id
         and a.municipality_id = rtaxdoc.municipality_id
         ;
        select nextval('s_debtsubject')
        into   vdebtsubject_id;
        insert into debtsubject
          (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,
           taxperiod_id, doccode, tax_begidate, tax_enddate, relief_id, Totalval,
           Totaltax, calcdate, FreeSum_obj, prtdate, inst_number, FreeSum_Subj,
           corr_instnumber, codetbo, corr_sumtotal, userdate, user_id,
           TAXOBJECT_ID, PARTIDANO, MUNICIPALITY_ID, KINDPARREG_ID, PAYDISCSUM,
           DOCNO, DOC_DATE, PARENT_DEBTSUBJECT_ID,admregion_id)
        values
          (vdebtsubject_id, rtaxdoc.taxsubject_id, iptaxdoc_Id, 1, 4,
           vtaxperiod_id, vdoccode, vxxdate, vTDateEnd, null, 0, 0,
           trunc(current_date), 0, null, 1, 0, null, null, null, CURRENT_TIMESTAMP, ipuser_id,
           rtaxdoc.taxobject_id, rtaxdoc.partidano, rtaxdoc.municipality_id,
           vparreg, null, rtaxdoc.docno, rtaxdoc.doc_date, null,vadmregion_id);
        select nextval('s_debtpartproperty')
        into   vdebtpp_id;
        insert into debtpartproperty
          (debtpartproperty_id, debtsubject_id, taxperiod_id, isrelief,
           relief_id, divident, divisor, part, sumval, sumtax, taxbegindate,
           taxenddate, totalval, totaltax, userdate, user_id, homeobj_id,
           freefrom, freemonths, freesuma_obj, freesuma_subj, parentdebtprop_id,
           subjpartval, taxbefore)
        values
          (vdebtpp_id, vdebtsubject_id, vtaxperiod_id, 0, null, 1, 1, 1, null,
           null, vxxdate, vTDateEnd, 0, 0, CURRENT_TIMESTAMP, ipuser_id,
           rtaxdoc.taxobject_id, null, 0, 0, 0, null, null, 0);
      
        ----------------------------------
      else
        ipStatus := 'OK';
      
        if vdoccode = '54L'
        then
          vtaxval   := 0;
          vtaxper   := 0;
          vtaxfreeO := 0;
          vtaxfreeS := 0;
          select min(tr.transpmeansreg_id), min(to_number(tr.code)),
                 min(tr.type)
          into   vtrmins_id, vtcode, vttype
          from   transpmeansreg tr, carreg cr, carmodel cmo, carmark cm
          where  cr.carreg_id = rtransport.carreg_id
          and    cr.carmodel_id = cmo.carmodel_id
          and    cmo.carmark_id = cm.carmark_id
          and    cm.transpmeansreg_id = tr.transpmeansreg_id;
          if vtcode = 1
          then
             select min(ctp.pricevalue)
            into   vprice
            from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
            and    ctp.taxperiod_id = tp.taxperiod_id
            and    tp.taxperkind = '0'
            and    to_char(tp.begin_date, 'yyyy') =
                   to_char(vTDateBegin, 'yyyy')
            and    ctp.measurefrom::numeric <= rtransport.power_kw
            and    ctp.measureto::numeric >= rtransport.power_kw
            and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
            ;
            vper                    := round(months_between(vTDateEnd,
                                                            vTDateBegin));
            vprice                  := nvl(vprice, 0.0);
            vtaxval                 := vprice * rtransport.power_kw;
            rtransport.produce_year := coalesce(rtransport.produce_year,
                                           rtransport.firstreg_year);
            rtransport.produce_year := coalesce(rtransport.produce_year, '15');
            carage                  := to_number(to_char(vTDateBegin, 'yyyy')) -
                                       to_number(rtransport.produce_year) + 1;
            if carage > 14
            then
              vtaxval := vtaxval * 1;
            elsif carage between 6 and 14
            then
              vtaxval := vtaxval * 1.5;
            elsif carage <= 5
            then
              vtaxval := vtaxval * 2.8;
            end if;
            vtaxval := round(vper * vtaxval / 12, 2);
            vtaxper := vtaxval;
            --- nachalna data na katalizator
            select ln.maxvalue
            into   vkatalnorm
            from   legalnorm ln
            where  ln.name = 'Katal_power'
            and    ln.begindate =
                   (select max(ll.begindate)
                     from   legalnorm ll
                     where  ll.name = 'Katal_power'
                     and    ll.begindate <= vTDateBegin);
            if nvl(rtransport.power_kw, 0.0) > 0 and
               nvl(rtransport.power_kw, 0.0) <= vkatalnorm and
               rtransport.katalizator = 1
            then
              if coalesce(rtransport.katalizator_date,
                     coalesce(rtransport.GAIN_DATE, vTDateBegin - integer '1')) <= vTDateBegin
                 or
                     (coalesce(rtransport.katalizator_date,coalesce(rtransport.GAIN_DATE, vTDateBegin - 1)) <= coalesce(rtransport.GAIN_DATE, vTDateBegin))    
              then
                vtaxper   := vtaxval * 0.5;
                vtaxfreeO := vtaxval * 0.5;
              else
              if rtransport.katalizator_date between vTDateBegin and vTDateEnd
              then
                vtaxfreeO := round(round(months_between(vTDateEnd,
                                                        rtransport.katalizator_date::Date)) *
                                   vtaxval / vper * 0.5, 2);
                vtaxper   := vtaxval - vtaxfreeO;
              end if;
            
            end if;
	    end if;
            if rtransport.budget = 1
            then
              vtaxper := 0;
            elsif rtransport.diplomat = 1
            then
              vtaxper := 0;
            elsif rtransport.amb_car = 1
            then
              vtaxper := 0;
            elsif rtransport.bck = 1
            then
              vtaxper := 0;
              --      elsif rtransport.isdefect = 1 then  vtaxper := 0;
            end if;
            if vtaxper = 0
            then
              vtaxfreeO := vtaxval;
            end if;
            ----------- po Subekti
            --      vtaxfreeS := 0;
            open crTaxSubject(rtransport.transport_id, vTDateBegin);
            loop
              vtaxfreeS := 0;
              fetch crTaxSubject
                into rTaxSubject;
              exit when not FOUND;
              if nvl(rTaxSubject.Part, 0.0) = 0 and rTaxSubject.Divisor <> 0
              then
                rTaxSubject.Part := rTaxSubject.Divident / rTaxSubject.Divisor;
              end if;
              if rTaxSubject.Enddate is not null
              then
                rTaxSubject.Enddate := to_date('01.' ||
                                               to_char(add_months(rTaxSubject.Enddate::Date,
                                                                  1), 'mm.yyyy'),
                                               'dd.mm.yyyy');
              end if;
              if coalesce(rTaxSubject.Enddate, vTDateBegin + integer '1') = vTDateBegin
              then
                vtaxvals   := 0;
                vtaxpers   := 0;
                vtaxfreeOs := 0;
              else
                vtaxvals   := rTaxSubject.Part * vtaxval;
                vtaxpers   := rTaxSubject.Part * vtaxper;
                vtaxfreeOs := round(rTaxSubject.Part * vtaxfreeO, 2);
              end if;
              select max(pt.relief_id)
              into   vrelief_id
              from   parttransport pt --, relief r
              where  pt.transport_id = rtransport.transport_id
              and    pt.taxsubject_id = rTaxSubject.Taxsubject_Id
              --      and pt.relief_id = r.relief_id
              --      and ((r.telk_decisionno is not null) or (r.retired_begindate is not null))
              ;
              select ln.maxvalue
              into   vtelk_mcap
              from   legalnorm ln
              where  ln.name = 'TELK_motorcapacity'
              and    ln.begindate =
                     (select max(ll.begindate)
                       from   legalnorm ll
                       where  ll.name = 'TELK_motorcapacity'
                       and    ll.begindate <= vTDateBegin);
              select ln.maxvalue
              into   vtelk_power
              from   legalnorm ln
              where  ln.name = 'TELK_power'
              and    ln.begindate =
                     (select max(ll.begindate)
                       from   legalnorm ll
                       where  ll.name = 'TELK_power'
                       and    ll.begindate <= vTDateBegin);
            
              if nvl(vrelief_id, 0.0) <> 0 and
                 nvl(rtransport.power_kw, 0.0) <= vtelk_power and
                 nvl(rtransport.power_kw, 0.0) > 0 and
                 rtransport.motor_capacity <= vtelk_mcap
              then
              
                select max(r.telk_begindate), max(r.telk_enddate)
                into   telkbdate, telkedate
                from   relief r
                where  r.relief_id = vrelief_id;
              
                select min(ds.debtsubject_id)
                into   vDublTransp
                from   debtsubject ds, taxdoc td, relief r
                where  ds.taxsubject_id = rTaxSubject.Taxsubject_Id
                and    ds.relief_id = r.relief_id
                and    ds.document_id <> rtransport.taxdoc_id
                and    ds.taxperiod_id = vtaxperiod_id
                and    ds.document_id = td.taxdoc_id
                and    td.close_date is null
                and    td.documenttype_id = 26
                and    ((r.telk_enddate is null) or
                      (r.telk_enddate > vTDateBegin));
                if telkbdate is not null
                then
                  telkbdate := to_date('01.' || to_char(add_months(telkbdate::Date, 1),
                                                        'mm.yyyy'), 'dd.mm.yyyy');
                end if;
                if telkedate is not null
                then
                  telkedate := to_date('01.' || to_char(add_months(telkedate, 1),
                                                        'mm.yyyy'), 'dd.mm.yyyy');
                end if;
                if vDublTransp is null and (telkbdate < vTDateEnd) and
                   (coalesce(telkedate, to_date('22000101', 'yyyymmdd')) >
                   vTDateBegin)
                then
                  --- proverka za perioda
                  if telkbdate > vTDateBegin
                  then
                    vTaxFreeFrom := telkbdate;
                  else
                    vTaxFreeFrom := vTDateBegin;
                  end if;
                  if coalesce(telkedate, to_date('22000101', 'yyyymmdd')) <
                     vTDateEnd
                  then
                    vTaxFreeTo := telkedate;
                  else
                    vTaxFreeTo := vTDateEnd;
                  end if;
                  vfreemonths := round(months_between(vTaxFreeTo, vTaxFreeFrom));
                  vtaxfreeS   := round(vfreemonths * vtaxpers / vper, 2);
                  -- obshto za sobstvenicite -- vtaxfreeS := vtaxfreeS + round(round(months_between(vTaxFreeTo , vTaxFreeFrom)) * vtaxpers/vper,2);
                  --   vtaxpers := vtaxpers - vtaxfreeS;
                else
                  --     ipStatus := '���� ��������� ����';
                  vrelief_id := null;
                end if;
              end if;
              select max(ds.debtsubject_id)
              into   voldds_id
              from   debtsubject ds
              where  ds.document_id = iptaxdoc_Id
              and    ds.taxsubject_id = rTaxSubject.Taxsubject_Id
              and    ds.taxperiod_id = vtaxperiod_id;
              if to_char(vTDateBegin, 'ddmm') = '0101'
              then
                vinst_number := 2;
              else
                vinst_number := 1;
              end if;
              vtaxpers := round(vtaxvals - vtaxfreeOs - vtaxfreeS, 2);
              if vtaxpers < 0
              then
                vtaxpers := 0;
              end if;
              vtaxvals   := round(vtaxvals, 2);
              vtaxfreeOs := round(vtaxfreeOs, 2);
              select max(a.admregion_id) into vadmregion_id
               from address a, taxsubject ts
               where ts.taxsubject_id = rTaxSubject.taxsubject_id
               and a.address_id = ts.permanent_clientaddr_id
               and a.municipality_id = rtaxdoc.municipality_id
               ;
              select nextval('s_debtsubject')
              into   vdebtsubject_id;
              insert into debtsubject
                (debtsubject_id, taxsubject_id, document_id, kinddoc,
                 kinddebtreg_id, taxperiod_id, doccode, tax_begidate,
                 tax_enddate, relief_id, Totalval, Totaltax, calcdate,
                 FreeSum_obj, prtdate, inst_number, FreeSum_Subj,
                 corr_instnumber, codetbo, corr_sumtotal, userdate, user_id,
                 TAXOBJECT_ID, PARTIDANO, MUNICIPALITY_ID, KINDPARREG_ID,
                 PAYDISCSUM, DOCNO, DOC_DATE, PARENT_DEBTSUBJECT_ID,admregion_id)
              values
                (vdebtsubject_id, rTaxSubject.taxsubject_id, iptaxdoc_Id, 1, 4,
                 vtaxperiod_id, vdoccode, vTDateBegin, vTDateEnd, vrelief_id,
                 vtaxvals, vtaxpers, trunc(current_date), vtaxfreeOs, null,
                 vinst_number, vtaxfreeS, null, null, null, CURRENT_TIMESTAMP, ipuser_id,
                 rtaxdoc.taxobject_id, rtaxdoc.partidano,
                 rtaxdoc.municipality_id, vparreg, null, rtaxdoc.docno,
                 rtaxdoc.doc_date, null,vadmregion_id);
              select nextval('s_debtpartproperty')
              into   vdebtpp_id;
              insert into debtpartproperty
                (debtpartproperty_id, debtsubject_id, taxperiod_id, isrelief,
                 relief_id, divident, divisor, part, sumval, sumtax,
                 taxbegindate, taxenddate, totalval, totaltax, userdate, user_id,
                 homeobj_id, freefrom, freemonths, freesuma_obj, freesuma_subj,
                 parentdebtprop_id, subjpartval, taxbefore)
              values
                (vdebtpp_id, vdebtsubject_id, vtaxperiod_id,
                 decode(nvl(vrelief_id, 0.0), 0.0, 0.0, 1.0), vrelief_id,
                 rTaxSubject.Divident, rTaxSubject.Divisor, rTaxSubject.Part,
                 null, null, vTDateBegin, vTDateEnd, vtaxvals, vtaxpers, CURRENT_TIMESTAMP,
                 ipuser_id, rtaxdoc.taxobject_id,
                 decode(vrelief_id, null, vTaxFreeFrom), vfreemonths, vtaxfreeOs,
                 vtaxfreeS, null, null, 0);
            
              --- Vnoski i dalzimo ?????
              if vtaxpers > 0 and ((voldds_id is null) or ipfl <> 2)
              then
                select nvl(count(tp.taxperiodpay_id)::integer, 0)
                into   instnum
                from   taxperiodpay tp, documenttype d
                where  tp.documenttype_id = d.documenttype_id
                and    d.doccode = vdoccode
                and    tp.taxperiod_id = vtaxperiod_id;
                if instnum = 0
                then
                  instnum := 2;
                end if;
                --    if  to_char(vTDateBegin,'ddmm') = '0101' then
                if to_char(coalesce(rtaxdoc.earn_date,
                               (to_date('20000101', 'yyyymmdd'))), 'yyyy') <>
                   to_char(vTDateBegin, 'yyyy')
                then
                  vnoski := instnum;
                else
                  vnoski := 1;
                end if;
                --   vnoski := round(round(months_between(vTDateEnd, vTDateBegin))/(12/instnum),0);
                --   if vnoski = 0 then vnoski := 1; end if;
                i := vnoski;
                while i > 0
                loop
                  nv := instnum - vnoski + i;
                  if nv = instnum
                  then
                    sumzad := round(vtaxpers -
                                    ((vnoski - 1) * round(vtaxpers / vnoski, 2)),
                                    2);
                  else
                    sumzad := round(vtaxpers / vnoski, 2);
                  end if;
                  i := i - 1;
                  --    if  to_char(vTDateBegin,'ddmm') = '0101' then
                  if to_char(coalesce(rtaxdoc.earn_date,
                                 (to_date('20000101', 'yyyymmdd'))), 'yyyy') <>
                     to_char(vTDateBegin, 'yyyy')
                  then
                    select getWorkingDay(tp.termpaydate::date, 1)
                    into   vtermpaydate
                    from   taxperiodpay tp
                    where  tp.taxperiod_id = vtaxperiod_id
                    and    tp.instalmentnumber = nv
                    and    tp.documenttype_id = rtaxdoc.documenttype_id;
                  else
                    vtermpaydate := add_months(coalesce(rtaxdoc.earn_date::Date,
                                                   vTDateBegin), 2);
                  end if;
                  select nextval('s_debtinstalment')
                  into   vdebtinstalment_id;
                  insert into debtinstalment
                    (debtinstalment_id, debtsubject_id, instno, termpay_date,
                     instsum, intbegindate)
                  values
                    (vdebtinstalment_id, vdebtsubject_id, nv,
                     getWorkingDay(vtermpaydate::date, 1), sumzad,
                     getWorkingDay(vtermpaydate::date, 1) + integer '1'); --???
                  insert into baldebtinst
                    (debtinstalment_id, instsum, interestsum, discsum)
                  values
                    (vdebtinstalment_id, sumzad, 0, 0);
                end loop;
              end if;
            end loop; -- za subject
            close crTaxSubject;
          end if;
          --commit;
        end if;
        -----------------------
        if vdoccode = '54B'
        then
          vtaxval   := 0;
          vtaxper   := 0;
          vtaxfreeO := 0;
          vtaxfreeS := 0;
          select *
          into   rtransport
          from   transport t
          where  t.taxdoc_id = iptaxdoc_Id;
          select min(tr.transpmeansreg_id), min(to_number(tr.code)),
                 min(tr.type)
          into   vtrmins_id, vtcode, vttype
          from   transpmeansreg tr, carreg cr, carmodel cmo, carmark cm
          where  cr.carreg_id = rtransport.carreg_id
          and    cr.carmodel_id = cmo.carmodel_id
          and    cmo.carmark_id = cm.carmark_id
          and    cm.transpmeansreg_id = tr.transpmeansreg_id;
          if vtcode in (2, 3, 10, 12, 14, 37, 40, 38) -- 15.09
          then
            select min(ctp.pricevalue)
            into   vprice
            from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
            and    ctp.taxperiod_id = tp.taxperiod_id
            and    tp.taxperkind = '0'
            and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
            and    to_char(tp.begin_date, 'yyyy') =
                   to_char(vTDateBegin, 'yyyy');

            vper   := round(months_between(vTDateEnd, vTDateBegin));
            vprice := nvl(vprice, 0.0);
            --     vtaxval := vprice;
            vtaxval := round(vper * vprice / 12, 2);
            vtaxper := vtaxval;
          end if;
          if (vtcode = 4) or (vtcode = 5) or (vtcode = 6) or (vtcode = 11)
          then
            if vtcode = 4
            then
              vmeasur := rtransport.motor_capacity;
            elsif vtcode = 5
            then
              vmeasur := rtransport.weigth_total;
            elsif vtcode = 6
            then
            ----�� ���� �� ��� ����������� ������� �� substr
               if(rtransport.seat_number LIKE '%+%' )
                 then
                   vmeasur := to_number(coalesce(trim(substring(rtransport.seat_number, 1,
                                                   instr(rtransport.seat_number,
                                                          '+') - 1)), '0')) +
                              to_number(trim(substring(rtransport.seat_number,
                                               instr(rtransport.seat_number, '+') + 1,
                                               100)));
                 else 
                   vmeasur := to_number(coalesce(trim(rtransport.seat_number),'0'));
                 end if;
            
            elsif vtcode = 11
            then
              vmeasur := rtransport.power_kw;
            end if;
            select min(ctp.pricevalue)
            into   vprice
            from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
            and    ctp.taxperiod_id = tp.taxperiod_id
            and    tp.taxperkind = '0'
            and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
            and    to_char(tp.begin_date, 'yyyy') =
                   to_char(vTDateBegin, 'yyyy')
            and    ctp.measurefrom::numeric <= vmeasur
            and    ctp.measureto::numeric >= vmeasur;

            vper   := round(months_between(vTDateEnd, vTDateBegin));
            vprice := nvl(vprice, 0.0);
            --     vtaxval := vprice;
            vtaxval := round(vper * vprice / 12, 2);
            vtaxper := vtaxval;
          end if;
          if (vtcode = 8)
          then
            vmeasur := round(rtransport.loading_capacity + 0.499, 0);
            select min(ctp.pricevalue)
            into   vprice
            from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
            and    ctp.taxperiod_id = tp.taxperiod_id
            and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
            and    tp.taxperkind = '0'
            and    to_char(tp.begin_date, 'yyyy') =
                   to_char(vTDateBegin, 'yyyy');

            vper   := round(months_between(vTDateEnd, vTDateBegin));
            vprice := nvl(vprice, 0.0);
            --     vtaxval := vprice;
            vtaxval := round(vper * vprice * vmeasur / 12, 2);
            vtaxper := vtaxval;
          end if;
          if (vtcode = 7) and ((rtransport.max_mass <= 12) or
             (to_char(vTDateBegin, 'yyyy') = '2004'))
          then
            vmeasur := round(rtransport.loading_capacity + 0.499, 0);
            select min(ctp.pricevalue)
            into   vprice
          from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
            and    ctp.taxperiod_id = tp.taxperiod_id
            and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
            and    tp.taxperkind = '0'
            and    to_char(tp.begin_date, 'yyyy') =
                   to_char(vTDateBegin, 'yyyy');

            vper   := round(months_between(vTDateEnd, vTDateBegin));
            vprice := nvl(vprice, 0.0);
            --     vtaxval := vprice;
            vtaxval := round(vper * vprice * vmeasur / 12, 2);
            vtaxper := vtaxval;
          elsif (vtcode = 7)
          then
            select decode(rtransport.kindhanging, 1, min(ctp.hangingptax),
                           min(ctp.hangothertax))
            into   vprice
            from   trucktaxprice ctp, taxperiod tp, municipality m
            where  ctp.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
            and    ctp.taxperiod_id = tp.taxperiod_id
            and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
            and    ctp.axes_number = least(rtransport.axes_number, 4)
            and    to_char(tp.begin_date, 'yyyy') =
                   to_char(vTDateBegin, 'yyyy')
            and    rtransport.max_mass >= ctp.maxmassfrom
            and    rtransport.max_mass < ctp.maxmassto;

            vper   := round(months_between(vTDateEnd, vTDateBegin));
            vprice := nvl(vprice, 0.0);
            --     vtaxval := vprice;
            vtaxval   := round(vper * vprice / 12, 2);
            vtaxper   := vtaxval;
            vtaxfreeO := 0;
          end if;
          if (vtcode in (9, 36))
          then
            if (to_char(vTDateBegin, 'yyyy') in ('2004', '2005'))
            then
              select min(ctp.pricevalue)
              into   vprice
          from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
                and    ctp.taxperiod_id = tp.taxperiod_id
              and    ctp.transpmeansreg_id = vtrmins_id
              and    tp.taxperkind = '0'
              and    to_char(tp.begin_date, 'yyyy') =
                     to_char(vTDateBegin, 'yyyy');

            else
              select decode(rtransport.kindhanging, '1', min(ctp.hangingptax),
                             min(ctp.hangothertax))
              into   vprice
            from   trucktaxprice ctp, taxperiod tp, municipality m
            where  ctp.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
              and    ctp.taxperiod_id = tp.taxperiod_id
              and    ctp.transpmeansreg_id = 37 --vtrmins_id --rtransport.transpmeansreg_id
              and    ctp.axes_number = least(rtransport.axes_number, 3)
              and    to_char(tp.begin_date, 'yyyy') =
                     to_char(vTDateBegin, 'yyyy')
              and    rtransport.max_mass_comp >= ctp.maxmassfrom
              and    rtransport.max_mass_comp < ctp.maxmassto;
            end if;
            vper   := round(months_between(vTDateEnd, vTDateBegin));
            vprice := nvl(vprice, 0.0);
            --     vtaxval := vprice;
            vtaxval   := round(vper * vprice / 12, 2);
            vtaxper   := vtaxval;
            vtaxfreeO := 0;
          end if;
          select ln.maxvalue
          into   vkatalnorm
          from   legalnorm ln
          where  ln.name = 'Katal_power'
          and    ln.begindate =
                 (select max(ll.begindate)
                   from   legalnorm ll
                   where  ll.name = 'Katal_power'
                   and    ll.begindate <= vTDateBegin);
          if rtransport.katalizator = 1 and
             nvl(rtransport.power_kw, 0.0) <= vkatalnorm and
             nvl(rtransport.power_kw, 0.0) > 0
          then
            if (coalesce(rtransport.katalizator_date,
                   coalesce(rtransport.GAIN_DATE, vTDateBegin - 1)) < vTDateBegin)
		or (coalesce(rtransport.katalizator_date,
                   coalesce(rtransport.GAIN_DATE, vTDateBegin - 1)) <= coalesce(rtransport.GAIN_DATE, vTDateBegin))
            then
              vtaxper   := vtaxper * 0.5;
              vtaxfreeO := vtaxval - vtaxper;
            else
            if rtransport.katalizator_date between vTDateBegin and vTDateEnd
            then
              vtaxfreeO := round(round(months_between(vTDateEnd,
                                                      rtransport.katalizator_date::Date)) *
                                 vtaxval / vper * 0.5, 2);
              vtaxper   := vtaxval - vtaxfreeO;
            end if;
		end if;
          end if;
          if (rtransport.eco_motor = 1) and
             ((vtcode = 6) or (vtcode = 7) or (vtcode = 9) or (vtcode = 36)) -- 15.09
          then
            --         vtaxper := vtaxval * 0.5;
            --         vtaxfreeO := vtaxfreeO + vtaxval * 0.5;
            vtaxper   := vtaxper * 0.5;
            vtaxfreeO := vtaxval - vtaxper;
          end if;
          if (vtcode = 6) and rtransport.public_transport = 1
          then
            --         vtaxper := vtaxval * 0.1;
            --         vtaxfreeO := vtaxval * 0.9;
            vtaxper   := vtaxper * 0.1;
            vtaxfreeO := vtaxval - vtaxper;
          end if;
          if rtransport.budget = 1
          then
            vtaxper := 0;
          elsif rtransport.diplomat = 1
          then
            vtaxper := 0;
          elsif rtransport.amb_car = 1
          then
            vtaxper := 0;
          elsif rtransport.bck = 1
          then
            vtaxper := 0;
          end if;
          if vtaxper = 0
          then
            vtaxfreeO := vtaxval;
          end if;
          ----------- po Subekti
          vtaxfreeS := 0;
          open crTaxSubject(rtransport.transport_id, vTDateBegin);
          loop
            fetch crTaxSubject
              into rTaxSubject;
            exit when not FOUND;
            if nvl(rTaxSubject.Part, 0.0) = 0 and rTaxSubject.Divisor <> 0
            then
              rTaxSubject.Part := rTaxSubject.Divident / rTaxSubject.Divisor;
            end if;
            if coalesce(rTaxSubject.Enddate, vTDateBegin + integer '1') = vTDateBegin
            then
              vtaxvals   := 0;
              vtaxpers   := 0;
              vtaxfreeOs := 0;
            else
              vtaxvals   := round(rTaxSubject.Part * vtaxval, 2);
              vtaxpers   := round(rTaxSubject.Part * vtaxper, 2);
              vtaxfreeOs := round(rTaxSubject.Part * vtaxfreeO, 2);
            end if;
            if (vtcode = 5) and to_number(to_char(vTDateBegin, 'yyyy')) < 2009
            then
              select max(pt.relief_id)
              into   vrelief_id
              from   parttransport pt
              where  pt.transport_id = rtransport.transport_id
              and    pt.taxsubject_id = rTaxSubject.Taxsubject_Id;
            
              if nvl(vrelief_id, 0) <> 0 and nvl(rtransport.power_kw, 0.0) <= 74 and
                 nvl(rtransport.power_kw, 0.0) > 0 and
                 rtransport.motor_capacity <= 1800
              then
                select max(r.telk_begindate), max(r.telk_enddate)
                into   telkbdate, telkedate
                from   relief r
                where  r.relief_id = vrelief_id;
                select min(ds.debtsubject_id)
                into   vDublTransp
                from   debtsubject ds
                where  ds.taxsubject_id = rTaxSubject.Taxsubject_Id
                and    ds.relief_id is not null
                and    ds.document_id <> rtransport.taxdoc_id
                and    ds.taxperiod_id = vtaxperiod_id;
                if telkbdate is not null
                then
                  telkbdate := to_date('01.' || to_char(add_months(telkbdate, 1),
                                                        'mm.yyyy'), 'dd.mm.yyyy');
                end if;
                if telkedate is not null
                then
                  telkedate := to_date('01.' || to_char(add_months(telkedate, 1),
                                                        'mm.yyyy'), 'dd.mm.yyyy');
                end if;
                if vDublTransp is null
                then
                  --- proverka za perioda
                  if telkbdate > vTDateBegin
                  then
                    vTaxFreeFrom := telkbdate;
                  else
                    vTaxFreeFrom := vTDateBegin;
                  end if;
                  if coalesce(telkedate, to_date('22000101', 'yyyymmdd')) <
                     vTDateEnd
                  then
                    vTaxFreeTo := telkedate;
                  else
                    vTaxFreeTo := vTDateEnd;
                  end if;
                  vfreemonths := round(months_between(vTaxFreeTo, vTaxFreeFrom));
                  vtaxfreeS   := round(vfreemonths * vtaxpers / vper, 2);
                  --      vtaxfreeS := round(round(months_between(vTaxFreeTo , vTaxFreeFrom)) * vtaxpers/vper,2);
                end if;
              end if;
            end if;
            select max(ds.debtsubject_id)
            into   voldds_id
            from   debtsubject ds
            where  ds.document_id = iptaxdoc_Id
            and    ds.taxsubject_id = rTaxSubject.Taxsubject_Id
            and    ds.taxperiod_id = vtaxperiod_id;
            if to_char(vTDateBegin, 'ddmm') = '0101'
            then
              vinst_number := 2;
            else
              vinst_number := 1;
            end if;
            --   end loop;
            vtaxpers := round(vtaxvals - vtaxfreeOs - vtaxfreeS, 2); -- ????
            if vtaxpers < 0
            then
              vtaxpers := 0;
            end if;
            vtaxvals   := round(vtaxvals, 2);
            vtaxfreeOs := round(vtaxfreeOs, 2);
           select max(a.admregion_id) into vadmregion_id
           from address a, taxsubject ts
           where ts.taxsubject_id = rTaxSubject.taxsubject_id
           and a.address_id = ts.permanent_clientaddr_id
           and a.municipality_id = rtaxdoc.municipality_id
           ;
            select nextval('s_debtsubject')
            into   vdebtsubject_id;
            insert into debtsubject
              (debtsubject_id, taxsubject_id, document_id, kinddoc,
               kinddebtreg_id, taxperiod_id, doccode, tax_begidate, tax_enddate,
               relief_id, Totalval, Totaltax, calcdate, FreeSum_obj, prtdate,
               inst_number, FreeSum_Subj, corr_instnumber, codetbo,
               corr_sumtotal, userdate, user_id, TAXOBJECT_ID, PARTIDANO,
               MUNICIPALITY_ID, KINDPARREG_ID, PAYDISCSUM, DOCNO, DOC_DATE,
               PARENT_DEBTSUBJECT_ID,admregion_id)
            values
              (vdebtsubject_id, rTaxSubject.taxsubject_id, iptaxdoc_Id, 1, 4,
               vtaxperiod_id, vdoccode, vTDateBegin, vTDateEnd, vrelief_id,
               vtaxvals, vtaxpers, trunc(current_date), vtaxfreeOs, null,
               vinst_number, vtaxfreeS, null, null, null, CURRENT_TIMESTAMP, ipuser_id,
               rtaxdoc.taxobject_id, rtaxdoc.partidano, rtaxdoc.municipality_id,
               vparreg, null, rtaxdoc.docno, rtaxdoc.doc_date, null,vadmregion_id);
            select nextval('s_debtpartproperty')
            into   vdebtpp_id;
            insert into debtpartproperty
              (debtpartproperty_id, debtsubject_id, taxperiod_id, isrelief,
               relief_id, divident, divisor, part, sumval, sumtax, taxbegindate,
               taxenddate, totalval, totaltax, userdate, user_id, homeobj_id,
               freefrom, freemonths, freesuma_obj, freesuma_subj,
               parentdebtprop_id, subjpartval, taxbefore)
            values
              (vdebtpp_id, vdebtsubject_id, vtaxperiod_id,
               decode(vrelief_id, null, 0, 1), vrelief_id, rTaxSubject.Divident,
               rTaxSubject.Divisor, rTaxSubject.Part, null, null, vTDateBegin,
               vTDateEnd, vtaxvals, vtaxpers, CURRENT_TIMESTAMP, ipuser_id,
               rtaxdoc.taxobject_id, decode(vrelief_id, null, vTaxFreeFrom),
               vfreemonths, vtaxfreeOs, vtaxfreeS, null, null, 0);
          
            --- Vnoski i dalzimo ?????
            if vtaxpers > 0 and ((voldds_id is null) or ipfl <> 2)
            then
              select nvl(count(tp.taxperiodpay_id)::integer, 0)
              into   instnum
              from   taxperiodpay tp, documenttype d
              where  tp.documenttype_id = d.documenttype_id
              and    d.doccode = vdoccode
              and    tp.taxperiod_id = vtaxperiod_id;
              if instnum = 0
              then
                instnum := 2;
              end if;
              ----------------
              if to_char(coalesce(rtaxdoc.earn_date,
                             (to_date('20000101', 'yyyymmdd'))), 'yyyy') <>
                 to_char(vTDateBegin, 'yyyy')
              then
                vnoski := instnum;
              else
                vnoski := 1;
              end if;
            
              ----------------
              --   vnoski := round(round(months_between(vTDateEnd, vTDateBegin))/(12/instnum),0);
              if vnoski = 0
              then
                vnoski := 1;
              end if;
              i := vnoski;
              while i > 0
              loop
                nv := instnum - vnoski + i;
                if nv = instnum
                then
                  sumzad := round(vtaxpers -
                                  ((vnoski - 1) * round(vtaxpers / vnoski, 2)), 2);
                else
                  sumzad := round(vtaxpers / vnoski, 2);
                end if;
                i := i - 1;
                ---------------------
                if to_char(coalesce(rtaxdoc.earn_date,
                               (to_date('20000101', 'yyyymmdd'))), 'yyyy') <>
                   to_char(vTDateBegin, 'yyyy')
                then
                  select getWorkingDay(tp.termpaydate::date, 1)
                  into   vtermpaydate
                  from   taxperiodpay tp
                  where  tp.taxperiod_id = vtaxperiod_id
                  and    tp.instalmentnumber = nv
                  and    tp.documenttype_id = rtaxdoc.documenttype_id;
                else
                  vtermpaydate := add_months(coalesce(rtaxdoc.earn_date::Date, vTDateBegin),
                                             2);
                end if;
                ---------------------
                select nextval('s_debtinstalment')
                into   vdebtinstalment_id;
                insert into debtinstalment
                  (debtinstalment_id, debtsubject_id, instno, termpay_date,
                   instsum, intbegindate)
                values
                  (vdebtinstalment_id, vdebtsubject_id, nv,
                   getWorkingDay(vtermpaydate::date, 1), sumzad,
                   getWorkingDay(vtermpaydate::date, 1) + integer '1');
                insert into baldebtinst
                  (debtinstalment_id, instsum, interestsum, discsum)
                values
                  (vdebtinstalment_id, sumzad, 0, 0);
              end loop;
            end if;
          end loop;
          close crTaxSubject;
          --commit;
        end if; ---- 54B
        ---------------------
        if vdoccode = '54P'
        then
          ---- 54P
          vtaxval   := 0;
          vtaxper   := 0;
          vtaxfreeO := 0;
          vtaxfreeS := 0;
          select *
          into   rtransport
          from   transport t
          where  t.taxdoc_id = iptaxdoc_Id;
          select min(tr.transpmeansreg_id), min(to_number(tr.code)),
                 min(tr.type)
          into   vtrmins_id, vtcode, vttype
          from   transpmeansreg tr
          where  tr.transpmeansreg_id = rtransport.transpmeansreg_id;
          if (vtcode = 20)
          then
            select min(ctp.pricevalue)
            into   vprice
          from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
              and    ctp.taxperiod_id = tp.taxperiod_id
            and    tp.taxperkind = '0'
            and    to_char(tp.begin_date, 'yyyy') =
                   to_char(vTDateBegin, 'yyyy')
            and    ctp.measureto::numeric <= 40.0
            and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
            ;

          else
            select min(ctp.pricevalue)
            into   vprice
          from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
              and    ctp.taxperiod_id = tp.taxperiod_id
            and    tp.taxperkind = '0'
            and    to_char(tp.begin_date, 'yyyy') =
                   to_char(vTDateBegin, 'yyyy')
            and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
            ;

          end if;
          vper   := round(months_between(vTDateEnd, vTDateBegin));
          vprice := nvl(vprice, 0.0);
          --     vtaxval := vprice;
          vtaxval := vper * vprice / 12;
          vtaxper := vtaxval;
          if (vtcode = 20)
          then
            if round(rtransport.brutto_ton + 0.499) <= 40
            then
              vtaxval := vtaxval * round(rtransport.brutto_ton + 0.499);
            else
              vtaxval := vtaxval * 40;
              select min(ctp.pricevalue)
              into   vprice
          from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
                and    ctp.taxperiod_id = tp.taxperiod_id
              and    tp.taxperkind = '0'
              and    to_char(tp.begin_date, 'yyyy') =
                     to_char(vTDateBegin, 'yyyy')
              and    ctp.measurefrom::numeric > 40.0
              and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
              ;

              vtaxval := vtaxval + (vper * vprice / 12) *
                         (round(rtransport.brutto_ton + 0.499) - 40);
            end if;
          elsif (vtcode = 16)
          then
            vtaxval := vtaxval * round(rtransport.brutto_ton + 0.499);
          elsif (vtcode = 17) or (vtcode = 18)
          then
            vtaxval := vtaxval * rtransport.power_kw;
          elsif (vtcode = 19)
          then
            vtaxval := vtaxval * rtransport.tonnage;
          end if;
          vtaxval := round(vtaxval, 2);
          if rtransport.bck = 1
          then
            vtaxfreeO := vtaxval;
            vtaxper   := 0;
          end if;
          vtaxper := round(vtaxval - vtaxfreeO - vtaxfreeS, 2); -- ????
          --     vtaxfreeO := round(vtaxfreeO,2);
          if vtaxper = 0
          then
            vtaxfreeO := vtaxval;
          end if;
          ----------- po Subekti
          vtaxfreeS := 0;
          open crTaxSubject(rtransport.transport_id, vTDateBegin);
          loop
            fetch crTaxSubject
              into rTaxSubject;
            exit when not FOUND;
            if nvl(rTaxSubject.Part, 0.0) = 0 and rTaxSubject.Divisor <> 0
            then
              rTaxSubject.Part := rTaxSubject.Divident / rTaxSubject.Divisor;
            end if;
            if coalesce(rTaxSubject.Enddate, vTDateBegin + integer '1') = vTDateBegin
            then
              vtaxvals   := 0;
              vtaxpers   := 0;
              vtaxfreeOs := 0;
            else
              vtaxvals   := round(rTaxSubject.Part * vtaxval, 2);
              vtaxpers   := round(rTaxSubject.Part * vtaxper, 2);
              vtaxfreeOs := round(rTaxSubject.Part * vtaxfreeO, 2);
            end if;
            select max(ds.debtsubject_id)
            into   voldds_id
            from   debtsubject ds
            where  ds.document_id = iptaxdoc_Id
            and    ds.taxsubject_id = rTaxSubject.Taxsubject_Id
            and    ds.taxperiod_id = vtaxperiod_id;
            if to_char(vTDateBegin, 'ddmm') = '0101'
            then
              vinst_number := 2;
            else
              vinst_number := 1;
            end if;
            vtaxpers := round(vtaxvals - vtaxfreeOs - vtaxfreeS, 2); -- ????
            if vtaxpers < 0
            then
              vtaxpers := 0;
            end if;
            vtaxvals   := round(vtaxvals, 2);
            vtaxfreeOs := round(vtaxfreeOs, 2);
           select max(a.admregion_id) into vadmregion_id
           from address a, taxsubject ts
           where ts.taxsubject_id = rTaxSubject.taxsubject_id
           and a.address_id = ts.permanent_clientaddr_id
           and a.municipality_id = rtaxdoc.municipality_id
           ;
            select nextval('s_debtsubject')
            into   vdebtsubject_id;
            insert into debtsubject
              (debtsubject_id, taxsubject_id, document_id, kinddoc,
               kinddebtreg_id, taxperiod_id, doccode, tax_begidate, tax_enddate,
               relief_id, Totalval, Totaltax, calcdate, FreeSum_obj, prtdate,
               inst_number, FreeSum_Subj, corr_instnumber, codetbo,
               corr_sumtotal, userdate, user_id, TAXOBJECT_ID, PARTIDANO,
               MUNICIPALITY_ID, KINDPARREG_ID, PAYDISCSUM, DOCNO, DOC_DATE,
               PARENT_DEBTSUBJECT_ID,admregion_id)
            values
              (vdebtsubject_id, rTaxSubject.taxsubject_id, iptaxdoc_Id, 1, 4,
               vtaxperiod_id, vdoccode, vTDateBegin, vTDateEnd, vrelief_id,
               vtaxvals, vtaxpers, trunc(current_date), vtaxfreeOs, null,
               vinst_number, vtaxfreeS, null, null, null, CURRENT_TIMESTAMP, ipuser_id,
               rtaxdoc.taxobject_id, rtaxdoc.partidano, rtaxdoc.municipality_id,
               vparreg, null, rtaxdoc.docno, rtaxdoc.doc_date, null,vadmregion_id);
            select nextval('s_debtpartproperty')
            into   vdebtpp_id;
            insert into debtpartproperty
              (debtpartproperty_id, debtsubject_id, taxperiod_id, isrelief,
               relief_id, divident, divisor, part, sumval, sumtax, taxbegindate,
               taxenddate, totalval, totaltax, userdate, user_id, homeobj_id,
               freefrom, freemonths, freesuma_obj, freesuma_subj,
               parentdebtprop_id, subjpartval, taxbefore)
            values
              (vdebtpp_id, vdebtsubject_id, vtaxperiod_id,
               decode(vrelief_id, null, 0, 1), vrelief_id, rTaxSubject.Divident,
               rTaxSubject.Divisor, rTaxSubject.Part, null, null, vTDateBegin,
               vTDateEnd, vtaxvals, vtaxpers, CURRENT_TIMESTAMP, ipuser_id,
               rtaxdoc.taxobject_id, decode(vrelief_id, null, vTaxFreeFrom),
               vfreemonths, vtaxfreeOs, vtaxfreeS, null, null, 0);
          
            --- Vnoski i dalzimo ?????
            if vtaxpers > 0 and ((voldds_id is null) or ipfl <> 2)
            then
              select count(tp.taxperiodpay_id)
              into   instnum
              from   taxperiodpay tp, documenttype d
              where  tp.documenttype_id = d.documenttype_id
              and    d.doccode = vdoccode
              and    tp.taxperiod_id = vtaxperiod_id;
              if nvl(instnum, 0.0) = 0
              then
                instnum := 2;
              end if;
              vnoski := round(round(months_between(vTDateEnd, vTDateBegin)) /
                              (12 / instnum), 0);
              if vnoski = 0
              then
                vnoski := 1;
              end if;
              i := vnoski;
              while i > 0
              loop
                nv := instnum - vnoski + i;
                if nv = instnum
                then
                  sumzad := round(vtaxpers -
                                  ((vnoski - 1) * round(vtaxpers / vnoski, 2)), 2);
                else
                  sumzad := round(vtaxpers / vnoski, 2);
                end if;
                i := i - 1;
                select nextval('s_debtinstalment')
                into   vdebtinstalment_id;
                insert into debtinstalment
                  (debtinstalment_id, debtsubject_id, instno, termpay_date,
                   instsum, intbegindate)
                  select vdebtinstalment_id, vdebtsubject_id,
                         tp.instalmentnumber, getWorkingDay(tp.termpaydate::date, 1),
                         sumzad, getWorkingDay(tp.termpaydate::date, 1) + integer '1'
                         --????
                  from   taxperiodpay tp
                  where  tp.taxperiod_id = vtaxperiod_id
                  and    tp.instalmentnumber = nv
                  and    tp.documenttype_id = rtaxdoc.documenttype_id;
                insert into baldebtinst
                  (debtinstalment_id, instsum, interestsum, discsum)
                values
                  (vdebtinstalment_id, sumzad, 0, 0);
              end loop;
            end if;
          end loop;
          close crTaxSubject;
          --commit;
        end if; --- 54P
        if vdoccode = '54V'
        then
          ---- 54V
          vtaxval   := 0;
          vtaxper   := 0;
          vtaxfreeO := 0;
          vtaxfreeS := 0;
          select *
          into   rtransport
          from   transport t
          where  t.taxdoc_id = iptaxdoc_Id;
          select min(tr.transpmeansreg_id), min(to_number(tr.code)),
                 min(tr.type)
          into   vtrmins_id, vtcode, vttype
          from   transpmeansreg tr
          where  tr.transpmeansreg_id = rtransport.transpmeansreg_id;
          select min(ctp.pricevalue)
          into   vprice
          from   cartaxprice ctp, taxperiod tp, municipality m
            where  m.municipality_id = rtaxdoc.municipality_id
            and    ctp.municipality_id = nvl(m.parentmunicipality_id, m.municipality_id)
            and    ctp.taxperiod_id = tp.taxperiod_id
          and    tp.taxperkind = '0'
          and    to_char(tp.begin_date, 'yyyy') = to_char(vTDateBegin, 'yyyy')
          and    ctp.transpmeansreg_id = vtrmins_id --rtransport.transpmeansreg_id
          ;

          vper   := round(months_between(vTDateEnd, vTDateBegin));
          vprice := nvl(vprice, 0.0);
          --     vtaxval := vprice;
          vtaxval := round(vper * vprice / 12, 2);
          vtaxper := vtaxval;
          if (vtcode = 30)
          then
            vtaxval := vtaxval * round(rtransport.air_weight + 0.499);
          end if;
          if rtransport.bck = 1
          then
            vtaxfreeO := vtaxval;
            vtaxper   := 0;
          end if;
          vtaxper := round(vtaxval - vtaxfreeO - vtaxfreeS, 2); -- ????
          --     vtaxfreeO := round(vtaxfreeO,2);
          if vtaxper = 0
          then
            vtaxfreeO := vtaxval;
          end if;
          ----------- po Subekti
          vtaxfreeS := 0;
          open crTaxSubject(rtransport.transport_id, vTDateBegin);
          loop
            fetch crTaxSubject
              into rTaxSubject;
            exit when not FOUND;
            if nvl(rTaxSubject.Part, 0.0) = 0 and rTaxSubject.Divisor <> 0
            then
              rTaxSubject.Part := rTaxSubject.Divident / rTaxSubject.Divisor;
            end if;
            if coalesce(rTaxSubject.Enddate, vTDateBegin + integer '1') = vTDateBegin
            then
              vtaxvals   := 0;
              vtaxpers   := 0;
              vtaxfreeOs := 0;
            else
              vtaxvals   := round(rTaxSubject.Part * vtaxval, 2);
              vtaxpers   := round(rTaxSubject.Part * vtaxper, 2);
              vtaxfreeOs := round(rTaxSubject.Part * vtaxfreeO, 2);
            end if;
            vtaxpers := round(vtaxvals - vtaxfreeOs - vtaxfreeS, 2); -- ????
            if vtaxpers < 0
            then
              vtaxpers := 0;
            end if;
            vtaxvals   := round(vtaxvals, 2);
            vtaxfreeOs := round(vtaxfreeOs, 2);
            select max(ds.debtsubject_id)
            into   voldds_id
            from   debtsubject ds
            where  ds.document_id = iptaxdoc_Id
            and    ds.taxsubject_id = rTaxSubject.Taxsubject_Id
            and    ds.taxperiod_id = vtaxperiod_id;
            if to_char(vTDateBegin, 'ddmm') = '0101'
            then
              vinst_number := 2;
            else
              vinst_number := 1;
            end if;
          

           select max(a.admregion_id) into vadmregion_id
           from address a, taxsubject ts
           where ts.taxsubject_id = rTaxSubject.taxsubject_id
           and a.address_id = ts.permanent_clientaddr_id
           and a.municipality_id = rtaxdoc.municipality_id
           ;
             select nextval('s_debtsubject')
            into   vdebtsubject_id;
            insert into debtsubject
              (debtsubject_id, taxsubject_id, document_id, kinddoc,
               kinddebtreg_id, taxperiod_id, doccode, tax_begidate, tax_enddate,
               relief_id, Totalval, Totaltax, calcdate, FreeSum_obj, prtdate,
               inst_number, FreeSum_Subj, corr_instnumber, codetbo,
               corr_sumtotal, userdate, user_id, TAXOBJECT_ID, PARTIDANO,
               MUNICIPALITY_ID, KINDPARREG_ID, PAYDISCSUM, DOCNO, DOC_DATE,
               PARENT_DEBTSUBJECT_ID,admregion_id)
            values
              (vdebtsubject_id, rTaxSubject.taxsubject_id, iptaxdoc_Id, 1, 4,
               vtaxperiod_id, vdoccode, vTDateBegin, vTDateEnd, vrelief_id,
               vtaxvals, vtaxpers, trunc(current_date), vtaxfreeOs, null,
               vinst_number, vtaxfreeS, null, null, null, CURRENT_TIMESTAMP, ipuser_id,
               rtaxdoc.taxobject_id, rtaxdoc.partidano, rtaxdoc.municipality_id,
               vparreg, null, rtaxdoc.docno, rtaxdoc.doc_date, null,vadmregion_id);
            select nextval('s_debtpartproperty')
            into   vdebtpp_id;
            insert into debtpartproperty
              (debtpartproperty_id, debtsubject_id, taxperiod_id, isrelief,
               relief_id, divident, divisor, part, sumval, sumtax, taxbegindate,
               taxenddate, totalval, totaltax, userdate, user_id, homeobj_id,
               freefrom, freemonths, freesuma_obj, freesuma_subj,
               parentdebtprop_id, subjpartval, taxbefore)
            values
              (vdebtpp_id, vdebtsubject_id, vtaxperiod_id,
               decode(vrelief_id, null, 0, 1), vrelief_id, rTaxSubject.Divident,
               rTaxSubject.Divisor, rTaxSubject.Part, null, null, vTDateBegin,
               vTDateEnd, vtaxvals, vtaxpers, CURRENT_TIMESTAMP, ipuser_id,
               rtaxdoc.taxobject_id, decode(vrelief_id, null, vTaxFreeFrom),
               vfreemonths, vtaxfreeOs, vtaxfreeS, null, null, 0);
          
            --- Vnoski i dalzimo ?????
            if vtaxpers > 0 and ((voldds_id is null) or ipfl <> 2)
            then
              select count(tp.taxperiodpay_id)
              into   instnum
              from   taxperiodpay tp, documenttype d
              where  tp.documenttype_id = d.documenttype_id
              and    d.doccode = vdoccode
              and    tp.taxperiod_id = vtaxperiod_id;
              if nvl(instnum, 0.0) = 0
              then
                instnum := 2;
              end if;
              vnoski := round(round(months_between(vTDateEnd, vTDateBegin)) /
                              (12 / instnum), 0);
              if vnoski = 0
              then
                vnoski := 1;
              end if;
              i := vnoski;
              while i > 0
              loop
                nv := instnum - vnoski + i;
                if nv = instnum
                then
                  sumzad := round(vtaxpers -
                                  ((vnoski - 1) * round(vtaxpers / vnoski, 2)), 2);
                else
                  sumzad := round(vtaxpers / vnoski, 2);
                end if;
                i := i - 1;
                select nextval('s_debtinstalment')
                into   vdebtinstalment_id;
                insert into debtinstalment
                  (debtinstalment_id, debtsubject_id, instno, termpay_date,
                   instsum, intbegindate)
                  select vdebtinstalment_id, vdebtsubject_id,
                         tp.instalmentnumber, getWorkingDay(tp.termpaydate::date, 1),
                         sumzad, getWorkingDay(tp.termpaydate::date, 1) + integer '1'
                  from   taxperiodpay tp
                  where  tp.taxperiod_id = vtaxperiod_id
                  and    tp.instalmentnumber = nv
                  and    tp.documenttype_id = rtaxdoc.documenttype_id;
                insert into baldebtinst
                  (debtinstalment_id, instsum, interestsum, discsum)
                values
                  (vdebtinstalment_id, sumzad, 0, 0);
              end loop;
            end if;
          end loop;
          close crTaxSubject;
          --commit;
        end if; --- 54V
      end if; -- za novo nachislenie
      -----------------------
      -- end if; --- bez zadalzenie za godinata !!!
      if (ipStatus <> 'OK') and (ipStatus <> 'errNoDuty')
      then
        exit;
      end if;
      vTaxYear := vTaxYear + 1;
    end loop;
    --commit;
  exception
   when others then
     ipStatus := sqlerrm; -- 'errOrclDB'; --
  
end;
$function$
; DROP FUNCTION taxvaluation.taxvalhome(numeric, date, character varying); 
CREATE OR REPLACE FUNCTION taxvaluation.taxvalhome(OUT return_val character varying, iphomeobj_id numeric, ipyear date, vkindfunction character varying, OUT vgroupe numeric, OUT opmess character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  RowHomeObj  Homeobj%rowtype;
  rowBuilding Building%rowtype;
  RowProperty Property%rowtype;
  vBS1        numeric;
  vBS         numeric;
  vKM         numeric;
  vKI         numeric;
  vKX         numeric;
  vKB         numeric;
  vKO         numeric;
  vPL         numeric;
  vgr         varchar(10);
  vekatte     varchar(10);
  vki1        numeric;
  vki2        numeric;
  vki3        numeric;
  vKO1        numeric;
  vKX1        numeric;
  vKX2        numeric;
  vKX3        numeric;
  vkZav       numeric;
  vObjGroup   numeric;
  --   vGroupe numeric;
  vkzone   numeric [ ];
  vcitycat integer;
  voFloor  numeric;
  vmunicipality_id integer;
  voldKO varchar(20);

  i integer;
begin
  select *
  into   RowHomeObj
  from   homeobj h
  where  h.homeobj_id = ipHomeobj_Id;
  select *
  into   rowBuilding
  from   building b
  where  b.building_id = rowhomeobj.building_id;
  select *
  into   RowProperty
  from   property p
  where  p.property_id = rowBuilding.Property_Id;
    select nvl(m.parentmunicipality_id, m.municipality_id)
    into   vmunicipality_id
    from   property p, municipality m
    where  p.property_id = rowBuilding.Property_Id
    and p.location_municipality_id = m.municipality_id;

  -------  BS
  select min(kh.objgroup)
  into   vObjGroup
  from   kindhomeobjreg kh
  where  kh.kindhomeobjreg_id = RowHomeObj.Kindhomeobjreg_Id;
  select (case
            when vkindfunction = '2' then
             nb.apartmentvalue
            when vkindfunction = '1' then
             nb.housevalue
            when vkindfunction = '3' then
             nb.housevalue
            when vkindfunction = '4' then
             nb.housevalue
            else
             nb.housevalue
          end)
  /*    decode(vkindfunction, '2', nb.apartmentvalue, '1', nb.housevalue, '3',
  nb.housevalue, '4', nb.housevalue, nb.nohousevalue)*/
  into   vBS
  from   normbs nb
  where  nb.kindconstruction = nvl(RowHomeObj.Kindconstruction,'0')
  and    nb.normyear = (select max(n.normyear)
                        from   normbs n
                        where  n.normyear <= ipYear);
  vBS1 := 100;
  if vkindfunction in ('1', '3', '4')
  then
    if vObjGroup in (3, 4)
    then
      vBS1 := 60;
    end if;
    if vObjGroup = 5
    then
      vBS1 := 40;
    end if;
    if vObjGroup = 2
    then
      vBS1 := 85;
    end if;
    if vObjGroup = 10
    then
      vBS1 := 80;
    end if;
  elsif vkindfunction = '2'
  then
    if vObjGroup in (2, 10)
    then
      vBS1 := 80;
    end if;
  else
    if vObjGroup in (3, 4)
    then
      vBS1 := 60;
    end if;
    if vObjGroup = 5
    then
      vBS1 := 40;
    end if;
    if vObjGroup in (10)
    then
      vBS1 := 80;
    end if;
    --    if vObjGroup in (2) then vBS1 := 85; end if;
  end if;
  vBS := vBS * vBS1 / 100;
  ---------- KM

  select min(c.ekatte)
  into   vekatte
  from   address a, city c
  where  a.address_id = RowProperty.Property_address_id
  and    c.city_id = a.city_id;
  select min(c.citycat)::integer, min(c.citygroup)
  into   vcitycat, vgr
  from   CITYCAT_NORMKM3 c
  where  c.ekatte = vekatte
  and    c.begindate = (select max(cc.begindate)
                        from   CITYCAT_NORMKM3 cc
                        where  cc.ekatte = vekatte
                        and    cc.begindate <= ipYear);
  if vcitycat is null
  then
    vcitycat := rowproperty.category_city::integer;
    if rowproperty.category_city = 0
    then
      vgr := vekatte;
    elsif rowproperty.category_city > 1
    then
      vgr := '0';
    elsif rowproperty.category_city = 1
    then
      vgr := '2';
    end if;
  end if;
  vKM := 1;
  if (rowBuilding.Kindfunction = '6') or (rowBuilding.Kindfunction = '7')
  then
    select array [ min(n.productionbuildingbm), min(n.productionbuildingnbm),
           min(n.farmbuildingbm), min(n.farmbuildingnbm) ]
    into   vkzone
    from   normkm4 n
    where  n.normyear = (select max(nn.normyear)
                         from   normkm4 nn
                         where  nn.normyear <= ipYear)
    and    cast(n.category_city as varchar(30)) = cast(vcitycat  as varchar(30))
    and    n.groupe = vgr;
    if (rowBuilding.Kindfunction = '6')
    then
      if ((2 - nvl(RowProperty.Constructionbound, '2') ::numeric) +
         nvl(RowProperty.Isnationalroadnet, 0.0) +
         nvl(RowProperty.Isisolatedzone, 0.0)) > 1
      then
        vKM := nvl(vkzone [ 1 ], 0.0);
      else
        vKM := nvl(vkzone [ 2 ], 0.0);
      end if;
    end if;
    if (rowBuilding.Kindfunction = '7')
    then
      if ((2 - nvl(RowProperty.Constructionbound, '2') ::numeric) +
         nvl(RowProperty.Isnationalroadnet, 0.0) +
         nvl(RowProperty.Isisolatedzone, 0.0)) > 1
      then
        vKM := nvl(vkzone [ 3 ], 0.0);
      else
        vKM := nvl(vkzone [ 4 ], 0.0);
      end if;
    end if;
  else
    select count(*) into i
      from   normkm3 n
      where  n.normyear = (select max(nn.normyear)
                           from   normkm3 nn
                           where  nn.normyear <= ipYear)
      and    n.category_city = cast(vcitycat  as varchar(30))
      and    n.groupe = vgr;
      if i = 0 then
        return_val := '������ ���������� ���� �� ��';
        return;
      end if;
    select array [ min(n.kzone1), min(n.kzone2), min(n.kzone3), min(n.kzone4),
           min(n.kzone5), min(n.inbound), min(n.outbound), min(n.villazone1),
           min(n.villazone2) ]
    into   vkzone
    from   normkm3 n
    where  n.normyear = (select max(nn.normyear)
                         from   normkm3 nn
                         where  nn.normyear <= ipYear)
    and    n.category_city = cast(vcitycat  as varchar(30))
    and    n.groupe = vgr;
    --- Stroitelni granici
    if coalesce(RowProperty.Builder_Zone, 0.0) > 0
    then
      vKM := vkzone [ RowProperty.Builder_Zone ];
    else
      if nvl(RowProperty.Seezone_Cat, 0.0) > 0
      then
        vKM := vkzone [ RowProperty.Seezone_Cat + 7 ];
      end if;
    end if;
    if (coalesce(RowProperty.Builder_Zone, 0.0) = 0) and
       (coalesce(RowProperty.Seezone_Cat, 0.0) = 0)
    then
      vKM := vkzone [ nvl(RowProperty.Constructionbound,'1')::integer + 5 ];
    end if;
    if RowHomeObj.Kindhomeobjreg_Id in (6, 10, 14, 18, 22)
    then
      vKM := nvl(vKM, 0.0) * 140 / 100;
    end if;
  end if;
  ---- Zavishenie na KM
  vkZav := 1;
  if (RowProperty.Isnationalresort = 1) or (RowProperty.Isseezone = 1)
  then
    if vekatte not in ('10135', '07079') -- and vcitycat <> 1  ???????
       and ((coalesce(RowProperty.Constructionbound, '0') <> '2') or
       (coalesce(RowProperty.Builder_Zone, 0.0) <> 0) or
       (coalesce(RowProperty.Seezone_Cat, 0.0) <> 0))
    then
      if to_number(to_char(ipYear, 'yyyy')) < 2006
      then
        vkZav := vkZav * 1.20;
      else
        if vcitycat <> 1
        then
          vkZav := vkZav * 1.50;
        end if;
      end if;
    end if;
  end if;
  if RowProperty.Islocalresort = 1 -- and vcitycat <> 1   ?????
     and ((coalesce(RowProperty.Constructionbound, '0') <> '2') or
     (coalesce(RowProperty.Builder_Zone, 0.0) <> 0) or
     (coalesce(RowProperty.Seezone_Cat, 0.0) <> 0))
  then
    if to_number(to_char(ipYear, 'yyyy')) < 2006
    then
      vkZav := vkZav * 1.10;
    else
      if vcitycat <> 1
      then
        vkZav := vkZav * 1.20;
      end if;
    end if;
  end if;
  --   if RowHomeObj.Kindhomeobjreg_Id in (6,10,14,18,22) then
  --     vkZav := vkZav + 40;
  --   end if;
  vkm := coalesce(vkm, 0.0) * vkzav; ---(100 + vkzav)/ 100;
  ---------- KI
  vKI := 1;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 1; --- isWoter
  if ((RowHomeObj.Iswater = 1) or (RowProperty.Iswater = 1))
  then
    vKI := vKI + vKi1;
  else
    if RowProperty.Iswater = 3
    then
      vKI := vKI + vKi2;
    else
      vKI := vKI + vKi3;
    end if;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 2; --- isSewer
  if ((RowHomeObj.Issewer = 1) or (RowProperty.Issewer = 1))
  then
    vKI := vKI + vKi1;
  else
    if RowProperty.Issewer = 3
    then
      vKI := vKI + vKi2;
    else
      vKI := vKI + vKi3;
    end if;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 3; --- isElectro
  if ((RowHomeObj.Iselectro = 1) or (RowProperty.Iselectro = 1))
  then
    vKI := vKI + vKi1;
  else
    if RowProperty.Iselectro = 3
    then
      vKI := vKI + vKi2;
    else
      vKI := vKI + vKi3;
    end if;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 4; --- Istelefon
  if RowHomeObj.Istelefon = 1
  then
    vKI := vKI + vKi1;
  else
    vKI := vKI + vKi3;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 5; --- isTEC
  --   if ((RowHomeObj.Istec = 1) or (RowProperty.Istec = 1)) then vKI := vKI + vKi1;
  if (RowHomeObj.Istec = 1)
  then
    vKI := vKI + vKi1;
  else
    if RowProperty.Istec = 3
    then
      vKI := vKI + vKi2;
    else
      vKI := vKI + vKi3;
    end if;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 6; --- isRoad
  if RowProperty.Isroad = 1
  then
    vKI := vKI + vKi1;
  else
    vKI := vKI + vKi3;
  end if;
  ---------- KX
  vKX     := 1;
  vkx1    := 0;
  voFloor := to_number(case when trim(coalesce(regexp_replace(RowHomeObj.Floor,'[^0-9]', ''),'0')) = '' then '0' else trim(coalesce(regexp_replace(RowHomeObj.Floor,'[^0-9]', ''),'0')) end );
  voFloor := round(voFloor);
  if rowBuilding.Kindfunction = '2'
  then
    -- if to_number(trim(RowHomeObj.Floor)) > 6
    if voFloor > 6
    then
      --RowHomeObj.Floor := 6;
      voFloor := 6;
    end if;
    --if to_number(trim(RowHomeObj.Floor)) > 0
    if voFloor > 0
    then
    
      if rowBuilding.Floornumover > 5 and
         rowBuilding.Elevator <> 1
      then
        select ne.noelevatornohome, ne.noelevatorapartment
        into   vkx1, vKX2
        from   normet ne
        where  ne.normyear = (select max(n.normyear)
                              from   normet n
                              where  n.normyear <= ipYear)
        --and    ne.floor = to_number(trim(RowHomeObj.Floor));
        and    ne.floor = voFloor;
        --    if RowHomeObj.Isbusiness <> 1 then  vkx1 := vKX2; end if;
        if RowHomeObj.Kindhomeobjreg_Id = 1
        then
          vkx1 := vKX2;
        end if;
      else
        select ne.nohouse, ne.apartment
        into   vkx1, vKX2
        from   normet ne
        where  ne.normyear = (select max(n.normyear)
                              from   normet n
                              where  n.normyear <= ipYear)
        and    ne.floor = voFloor; 
        --    if RowHomeObj.Isbusiness <> 1 then  vkx1 := vKX2; end if;
        if RowHomeObj.Kindhomeobjreg_Id = 1
        then
          vkx1 := vKX2;
        end if;
      end if;
      if RowHomeObj.Kindhomeobjreg_Id in (2, 3, 4, 5)
      then
        vkx1 := 0;
      end if;
      --    if RowHomeObj.Floor = rowBuilding.Floornumover and RowHomeObj.Floor > 1 then
      --   if voFloor = rowBuilding.Floornumover and voFloor > 1
      if RowHomeObj.Floor::integer = rowBuilding.Floornumover::integer and RowHomeObj.Floor::integer > 1
      then
        vkx1 := vkx1 - 0.05;
      end if;
    end if;
    if vObjGroup in (2, 10)
    then
      vkx1 := 0;
    end if;
    if RowHomeObj.objectArea = 0
    then
      vkx1 := 0;
    end if;
  end if;
  vKX2 := 0;
  if trim(RowHomeObj.Repairdate) = '' then 
       RowHomeObj.Repairdate := null; 
  end if;
  if trim(RowHomeObj.Builddate) = '' then 
    RowHomeObj.Builddate := null;
  end if; 

  if to_number(to_char(ipyear, 'yyyy'), '9999') -
     to_number(nvl(trim(RowHomeObj.Repairdate), nvl(trim(RowHomeObj.Builddate), '1900')),
               '9999') > 20
  then
    vKX2 := -0.05;
  end if;
  vKX3 := 0;
  select vKX3 + (case
            when rowhomeobj.isheating = 1 then
             np.have
            else
             np.havenot
          end)
  into   vKX3
  from   normpod np
  where  np.kindchange = 1
  and    to_number(to_char(np.normyear, 'yyyy'), '9999') =
         (select to_number(to_char(max(nn.normyear), 'yyyy'), '9999')
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + (case
            when rowhomeobj.isaircondition = 1 then
             np.have
            else
             np.havenot
          end)
  into   vKX3
  from   normpod np
  where  np.kindchange = 2
  and    to_number(to_char(np.normyear, 'yyyy'), '9999') =
         (select to_number(to_char(max(nn.normyear), 'yyyy'), '9999')
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + (case
            when rowhomeobj.luxwindow = 1 then
             np.have
            else
             np.havenot
          end)
  into   vKX3
  from   normpod np
  where  np.kindchange = 3
  and    to_number(to_char(np.normyear, 'yyyy'), '9999') =
         (select to_number(to_char(max(nn.normyear), 'yyyy'), '9999')
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + decode(rowhomeobj.soundinsulation::numeric, 1.0, np.have, np.havenot)
  into   vKX3
  from   normpod np
  where  np.kindchange = 4
  and    to_number(to_char(np.normyear, 'yyyy'), '9999') =
         (select to_number(to_char(max(nn.normyear), 'yyyy'), '9999')
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + decode(rowhomeobj.specialroof::numeric, 1.0, np.have, np.havenot)
  into   vKX3
  from   normpod np
  where  np.kindchange = 5
  and    to_number(to_char(np.normyear, 'yyyy'), '9999') =
         (select to_number(to_char(max(nn.normyear), 'yyyy'), '9999')
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + decode(rowhomeobj.luxdecorate::numeric, 1.0, np.have, np.havenot)
  into   vKX3
  from   normpod np
  where  np.kindchange = 6
  and    to_number(to_char(np.normyear, 'yyyy'), '9999') =
         (select to_number(to_char(max(nn.normyear), 'yyyy'), '9999')
           from   normpod nn
           where  nn.normyear <= ipYear);
  vKX := vKX + vkx1 + vKX2 + vkx3;
  --------- KB
  vKB := 1;
  --    if ((rowBuilding.Kindfunction = 5) or (rowBuilding.Kindfunction = 6) or
  --        (rowBuilding.Kindfunction = 7)) and RowHomeObj.Height > 4 then
  if (RowHomeObj.Kindhomeobjreg_Id in
     (6, 7, 8, 10, 11, 12, 14, 15, 16, 18, 19, 20, 22, 23, 24)) and
     RowHomeObj.Height > 4
  then
    vKB := power((RowHomeObj.Height - 3), 0.05);
    vKb := round(vKB, 3);
  end if;
  --------- KO
  vKO := 1;
  if vmunicipality_id in (1239, 1147, 1290, 1112,1185,1114) then i := 0; else i := 1; end if;
    if to_number(to_char(ipYear, 'yyyy'),'9999') -
       (to_number(nvl(RowHomeObj.Builddate, '0'),'9999') + i) > 5
    then
      select (100 -
              (to_number(to_char(ipYear, 'yyyy'),'9999') -
              (to_number(nvl(RowHomeObj.Builddate, '0'),'9999') + i) - 5) * n.pctwornout) / 100,
             n.wornoutlimit
      into   vKO, vKO1
      from   normbs n
      where  n.kindconstruction = nvl(RowHomeObj.Kindconstruction,'0')
      and    n.normyear = (select max(nn.normyear)
                           from   Normki nn
                           where  nn.normyear <= ipYear);

/*  if to_number(to_char(ipYear, 'yyyy'), '9999') -
     to_number(coalesce(RowHomeObj.Builddate, '0'), '9999') > 5
  then
    select (100 - (to_number(to_char(ipYear, 'yyyy'), '9999') -
            to_number(coalesce(RowHomeObj.Builddate, '0'), '9999') - 5) *
            n.pctwornout) / 100, n.wornoutlimit
    into   vKO, vKO1
    from   normbs n
    where  n.kindconstruction = RowHomeObj.Kindconstruction
    and    n.normyear = (select max(nn.normyear)
                         from   Normki nn
                         where  nn.normyear <= ipYear);
*/
    if vKO < vKo1
    then
      vKO := vKo1;
    end if;
  end if;
  --------- PL
  vPL := RowHomeObj.Objectarea;
  if RowHomeObj.Kindhomeobjreg_Id < 6
  then
    vPL := vPL +
           (coalesce(RowHomeObj.Cellerarea, 0.0) + coalesce(RowHomeObj.Atticarea, 0.0)) * 30 / 100;
  else
    vPL := vPL +
           (coalesce(RowHomeObj.Cellerarea, 0.0) + coalesce(RowHomeObj.Atticarea, 0.0)) * 60 / 100;
  end if;
  --------
  vGroupe    := nvl(vBS, 0.0) * nvl(vKM, 0.0) * nvl(vKI, 0.0) * nvl(vKX, 0.0) *
                nvl(vKB, 0.0) * nvl(vKO, 0.0) * nvl(vPL, 0.0);
  vGroupe    := round(vGroupe, 1);
  opmess     := ' BS=' || to_char(vBS,'990.999') || ' * KM=' || to_char(vKM,'990.999') || ' * KI=' || to_char(vKI,'990.999') ||
                  ' * KX=' || to_char(vKX,'990.999') || ' * KB=' || to_char(vKB,'990.999') || ' * KO=' || to_char(vKO,'990.999') ||
                  ' * PL=' || to_char(vPL,'99990.999');
  return_val := 'OK';
  return;

end;
$function$
; DROP FUNCTION taxvaluation.upd_doc14(numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.upd_doc14(iptaxdoc_id numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
declare
    vtd14_id          numeric;
    vpartno           varchar(50);
    vreccount         numeric;
    mymunicipality_id numeric;
    vuser_id          numeric;
    vdocstat          varchar(10);
  begin
  
    select min(td.taxdoc_id), min(td.partidano), count(*),
           max(td.municipality_id), max(td.user_id), max(td.docstatus)
    into   vtd14_id, vpartno, vreccount, mymunicipality_id, vuser_id, vdocstat
    from   firm_1417 f, taxdoc td
    where  f.taxdoc_id_17 = iptaxdoc_id
    and    td.taxdoc_id = f.taxdoc_id_14
    and    nvl(f.no_active, 0.0) <> 1;
    if vtd14_id is not null
    then
      if vdocstat = '10'
      then
        update taxdoc td
        set    docstatus = '30'
        where  td.taxdoc_id = vtd14_id;
      
        if vpartno is null and (nvl(vreccount, 0.0) = 1)
        then
          --perform getpartidano(mymunicipality_id, 21, vpartno);
          vpartno := public.getpartidano(mymunicipality_id, 21);
          if vpartno <> '-1'
          then
            update taxdoc td
            set    partidano = vpartno
            where  td.taxdoc_id = vtd14_id;
          end if;
        end if;
        --commit;
        perform taxvaluation.arxdoc(vtd14_id);
        --commit;
      end if;
    end if;
  end;
$function$
; DROP FUNCTION taxvaluation.updpat(integer, numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.updpat(fl integer, iptaxvalobj numeric, ipactivityobj_id numeric, iptaxvalue_decl numeric, ippatentactivity_id numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
    begin
     if fl = 1
      then
        update patentactivityobj po
        set    taxvalue_calc = iptaxvalobj,
               isfalse_taxvalue = case sign(iptaxvalobj - iptaxvalue_decl)
                                   when 0 then 0
                                    else 1
                                  end
        where  po.patentactivityobj_id = ipactivityobj_id;
        ----commit;
      end if;
      if fl = 0
      then
        update patentactivity pa
        set    taxvalue_calc = iptaxvalobj,
               isfalse_taxvalue = case sign(iptaxvalobj - pa.taxvalue_decl)
                                   when 0 then 0
                                    else 1
                                  end
        where  pa.patentactivity_id = ippatentactivity_id;
        ----commit;
      end if;
    end;
$function$
; DROP FUNCTION taxvaluation.updprop(integer, numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION taxvaluation.updprop(fl integer, ipfirmpropobj_id numeric, iptaxvalobj numeric, ipearntaxvalobj numeric, iptboobj numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
      
    begin
      if fl = 1
      then
        update firmpropobj o
        set    taxvalue_calc = iptaxvalobj,
               earntaxvalue_calc = ipearntaxvalobj,
             --  isfalse_taxvalue = decode(sign(o.taxvalue_decl - iptaxvalobj), 0,
             --                               0, 1),
               isfalse_taxvalue = case sign(o.taxvalue_decl - iptaxvalobj)
                                   when 0 then 0
                                    else 1
                                  end,
               -- isfalse_earntaxvalue = decode(sign(o.earntaxvalue_decl -
               --                                      ipearntaxvalobj), 0, 0, 1),
               isfalse_earntaxvalue = case sign(o.earntaxvalue_decl - ipearntaxvalobj)
                                       when 0 then 0
                                        else 1
                                      end,
               tbo_calc = iptboobj
        where  o.firmpropobj_id = ipfirmpropobj_id;
        ----commit;
      end if;
      if fl = 0
      then
        update firmproperty p
        set    taxprop_calc = iptaxvalobj,
               --vearntaxval,
               taxgarb_calc = ipearntaxvalobj,
            --   isfalse_taxprop = decode(sign(p.taxprop_decl - iptaxvalobj), 0,
             --                              0, 1),
               isfalse_taxprop = case sign(p.taxprop_decl - iptaxvalobj)
                                  when 0 then 0
                                   else 1
                                 end,
              -- isfalse_taxgarb = decode(sign(p.taxgarb_decl - ipearntaxvalobj),
              --                             0, 0, 1)
               isfalse_taxgarb = case sign(p.taxgarb_decl - ipearntaxvalobj)
                                  when 0 then 0
                                   else 1
                                 end
        where  p.firmprop_id = ipfirmpropobj_id;
        ----commit;
      end if;
    end;
    $function$
; DROP FUNCTION taxvaluation.workday(date); 
CREATE OR REPLACE FUNCTION taxvaluation.workday(cdate date)
 RETURNS date
 LANGUAGE plpgsql
AS $function$
declare
  fdate date;
  rdate date;
begin
  rdate := cdate;
  loop
    select min(c.freedate)
    into   fdate
    from   calendar c
    where  c.freedate = rdate; --trunc(rdate);
    if fdate is null
    then
      exit;
    end if;
    rdate := rdate + 1;
  end loop;
  return(rdate);
end;
$function$
; DROP FUNCTION taxvaluation.firmproperty(numeric, date, date, numeric, integer, integer); 
CREATE OR REPLACE FUNCTION taxvaluation.firmproperty(iptaxdoc_id numeric, ipfromdate date, iptodate date, ipuser_id numeric, ipoblwr integer DEFAULT 0, OUT ipstatus character varying, ipflrec integer DEFAULT 0, OUT optotalval numeric, OUT optotaltax numeric, OUT optbototaltax numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                         

    crfirmprop cursor is

      select f.*

      from   Firmproperty f

      -- where f.taxdoc_id =  --iptaxdoc_Id

      where  f.firmprop_id =

             (select max(ff.firmprop_id)

              from   Firmproperty ff

              where  ff.taxdoc_id = iptaxdoc_Id);

    rfirmprop record;

  

    crfirmobj cursor (firmpro_id numeric) is

      select po.*, po.accvalue accvalueTBO  

      from   firmpropobj po

      where  po.firmproperty_id = firmpro_id;

  

    rowfirmobj record;

    rowtaxdoc  taxdoc%rowtype;

  

    rgrouptbo          grouptbo%rowtype;

    vcity_id           numeric;

    vcity0_id          numeric;

    flfree             integer;

    vtaxperiod_id      numeric;

    vhomeprom          numeric;

    vnohomeprom        numeric;

    i                  integer;

    vgrouptbo_id       numeric;

    rprtbo             promtbo%rowtype;

    vtaxdoc71_id       numeric;

    vtaxdoc19_id       numeric;

    vtaxtbo            numeric;

    vodateb            date;

    vodatee            date;

    brmes              integer;

    brmesfree          integer;

    vtaxvalobj         numeric;

    vearntaxvalobj     numeric;

    vtaxtboobj         numeric;

    vtaxval            numeric;

    vearntaxval        numeric;

    vdoccode           varchar(20);

    vinst_number       integer;

    vtbodebtsubject_id numeric;

    vdebtsubject_id    numeric;

    vdpproperty_id     numeric;

    vdptbo_id          numeric;

    nv                 integer;

    sumzad             numeric;

    vfreesumobj        numeric;

    vtaxtbofree        numeric;

    vtbofreeobj        numeric;

    vtaxvalfree        numeric;

    vearnval           numeric;

    vearnvalobj        numeric;

    --- 18.07

    vearnvalTBO    numeric;

    vearnvalTBOobj numeric;

--    fldif              integer;

    vearntboobj        numeric;

    perbdate           date;

    peredate           date;

    vtaxyear           numeric;

    flfirsy            numeric;

    vsw_missing        numeric;

    vclean_missing     numeric;

    vdepot_missing     numeric;

    oldds_id           numeric;

    oldtbods_id        numeric;

    vmindo             numeric;

    vCurYear           varchar(10);

    vparreg            numeric;

    vaccvalueo         numeric;

    vdecltbo           numeric;

    vmunicipality_id   numeric;

    vsumacc            numeric;

    vgarbtax19         numeric;

    vgarbtax71         numeric;

    vdocst             varchar(20);

    vadmregion_id      numeric;

    invsumtbo          numeric;

    sumtbo             numeric;

    invsum             numeric;

    vminp              integer;

    vho_kindobj        varchar(10);

    vho_obj_id         numeric;

    errmess            varchar(200);

    vbuildkf           varchar(10);

    vDOhomeobj         numeric;

    XX                 varchar(200);

    vnocorect          numeric;

    vnorminst          integer; --numeric;

    vdiv               numeric;

    --- 18.07

    kindcalTBO   varchar(2);

    vsumaccTBO   numeric;

    vaccvalueTBO numeric;



    taxValLandRec record;

    taxValHomeRec record;

    vownerp          numeric;      
    vtermpaydate     timestamp;
    vtaxdoc_id_14    numeric;
    vconstr_bound    varchar(10);
    vobjbuilddate    varchar(10);
    vper             numeric;

  begin

  

    select *

    into   rowtaxdoc

    from   taxdoc td

    where  td.taxdoc_id = iptaxdoc_Id;

    select c.configvalue

    into   vCurYear

    from   config c

    where  name = 'TAXYEAR17' and c.municipality_id = rowtaxdoc.municipality_id;

    select min(ds.debtsubject_id)

    into   vdebtsubject_id

    from   debtsubject ds, taxdoc td

    where  ds.document_id = iptaxdoc_Id

    and    ds.document_id = td.taxdoc_id

    and    nvl(ds.docno, '*') = nvl(td.docno, '*')

    and    nvl(ds.doc_date::date, trunc(current_date)) = nvl(td.doc_date::date, trunc(current_date))

    and    ds.doc_date = td.doc_date

    and    ds.taxperiod_id =

           (select tp.taxperiod_id

             from   taxperiod tp

             where  to_char(tp.begin_date, 'yyyy') = to_char(ipFromDate, 'yyyy')

             and    tp.taxperkind = '0');

  

    if (vdebtsubject_id is not null) and

       (nvl(rowtaxdoc.close_taxdoc_id, 0.0) <> 1)

    then

      ipStatus := 'errEndProcess'; --'���� �������� �������� ' || iptaxdoc_Id ;

      return;

    end if;

  

    vTaxYear := to_number(to_char(ipFromDate, 'yyyy'));

    if vtaxyear > vCurYear::numeric

    then

      ipStatus := 'OK';

      return;

    end if;

  

    select c.configvalue

    into   vCurYear

    from   config c

    where  name = 'TAXYEAR';

  

    while vTaxYear <= to_number(to_char(ipToDate, 'yyyy'))

    loop

      --- 18.07    

      select min(c.configvalue)

      into   kindcalTBO

      from   config c

      where  c.name = 'TBO17OTCHET' || to_char(vTaxYear);

    

      vtaxval     := 0;

      vearntaxval := 0;

      vtaxtbo     := 0;

      vtaxvalfree := 0;

      vtaxtbofree := 0;

      vearnval    := 0;

      vearnvalTBO := 0; --- 18.07

    

      if vTaxYear < to_number(vcuryear)

      then

        vparreg := 3;

      else

        vparreg := 2;

      end if;

    

      perbdate := to_date('01.01.' || to_char(vTaxYear), 'dd.mm.yyyy');

      if perbdate < ipFromDate

      then

        perbdate := ipFromDate;

      end if;

      peredate := to_date('31.12.' || to_char(vTaxYear), 'dd.mm.yyyy');

      if peredate > ipToDate

      then

        peredate := ipToDate;

      end if;

    

      select min(ds.debtsubject_id)

      into   flfirsy

      from   debtsubject ds

      where  ds.document_id = iptaxdoc_Id

      and    nvl(ds.docno, '*') = nvl(rowtaxdoc.docno, '*')

      and    nvl(ds.doc_date::date, trunc(current_date)) =

             nvl(rowtaxdoc.doc_date::date, trunc(current_date));

    

      select tp.taxperiod_id

      into   vtaxperiod_id

      from   taxperiod tp

      where  to_char(tp.begin_date, 'yyyy') = to_char(perbdate, 'yyyy')

      and    tp.taxperkind = '0';

      open crfirmprop;

      -----------------

      select dt.doccode

      into   vdoccode

      from   documenttype dt

      where  dt.documenttype_id = rowtaxdoc.documenttype_id

      -- and dt.municipality_id = rowtaxdoc.municipality_id

      ;

      select nextval('s_debtsubject')

      into   vdebtsubject_id;

      select nextval('s_debtsubject')

      into   vtbodebtsubject_id;

      ------------------
        select a.city_id, a.admregion_id
        into   vcity_id, vadmregion_id
        from   address a, firmproperty p
        where  a.address_id = p.property_address_id
        and p.taxdoc_id = iptaxdoc_Id;

      insert into debtsubject

        (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,

         taxperiod_id, doccode, tax_begidate, tax_enddate, relief_id, Totalval,

         Totaltax, calcdate, FreeSum_obj, prtdate, inst_number, FreeSum_Subj,

         corr_instnumber, codetbo, corr_sumtotal, userdate, user_id,

         TAXOBJECT_ID, PARTIDANO, MUNICIPALITY_ID, KINDPARREG_ID, PAYDISCSUM,

         DOCNO, DOC_DATE, PARENT_DEBTSUBJECT_ID, admregion_id)

      values

        (vdebtsubject_id, rowtaxdoc.taxsubject_id, iptaxdoc_Id, 1, 2,

         vtaxperiod_id, vdoccode, perbdate, peredate, null, null, null,

         trunc(current_date), null, null, null, null, null, null, null, CURRENT_TIMESTAMP,

         ipuser_id, rowtaxdoc.taxobject_id, rowtaxdoc.partidano,

         rowtaxdoc.municipality_id, vparreg, null, rowtaxdoc.docno,

         rowtaxdoc.doc_date, null, vadmregion_id);

      insert into debtsubject

        (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,

         taxperiod_id, doccode, tax_begidate, tax_enddate, relief_id, Totalval,

         Totaltax, calcdate, FreeSum_obj, prtdate, inst_number, FreeSum_Subj,

         corr_instnumber, codetbo, corr_sumtotal, userdate, user_id,

         TAXOBJECT_ID, PARTIDANO, MUNICIPALITY_ID, KINDPARREG_ID, PAYDISCSUM,

         DOCNO, DOC_DATE, PARENT_DEBTSUBJECT_ID, admregion_id)

      values

        (vtbodebtsubject_id, rowtaxdoc.taxsubject_id, iptaxdoc_Id, 1, 5,

         vtaxperiod_id, vdoccode, perbdate, peredate, null, null, null,

         trunc(current_date), null, null, null, null, null, null, null, CURRENT_TIMESTAMP,

         ipuser_id, rowtaxdoc.taxobject_id, rowtaxdoc.partidano,

         rowtaxdoc.municipality_id, vparreg, null, rowtaxdoc.docno,

         rowtaxdoc.doc_date, null, vadmregion_id);

   

    

      ------------------

    

    

      loop

        -- firmprop

        fetch crfirmprop

          into rfirmprop;

        exit when not found;

        ---------------------   danni za DNI

        select nvl(m.parentmunicipality_id, m.municipality_id)

        into   vmunicipality_id

        from   municipality m

        where  m.municipality_id = rowtaxdoc.municipality_id;

      

        select min(homeprom), min(nohomeprom)

        into   vhomeprom, vnohomeprom

        from   (select nd.homeprom, nd.nohomeprom

                 from   normdni nd

                 where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id

                 and    nd.city_id = vcity_id

                 and    nd.code = '99'

                 and    nd.calctype = '1'

                 and    nd.taxperiod_id = vtaxperiod_id

                 union

                 select nd.homeprom, nd.nohomeprom

                 from   normdni nd

                 where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id

                 and    nd.city_id = vcity_id

                 and    nd.code = '99'

                 and    nd.calctype = '0'

                 and    nd.taxperiod_id = vtaxperiod_id

                 union

                 select nd.homeprom, nd.nohomeprom

                 from   normdni nd

                 where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id

                 and    nd.city_id = vcity_id

                 and    nd.code = '99'

                 and    nd.calctype = '2'

                 and    nd.taxperiod_id = vtaxperiod_id) sub;

        if vhomeprom is null

        then

          select min(homeprom), min(nohomeprom)

          into   vhomeprom, vnohomeprom

          from   (select nd.homeprom, nd.nohomeprom

                   from   normdni nd, city c

                   where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id

                   and    nd.city_id = 0

                   and    nd.code = '99'

                   and    nd.calctype = '1'

                   and    nd.taxperiod_id = vtaxperiod_id

                   union

                   select nd.homeprom, nd.nohomeprom

                   from   normdni nd

                   where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id

                   and    nd.city_id = 0

                   and    nd.code = '99'

                   and    nd.calctype = '0'

                   and    nd.taxperiod_id = vtaxperiod_id

                   union

                   select nd.homeprom, nd.nohomeprom

                   from   normdni nd

                   where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id

                   and    nd.city_id = 0

                   and    nd.code = '99'

                   and    nd.calctype = '2'

                   and    nd.taxperiod_id = vtaxperiod_id) sub;

        end if;

        vtaxtbo := 0;

        select min(f.no_correct), min(f.taxdoc_id_14)
        into   vnocorect, vtaxdoc_id_14

        from   firm_1417 f

        where  f.taxdoc_id_17 = rowtaxdoc.taxdoc_id

        and    nvl(f.no_active, 0.0) <> 1;

        if vtaxdoc_id_14 is not null then
          select min(p.constructionbound) into vconstr_bound 
          from property p where p.taxdoc_id = vtaxdoc_id_14;
        end if;
        vconstr_bound := nvl(vconstr_bound, '1');
        -------------------------------------

        if to_number(to_char(perbdate, 'yyyy')) > 2010

        then

          open crfirmobj(rfirmprop.firmprop_id);

          --- 18.07

          vsumaccTBO := 0;

          vsumacc := 0;

          loop

            -- firmobj

            fetch crfirmobj

              into rowfirmobj;

            exit when not found;
            vownerp := 1;

            if ((rowfirmobj.taxenddate is null) or

               (rowfirmobj.taxenddate > perbdate)) and

               (nvl(rowfirmobj.taxbegindate::date,

                    to_date('01.' ||

                             to_char(add_months(nvl(rowfirmobj.earn_date::date,

                                                    ipFromDate), 1), 'mm.yyyy'),

                             'dd.mm.yyyy')) < peredate)

            then

              if rowfirmobj.firm1417_obj_id is not null

              then

                select max(fo.kindobj)::integer, max(fo.obj_id)

                into   vho_kindobj, vho_obj_id

                from   firm_1417_obj fo

                where  fo.firm1417_obj_id = rowfirmobj.firm1417_obj_id;

                if nvl(vho_kindobj, '0') = '1'

                then

                  /*select taxvaluation.TaxValLand(errmess, vho_obj_id,

                             to_date('01.01.' || to_char(perbdate, 'yyyy'),

                                      'dd.mm.yyyy'), vDOhomeobj, XX);*/

                  select into taxValLandRec * from taxvaluation.TaxValLand(vho_obj_id,

                             to_date('01.01.' || to_char(perbdate, 'yyyy'),

                                      'dd.mm.yyyy'));

                  errmess := taxValLandRec.return_val;

                  vDOhomeobj := taxValLandRec.vgroupe;

                  XX := taxValLandRec.opmess;

                  if errmess <> 'OK'

                  then

                    vDOhomeobj := 0;

                  end if;
        ----      
                  select into vownerp * from ownerpart(rowtaxdoc.taxsubject_id::integer,'1',vho_obj_id::integer,peredate);
                  vDOhomeobj := vDOhomeobj * vownerp;
                  if vownerp = 0 then rowfirmobj.accvalue := 0; end if; ---- 15.05.2012
                  if vDOhomeobj > rowfirmobj.accvalue

                  then

                    rowfirmobj.accvalue := vDOhomeobj;

                  end if;

                elsif nvl(vho_kindobj, '0') = '2'

                then

                  select max(b.kindfunction)

                  into   vbuildkf

                  from   homeobj h, building b

                  where  h.homeobj_id = vho_obj_id

                  and    h.building_id = b.building_id;

                

                  /*select taxvaluation.TaxValHome(errmess, vho_obj_id,

                             to_date('01.01.' || to_char(perbdate, 'yyyy'),

                                      'dd.mm.yyyy'), vbuildkf, vDOhomeobj, XX);*/

                  select into taxValHomeRec * from taxvaluation.TaxValHome(vho_obj_id,

                             to_date('01.01.' || to_char(perbdate, 'yyyy'),

                                      'dd.mm.yyyy'), vbuildkf);

                  errmess := taxValHomeRec.return_val;

                  vDOhomeobj := taxValHomeRec.vgroupe;

                  XX := taxValHomeRec.opmess;



                  if errmess <> 'OK'

                  then

                    vDOhomeobj := 0;

                  end if;
		  select into vownerp * from ownerpart(rowtaxdoc.taxsubject_id::integer,'2',vho_obj_id::integer,peredate);
    --              vownerp := ownerpart(rowtaxdoc.taxsubject_id,'2',vho_obj_id,peredate);
                  vDOhomeobj := vDOhomeobj * vownerp;
                  if vownerp = 0 then rowfirmobj.accvalue := 0; end if; ---- 15.05.2012

                  if vDOhomeobj > rowfirmobj.accvalue

                  then

                    rowfirmobj.accvalue := vDOhomeobj;

                  end if;

                end if;

              end if;

              vsumacc := vsumacc + rowfirmobj.accvalue;

              --- 18.07

              if nvl(kindcalTBO, '0') = '1'

              then

                vsumaccTBO := vsumaccTBO + rowfirmobj.accvaluetbo;

              else

                vsumaccTBO := vsumaccTBO + rowfirmobj.accvalue;

              end if;

            end if;

          end loop;

          close crfirmobj;

          -------------------------------------

        else

          select sum(nvl(o.accvalue, 0.0))

          into   vsumacc

          from   firmpropobj o

          where  o.firmproperty_id = rfirmprop.firmprop_id

          and    ((o.taxenddate is null) or (o.taxenddate > perbdate))

          and    (case when o.taxbegindate is null then

                         (to_date('01.' ||

                                   to_char(add_months(nvl(o.earn_date::date, ipFromDate),

                                                      1), 'mm.yyyy'), 'dd.mm.yyyy')) else

                         o.taxbegindate end) < peredate

          --   and ((o.taxbegindate is null) and ((o.earn_date is null) or (to_date('01.' || to_char(add_months(nvl(o.earn_date,ipToDate-100),1),'mm.yyyy'),'dd.mm.yyyy') < peredate)))

          --    and ((o.circumchange_date is null) or (to_date('01.' || to_char(add_months(nvl(o.circumchange_date,ipToDate-100),1),'mm.yyyy'),'dd.mm.yyyy') <= perbdate))

          ;

          ---- 18.07

          vsumaccTBO := vsumacc;

        end if;

        if (nvl(vnocorect, 0.0) = 1) and

           (to_number(to_char(perbdate, 'yyyy')) > 2010)

        then

          -- rollback;
	  ipStatus := '��������� ���������� �� ��.14';
          exit;

        end if;

        open crfirmobj(rfirmprop.firmprop_id);

        vaccvalueo := 0;

        loop

          -- firmobj

          fetch crfirmobj

            into rowfirmobj;

          exit when not found;
          vobjbuilddate := null;

          if ((rowfirmobj.taxenddate is null) or

             (rowfirmobj.taxenddate > perbdate)) and

             (nvl(rowfirmobj.taxbegindate::date,

                  to_date('01.' ||

                           to_char(add_months(nvl(rowfirmobj.earn_date::date, ipFromDate),

                                              1), 'mm.yyyy'), 'dd.mm.yyyy')) <

             peredate)

          then

            if to_number(to_char(perbdate, 'yyyy')) > 2010

            then

              if rowfirmobj.firm1417_obj_id is not null

              then

                select max(fo.kindobj)::integer, max(fo.obj_id)

                into   vho_kindobj, vho_obj_id

                from   firm_1417_obj fo

                where  fo.firm1417_obj_id = rowfirmobj.firm1417_obj_id;

                if nvl(vho_kindobj, '0') = '1'

                then

                  /*select taxvaluation.TaxValLand(errmess, vho_obj_id,

                             to_date('01.01.' || to_char(perbdate, 'yyyy'),

                                      'dd.mm.yyyy'), vDOhomeobj, XX);*/

                  select into taxValLandRec * from  taxvaluation.TaxValLand(vho_obj_id,

                             to_date('01.01.' || to_char(perbdate, 'yyyy'),

                                      'dd.mm.yyyy'));

                  errmess := taxValLandRec.return_val;

                  vDOhomeobj := taxValLandRec.vgroupe;

                  XX := taxValLandRec.opmess;

                  if errmess <> 'OK'

                  then

                    vDOhomeobj := 0;

                  end if;
                  select into vownerp * from ownerpart(rowtaxdoc.taxsubject_id::integer,'1',vho_obj_id::integer,peredate);
     --             vownerp := ownerpart(rowtaxdoc.taxsubject_id,'1',vho_obj_id,peredate);
                  vDOhomeobj := vDOhomeobj * vownerp;
                  if vownerp = 0.0 then rowfirmobj.accvalue := 0.0; end if; ---- 15.05.2012

                  if vDOhomeobj > rowfirmobj.accvalue

                  then

                    rowfirmobj.accvalue := vDOhomeobj;

                  end if;

                elsif nvl(vho_kindobj, '0') = '2'

                then
                  select max(b.kindfunction), max(h.builddate)
                  into   vbuildkf, vobjbuilddate

                  from   homeobj h, building b

                  where  h.homeobj_id = vho_obj_id

                  and    h.building_id = b.building_id;

                

                  /*select taxvaluation.TaxValHome(errmess, vho_obj_id,

                             to_date('01.01.' || to_char(perbdate, 'yyyy'),

                                      'dd.mm.yyyy'), vbuildkf, vDOhomeobj, XX);*/

                  select into taxValHomeRec * from  taxvaluation.TaxValHome(vho_obj_id,

                             to_date('01.01.' || to_char(perbdate, 'yyyy'),

                                      'dd.mm.yyyy'), vbuildkf);

                  errmess := taxValHomeRec.return_val;

                  vDOhomeobj := taxValHomeRec.vgroupe;

                  XX := taxValHomeRec.opmess;

                  if errmess <> 'OK'

                  then

                    vDOhomeobj := 0;

                  end if;
                  select into vownerp * from ownerpart(rowtaxdoc.taxsubject_id::integer,cast('2' as varchar),vho_obj_id::integer,peredate);
         --          vownerp := ownerpart(rowtaxdoc.taxsubject_id,'2',vho_obj_id,peredate);
                   vDOhomeobj := vDOhomeobj * vownerp;
                 if vownerp = 0.0 then rowfirmobj.accvalue := 0.0; end if; ---- 15.05.2012
                  if vDOhomeobj > rowfirmobj.accvalue

                  then

                    rowfirmobj.accvalue := vDOhomeobj;

                  end if;

                end if;

              end if;

            end if;

          

            ------- danni za TBO

            select max(gt.garbtax_id), max(td.taxdoc_id),

                   decode(max(gt.sw_missing), 1.0, 0.0, 1.0),

                   decode(max(gt.clean_missing), 1.0, 0.0, 1.0),

                   decode(max(gt.depot_missing), 1.0, 0.0, 1.0)

            into   vgarbtax71, vtaxdoc71_id, vsw_missing, vclean_missing,

                   vdepot_missing

            from   garbtax gt, taxdoc td

            where  td.taxdoc_id = gt.taxdoc_id

            and    td.documenttype_id =

                   (select t.documenttype_id

                     from   documenttype t

                     where  t.doccode = '71')

            and    gt.proptaxdoc_id = iptaxdoc_Id

            and    gt.taxperiod_id = vtaxperiod_id

            and    td.docstatus <> '90' 
            and coalesce(gt.isforobject,0.0) <> 1.0
            ;
            if vtaxdoc71_id is null
            then
              select max(gt.garbtax_id), max(td.taxdoc_id),
                     (case when max(o.sw_missing) = 1 then 0 else 1 end),
                     (case when max(o.clean_missing) = 1 then 0 else 1 end),
                     (case when max(o.depot_missing) = 1 then 0 else 1 end)
              into   vgarbtax71, vtaxdoc71_id, vsw_missing, vclean_missing,
                     vdepot_missing
              from   garbtax gt, taxdoc td, garbobject o
              where  td.taxdoc_id = gt.taxdoc_id
              and    td.documenttype_id =
                     (select t.documenttype_id
                       from   documenttype t
                       where  t.doccode = '71')
              and    gt.proptaxdoc_id = iptaxdoc_Id
              and    gt.taxperiod_id = vtaxperiod_id
              and    td.docstatus <> '70' and td.docstatus <> '90'
              and    o.garbtax_id = gt.garbtax_id and o.homeobj_id = rowfirmobj.firmpropobj_id;
            end if;

            if vtaxdoc71_id is not null

            then

              select td.docstatus

              into   vdocst

              from   taxdoc td

              where  td.taxdoc_id = vtaxdoc71_id;

              if vdocst = '10'

              then

                update taxdoc td

                set    docstatus = '30'

                where  td.taxdoc_id = vtaxdoc71_id;

                perform taxvaluation.arxdoc(vtaxdoc71_id);

              end if;

            end if;

            select max(gt.garbtax_id), max(td.taxdoc_id)

            into   vgarbtax19, vtaxdoc19_id

            from   garbtax gt, taxdoc td

            where  td.taxdoc_id = gt.taxdoc_id

            and    td.documenttype_id =

                   (select t.documenttype_id

                     from   documenttype t

                     where  t.doccode = '19')

            and    gt.proptaxdoc_id = iptaxdoc_Id

            and    gt.taxperiod_id = vtaxperiod_id

            and    td.docstatus <> '90';

            if vtaxdoc19_id is not null

            then

              select td.docstatus

              into   vdocst

              from   taxdoc td

              where  td.taxdoc_id = vtaxdoc19_id;

              if vdocst = '10'

              then

                update taxdoc td

                set    docstatus = '30'

                where  td.taxdoc_id = vtaxdoc19_id;

                perform taxvaluation.arxdoc(vtaxdoc19_id);

              end if;

            end if;

            select max(g.grouptbo_id)

            into   vgrouptbo_id

            from   propgrouptbo g

            where  g.taxdoc_id = rowtaxdoc.taxdoc_id

                  --- ?????? ------

            and    nvl(g.enddate::date, perbdate) >= perbdate

            and    g.begindate =

                   (select max(pg.begindate)

                     from   propgrouptbo pg

                     where  pg.begindate <= perbdate

                     and    pg.taxdoc_id = rowtaxdoc.taxdoc_id)

            

            ;

            vcity0_id := vcity_id;

            select count(*)

            into   i

            from   promtbo t, municipality m

            where  m.municipality_id = vmunicipality_id

            and    t.municipality_id =

                   nvl(m.parentmunicipality_id, m. municipality_id)

            and    m.municipality_id = vmunicipality_id

            and    t.taxperiod_id = vtaxperiod_id

            and    t.city_id = 0;

            if i > 0

            then

              vcity0_id := 0;

            end if;



            select pt.*

            into   rprtbo

            from   promtbo pt

            where  pt.city_id = vcity0_id

            and    pt.taxperiod_id = vtaxperiod_id

            and    pt.calctype = '0'

            and    pt.code = '1'

            union

            select pt.*

            from   promtbo pt

            where  pt.city_id = vcity0_id

            and    pt.taxperiod_id = vtaxperiod_id

            and    pt.calctype in ('6')

            and    pt.code = '1'

            and    (vgarbtax19 is not null or (vsumaccTBO <= 0.01)) --- 18.07

            union

            select pt.*

            from   promtbo pt

            where  pt.city_id = vcity0_id

            and    pt.taxperiod_id = vtaxperiod_id

            and    pt.calctype in ('6')

            and    pt.code = (select max(pp.code)

                              from   promtbo pp

                              where  pp.city_id = vcity0_id

                              and    pp.taxperiod_id = vtaxperiod_id

                              and    pp.calctype in ('6')

                              and    pp.fromvalue < vsumaccTBO) --- 18.07

            and    vgarbtax19 is null

            

            union

            --- ���������/�����������

            select pt.*

            from   promtbo pt

            where  pt.city_id = vcity0_id

            and    pt.taxperiod_id = vtaxperiod_id

            and    pt.calctype in ('1', '2')

            and    pt.code =

                   (case when vgrouptbo_id is null then 

                           (case when rfirmprop.kindproperty =  '1' then '1' else '2' end) else '2' end)

            union

            select pt.*

            from   promtbo pt

            where  pt.city_id = vcity0_id

            and    pt.taxperiod_id = vtaxperiod_id

            and    pt.calctype in ('4', '7')

            and    pt.code =

                   (case when vgrouptbo_id is null then

                           (case when rfirmprop.kindproperty = '1' then '1' else '2' end) else  '2' end)

            and    (vgarbtax19 is not null or (vsumaccTBO <= 0.01)) --- 18.07

            union

            select pt.*

            from   promtbo pt

            where  pt.city_id = vcity0_id

            and    pt.taxperiod_id = vtaxperiod_id

            and    pt.calctype in ('4', '7')

            and    pt.code = (select max(pp.code)

                              from   promtbo pp

                              where  pp.city_id = vcity_id

                              and    pp.taxperiod_id = vtaxperiod_id

                              and    pp.calctype in ('4', '7')

                              and    pp.fromvalue < vsumaccTBO) --- 18.07

            and    vgarbtax19 is null

            union

            --- � ��������� / ����� ���������

            select pt.*

            from   promtbo pt

            where  pt.city_id = vcity0_id

            and    pt.taxperiod_id = vtaxperiod_id

            and    pt.calctype in ('3')

            and    pt.code = '1'

            and    (vgarbtax19 is not null or (vsumaccTBO <= 0.01)) --- 18.07

            union

            select pt.*

            from   promtbo pt

            where  pt.city_id = vcity0_id

            and    pt.taxperiod_id = vtaxperiod_id

            and    pt.calctype in ('5')

            and    pt.code = (case when vgarbtax19 is null then (case when vconstr_bound = '2' then '2' else '1' end) else '1' end)

            union

            select pt.*

            from   promtbo pt

            where  pt.city_id = vcity0_id

            and    pt.taxperiod_id = vtaxperiod_id

            and    pt.calctype in ('3')

            and    pt.code = (select max(pp.code)

                              from   promtbo pp

                              where  pp.city_id = vcity0_id

                              and    pp.taxperiod_id = vtaxperiod_id

                              and    pp.calctype in ('3')

                              and    pp.fromvalue < vsumaccTBO) --- 18.07

             and    vgarbtax19 is null
            union
            ------------------
            select pt.*
            from   promtbo pt
            where  pt.city_id = vcity0_id
            and    pt.taxperiod_id = vtaxperiod_id
            and    pt.calctype in ('8')
            and    pt.code = (case when vgrouptbo_id is null then
            (case when ((rfirmprop.kindproperty = 1) and (vconstr_bound = '2')) then '4'  --  nezastroen
                     when rfirmprop.kindproperty <> 1 and  vconstr_bound = '2' then '3'         -- v izvan regulaciq            
                     when rfirmprop.kindproperty = 1 and vconstr_bound <> '2' then '2' 
                     when rfirmprop.kindproperty <> 1 and vconstr_bound <> '2' then '1' end) 
           else '1' end);

            if rprtbo.calctype = '4' and vgrouptbo_id is null and

               rfirmprop.kindproperty = 1

            then

              rprtbo.sw_home  := 0;

              rprtbo.sw       := 0;

              rprtbo.fsw_home := 0;

              rprtbo.fsw      := 0;

            end if;

            if rprtbo.calctype = '7' and vgrouptbo_id is null and

               rfirmprop.kindproperty = 1

            then

              select decode(pt.fsw, 0, 0, rprtbo.fsw),

                     decode(pt.fclean, 0, 0, rprtbo.fclean),

                     decode(pt.fdepot, 0, 0, rprtbo.fdepot)

              into   rprtbo.fsw, rprtbo.fclean, rprtbo.fdepot

              from   promtbo pt

              where  pt.city_id = vcity0_id

              and    pt.taxperiod_id = vtaxperiod_id

              and    pt.calctype in ('7')

              and    pt.code = 1;

            end if;

            

            if (nvl(rprtbo.minvalue, 0.0) > 0.0) and

               (((rprtbo.minvalue / vsumaccTBO) * 1000) - rprtbo.fsw - --- 18.07

               rprtbo.fclean - rprtbo.fdepot > 0)

            then

              rprtbo.fsw := ((rprtbo.minvalue / vsumaccTBO) * 1000) - --- 18.07

                            rprtbo.fclean - rprtbo.fdepot;

            end if;

            if vgrouptbo_id is not null

            then

              select *

              into   rgrouptbo

              from   grouptbo gt

              where  gt.grouptbo_id = vgrouptbo_id;

              if nvl(rgrouptbo.tbo_code, '0') <> '9'

              then

                rprtbo.fsw      := rprtbo.fsw * nvl(rgrouptbo.issw, 0.0);

                rprtbo.fclean   := rprtbo.fclean * nvl(rgrouptbo.isclean, 0.0);

                rprtbo.fdepot   := rprtbo.fdepot * nvl(rgrouptbo.isdepot, 0.0);

                rprtbo.tbo_code := rgrouptbo.tbo_code;

              else

                rprtbo.fsw      := nvl(rgrouptbo.issw, 0.0);

                rprtbo.fclean   := nvl(rgrouptbo.isclean, 0.0);

                rprtbo.fdepot   := nvl(rgrouptbo.isdepot, 0.0);

                rprtbo.tbo_code := rgrouptbo.tbo_code;

              end if;

            end if;

            ----------------------

            if vgarbtax71 is not null

            then

              rprtbo.fsw    := rprtbo.fsw * nvl(vsw_missing, 0.0);

              rprtbo.fclean := rprtbo.fclean * nvl(vclean_missing, 0.0);

              rprtbo.fdepot := rprtbo.fdepot * nvl(vdepot_missing, 0.0);

              --    rprtbo.fsw_home := 0;

              --    rprtbo.fsw := 0;

            end if;

            --   vtaxtbo := 0;

            if vgarbtax19 is not null

            then

              select sum(gt.container_number * nvl(gt.frequency, 1.0) *

                          (select nvl(min(cn.value), 0.0) *

                                   (case when min(cn.kindvalue) =  '2' then 12 else 1 end)

                           from   containernorm cn

                           where  cn.containernorm_id = gt.containernorm_id

                           

                           ))

              into   vdecltbo

              from   garbtax gt

              where  gt.taxdoc_id = vtaxdoc19_id;

              if ((vgrouptbo_id is null) or

                 (nvl(rgrouptbo.tbo_code, '0') <> '9'))

              then

                rprtbo.fsw    := 0;

                rprtbo.fdepot := 0;

              end if;

            end if;

            ---------------------  end danni za TBO

            -- opDNI := round(vnohomeprom * rowfirmobj.accvalue/1000,2);

            if rprtbo.calctype in ('2', '4')

            then

              if rowfirmobj.kindowner = 2 and rfirmprop.kindproperty = 1 and

                 nvl(rowfirmobj.ispublic, 0.0) <> 1

              then

                select pt.*

                into   rprtbo

                from   promtbo pt

                where  pt.city_id = vcity0_id

                and    pt.taxperiod_id = vtaxperiod_id

                and    pt.calctype in ('2', '4')

                and    pt.code = 3;

              end if;

              if rowfirmobj.kindowner = 2 and nvl(rowfirmobj.ispublic, 0.0) = 1

              then

                select pt.*

                into   rprtbo

                from   promtbo pt

                where  pt.city_id = vcity0_id

                and    pt.taxperiod_id = vtaxperiod_id

                and    pt.calctype in ('2', '4')

                and    pt.code = 4;

              end if;

            end if;

            i      := 1;

            flfree := 0;

            while i < 15

            loop

              if substr(rowfirmobj.taxfreereason, i, 1) = '1'

              then

                if (i in (9,10, 11, 13, 14)) and

                   (nvl(rowfirmobj.isbusiness, 0.0) <> 1.0)

                then

                  flfree := 1;

                elsif (i in (3, 4, 5, 7, 12))

                then

                  flfree := 1;

                elsif (i in (1, 2)) and

                      (nvl(rowfirmobj.isbusiness, 0.0) <> 1.0) and

                      (nvl(rowfirmobj.KindOwner, 0.0) <> 1.0)

                then

                  flfree := 1;

                elsif (i in (8)) and

                      (perbdate < to_date('01.01.2010', 'dd.mm.yyyy'))

                then

                  flfree := 1;

                end if;

              end if;

              i := i + 1;

            end loop;

            if substr(rowfirmobj.taxfreereason, 15, 1) = '1' and flfree <> 1

            then

              if (rowfirmobj.Zeecategory = 'A') or --- ??? Vazobnovqemi izto4nici ????

                 (rowfirmobj.Zeecategory = '�')

              then

                if (nvl(trunc(vobjbuilddate), '1900') < '2005') and

                   (rowfirmobj.iszee = 1) and

                   perbdate between

                   to_date('01.01.' ||

                           to_char(to_number(to_char(rowfirmobj.Zeesertdate - 1,

                                                     'yyyy')) + 1), 'dd.mm.yyyy') and

                   to_date('01.01.' ||

                           to_char(to_number(to_char(rowfirmobj.Zeesertdate - 1,

                                                     'yyyy')) + 10), 'dd.mm.yyyy')

                then

                  flfree := 1;

                end if;
                if (nvl(trunc(vobjbuilddate), '1900') < '2005') and
                   (nvl(rowfirmobj.iszee,0) <> 1) and
                   perbdate between
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rowfirmobj.Zeesertdate - 1,
                                                     'yyyy')) + 1), 'dd.mm.yyyy') and
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rowfirmobj.Zeesertdate - 1,
                                                     'yyyy')) + 7), 'dd.mm.yyyy')
                then
                  flfree := 1;
                end if;

              end if;

              if (rowfirmobj.Zeecategory = 'B') or

                 (rowfirmobj.Zeecategory = '�')

              then

                if (nvl(trunc(vobjbuilddate), '1900') < '2005') and

                   (rowfirmobj.iszee = 1) and

                   perbdate between

                   to_date('01.01.' ||

                           to_char(to_number(to_char(rowfirmobj.Zeesertdate - 1,

                                                     'yyyy')) + 1), 'dd.mm.yyyy') and

                   to_date('01.01.' ||

                           to_char(to_number(to_char(rowfirmobj.Zeesertdate - 1,

                                                     'yyyy')) + 5), 'dd.mm.yyyy')

                then

                  flfree := 1;

                end if;

                if (nvl(trunc(vobjbuilddate), '1900') < '2005') and
                   (nvl(rowfirmobj.iszee,0) <> 1) and
                   perbdate between
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rowfirmobj.Zeesertdate - 1,
                                                     'yyyy')) + 1), 'dd.mm.yyyy') and
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rowfirmobj.Zeesertdate - 1,
                                                     'yyyy')) + 3), 'dd.mm.yyyy')
                then
                  flfree := 1;
                end if;
              end if;

            end if;

            vodateb := nvl(rowfirmobj.taxbegindate::date,

                           to_date('01.' ||

                                    to_char(add_months(rowfirmobj.earn_date::date, 1),

                                            'mm.yyyy'), 'dd.mm.yyyy'));

            if vodateb < perbdate

            then

              vodateb := perbdate;

            end if;

            if (rowfirmobj.taxenddate is null) or

               (rowfirmobj.taxenddate > peredate)

            then

              vodatee := peredate;

            else

              vodatee := last_day(rowfirmobj.taxenddate::date) + interval '1 day';

            end if;

            if vodatee >= vodateb

            then

              brmes := round(months_between(vodatee, vodateb));

              

              brmesfree := 0;

              if flfree = 1

              then

                --opfreedni := opDNI; opDNI := 0;

                brmesfree := brmes;

              end if;

              vtaxvalobj     := round(rowfirmobj.accvalue * vnohomeprom / 1000,

                                      2);

              vearntaxvalobj := round(vtaxvalobj * brmes / 12, 2);

              vfreesumobj    := round(vtaxvalobj * brmesfree / 12, 2);

              vearntaxvalobj := vearntaxvalobj - vfreesumobj;

              if vearntaxvalobj = 0

              then

                vtaxvalobj := 0;

              end if;

              --- 18.07

              if nvl(kindcalTBO, '0') = '1'

              then

                vearntboobj := round((rprtbo.fsw + rprtbo.fclean +

                                     rprtbo.fdepot) * rowfirmobj.accvalueTBO *

                                     brmes / 12000, 2);

                vtbofreeobj := 0;

                vtaxtboobj  := round((rprtbo.fsw + rprtbo.fclean +

                                     rprtbo.fdepot) * rowfirmobj.accvalueTBO / 1000,

                                     2);
                vearnvalTBOobj := round(rowfirmobj.accvalueTBO * brmes / 12, 2); ---18.07

              else

                vearntboobj := round((rprtbo.fsw + rprtbo.fclean +

                                     rprtbo.fdepot) * rowfirmobj.accvalue *

                                     brmes / 12000, 2);

                vtbofreeobj := 0;

                vtaxtboobj  := round((rprtbo.fsw + rprtbo.fclean +

                                     rprtbo.fdepot) * rowfirmobj.accvalue / 1000,

                                     2);

                vearnvalTBOobj := round(rowfirmobj.accvalue * brmes / 12, 2); ---18.07
              end if;

              --  vtbofreeobj := round((rprtbo.fsw + rprtbo.fclean + rprtbo.fdepot) * rowfirmobj.accvalue * brmesfree /12000,1);

              --  vtaxtboobj := vtaxtboobj - vtbofreeobj;

              vearnvalobj := round(rowfirmobj.accvalue * brmes / 12, 2); ------------------------------

          

              vtaxval     := nvl(vtaxval, 0.0) + vtaxvalobj;

              vearntaxval := nvl(vearntaxval, 0.0) + vearntaxvalobj;

              vtaxtbo     := nvl(vtaxtbo, 0.0) + vearntboobj;

              vtaxtbofree := nvl(vtaxtbofree, 0.0) + vtbofreeobj;

              vtaxvalfree := nvl(vtaxvalfree, 0.0) + vfreesumobj;

              vearnval    := nvl(vearnval, 0.0) + vearnvalobj;

              vaccvalueo  := vaccvalueo + rowfirmobj.accvalue;

            

              if ((flfirsy is null) or (ipoblwr = 2))

              then

                /*select taxvaluation.updprop(1, rowfirmobj.firmpropobj_id, vtaxvalobj,

                        vearntaxvalobj, vearntboobj);*/

                perform taxvaluation.updprop(1, rowfirmobj.firmpropobj_id, vtaxvalobj,

                        vearntaxvalobj, vearntboobj);

              end if;

              -- debtpartproperty

              if nvl(ipflrec, 0) <> 1

              then

                select nextval('s_debtpartproperty')

                into   vdpproperty_id;

                insert into debtpartproperty

                  (debtpartproperty_id, debtsubject_id, taxperiod_id,

                   kindproperty, seqnots, typedeclar, isbasehome, isrelief,

                   relief_id, divident, divisor, part, sumval, sumtax,

                   taxbegindate, taxenddate, totalval, totaltax, userdate,

                   user_id, homeobj_id, freefrom, freemonths, codetbo, promiltbo,

                   freesuma_obj, freesuma_subj, parentdebtprop_id, SUBJPARTVAL)

                values

                  (vdpproperty_id, vdebtsubject_id, vtaxperiod_id, 1,

                   rowfirmobj.seqno, null, null, null, null, 0, 0, vownerp,
 
                   round(rowfirmobj.accvalue, 2), round(vtaxvalobj, 2), vodateb,

                   vodatee, vearnvalobj, round(vearntaxvalobj, 2), CURRENT_TIMESTAMP,

                   ipuser_id, rowfirmobj.firmpropobj_id, vodateb, brmesfree,

                   null, null, vfreesumobj, null, null, round(vearntaxvalobj, 2));

                ----  TBO

                --- 18.07

                if nvl(kindcalTBO, '0') = '1'

                then

                  vaccvalueTBO := round(rowfirmobj.accvalueTBO, 2);

                else

                  vaccvalueTBO := round(rowfirmobj.accvalue, 2);

                end if;

                select nextval('s_debtpartproperty')

                into   vdptbo_id;

                insert into debtpartproperty

                  (debtpartproperty_id, debtsubject_id, taxperiod_id,

                   kindproperty, seqnots, typedeclar, isbasehome, isrelief,

                   relief_id, divident, divisor, part, sumval, sumtax,

                   taxbegindate, taxenddate, totalval, totaltax, userdate,

                   user_id, homeobj_id, freefrom, freemonths, codetbo, promiltbo,

                   freesuma_obj, freesuma_subj, parentdebtprop_id, SUBJPARTVAL,

                   FSW, FCLEAN, FDEPOT)

                values

                  (vdptbo_id, vtbodebtsubject_id, vtaxperiod_id, 1,

                   rowfirmobj.seqno, null, null, null, null, 0, 0, vownerp,

                   vaccvalueTBO, round(vtaxtboobj, 2), vodateb,

                    ---- 18.07

                   vodatee, vearnvalTBOobj, round(vearntboobj, 2), CURRENT_TIMESTAMP,

                   ipuser_id, rowfirmobj.firmpropobj_id, vodateb, brmesfree,

                   rprtbo.tbo_code,

                   (nvl(rprtbo.fsw, 0.0) + nvl(rprtbo.fclean, 0.0) +

                    nvl(rprtbo.fdepot, 0.0)), vtbofreeobj, null, null,

                   round(vearntboobj, 2),

                   (rprtbo.fsw * rowfirmobj.accvalue / 1000),

                   (rprtbo.fclean * rowfirmobj.accvalue / 1000),

                   (rprtbo.fdepot * rowfirmobj.accvalue / 1000));

              end if;

              --    vsumdni := nvl(vsumdni,0) + vearntaxval;

              --    vsumtbo := nvl(vsumtbo,0) + vtaxtbo;

            end if;

          end if;

        end loop; --- firmobj

        close crfirmobj;

        if (vgarbtax19 is not null) and (nvl(ipflrec, 0) <> 1)

        then
       if to_char(rowtaxdoc.begintaxdate,'yyyy') =  to_char(perbdate ,'yyyy') then
         vper := round(months_between(to_date('31.12.' || to_char(perbdate,'yyyy'),'dd.mm.yyyy'), rowtaxdoc.begintaxdate) +0.4);
       else
         vper := 12;
       end if;

          select nextval('s_debtpartproperty')

          into   vdptbo_id;

          insert into debtpartproperty

            (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,

             seqnots, typedeclar, isbasehome, isrelief, relief_id, divident,

             divisor, part, sumval, sumtax, taxbegindate, taxenddate, totalval,

             totaltax, userdate, user_id, homeobj_id, freefrom, freemonths,

             codetbo, promiltbo, freesuma_obj, freesuma_subj, parentdebtprop_id,

             SUBJPARTVAL, FSW, FCLEAN, FDEPOT)

          values

            (vdptbo_id, vtbodebtsubject_id, vtaxperiod_id, 1, 0, null, null,

             null, null, 0, 0, vownerp, 0, round(vdecltbo, 2), perbdate, peredate, 0,

             round(vdecltbo * round(months_between(peredate, vodateb)) / vper, 2),

             CURRENT_TIMESTAMP, ipuser_id, 0, vodateb, brmesfree, rprtbo.tbo_code, 0,

             vtbofreeobj, null, null, round(vdecltbo, 2), 0, 0, 0);

          vdecltbo := vdecltbo * round(months_between(peredate, vodateb)) / vper;

          vtaxtbo  := vtaxtbo + round(vdecltbo, 2);

        end if;

        if flfirsy is null

        then

          perform taxvaluation.updprop(0, rfirmprop.firmprop_id, vtaxval, vtaxtbo, 0);

        end if;

        select nvl(min(n.minvalue), 0.0)

        into   vmindo

        from   legalnorm n

        where  n.name = 'mindo'

        and    n.begindate = (select max(nn.begindate)

                              from   legalnorm nn

                              where  to_char(nn.begindate, 'yyyy')::numeric <= vTaxYear

                              and    nn.name = 'mindo');

        --  vinst_number := trunc(round(months_between(peredate, perbdate))/3);

        ---------------

  /*      select count(*)

        into   vnorminst

        from   taxperiodpay p

        where  p.documenttype_id = 22

        and    p.taxperiod_id = vtaxperiod_id;

        if vnorminst = 0

        then

          vdiv := 1;

        else

          vdiv := round(12 / vnorminst);

        end if;

        --------------- 

        vminp        := round(months_between(peredate, perbdate) + 0.5);

        vinst_number := round((vminp / vdiv) + 0.4); --/ 3)+ 0.3);
*/
        optotalval   := vearnval;

        if vaccvalueo < vmindo

        then

          vfreesumobj := vfreesumobj + vearntaxval;

          optotaltax  := 0;

          vearntaxval := 0;

        

          update debtpartproperty pp

          set    freesuma_obj = pp.freesuma_obj + pp.totaltax,

                 totaltax = 0

          where  pp.debtsubject_id in

                 (select ds.debtsubject_id

                  from   debtsubject ds

                  where  ds.debtsubject_id = vdebtsubject_id);

        

        else

          optotaltax := vearntaxval;

        end if;

        optbototaltax := vtaxtbo;

        if nvl(ipflrec, 0) = 1

        then

          ipStatus := 'OK';

          --   ----rollback;

          return;

        end if;

        if ((rfirmprop.taxprop_decl = vtaxval) or (flfirsy is not null) or

           (ipoblwr = 1)) and (ipoblwr <> 2)

        then

          --   if true then

          -- debtsubject
       select count(*)
        into   vnorminst
        from   taxperiodpay p
        where  p.documenttype_id = 22
        and ((p.kinddebtreg_id = 2) or (p.kinddebtreg_id is null))
        and    p.taxperiod_id = vtaxperiod_id;
        if vnorminst = 0
        then
          vdiv := 1;
        else
          vdiv := round(12 / vnorminst);
        end if;
        ---------------
        vminp        := round(months_between(peredate, perbdate) + 0.5);
        vinst_number := round((vminp / vdiv) + 0.4); --/ 3)+ 0.3);

          update debtsubject ds

          set    Totalval = vearnval, totaltax = vearntaxval,

                 FreeSum_obj = vfreesumobj, inst_number = vinst_number

          where  ds.debtsubject_id = vdebtsubject_id;

          -- debtinstalment

          select min(ds.debtsubject_id)

          into   oldds_id

          from   debtsubject ds, kinddebtreg dr

          where  ds.debtsubject_id <> vdebtsubject_id

          and    ds.kinddebtreg_id = dr.kinddebtreg_id

          and    dr.code = '2100'

          and    ds.taxperiod_id = vtaxperiod_id

          and    ds.document_id = iptaxdoc_Id;

        

          select min(ds.debtsubject_id)

          into   oldtbods_id

          from   debtsubject ds, kinddebtreg dr

          where  ds.debtsubject_id <> vtbodebtsubject_id

          and    ds.kinddebtreg_id = dr.kinddebtreg_id

          and    dr.code = '2400'

          and    ds.taxperiod_id = vtaxperiod_id

          and    ds.document_id = iptaxdoc_Id;

          if vinst_number = 0

          then

            vinst_number := 1;

          end if;

          i         := vinst_number;

          invsum    := 0;

          invsumtbo := 0;

          while i > 0

          loop

            nv := vnorminst - vinst_number + i;
            if i = vinst_number then
              sumzad := vearntaxval - ((vinst_number - 1) * round(vearntaxval / vinst_number, 2));
              invsum := invsum + sumzad;
            else
              sumzad := round(vearntaxval / vinst_number, 2);
              invsum := invsum + sumzad;
            end if;
            i  := i - 1;

        /*    if i = 0

            then

              sumzad := vearntaxval - invsum;

            else

              sumzad := round(vearntaxval / vinst_number, 2);

              invsum := invsum + sumzad;

            end if;  */

          

 /*           if nvl(ipflrec, 0) <> 1 and oldds_id is null

            then

              insert into debtinstalment

                (debtinstalment_id, debtsubject_id, instno, termpay_date,

                 instsum, intbegindate)

                select nextval('s_debtinstalment'), vdebtsubject_id,

                       tp.instalmentnumber, getWorkingDay(tp.termpaydate::date, 1.0),

                       sumzad, getWorkingDay(tp.termpaydate::date, 1.0) + 1 */
                select tp.termpaydate into vtermpaydate       

                from   taxperiodpay tp, documenttype dt

                where  tp.taxperiod_id = vtaxperiod_id

                and    tp.instalmentnumber = nv

                and    tp.documenttype_id = dt.documenttype_id

                and ((tp.kinddebtreg_id = 2) or (tp.kinddebtreg_id is null))
                and    dt.doccode = '17'

                --    and dt.municipality_id = rowtaxdoc.municipality_id

                ;
                if vtermpaydate < perbdate then
			vtermpaydate := perbdate;
		end if;
		if nvl(ipflrec, 0) <> 1 and oldds_id is null then
		insert into debtinstalment
                (debtinstalment_id, debtsubject_id, instno, termpay_date,
                 instsum, intbegindate)
                select nextval('s_debtinstalment'), vdebtsubject_id,
                       nv, getWorkingDay(vtermpaydate::date, 1.0),
                       sumzad, getWorkingDay(vtermpaydate::date, 1.0) + 1;
                

              -- baldebtinstall

              insert into baldebtinst

                (debtinstalment_id, instsum, interestsum, discsum)

              values

                (currval('s_debtinstalment'), sumzad, 0, 0);

            end if;

          end loop;
-------------  vnoski TBO --------------------
        select count(*)
        into   vnorminst
        from   taxperiodpay p
        where  p.documenttype_id = 22
        and ((p.kinddebtreg_id = 5) or (p.kinddebtreg_id is null))
        and    p.taxperiod_id = vtaxperiod_id;

          update debtsubject ds
          set    Totalval = vearnvalTBO, totaltax = vtaxtbo,   ---- 18.07
                 FreeSum_obj = vtaxtbofree, inst_number = vinst_number
          where  ds.debtsubject_id = vtbodebtsubject_id;

        if vnorminst = 0
        then
          vdiv := 1;
        else
          vdiv := round(12 / vnorminst);
        end if;
        ---------------
        vminp        := round(months_between(peredate, perbdate) + 0.5);
        vinst_number := round((vminp / vdiv) + 0.4); --/ 3)+ 0.3);
          if vinst_number = 0
          then
            vinst_number := 1;
          end if;
          i         := vinst_number;
 --         invsum    := 0;
          invsumtbo := 0;

      while i > 0
          loop
            nv := vnorminst - vinst_number + i;           

         /*   if i = 0

            then

              sumtbo := vtaxtbo - invsumtbo;

            else

              sumtbo    := round(vtaxtbo / vinst_number, 2);

              invsumtbo := invsumtbo + sumtbo;

            end if;    */

             if i = vinst_number then
              sumtbo    := vtaxtbo - ((vinst_number - 1) * round(vtaxtbo / vinst_number, 2));
              invsumtbo := invsumtbo + sumtbo;
            else
              sumtbo    := round(vtaxtbo / vinst_number, 2);
              invsumtbo := invsumtbo + sumtbo;
            end if;
            i  := i - 1;

            select tp.termpaydate into vtermpaydate
            from   taxperiodpay tp, documenttype dt
            where  tp.taxperiod_id = vtaxperiod_id
            and    tp.instalmentnumber = nv
            and    tp.documenttype_id = dt.documenttype_id
            and ((tp.kinddebtreg_id = 5) or (tp.kinddebtreg_id is null))
            and    dt.doccode = '17'
            --    and dt.municipality_id = rowtaxdoc.municipality_id
            ;
         

            if nvl(ipflrec, 0) <> 1 and oldtbods_id is null

            then

              insert into debtinstalment

                (debtinstalment_id, debtsubject_id, instno, termpay_date,

                 instsum, intbegindate)

                select nextval('s_debtinstalment'), vtbodebtsubject_id,
                      nv, getWorkingDay(vtermpaydate::date, 1.0),
                       sumtbo, getWorkingDay(vtermpaydate::date, 1.0) + 1;

/*                       tp.instalmentnumber, getWorkingDay(tp.termpaydate::date, 1.0),

                       sumtbo, getWorkingDay(tp.termpaydate::date, 1.0) + 1

                from   taxperiodpay tp, documenttype dt

                where  tp.taxperiod_id = vtaxperiod_id

                and    tp.instalmentnumber = nv

                and    tp.documenttype_id = dt.documenttype_id

                and    dt.doccode = '17'

                --   and dt.municipality_id = rowtaxdoc.municipality_id

                ; */

              -- baldebtinstall

              insert into baldebtinst

                (debtinstalment_id, instsum, interestsum, discsum)

              values

                (currval('s_debtinstalment'), sumtbo, 0, 0);

            end if;

          end loop;

          ipStatus := 'OK';

          ----commit;

        else

          delete from debtpartproperty pp

          where  pp.debtsubject_id in (vdebtsubject_id, vtbodebtsubject_id);

          delete from debtsubject ds

          where  ds.debtsubject_id in (vdebtsubject_id, vtbodebtsubject_id);

          ipStatus := 'errDiferData'; -- '������� � ����������� � ���������';

          ----commit;

          return;

        end if;

      end loop; --firmprop

      close crfirmprop;

      vTaxYear := vTaxYear + 1;

    end loop;

  

  exception

    when others then

      ipStatus := sqlerrm;

    

end;
$function$
;
