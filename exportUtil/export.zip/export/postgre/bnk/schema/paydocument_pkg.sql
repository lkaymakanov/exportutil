DROP FUNCTION paydocument_pkg.talonstandart(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.talonstandart(OUT return_val character varying, itaxdoc_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                          
    vPDPrt varchar[];
    ErrMsg        varchar(100);
    i             numeric;
    vMunicipality varchar(100);
    vMunAddress   varchar(100);
    vDocname      varchar(100);
    vSubjectName  varchar(100);
    vDocnoDate    varchar(100);
    v_region varchar(10) := ', �-� '; 
  begin
    if (iTaxDoc_id > 0)
    then
      select nvl(m1.fullname,m.fullname) ||
             case when m1.municipality_id is not null then v_region || m.fullname else '' end, getaddress(ts.present_clientaddr_id)
      into   vMunicipality, vMunAddress
      from   users u
      inner join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id      
      inner join config c on m.municipality_id = c.municipality_id
      inner join taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id 
      left outer join province p on m.province_id = p.province_id
      where u.user_id = iUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';
      select dt.docname, td.docno || '/' || to_char(td.doc_date, 'dd.mm.yyyy'),
             ts.name || ' � ' ||
              (select d.value
               from   decode d
               where  upper(d.columnname) = 'KIND_IDN'
               and    d.code = ts.kind_idn) || ' ' || ts.idn
      into   vDocname, vDocnoDate, vSubjectName
      from   taxdoc td, documenttype dt, taxsubject ts
      where  td.taxdoc_id = iTaxDoc_id
      and    td.documenttype_id = dt.documenttype_id
      and    td.taxsubject_id = ts.taxsubject_id;
    
      i := 1; -- �����
      vPDPrt[i] := rpadc(' ------------------------------------------------', 60,
                         '-');
      i := i + 1;
      vPDPrt[i] := rpadc('|       ' || '� � � � � �  ' || vMunicipality, 60, ' ') || '|';
      i := i + 1;
      vPDPrt[i] := rpadc('|       ' || '������ ������ � �����', 60, ' ') || '|';
      i := i + 1;
      vPDPrt[i] := rpadc('|       ' || vMunAddress, 60, ' ') || '|';
      i := i + 1;
      vPDPrt[i] := rpadc(' ------------------------------------------------', 60,
                         '-');
      i := i + 1;
      vPDPrt[i] := rpadc('| �������� "���"', 60) || '|';
      i := i + 1;
      vPDPrt[i] := rpadc('| ���������� �� ��� ���������� �� ' || vDocname, 60) || '|';
      i := i + 1;
      vPDPrt[i] := rpadc('| �� ' || vSubjectName || ' � ', 60) || '|';
      i := i + 1;
      vPDPrt[i] := rpadc('| �������� ��� �� � ' || vDocnoDate, 60) || '|';
      i := i + 1;
      vPDPrt[i] := rpadc(' ------------------------------------------------', 60,
                         '-');
      i := i + 1;
      vPDPrt[i] := '';
    end if;
    
    vPD_lob := paydocument_pkg.tblToLob(vPDPrt );
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        return_val := sqlerrm;
        
        ErrMsg :=  NOM_PKG.ErrManage(sqlstate,sqlerrm);
        return_val := ErrMsg;
        return;
      
      end;
end;

$function$
; DROP FUNCTION paydocument_pkg.talonwide(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.talonwide(OUT return_val character varying, itaxdoc_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                      
    vPDPrt varchar[];
    ErrMsg varchar(100);
    garb cursor (vTaxDoc_id numeric) is
     select gt.container_number, c.name cname,
             to_char(tp.begin_date, 'dd.mm.yyyy') || 
             case when tp.begin_date is null then ''
                  when tp.end_date is null then ''
             else ' - ' end || to_char(tp.end_date, 'dd.mm.yyyy') period,
             gt.frequency,
             case when gt.sw_missing = 1 then '������������� � ��������������' else null end sw_missing,
             case when gt.clean_missing = 1 then '�������' else null end clean_missing,
             case when gt.depot_missing = 1 then '����' else null end depot_missing 
      from   TaxDoc td
      left   outer join Garbtax gt on td.taxdoc_id = gt.taxdoc_id
      left   outer join Containernorm cn on gt.containernorm_id = cn.containernorm_id
      left   outer join Container c on cn.container_id = c.container_id
      left   outer join Taxperiod tp on gt.taxperiod_id = tp.taxperiod_id
      where  td.taxdoc_id = vTaxDoc_id
      order by gt.garbtax_id desc;
    i               numeric;
    vMunicipality   varchar(100);
    vProvince       varchar(100);
    vMun_id         varchar(100);
    vMunAddress     varchar(300);
    vDocname        varchar(200);
    vSubjectName    varchar(300);
    vSubPaddress    varchar(300);
    vSubPostAddress varchar(300);
    vDocnoDate      varchar(100);
    vReason         varchar(200);
    vRest           varchar(200);
    vKindProperty   varchar(300);
    vPropertyAddr   varchar(300);
    vRecUserName    varchar(520);
    vDocCode        varchar(20);
    vidtObj         varchar(10);
    vRegNo          varchar(70);
    vPartidaNo      varchar(40);
    vBreed          varchar(100);
    vRegName        varchar(120);
    vReasonRegId    numeric;
    vDocumentTypeId numeric;
    j               numeric;
    v_region varchar(10) := ', �-� '; 
    r record;
  begin
    if (iTaxDoc_id > 0)
    then
      -- /Municipality/ 
       select nvl(m1.fullname,m.fullname) || 
             case when m1.municipality_id is not null then v_region || m.fullname else '' end, 
             getaddress(ts.present_clientaddr_id), m.municipality_id, p.name
      into   vMunicipality, vMunAddress, vMun_id, vProvince
      from   users u
      inner join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id      
      inner join config c on m.municipality_id = c.municipality_id
      inner join taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id
      left outer join province p on m.province_id = p.province_id
      where u.user_id = iUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';
      -- /TaxSubject/    
      select distinct dt.docname, td.documenttype_id, td.give_reasonreg_id,
                      td.docno || '/' || to_char(td.doc_date, 'dd.mm.yyyy') DocnoDate,
                      (ts.name || ' � ' ||
                       (select d.value
                         from   decode d
                         where  upper(d.columnname) = 'KIND_IDN'
                         and    d.code = ts.kind_idn) || ' ' || ts.idn) subjectName,
                      getaddress(ts.permanent_clientaddr_id) SubPaddress,
                      getaddress(ts.post_clientaddr_id) SubPostAddress,
                      (select d.value
                        from   decode d
                        where  upper(d.columnname) = 'KINDPROPERTY'
                        and    d.code = tob.kindproperty) KindProperty,
                      getaddress(tob.address_id) PropertyAddr,
                      (select u.fullname
                        from   users u
                        where  u.user_id = td.user_id) RecUserName,
                      rr.reason_text, tob.kindtaxobject idTObj,
                      dt.doccode doccode,
                      (' ���.�  ' || tob.registerno) registerno,
                      ('������� � ' || td2.partidano) partidano,
                      ('���.���: ' || tob.registername) regname,
                      ('������: ' || dog.breed) breed
      into   vDocname, vDocumentTypeId, vReasonRegId, vDocnoDate, vSubjectName, vSubPaddress, vSubPostAddress,
             vKindProperty, vPropertyAddr, vRecUserName, vReason, vidTObj,
             vDocCode, vRegNo, vPartidaNo, vRegName, vBreed
      from   taxdoc td
      inner  join documenttype dt
      on     td.documenttype_id = dt.documenttype_id
      inner  join taxsubject ts
      on     td.taxsubject_id = ts.taxsubject_id
      left   outer join taxobject tob
      on     td.taxobject_id = tob.taxobject_id
      left   outer join reasonreg rr
      on     td.documenttype_id = rr.documenttype_id
      and    td.give_reasonreg_id = rr.reasonreg_id
      and    td.municipality_id = rr.municipality_id
      left   outer join garbtax gt
      on     td.taxdoc_id = gt.taxdoc_id
      left   outer join taxdoc td2
      on     gt.proptaxdoc_id = td2.taxdoc_id
      left   outer join Dog
      on     td.taxobject_id = dog.taxobject_id
      where  td.taxdoc_id = iTaxDoc_id;
    
    
      i := 1; -- �����
      vPDPrt[i] := rpadc(' ------------------------------------------------', 60,
                         '-');
      i := i + 1;
      vPDPrt[i] := center('� � � � � �  ' || vProvince, 60);
      i := i + 1;
      vPDPrt[i] := center('� � � � � �  ' || vMunicipality, 60);
      i := i + 1;
      /* vPDPrt[i] := center('�������� ������ ������ � �����', 60);
      i := i + 1;
      vPDPrt[i] := center(vMunAddress, 60);
      i := i + 1; changed on 19.07.2011 */
      vPDPrt[i] := rpadc(' ------------------------------------------------', 60,
                         '-');
      i := i + 1;
      vPDPrt[i] := ' ';
      i := i + 1;
     if vDocumentTypeId = 40 then
        if vReasonRegId in (58,59) then
          vPDPrt[i] := rpadc(' �������� ����� �� ������. �����  ', 60, ' ');
          i := i + 1;
          vPDPrt[i] := rpadc('   �������� ��� �� � ' || vDocnoDate, 60);
          i := i + 1;
        end if;
        if vReasonRegId = 60 then
          vPDPrt[i] := rpadc(' �������� ���������� �� ������. ����� 61� ', 60, ' ');
          i := i + 1;
          vPDPrt[i] := rpadc('   �������� ��� �� � ' || vDocnoDate, 60);
          i := i + 1;
        end if;          
      else               
        r  := wordwrap( ' �������� �� ���  ' || vDocname, 60, 1);
        vPDPrt[i] := r.return_val;
	vRest := r.strrest;
        vPDPrt[i] := rpadc(' ' || vPDPrt[i], 60, ' ');
        i := i + 1;
        if (Length(vRest) > 1) then
          vPDPrt[i] := rpadc(vRest, 60, ' ');
          i := i + 1;
        end if;
        vPDPrt[i] := rpadc('   �������� ��� �� � ' || vDocnoDate, 60);
        i := i + 1;
      end if;  
      vPDPrt[i] := ' ';
      i := i + 1;
      if (trim(vDocCode) = '32')
      then
        -- pri decl 32
        r  := wordwrap(  ' ���������� ��: ' || vSubjectName, 60, 1 );
      vPDPrt[i] := r.return_val;
      vRest := r.strrest;
        
        vPDPrt[i] := rpadc(vPDPrt[i], 60, ' ');
      else
        r :=  wordwrap(  ' ��: ' || vSubjectName, 60, 1 );
      vPDPrt[i] := r.return_val;
      vRest := r.strrest;
        
        vPDPrt[i] := rpadc(vPDPrt[i], 60, ' ');
      end if;
      i := i + 1;
      if (Length(vRest) > 1)
      then
        vPDPrt[i] := rpadc(' ' || vRest, 60, ' ');
        i := i + 1;
      end if;
      vPDPrt[i] := ' ����� ';
      i := i + 1;
      r :=  wordwrap(  ' ���������: ' || vSubPaddress, 60, 1 );
      vPDPrt[i] := r.return_val;
      vRest := r.strrest;
      vPDPrt[i] := rpadc(' ' || vPDPrt[i], 60, ' ');
      i := i + 1;
      if (Length(vRest) > 1)
      then
        vPDPrt[i] := rpadc(vRest, 60, ' ');
        i := i + 1;
      end if;
      r :=  wordwrap(  '  �� ������: ' || vSubPostAddress, 60, 1 );
      vPDPrt[i] := r.return_val;
      vRest := r.strrest;
      
      i := i + 1;
      if (Length(vRest) > 1)
      then
        vPDPrt[i] := rpadc(' ' || vRest, 60, ' ');
        i := i + 1;
      end if;
      if vidTObj = '1'
      then
        vPDPrt[i] := rpadc(' ����: ' || vKindProperty, 60);
        i := i + 1;
        r :=  wordwrap(  vPropertyAddr, 60, 1 );
      vPDPrt[i] := r.return_val;
      vRest := r.strrest;
        
        vPDPrt[i] := rpadc(' ' || vPDPrt[i], 60, ' ');
        i := i + 1;
        if (Length(vRest) > 1)
        then
          vPDPrt[i] := rpadc(vRest, 60, ' ');
          i := i + 1;
        end if;
      end if;
      if vidTObj = '2'
      then
        vPDPrt[i] := rpadc(vRegNo, 60);
        i := i + 1;
      end if;
      if (trim(vDocCode) = '19')
      then
              -- pri decl 19
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := rpadc(vPartidaNo, 60, ' ');

        i := i + 1;
        vPDPrt[i] := '-------------------------------------------------------------------------';
        i := i + 1;
        vPDPrt[i] := '     ��� ���             | ���� |         ������        | �������������� ';
        i := i + 1;
        vPDPrt[i] := '-------------------------------------------------------------------------';
        i := i + 1;
        for rec in garb(iTaxDoc_id) loop
          vPDPrt[i] := rpadc(rec.cname, 25, ' ') || ' ' ||
                       lpadc(rec.container_number, 6) || ' ' ||
                       rpadc(rec.period, 23, ' ') || ' ' ||
                       lpadc(rec.frequency, 15);
          i := i + 1;
        end loop;
        vPDPrt[i] := '-------------------------------------------------------------------------';
        i := i + 1;
      end if;
      if (trim(vDocCode) = '71')
      then
         -- pri decl 71
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := rpadc(' '||vPartidaNo, 25);
        i := i + 1;
        j := 1;
        for rec in garb(iTaxDoc_id) loop
          if (rec.sw_missing is not null or 
              rec.clean_missing is not null or 
              rec.depot_missing is not null) then
           vPDPrt[i] := rpadc(' ������  '||rec.period, 36);
           i := i + 1;
           --vPDPrt(i) := rpadc(' ������������� ��',20);
           --i := i + 1;
           if rec.sw_missing is not null then  
            vPDPrt[i] := lpadc(' ',36)||rpadc(rec.sw_missing, 20);
            i := i + 1;
           end if;
           if rec.depot_missing is not null then  
            vPDPrt[i] := lpadc(' ',36)||rpadc(rec.depot_missing, 20);
            i := i + 1;
           end if;
           if rec.clean_missing is not null then  
            vPDPrt[i] := lpadc(' ',36)||rpadc(rec.clean_missing, 20);
            i := i + 1;
           end if;            
          end if;
          j := j + 1;
        end loop;
      end if;
      if (trim(vDocCode) = '117')
      then
        -- pri decl 117 ����
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := rpadc(vRegName, 40, ' ') || ' ' || rpadc(vRegNo, 20, ' ');
        i := i + 1;
        vPDPrt[i] := rpadc(vBreed, 50, ' ');
        i := i + 1;
      end if;
    
      vPDPrt[i] := '';
      i := i + 1;
      vPDPrt[i] := '';
      i := i + 1;
      vPDPrt[i] := rpadc(' ��������:..................... ', 60);
      i := i + 1;
      vPDPrt[i] := rpadc('           ' || vRecUserName, 60, ' ');
      i := i + 1;
      vPDPrt[i] := '';
    
    end if;
    
   vPD_lob := paydocument_pkg.tblToLob(vPDPrt );
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        return_val := sqlerrm;
        
        ErrMsg :=  NOM_PKG.ErrManage(sqlstate,sqlerrm);
        return_val := ErrMsg;
        return;
      
      end;
end;
$function$
; DROP FUNCTION paydocument_pkg.tbltolob(character varying[]); 
CREATE OR REPLACE FUNCTION paydocument_pkg.tbltolob(vpdprt character varying[], OUT vpd_lob text)
 RETURNS text
 LANGUAGE plpgsql
AS $function$
   begin
	vPD_lob := '';
	IF (array_length(vPDPrt,1) > 0) THEN
          FOR indx IN 1..array_length(vPDPrt,1) LOOP
            vPD_lob := vPD_lob || nvl(vPDPrt[indx]::varchar,'') || '@';
           END LOOP;
	END IF;              
   end; 

$function$
; DROP FUNCTION paydocument_pkg.transferorder(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.transferorder(OUT return_val character varying, vuser_id numeric, vpdocument_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                          
    vPDPrt varchar[];
    ErrMsg varchar(300);
  
     getPD cursor (vpdocument_id paydocument.paydocument_id%type) is
            select (rpadc('�� ' || b.fullname,50) ||' '|| '�������� ���. ����� .........') tobank, pt.trtype,
             (rpadc('���� ' /*|| b.name*/, 53) ||' '|| '���� ����������� .........') bbranch,
             (rpadc('����� ' || case when b.address is not null then b.address else '' end, 53)
               ||' '|| '������ ��������� .........') baddress,
             --||lpadc('������ �� ����������',40)) baddress,
             ('������� ������: ' || ts.name) taxsubj,

             ('������� �� ' || ts.name) rec_name,
             ('IBAN �� ���������� ' || pd.rcaccount) rec_iban,
             ('BIC �� ������� �� ���������� ' || pd.rcbic) rec_bic,
             ('��� ����� ' || case when (pt.trtype = '31') or (pd.kindpaydoc = '630') then b.fullname
                                   else b1.fullname end) rec_bankname,
             (case when pd.kindpaydoc in ('613','630') then '��� ������� ' || kdr.acc else '' end) rec_debtreg,
             pd.docsum,
             ('��������� �� �������: ' || pd.reason1) reas1,
             ('��� ���������: ' || pd.reason2) reas2,
             ('��� ���. 9' /*||pd.kindpaydoc*/
              ) kinddoc, ('� �� ���. ' || pd.documentno) docno,
             ('���� �� ���. ' || to_char(pd.paydate, 'dd.mm.yyyy')) docdate,
             ('������, �� ����� �� �����:  �� ' ||
              case when pd.docfromdate is not null then to_char(pd.docfromdate, 'dd.mm.yyyy') ||' �� '
                   else lpadc(' �� ',15) end ||
              to_char(pd.doctodate, 'dd.mm.yyyy')) period,

             ('���������: ��� ' || ts1.idn || ' ��� ' || ts1.name) arr_name,
             ('���������: ���...........' || ' ��� ' || u.fullname) arr_name1,
             ('�������: ' || ts1.idn) arr_idn, pd.note,
             ('IBAN �� ���������� ' || pd.tsaccount) arr_iban,
             ('BIC �� ���������� ' || pd.tsbic) arr_bic,
             -------
             (case when pd.kindpaydoc = '622' then '��� ������� ' || kdr.acc
                  when pd.kindpaydoc = '630' then '��� ������� ' || kdr1.acc else '' end) arr_debtreg,

             ('�������: ' || u.username || ' ' || u.fullname) receiver,
             ('�����: ' || GetAddress(ts.present_clientaddr_id)) Address

      from   Paydocument pd
      left   outer join Taxsubject ts on pd.receive_taxsubject_id = ts.taxsubject_id
      left   outer join Taxsubject ts1 on pd.taxsubject_id = ts1.taxsubject_id
      left   outer join Baccount ba on pd.baccount_id = ba.baccount_id
      left   outer join Bank b on ba.bank_id = b.bank_id
      left   outer join Bank b1 on pd.rcbank_id = b1.bank_id
      left   outer join Kinddebtreg kdr on pd.over_kinddebtreg_id = kdr.kinddebtreg_id
      left   outer join Kinddebtreg kdr1 on pd.from_kinddebtreg_id = kdr1.kinddebtreg_id
      left   outer join Users u on pd.user_id = u.user_id
      left   outer join Paytransaction pt on pt.paytransaction_id = pd.paytransaction_id
      where  pd.paydocument_id = vPDocument_id
      and    pd.kindpaydoc in ('613', '630', '622')
      order  by pd.paydate;
    i             integer;
    vRest         varchar(300);
    vTotalInstSum numeric(18, 2);
    r record;
  begin
    i             := 1; -- ����� 
    vTotalInstSum := 0;
    for getPD_rec in GetPD(vPDocument_id)
    loop
      vPDPrt[i] := '--------------------------------------------------------------------------------';
      i := i + 1;
      vPDPrt[i] := getPD_rec.tobank;
      i := i + 1;
      vPDPrt[i] := getPD_rec.bbranch;
      i := i + 1;
      vPDPrt[i] := getPD_rec.baddress;
      i := i + 1;
      vPDPrt[i] := '--------------------------------------------------------------------------------';
      i := i + 1;
      vPDPrt[i] := getPD_rec.rec_name;
      i := i + 1;
      vPDPrt[i] := getPD_rec.rec_iban || ' ' || getPD_rec.rec_bic;
      i := i + 1;
      vPDPrt[i] := rpadc(getPD_rec.rec_bankname,60) || ' ' || getPD_rec.rec_debtreg;
      i := i + 1;
      vPDPrt[i] := '--------------------------------------------------------------------------------';
      i := i + 1;
      vPDPrt[i] := '� � � � � � � �  � � � � � � � � �  | ��� ������ |            � � � �                   ';
      i := i + 1;
      vPDPrt[i] := '         /������ �������/           |            |   ';
      i := i + 1;
      vPDPrt[i] := '    �� ������� ��/��� �������       |     BGN    |' || lpadc(to_char(getPD_rec.docsum, '999999990.99') || '��.', 25, ' ');
      i := i + 1;
      vPDPrt[i] := '--------------------------------------------------------------------------------';
      i := i + 1;
      vPDPrt[i] := ' ���� � ����: ' ||
                   rpadc(advance_pkg.Slovom(trim(to_char(getPD_rec.docsum, '999999990.99'))), 70, ' ');
      i := i + 1;
      vPDPrt[i] := '--------------------------------------------------------------------------------';
      i := i + 1;
      r :=  wordwrap( getPd_rec.reas1, 80, 1);
     vPDPrt[i] := r.return_val;
      vRest := r.strrest;
      
      vPDPrt[i] := rpadc(vPDPrt[i], 80, ' ');
      i := i + 1;
      if (Length(vRest) > 1)
      then
        vPDPrt[i] := rpadc(vRest, 80, ' ');
        i := i + 1;
      end if;
      r :=  wordwrap(  getPd_rec.reas2, 80, 1 );
     vPDPrt[i] := r.return_val;
      vRest := r.strrest;
      
      vPDPrt[i] := rpadc(vPDPrt[i], 80, ' ');
      i := i + 1;
      if (Length(vRest) > 1)
      then
        vPDPrt[i] := rpadc(vRest, 80, ' ');
        i := i + 1;
      end if;
      vPDPrt[i] := getPD_rec.kinddoc::varchar || ' ' || getPD_rec.docno || ' ' ||
                   getPD_rec.docdate;
      i := i + 1;
      vPDPrt[i] := rpadc(getPD_rec.period, 80, '');
      i := i + 1;
      vPDPrt[i] := '================================================================================';
      i := i + 1;
      r :=  wordwrap(  getPD_rec.note, 70, 1 );
     vPDPrt[i] := r.return_val;
      vRest := r.strrest;
      
      vPDPrt[i] := rpadc(vPDPrt[i], 80, ' ');
      i := i + 1;
      if (Length(vRest) > 1)
      then
        vPDPrt[i] := rpadc(vRest, 80, ' ');
        i := i + 1;
      end if;
      --   vPDPrt[i]  := rpadc(getPD_rec.arr_idn,30,' ');
      --  i          := i + 1;   
      /*if (getPD_rec.finishday_id is not null) then 
       vPDPrt[i] := rpadc(getPD_rec.arr_name1, 80, ' ');
      else  
       vPDPrt[i] := rpadc(getPD_rec.arr_name, 80, ' ');
      end if; 
      i := i + 1;*/
            if (getPD_rec.trtype = '31') then
       vPDPrt[i] := rpadc(getPD_rec.arr_name1, 80, ' ');
      else
       vPDPrt[i] := rpadc(getPD_rec.arr_name, 80, ' ');
      end if;
      i := i + 1;
      if (getPD_rec.trtype != '31') then
        vPDPrt[i] := rpadc(getPD_rec.arr_iban, 50, ' ') || ' ' || rpadc(getPD_rec.arr_bic, 34, ' ');
        i := i + 1;
      end if;
--      vPDPrt[i] := rpadc(getPD_rec.arr_iban, 45, ' ') || ' ' ||
--                   rpadc(getPD_rec.arr_bic, 34, ' ');
--      i := i + 1;
      vPDPrt[i] := '�������� ������� ������ ����� 002 ���� �� ���. ..........    ' 
      || rpadc(getPD_rec.arr_debtreg, 20);
      i := i + 1;
      vPDPrt[i] := '';
      i := i + 1;
      vPDPrt[i] := '������������:...........................           ������:......................';
      i := i + 1;
      vPDPrt[i] := '- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -';
      i := i + 1;
    end loop;
    
   vPD_lob := paydocument_pkg.tblToLob(vPDPrt );
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        return_val := sqlerrm;
        
        ErrMsg :=  NOM_PKG.ErrManage(sqlstate,sqlerrm);
        return_val := ErrMsg;
        return;
      
      end;
end;
$function$
; DROP FUNCTION paydocument_pkg.accountreportcancellation(numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.accountreportcancellation(OUT return_val character varying, vpaydocument_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                                      
    vPDPrt varchar[];
    ErrMsg varchar(100);
    v_region character varying(10) := ', �-� '; 
    pdoc cursor (pPD_id numeric) is
      select ('������� �� �������:  ' || ts.name) tsname,
             (select d.value
               from   decode d
               where  upper(d.columnname) = 'KIND_IDN'
               and    d.code = ts.kind_idn) || ' ' || ts.idn tsidn,
             ('������� ���� � ������ ��:  ' || 
              to_char(pd.docsum, '999999990.99') || '��.') docsuma, pd.docsum,
             ('� ' || (select d.fullname
                        from   decode d
                        where  upper(d.columnname) = 'KINDPAYDOC'
                        and    d.code = pd.kindpaydoc) ||
              case when coalesce(pd.series, '') = '' then '' else ' ����� ' || pd.series end ||
              ' � ' || pd.documentno || ' / ���� ' ||
              to_char(pd.paydate, 'dd.mm.yyyy')) docnodate,
             ('��������� �� ��������������/���������:  ' || coalesce(pd.nullreason,'')) reason,
             '�������� ���. ��������� �������� � �����: ' ||
              (select x.documentno || ' / ' ||
                       to_char(x.documentdate, 'dd.mm.yyyy')
               from   paydocument x
               where  x.paydocument_id = pd.parent_paydocument_id
               and    x.kindpaydoc = '621') parent_docnodate,
             ('��� ������: ' || pd.user_name) cashier,
             ('��������: ' || pd.null_user_name) null_cashier, pd.kindpaydoc
      from   Paydocument pd, Taxsubject ts
      where  pd.paydocument_id = pPD_id
      and    pd.taxsubject_id = ts.taxsubject_id;
    i             numeric;
    vMunicipality varchar(100);
    vProvince     varchar(100);
    vRest         varchar(200);
    vRes          varchar(100);
    r record;
  begin
    i := 1; -- ����� 
    select coalesce(m1.fullname,m.fullname) ||
           case when m1.municipality_id is not null then v_region || m.fullname else '' end, p.name 
      into vMunicipality, vProvince
      from paydocument pd
      inner join users u on pd.user_id = u.user_id
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id      
      left outer join province p on m.province_id = p.province_id
     where pd.paydocument_id = vPayDocument_id;
    vPDPrt[i] := rpadc('������: ' || vProvince, 70) ||
                 lpadc('����: ' || to_char(current_date, 'dd.mm.yyyy'), 25);
    i := i + 1;
    vPDPrt[i] := rpadc('������: ' || vMunicipality, 70) ||
                 lpadc('      ' || to_char(current_date, 'hh24:mi:ss'), 25);
    i := i + 1;
    vPDPrt[i] := lpadc('���������� �������', 55);
    i := i + 1;
    vPDPrt[i] := lpadc('�� ��������� �� ���� ����� ��������� �����������', 60);
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    for pdoc_rec in pdoc(vPayDocument_id)
    loop
      vPDPrt[i] := rpadc(pdoc_rec.tsname, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.tsidn, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.docsuma, 80, ' ');
      i := i + 1;
      vPDPrt[i] := rpadc('������: ' ||
                         advance_pkg.Slovom(trim(to_char(pdoc_rec.docsum,
                                                         '999999990.99'))), 80);
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.docnodate, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.cashier, 80);
      i := i + 1;
      r := wordwrap( pdoc_rec.reason, 70, 1);
      vRest := r.strrest;
      vPDPrt[i] := rpadc(r.return_val, 80);
      i := i + 1;
      if (Length(vRest) > 80)
      then
        r :=  wordwrap(vRest, 70, 1 );
        vRes := r.strrest;
        vPDPrt[i] := rpadc(r.return_val, 80, ' ');
        i := i + 1;
        vPDPrt[i] := rpadc(vRes, 80, ' ');
        i := i + 1;
      elsif (Length(vRest) > 1)
      then
        vPDPrt[i] := rpadc(vRest, 80, ' ');
        i := i + 1;
      end if;
      vPDPrt[i] := '';
      i := i + 1;
      if (trim(pdoc_rec.kindpaydoc) = '621')
      then
        vPDPrt[i] := pdoc_rec.parent_docnodate;
        i := i + 1;
      end if;
      vPDPrt[i] := '';
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.null_cashier ||
                         '        ������������:..................', 80);
    end loop;
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    
    vPD_lob := paydocument_pkg.tblToLob(vPDPrt);
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;
      
      end;
end;
$function$
; DROP FUNCTION paydocument_pkg.accountreportstorn(numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.accountreportstorn(OUT return_val character varying, vpaydocument_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                               
    vPDPrt varchar[];
    ErrMsg varchar(100);
    pdoc cursor (pPD_id numeric) is
      select ('������� �� �������:  ' || ts.name) tsname,
             (select d.value
               from   decode d
               where  upper(d.columnname) = 'KIND_IDN'
               and    d.code = ts.kind_idn) || ': ' || ts.idn tsidn,
             ('������� ���� � ������ ��:  ' || to_char(pd.docsum, '9999990.99') ||
              '��.') docsuma, pd.docsum,
             ('� ' || (select d.fullname
                        from   decode d
                        where  upper(d.columnname) = 'KINDPAYDOC'
                        and    d.code = pd.kindpaydoc) ||
              case when pd.series is null then '' else ' ����� ' || pd.series end || ' � ' ||
              pd.documentno || ' / ���� ' || to_char(pd.paydate, 'dd.mm.yyyy')) docnodate,
             ('��������� �� ����������:  ' || pd.nullreason) reason,
             ('���� ���������� �� �������� ��������:  ' ||
              to_char(pd.null_userdate, 'dd.mm.yyyy')) nulluserdate,
             ('��� ������: ' || pd.user_name) cashier,
             ('��������� ��������: ' || pd.null_user_name) null_cashier
      from   Paydocument pd, Taxsubject ts
      where  pd.paydocument_id = pPD_id
      and    pd.taxsubject_id = ts.taxsubject_id;
    oversum cursor (pPD_id numeric) is
      select od.kinddebtreg_id, sum(od.operoversum) operoversum,
             max(kdr.code) kdrcode
      from   operation o, operdebt od, kinddebtreg kdr
      where  o.cancel_paydocument_id = pPD_id
      and    o.operation_id = od.operation_id
      and    od.kinddebtreg_id = kdr.kinddebtreg_id
      group  by od.kinddebtreg_id;
    i             numeric;
    vMunicipality varchar(100);
    vProvince     varchar(100);
    vRest         varchar(200);
    vRes          varchar(100);
    vOpersum      numeric(18, 2);
    v_region varchar(15) := ', �-� '; 
    r record;
  begin
    i := 1; -- �����   
   select coalesce(m1.fullname,m.fullname) || 
           case when m1.municipality_id is not null then v_region || m.fullname else '' end, p.name 
      into vMunicipality, vProvince
      from paydocument pd
      inner join users u on pd.user_id = u.user_id
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id      
      left outer join province p on m.province_id = p.province_id
     where pd.paydocument_id = vPayDocument_id;
    vPDPrt[i] := rpadc('������: ' || vProvince, 70) ||
                 lpadc('����: ' || to_char(current_timestamp, 'dd.mm.yyyy'), 25);
    i := i + 1;
    vPDPrt[i] := rpadc('������: ' || vMunicipality, 70) ||
                 lpadc('      ' || to_char(current_timestamp, 'hh24:mi:ss'), 25);
    i := i + 1;
    vPDPrt[i] := lpadc('���������� �������', 55);
    i := i + 1;
    vPDPrt[i] := lpadc('�� ���������� �� �������� ��������', 60);
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    for pdoc_rec in pdoc(vPayDocument_id)
    loop
      vPDPrt[i] := rpadc(pdoc_rec.tsname, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.tsidn, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.docsuma, 80);
      i := i + 1;
      vPDPrt[i] := rpadc('������: ' ||
                         advance_pkg.Slovom(trim(to_char(pdoc_rec.docsum,
                                                         '9999990.99'))), 80);
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.docnodate, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.cashier, 80);
      i := i + 1;
      r := wordwrap(pdoc_rec.reason, 70, 1);
      vRest := r.strrest;
      vPDPrt[i] := rpadc(r.return_val, 80);
      i := i + 1;
      if (Length(vRest) > 80)
      then
        r := wordwrap(vRest, 70, 1);
        vPDPrt[i] := rpadc(r.return_val, 80, ' ');
        vRes := r.strrest;
        i := i + 1;
        vPDPrt[i] := rpadc(vRes, 80, ' ');
        i := i + 1;
      elsif (Length(vRest) > 1)
      then
        vPDPrt[i] := rpadc(vRest, 80, ' ');
      
        i := i + 1;
      end if;
      vPDPrt[i] := rpadc(pdoc_rec.nulluserdate, 80);
      i := i + 1;
      --    vPDPrt[i]  := rpadc(pdoc_rec.null_cashier,80);         
      --    i          := i + 1; 
      vPDPrt[i] := '';
      i := i + 1;
    
      select sum(o.opersum)
      into   vOpersum
      from   operation o
      where  o.cancel_paydocument_id = vPayDocument_id;
      if (coalesce(vOpersum, 0.0) > 0)
      then
        vPDPrt[i] := rpadc('���� ���� �� ��������������: ', 30) ||
                     lpadc(to_char(vOpersum, '99990.99'), 15);
        i := i + 1;
        vPDPrt[i] := lpadc('� �.�. �� ��� ��� ������:', 28);
        i := i + 1;
        for rec in oversum(vPayDocument_id)
        loop
          vPDPrt[i] := rpadc(' ', 20) || lpadc(rec.kdrcode, 15) ||
                       lpadc(to_char(rec.operoversum, '99990.99'), 10);
          i := i + 1;
        end loop;
      end if;
    
      vPDPrt[i] := '';
      i := i + 1;
      vPDPrt[i] := '';
      i := i + 1;
      vPDPrt[i] := rpadc(pdoc_rec.null_cashier, 40) ||
                   lpadc('  ������������:..................', 40);
    end loop;
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    
    vPD_lob := paydocument_pkg.tblToLob(vPDPrt);
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;
      
      end;
    
end;
$function$
; DROP FUNCTION paydocument_pkg.expensecashorder(numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.expensecashorder(OUT return_val character varying, vuser_id numeric, vpdocument_id numeric, vmunicipalityid numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                             
  
     GetPD cursor (pPDocument_id paydocument.paydocument_id%type) is
      select ('�������� ����� ����� �: ' || pd.documentno || ' ����: ' ||
              to_char(pd.paydate, 'dd.mm.yyyy')) Label1,

             ('������� ������ �: ' || ts.taxsubjectno) taxsubj,
             ('���/�������: ' || ts.idn) idn, ('���: ' || ts.name) tsname,
             ('�����: ' || GetAddress(ts.present_clientaddr_id)) address,

             pd.docsum docsum, ('��� ��� �������: ' || kdr.code) debtregcode,
             pd.note, pd.reason1 reas1, pd.reason2 reas2,
             -- receiver
             ('���: ' || ts1.idn) rec_idn, ('���: ' || ts1.name) rec_name,
             ('��: ' || coalesce(p.identdocno, '.............')) rec_docno,
             ('�������� ��: ' || coalesce(p.emission_date, '.............')) rec_emissiondate,
             ('�������� ��: ' || coalesce(rdvr.name, '.............')) rec_rdvrname,
             ('������: ' || u.fullname) cashier

      from   Paydocument pd
      left   outer join Taxsubject ts on pd.taxsubject_id = ts.taxsubject_id
      left   outer join Taxsubject ts1 on pd.receive_taxsubject_id = ts1.taxsubject_id
      left   outer join Person p on pd.receive_taxsubject_id = p.taxsubject_id
      left   outer join Rdvr on p.rdvr_id = rdvr.rdvr_id
      left   outer join Kinddebtreg kdr on pd.over_kinddebtreg_id = kdr.kinddebtreg_id
      left   outer join Users u on pd.user_id = u.user_id
      where  pd.paydocument_id = pPDocument_id
      order  by pd.paydate;

    vPDPrt varchar[];
    ErrMsg varchar(100);
    i             integer;
    vRest         varchar(200);
    vMunicipality varchar(200);
    vProvince     varchar(100);
    vMunAddress   varchar(300);
    vTotalInstSum numeric(18, 2);
    r record;
    d varchar;
    v_region      varchar(10) = ', �-� ';
  begin
    i             := 1; -- ����� 
    vTotalInstSum := 0;
    for GetPD_rec in GetPD(vPDocument_id) loop
      vPDPrt[i] := lpadc(GetPD_rec.label1, 60);
      i := i + 1;
      if (vMunicipalityId = 0) then
         select coalesce(m1.fullname,m.fullname) ||
           case when m1.municipality_id is not null then v_region || m.fullname else '' end, p.name,
               getaddress((select ts.present_clientaddr_id
                           from   taxsubject ts
                           where  ts.taxsubject_id =
                                  to_number((select c.configvalue
                                            from   config c
                                            where  upper(c.name) =
                                                   'TAXSUBJECT_ID'))))
        into vMunicipality, vProvince, vMunAddress
        from users u
        left outer join municipality m on u.municipality_id = m.municipality_id
        left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
        left outer join province p on m.province_id = p.province_id
       where u.user_id = vUser_id;

      else
       select coalesce(m1.fullname,m.fullname) ||
               case when m1.municipality_id is not null then v_region || m.fullname else '' end, p.name,
               getaddress((select ts.present_clientaddr_id
                           from   taxsubject ts
                           where  ts.taxsubject_id =
                                  to_number((select c.configvalue
                                            from   config c
                                            where  upper(c.name) =
                                                   'TAXSUBJECT_ID'))))
        into   vMunicipality, vProvince, vMunAddress
        from   municipality m
        left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
        left outer join province p on m.province_id = p.province_id
        where  m.municipality_id = vMunicipalityId;
      end if;
      vPDPrt[i] := rpadc('������: ' || vProvince, 70);
      i := i + 1;
      vPDPrt[i] := rpadc('������: ' || vMunicipality, 70);
      i := i + 1;
      vPDPrt[i] := '�����: ' || vMunAddress;
      i := i + 1;
      vPDPrt[i] := '--------------------------------------------------------------------------------';
      i := i + 1;
      vPDPrt[i] := GetPD_rec.taxsubj;
      i := i + 1;
      vPDPrt[i] := GetPD_rec.idn;
      i := i + 1;
      vPDPrt[i] := GetPD_rec.tsname;
      i := i + 1;
      vPDPrt[i] := GetPD_rec.address;
      i := i + 1;
      vPDPrt[i] := '';
      i := i + 1;
      vPDPrt[i] := '';
      i := i + 1;
      vPDPrt[i] := '�������� ����: ' || to_char(GetPD_rec.docsum, '99990.99') 
       ;
      i := i + 1;
      vPDPrt[i] := '������: ' ||
                   rpadc(advance_pkg.Slovom(trim(to_char(GetPD_rec.docsum, '9999990.99'))), 93, ' ');
      i := i + 1;
      vPDPrt[i] := '';
      i := i + 1;
      if GetPD_rec.reas1 is not null or (GetPD_rec.reas1 != '') then 
       r :=  wordwrap('��������� �� �������: ' || GetPD_rec.reas1, 80, 1);
       vPDPrt[i] := r.return_val;
       vRest := r.strrest;
       i := i + 1;
      end if; 
      if (Length(vRest) > 1) then
        vPDPrt[i] := rpadc(vRest, 80);
        i := i + 1;
      end if;
      if GetPD_rec.reas2 is not null or (GetPD_rec.reas2 != '') then 
       r :=  wordwrap(GetPD_rec.reas2, 80, 1);
       vPDPrt[i] := r.return_val;
       vRest := r.strrest;
       i := i + 1;
      end if;
      if (Length(vRest) > 1) then
        vPDPrt[i] := rpadc(vRest, 80);
        i := i + 1;
      end if;
      if GetPD_rec.note is not null or (GetPD_rec.note != '') then 
       r :=  wordwrap(getPd_rec.note, 80, 1);
       vPDPrt[i] := r.return_val;
       vRest := r.strrest;
       i := i + 1;
      end if; 
      if (Length(vRest) > 1) then
        vPDPrt[i] := rpadc(vRest, 80);
        i := i + 1;
      end if;
      vPDPrt[i] := '--------------------------------------------------------------------------------';
      i := i + 1;
      vPDPrt[i] := '���������';
      i := i + 1;
      vPDPrt[i] := GetPD_rec.rec_idn || ' ' || GetPD_rec.rec_name;
      i := i + 1;
      vPDPrt[i] := GetPD_rec.rec_docno || ' ' || GetPD_rec.rec_emissiondate || ' ' ||
                   GetPD_rec.rec_rdvrname;
      i := i + 1;
      vPDPrt[i] := '������ �� ';
      i := i + 1;
      vPDPrt[i] := '���������: ........... ' || lpadc(GetPD_rec.cashier, 50, ' ');
      i := i + 1;
      vPDPrt[i] := '';
    
    end loop;
    
    vPD_lob :=  paydocument_pkg.tblToLob(vPDPrt );
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        ErrMsg := sqlerrm;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;
      end;
end;
$function$
; DROP FUNCTION paydocument_pkg.interestlist(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.interestlist(OUT return_val character varying, idebtsubject_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  vPDPrt varchar [ ];

    crhead cursor (vDebtSubject_id numeric) is
      select distinct ds.debtsubject_id, max(ds.tax_begidate),
                      max('�������: ' || ds.partidano || ' ' || kdr.name) partidano,
                      max(kdr.code) kdrcode, max(kdr.name) kdrname,
                      max((select d.value
                            from   decode d
                            where  upper(d.columnname) = 'KIND_IDN'
                            and    d.code = ts.kind_idn) || ' ' || ts.idn) idn,
                      max(ts.name) tsname,
                      max('������ �������� ��: ' ||
                           to_char(ds.tax_begidate, 'dd.mm.yyyy') || ' ��: ' ||
                           to_char(ds.tax_enddate, 'dd.mm.yyyy')) period,
                      max('����������� ���.: ' || ds.docno || '/' ||
                           to_char(ds.doc_date, 'dd.mm.yyyy')) nodate,
                      sum(di.instsum) instsum, sum(idt.intdebtsum) intdebtsum
      from   debtsubject ds
      inner  join kinddebtreg kdr
      on     ds.kinddebtreg_id = kdr.kinddebtreg_id
      inner  join debtinstalment di
      on     di.debtsubject_id = ds.debtsubject_id
      inner  join interestdebt idt
      on     di.debtinstalment_id = idt.debtinstalment_id
      left   outer join taxsubject ts
      on     ds.taxsubject_id = ts.taxsubject_id
      where  ds.debtsubject_id = vDebtSubject_id
      group  by ds.debtsubject_id
      order  by 2, 3;
    crIL cursor (vDebtSubject_id numeric) is
      select kdr.code kodpl, di.instno NomVn,
             to_char(i.oper_date, 'dd.mm.yyyy') srokPl,
             to_char(i.begin_date, 'dd.mm.yyyy') otdata,
             to_char(i.end_date, 'dd.mm.yyyy') dodata, i.intpct pct,
             i.instsum instsum, i.interestsum interestsum, null pllix,
             null DokNo,
             case i.kindoper when 1 then '���.�����' when 20 then '��������' end zab
      from   interestoper i, debtinstalment di, debtsubject ds, kinddebtreg kdr
      where  i.debtinstalment_id = di.debtinstalment_id
      and    di.debtsubject_id = ds.debtsubject_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.debtsubject_id = vDebtSubject_id --676552--:dsid
      union all
      select kdr.code kodpl, di.instno NomVn,
             to_char(pd.paydate, 'dd.mm.yyyy') srokPl, null otdata, null dodata,
             null pct, null instsum, null interestsum, pdt.payinterestsum pllix,
             (select d.value
               from   decode d
               where  upper(d.columnname) = 'KINDPAYDOC'
               and    d.code = pd.kindpaydoc) || '/' || pd.documentno DokNo,
             null zab
      from   paydocument pd, paydebt pdt, debtinstalment di, debtsubject ds,
             kinddebtreg kdr
      where  pd.paydocument_id = pdt.paydocument_id
      and    pdt.debtinstalment_id = di.debtinstalment_id
      and    di.debtsubject_id = ds.debtsubject_id
      and    kdr.kinddebtreg_id = ds.kinddebtreg_id
      and    pd.null_date is null
      and    coalesce(pdt.payinterestsum, 0) > 0
      and    di.debtsubject_id = vDebtSubject_id --:dsid
      union all
      select kdr.code kodpl, di.instno NomVn,
             to_char(di.termpay_date, 'dd.mm.yyyy') srokPl,
             to_char(op.oper_date, 'dd.mm.yyyy') otdata, null dodata, null pct,
             null instsum, null interestsum, opd.operintsum pllix,
             To_char(op.operdocno) DokNo, '����������' zab
      from   operation op, operdebt opd, debtinstalment di, debtsubject ds,
             kinddebtreg kdr
      where  op.operation_id = opd.operation_id
      and    opd.debtinstalment_id = di.debtinstalment_id
      and    di.debtsubject_id = ds.debtsubject_id
      and    kdr.kinddebtreg_id = ds.kinddebtreg_id
      and    coalesce(opd.operintsum, 0) > 0
      and    di.debtsubject_id = vDebtSubject_id --:dsid
      and    op.null_date is null
      order  by 1, 3, 4;
    ErrMsg        varchar(100);
    i             numeric;
    vMunicipality varchar(200);
    vProvince     varchar(100);
    vtotalinstsum numeric(18, 2);
    vtotalpct     numeric(18, 2);
    vtotalintsum  numeric(18, 2);
    vtotalpllix   numeric(18, 2);
    vtotal        numeric(18, 2);
  begin
    i             := 1;
    vtotalinstsum := 0;
    vtotalpct     := 0;
    vtotalintsum  := 0;
    vtotalpllix   := 0;
    vtotal        := 0;
    select coalesce(m1.fullname,m.fullname), p.name
      into vMunicipality, vProvince
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      left outer join province p on m.province_id = p.province_id
     where u.user_id = iUser_id;
    vPDPrt[i] := rpadc('������: ' || vProvince, 50) ||
                 lpadc('����: ' || to_char(current_date, 'dd.mm.yyyy'), 25);
    i := i + 1;
    vPDPrt[i] := rpadc('������: ' || vMunicipality, 50) ||
                 lpadc('      ' || to_char(current_date, 'hh24:mi:ss'), 25);
    i := i + 1;
    vPDPrt[i] := center('������ ����', 80);
    i := i + 1;
    for cr in crhead(iDebtSubject_id)
    loop
      vPDPrt[i] := center(cr.idn || ' - ' || cr.tsname, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(cr.partidano, 60);
      i := i + 1;
      vPDPrt[i] := rpadc(cr.nodate, 60);
      i := i + 1;
      vPDPrt[i] := rpadc(cr.period, 60);
      exit;
    end loop;
    vPDPrt[i] := '----------------------------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := '��� ���|����� |  ����    |          |          |������� |        |���������|�������|           |         ';
    i := i + 1;
    vPDPrt[i] := '�������|������|  ������� | �� ����  | �� ����  |��������|������ %| �����   | ����� |��.��������|���������';
    i := i + 1;
    vPDPrt[i] := '----------------------------------------------------------------------------------------------------------';
    i := i + 1;
    for cr in crIL(iDebtSubject_id)
    loop
      vPDPrt[i] := rpadc(coalesce(cr.kodpl, ' '), 7) || ' ' ||
                   lpadc(coalesce(to_char(cr.nomvn), ' '), 6) || ' ' ||
                   lpadc(coalesce(cr.srokpl, ' '), 10) || ' ' ||
                   lpadc(cr.otdata, 10) || ' ' ||
                   lpadc(coalesce(cr.dodata, ' '), 10) || ' ' ||
                   lpadc(coalesce(to_char(cr.instsum, '999990.99'), ' '), 8) || ' ' ||
                   lpadc(coalesce(to_char(cr.pct, '999990.99'), ' '), 8) || ' ' ||
                   lpadc(coalesce(to_char(cr.interestsum, '999990.99'), ' '), 8) || ' ' ||
                   lpadc(coalesce(to_char(coalesce(cr.pllix, 0), '999990.99'), ' '), 8) || ' ' ||
                   rpadc(coalesce(cr.dokno, ' '), 11) || ' ' || rpadc(cr.zab, 20);
      i := i + 1;
      --vtotalinstsum := vtotalinstsum + coalesce(cr.instsum,0);
      --vtotalpct := vtotalpct + coalesce(cr.pct,0);
      vtotalintsum := vtotalintsum + coalesce(cr.interestsum, 0);
      vtotalpllix  := vtotalpllix + coalesce(cr.pllix, 0);
    end loop;
    vPDPrt[i] := '----------------------------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := rpadc(' ����: ', 66, ' ') ||
                --lpadc(to_char(vtotalinstsum,'9990.99'),8,' ')||' '||
                --lpadc(to_char(vtotalpct,'9990.99'),8,' ')||' '||
                 lpadc(to_char(vtotalintsum, '9990.99'), 8, ' ') || ' ' ||
                 lpadc(to_char(vtotalpllix, '9990.99'), 8, ' ');
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := ' ��������� �����:    ' ||
                 lpadc(to_char(coalesce(vtotalintsum, 0), '99990.99'), 12);
    i := i + 1;
    vPDPrt[i] := ' ������� �����:      ' ||
                 lpadc(to_char(coalesce(vtotalpllix, 0), '99990.99'), 12);
    i := i + 1;
    vPDPrt[i] := ' ---------------------------------';
    i := i + 1;
    vtotal := vtotalintsum - vtotalpllix;
    vPDPrt[i] := ' ������� �����:      ' ||
                 lpadc(to_char(vtotal, '99990.99'), 12);
    i := i + 1;
    select sum(sanction_pkg.TempInt(i.debtinstalment_id, current_date))
    into   vtotalpct
    from   debtinstalment i
    where  i.debtsubject_id = iDebtSubject_id;
    vPDPrt[i] := ' ����������� �����:  ' ||
                 lpadc(to_char(vtotalpct, '99990.99'), 12);
    i := i + 1;
    vtotal := vtotal + vtotalpct;
    vPDPrt[i] := ' ���� ������� �����: ' ||
                 lpadc(to_char(coalesce(vtotal, 0), '99990.99'), 12);
    i := i + 1;
    vPDPrt[i] := '';

  vPD_lob := paydocument_pkg.tblToLob(vPDPrt);

  --commit;
  return_val := 'OK';
  return;
exception
  when others then
    begin
      --rollback;
      ErrMsg := sqlerrm;
      perform NOM_PKG.ErrManage(ErrMsg);
      return_val := ErrMsg;
      return;
    end;
end;
$function$
; DROP FUNCTION paydocument_pkg.massmsgd14(numeric, numeric, character varying, character varying, integer, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.massmsgd14(OUT return_val character varying, igroupactionid numeric, itaxperiod_id numeric, ifromseqnom character varying, itotalseqnom character varying, irecap integer, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare

  vPDPrt varchar [ ];

  ErrMsg varchar(300);

  XXX    varchar(300);

    subject_fromto cursor (vGroupactionId numeric, vFromSeqNom character varying, vTotalSeqNom character varying) is
      select a.seqnom, max(ts.taxsubject_id) taxsubject_id, 
             max(ts.idn) idn, max(ts.name) ime, max(getaddress(ts.present_clientaddr_id)) address,        
             count(a.taxdoc_id) brojImoti   
        from action a
             inner join taxsubject ts on a.taxsubject_id = ts.taxsubject_id
       where a.seqnom >= vFromSeqNom and a.seqnom <= (vTotalSeqNom + vFromSeqNom - 1)  
         and a.groupaction_id = vGroupactionId
         and ts.taxsubject_id <> (select c.configvalue from config c where upper(c.name) = 'TAXSUBJECT_ID')      
       group by a.seqnom, a.taxdoc_id  
       order by ime, a.seqnom;
  -- municipality logo

     logo cursor (vUser_id numeric) is
      select coalesce(m1.fullname,m.fullname) fullname, coalesce(m1.ebk_code,m.ebk_code) ebk_code,
             case when m1.municipality_id is not null then m.fullname else null end region,             
             getaddress(ts.present_clientaddr_id) addr,
             m.municipality_id
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      left outer join config c on m.municipality_id = c.municipality_id
      left outer join taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id
      where u.user_id = vUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';


  -- message

  message cursor(vGroupaction_id numeric, vtaxsubject_id numeric, vtaxperiod_id numeric) is

    select distinct --         ('���������') Label,

                     ('������: ' || p.name) province,

                    ('������: ' || m.fullname) municipality,

                    ('���������� ��.�  ' || td.docno || '/' ||

                     to_char(td.doc_date, 'dd.mm.yyyy') || ' �.') msgnum,

                    dt.docname, ds.document_id, act.seqnom,

                    -- TaxSubject

                    (select d.value

                      from   decode d

                      where  upper(d.columnname) = 'KIND_IDN'

                      and    d.code = ts.kind_idn) || ' ' || ts.idn idn,

                    ('���: ' || ts.name) tsname,

                    ('������� ������: ' || ts.taxsubjectno) taxsubj,

                    ('�����: ' || GetAddress(ts.present_clientaddr_id)) tsaddr,

                    ('������: ' ||

                    (select mu.fullname
                          from municipality mu inner join Address adr on mu.municipality_id = adr.municipality_id
                         where adr.address_id = ts.post_clientaddr_id)) tsmunicipality,

                    -- TaxObject     

                    ('������� �: ' || td.partidano) partidano,

                    ('��� �� �����: ' ||

                     (select d.value

                       from   decode d

                       where  upper(d.columnname) = 'KINDPROPERTY'

                       and    d.code = tobj.kindproperty)) kindprop,

                    ('�����: ' || getaddress(tobj.address_id)) propaddr,

                    ('������:  ' ||

                     (select mu.fullname

                       from   municipality mu

                       where  mu.municipality_id = tobj.municipality_id)) objmunicipality

   from   Taxdoc td
      inner  join Taxobject tobj on td.taxobject_id = tobj.taxobject_id
      inner  join Documenttype dt on td.documenttype_id = dt.documenttype_id
      inner  join Debtsubject ds on td.taxdoc_id = ds.document_id
      left   outer join Taxsubject ts on coalesce(ds.taxsubject_id, td.taxsubject_id) = ts.taxsubject_id
      left   outer join Municipality m on td.municipality_id = m.municipality_id
      left   outer join Province p on m.province_id = p.province_id      
      inner  join (select min(a.seqnom) seqnom, a.taxsubject_id, a.taxdoc_id 
                     from action a 
                    where a.groupaction_id = vGroupaction_id 
                    group by a.taxsubject_id, a.taxdoc_id ) act on act.taxsubject_id = ts.taxsubject_id       
                                                               and act.taxdoc_id = td.taxdoc_id  
      where td.documenttype_id in (21,22) -- Decl 14, 17  
        and td.taxdoc_id = ds.document_id
        and ts.taxsubject_id = vtaxsubject_id
        and ds.taxperiod_id = vtaxperiod_id
      Order by act.seqnom;




  periods cursor(vTaxDoc_id numeric, vTaxSubject_id numeric, vtaxperiod_id numeric) is
 select distinct to_char(max(ds.tax_begidate), 'yyyy') taxperiod, 
                      max((select to_char(coalesce(sum(dp.sumval), 0), '9999999990.99')
                           from   Debtpartproperty dp
                           where  ds.debtsubject_id = dp.debtsubject_id
                           and    coalesce(ds.corrno, 0) =
                                  (select max(coalesce(ds_.corrno, 0))
                                    from   debtsubject ds_
                                    where  ds_.document_id = td.taxdoc_id
                                    and    ds_.taxsubject_id = ds.taxsubject_id
                                    and    coalesce(ds_.typecorr, 0) <> 2))) totalval,
                      ds.taxperiod_id, max(ds.doccode) doccode,
                      max(to_char(dis.termdisc, 'dd.mm.yyyy') || ' ' ||
                           (select to_char(di.termpay_date, 'dd.mm.yyyy')
                            from   debtinstalment di
                            where  di.debtsubject_id = ds.debtsubject_id
                            and    di.instno = '1')) period,
                      max(coalesce(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                                         from   debtinstalment di
                                                         where  di.debtsubject_id =
                                                                ds.debtsubject_id
                                                         and    di.instno = '4'),
                                                         trunc(current_date)), 0)) dis,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '1')) tdate1,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '2')) tdate2,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '3')) tdate3,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '4')) tdate4,
                      max(ds.debtsubject_id) debtsubj_id,
                      max(ds.parent_debtsubject_id) parent_debtsubject_id,
                      max(dr.name) kdrname
      from   TaxDoc td
      inner join Debtsubject ds on td.taxdoc_id = ds.document_id
                               and td.docno = ds.docno
                               and coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
                                   coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
      inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
      inner join kinddebtreg dr on ds.kinddebtreg_id = dr.kinddebtreg_id
      left outer join discount dis on td.documenttype_id = dis.documenttype_id
                                  and ds.taxperiod_id = dis.taxperiod_id
      where  td.taxdoc_id = vTaxDoc_id
        and  ds.taxsubject_id = vTaxSubject_id
        and  ds.prtdate is null
        and  ds.taxperiod_id = itaxperiod_id
      group  by ts.taxsubject_id, ds.taxperiod_id
      order  by taxperiod;

  -- installments   

  inst    cursor(vTaxDoc_id numeric, vTaxSubject_id numeric, vTaxPeriod_id numeric) is

    select (case when trim(dr.code) = '2400' then '���' else dr.name end) label1,

           ds.totaltax sumall, to_char(ds.tax_begidate, 'yyyy') taxperiod,

           (' �� ' || (select to_char(di.termpay_date, 'dd.mm.yyyy')

                        from   debtinstalment di

                        where  di.debtsubject_id = ds.debtsubject_id

                        and    di.instno = '1')) period,

           coalesce(sanction_pkg.tempdiscount((select di.debtinstalment_id

                                          from   debtinstalment di

                                          where  di.debtsubject_id =

                                                 ds.debtsubject_id

                                          and    di.instno = '4'), current_date),

                0.0) dis,

           coalesce((select di.instsum

                from   debtinstalment di

                where  di.debtsubject_id = ds.debtsubject_id

                and    di.instno = '1'), 0.00) v1,

           coalesce((select di.instsum

                from   debtinstalment di

                where  di.debtsubject_id = ds.debtsubject_id

                and    di.instno = '2'), 0.00) v2,

           coalesce((select di.instsum

                from   debtinstalment di

                where  di.debtsubject_id = ds.debtsubject_id

                and    di.instno = '3'), 0.00) v3,

           coalesce((select di.instsum

                from   debtinstalment di

                where  di.debtsubject_id = ds.debtsubject_id

                and    di.instno = '4'), 0.00) v4,

           coalesce((select to_char(di.termpay_date, 'dd.mm.yyyy')

                from   debtinstalment di

                where  di.debtsubject_id = ds.debtsubject_id

                and    di.instno = '4'), '') tdate2,

           coalesce((select coalesce(b.interestsum, 0.0) +

                        sanction_pkg.tempint(di.debtinstalment_id, current_date)

                from   debtinstalment di, baldebtinst b

                where  di.debtsubject_id = ds.debtsubject_id

                and    di.instno = '1'

                and    b.debtinstalment_id = di.debtinstalment_id), 0.00) lixv1,

           coalesce((select coalesce(b.interestsum, 0.0) +

                        sanction_pkg.tempint(di.debtinstalment_id, current_date)

                from   debtinstalment di, baldebtinst b

                where  di.debtsubject_id = ds.debtsubject_id

                and    di.instno = '2'

                and    b.debtinstalment_id = di.debtinstalment_id), 0.00) lixv2,

           coalesce((select coalesce(b.interestsum, 0.0) +

                        sanction_pkg.tempint(di.debtinstalment_id, current_date)

                from   debtinstalment di, baldebtinst b

                where  di.debtsubject_id = ds.debtsubject_id

                and    di.instno = '3'

                and    b.debtinstalment_id = di.debtinstalment_id), 0.00) lixv3,

           coalesce((select coalesce(b.interestsum, 0.0) +

                        sanction_pkg.tempint(di.debtinstalment_id, current_date)

                from   debtinstalment di, baldebtinst b

                where  di.debtsubject_id = ds.debtsubject_id

                and    di.instno = '4'

                and    b.debtinstalment_id = di.debtinstalment_id), 0.00) lixv4,

           ds.debtsubject_id

      from   TaxDoc td
             inner join Debtsubject ds on td.taxdoc_id = ds.document_id
                                      and ds.docno = td.docno
                                      and ds.doc_date = td.doc_date
             inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
             inner join kinddebtreg dr on ds.kinddebtreg_id = dr.kinddebtreg_id
      where  td.taxdoc_id = vTaxDoc_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    ds.taxperiod_id = vtaxperiod_id
      and    ds.prtdate is null
      order  by ds.tax_begidate, ds.kinddebtreg_id;


  offices cursor(vMunicipality_id numeric) is

    select o.fullname, coalesce(o.address, '') address

      from   Users u
             inner join Office o on o.office_id = u.office_id
      where  o.isactive = 1
      and    u.user_id = iUser_id;



  bank    cursor(vMunicipality_id numeric) is

    select b.name, a.iban, b.bic

      from   baccount a
             inner join bank b on b.bank_id = a.bank_id
      where  a.isactive = 1
      and    a.isbase = 1
      and    a.municipality_id = vMunicipality_id;


  --��� ��������� ������ ������������ �� �� ��������:
    --��� ��������� ������ ������������ �� �� ��������:
     currobl cursor(vTaxSubject_id numeric) is
      select min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
             inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
             inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
             inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <= TO_Date('01.05.2008', 'dd.mm.yyyy') --trunc(current_date)
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
             inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
             inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
             inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date > TO_Date('01.05.2008', 'dd.mm.yyyy') --trunc(current_date)
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 5, 4; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    currobl_rest cursor(vTaxSubject_id numeric) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.name) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id  
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id      
      where  --ds.partidano != vPartidaNo
             kdr.code not in ('2100','2400') 
      and    ds.taxsubject_id = vTaxSubject_id      
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.name),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id  
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id      
      where  --ds.partidano != vPartidaNo
             kdr.code not in ('2100','2400')
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_idsmpInt(di.debtinstalment_id,current_date),0),2)) obsto
  --��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������. 

  oversum          cursor(vTaxSubject_id numeric) is

    select max(kdr.fullname) taxname, max(kdr.acc) taxcode, os.partidano,

           sum(coalesce(boi.oversum, 0.0)) ndvn

      from   baloverinst boi
             inner join oversubject os on os.oversubject_id = boi.oversubject_id
             inner join kinddebtreg kdr on os.kinddebtreg_id = kdr.kinddebtreg_id
      where  os.taxsubject_id = vTaxSubject_id
      group  by os.partidano, os.kinddebtreg_id;


  promtbo          cursor(vdebtssubj_id numeric) is

    select p.debtsubject_id, p.taxperiod_id,

           case when sign(h.kindhomeobjreg_id - 6) = -1.0 then 0.0 else 1.0 end kod,

           min(p.promiltbo) promil

      from   debtpartproperty p inner join homeobj h on h.homeobj_id = p.homeobj_id
      where  p.debtsubject_id = vdebtssubj_id
      group  by p.debtsubject_id, p.taxperiod_id,
                case when sign(h.kindhomeobjreg_id - 6) = -1 then 0 else 1 end
      order  by p.debtsubject_id,
                case when sign(h.kindhomeobjreg_id - 6) = -1 then 0 else 1 end;



  i                numeric;

  vRest            varchar(300);

  vRest1           varchar(300);

  vMunicipality_id numeric;

  vSumDis          numeric(18, 2);

  vSumv1           numeric(18, 2);

  vSumv2           numeric(18, 2);

  vSumv3           numeric(18, 2);

  vSumv4           numeric(18, 2);

  vSumAll          numeric(18, 2);

  vSumLix          numeric(18, 2);

  vOperator        varchar(200);

  rowcount         integer;

  r                record;

  d                varchar;
  j numeric;

begin
    i := 1; -- �����
    j := 1;
    for rec in subject_fromto(iGroupactionId, iFromSeqNom, iTotalSeqNom) loop

  vSumDis := 0;

  vSumv1  := 0;

  vSumv2  := 0;

  vSumv3  := 0;

  vSumv4  := 0;

  vSumAll := 0;

  vRest   := '';

  vRest1  := '';
  j       := 1;
  
      if subject_fromto%rowcount > 1 then
        vPDPrt[i] := chr(13)||CHR(10);
        i := i + 1;
      end if;

    select u.username || '/' || u.fullname

    into   voperator

    from   users u

    where  u.user_id = iuser_id;

    vPDPrt [ i ] := center('���������', 80);

    i := i + 1;

      for log1 in logo(iUser_id) loop
        vMunicipality_id := log.municipality_id;
        vPDPrt[i] := rpadc(' ' || log.ebk_code || '  ������ ' || log.fullname, 80);

      i := i + 1;

    end loop;

    rowcount := 1;

   for msg in message(iGroupactionId, rec.taxsubject_id , iTaxPeriod_id) loop
        if message%rowcount > 1 then
         -- vPDPrt(i) := ' ';
         -- i := i + 1;
          if j > 60 then
            vPDPrt [ i ]  := chr(12);-- form feed character code 12(0xC in hexadecimal or '\f')
            i := i + 1;
            j := 1;
          end if;
        end if;
        vPDPrt [ i ]  := rpadc(' ' || msg.idn || '   ' || msg.partidano, 60) || lpadc(msg.seqnom , 30);


      vPDPrt [ i ] := rpadc(' -', 90, '-');

      i := i + 1;

    

      r := wordwrap(msg.tsname, 44, 1);

      vPDPrt [ i ] := r.return_val;

      vRest := r.strrest;

      vPDPrt [ i ] := '|' || rpadc(msg.kindprop, 44) || '|' ||

                      rpadc(vPDPrt [ i ], 44) || '|';

      i := i + 1;

      if (Length(vRest) > 1)

      then

        vPDPrt [ i ] := '|' || rpadc(msg.msgnum, 44) || '|' || rpadc(vRest, 44) || '|';

        i := i + 1;

      else

        vPDPrt [ i ] := '|' || rpadc(msg.msgnum, 44) || '|' || rpadc(' ', 44) || '|';

        i := i + 1;

      end if;

      r := wordwrap(msg.propaddr, 43, 1);

      vPDPrt [ i ] := r.return_val;

      vRest := r.strrest;

      r := wordwrap(msg.tsaddr, 44, 1);

      XXX := r.return_val;

      vRest1 := r.strrest;

      vPDPrt [ i ] := '|' || rpadc(vPDPrt [ i ], 44) || '|' || rpadc(XXX, 44) || '|';

      i := i + 1;

      if ((Length(vRest) > 1) or (Length(vRest1) > 1))

      then

        vPDPrt [ i ] := '|' || rpadc(case

                                       when vRest is null then

                                        ' '

                                       else

                                        vRest

                                     end, 44) || '|' ||

                        rpadc(case

                                when vRest1 is null then

                                 ' '

                                else

                                 vRest1

                              end, 44) || '|';

        i := i + 1;

      end if;

      vPDPrt [ i ] := '|' || rpadc(msg.objmunicipality, 44) || '|' ||

                      rpadc(msg.tsmunicipality, 44) || '|';

      i := i + 1;

      vPDPrt [ i ] := '|' || rpad(' ', 44) || '|' || rpad(' ', 44) || '|';

      i := i + 1;

      vPDPrt [ i ] := '|' || rpadc('-', 89, '-') || '|';

      i := i + 1;

      for per_rec in periods(msg.Document_id, rec.taxsubject_id)

      loop

        vSumDis := 0;

        vSumv1 := 0;

        vSumv2 := 0;

        vSumv3 := 0;

        vSumv4 := 0;

        vSumAll := 0;

        vSumLix := 0;

        vPDPrt [ i ] := ' ';

        for promtbo_rec in promtbo(per_rec.debtsubj_id)

        loop

          if coalesce(promtbo_rec.promil, 0.0) > 0

          then

           vPDPrt[i] := '|' ||   case when promtbo_rec.kod = 0 then '������� ����� ' else '��������� ����� ' end ||
                      coalesce(promtbo_rec.promil, 0) || '   ';
              --into   vPDPrt[i]
              --from   dual;

          end if;

        end loop;

        if vPDPrt [ i ] <> ' '

        then

          vPDPrt [ i ] := '|' || rpadc('������� �� ��� :' || vPDPrt [ i ], 89) || '|';

          i := i + 1;

          vPDPrt [ i ] := '|' || rpadc('-', 89, '-') || '|';

          i := i + 1;

        end if;

        --      vPDPrt[i]  := rpadc(' ------------------------------------------------',90,'-');

        --      i          := i + 1;

        vPDPrt [ i ] :=  '|' || '������� ������:      ' || '|' || 
                       rpadc(' ', 35) || '|' ||
                       rpadc(' ', 31) || '|';

        i := i + 1;

        vPDPrt [ i ] := '|' || lpadc(per_rec.totalval, 21) || '|' ||
                       lpadc('� ��������  I ������        ', 35) || '|' ||
                       lpadc(' II ������            ', 31) || '|';

        i := i + 1;

        vPDPrt [ i ] :=  '|' || rpadc('���������� ��        |           ���� �� �������         |        ���� �� �������         ', 89) || '|';

        i := i + 1;

        vPDPrt [ i ] :=  '|' || lpadc(per_rec.taxperiod || ' � ����', 20) || ' |' ||
                       lpadc(per_rec.period||'       ', 34, ' ') || ' |' ||
                       lpadc(per_rec.tdate2||'          ', 31) || '|';

        i := i + 1;

        vPDPrt [ i ] := '|' || rpadc('-', 89, '-') || '|';

        i := i + 1;

        -- Installments    

           for inst_rec in inst(msg.document_id, rec.taxsubject_id, itaxperiod_id)

        loop

          vPDPrt [ i ] :=  '|' || rpadc(inst_rec.label, 10) ||
                         lpadc(to_char(inst_rec.sumall, '9999990.99'), 11) || '|' ||
                         lpadc(to_char(inst_rec.sumall - coalesce(inst_rec.dis, 0),'999999990.99'), 12, ' ') ||
                         lpadc(to_char(coalesce(inst_rec.v1, 0), '9999990.99'), 22) || ' |' ||
                         lpadc(to_char(coalesce(inst_rec.v2, 0), '9999990.99'), 30) || ' |';

          i := i + 1;

          vSumLix := coalesce(inst_rec.lixv1, 0.0) + coalesce(inst_rec.lixv2, 0.0) +

                     coalesce(inst_rec.lixv3, 0.0) + coalesce(inst_rec.lixv4, 0.0);

          if vSumLix > 0

          then

            vPDPrt [ i ] := '|' || rpadc('�����', 10) ||
                           lpadc(to_char(vSumLix, '9990.99'), 11) || '|' ||
                           lpadc(to_char(coalesce(inst_rec.dis, 0), '999999990.99'), 12) ||
                           lpadc(to_char(coalesce(inst_rec.lixv1, 0), '9999990.99'), 22) || ' |' ||
                           lpadc(to_char(coalesce(inst_rec.lixv2, 0), '9999990.99'), 30) || ' |';


            i := i + 1;

          end if;

          vPDPrt [ i ] := '|' || rpadc('-', 89, '-') || '|';

          i := i + 1;

          vSumAll := vSumAll + inst_rec.sumall + vSumLix;

          vSumDis := vSumDis + coalesce(inst_rec.dis, 0.0);

          vSumv1 := vSumv1 + coalesce(inst_rec.v1, 0.0) + coalesce(inst_rec.lixv1, 0.0);

          vSumv2 := vSumv2 + coalesce(inst_rec.v2, 0.0) + coalesce(inst_rec.lixv2, 0.0);

          vSumv3 := vSumv3 + coalesce(inst_rec.v3, 0.0) + coalesce(inst_rec.lixv3, 0.0);

          vSumv4 := vSumv4 + coalesce(inst_rec.v4, 0.0) + coalesce(inst_rec.lixv4, 0.0);

        end loop;

        vPDPrt [ i ] := '|' || rpadc(' ������ ', 10) ||
                       lpadc(to_char(vSumAll, '9999990.99'), 11) || '|' ||
                       lpadc(to_char(coalesce(vSumDis, 0), '999999990.99'), 12) ||
                       lpadc(to_char(coalesce(vSumv1, 0), '99999990.99'), 22) || ' |' ||
                       lpadc(to_char(coalesce(vSumv2, 0), '99999990.99'), 30) || ' |';

        i := i + 1;

        vPDPrt [ i ] := '|' || rpadc('-', 89, '-') || '|';

        i := i + 1;

      end loop;

      for rec in offices(vMunicipality_id)

      loop

        d := rec.address;

        r := wordwrap('K���: ' || rec.address, 43, 1);

        vPDPrt [ i ] := r.return_val;

        vrest := r.strrest;

        vPDPrt [ i ] := '|' || rpadc(' ���� �� ���������:', 44) || '|' ||

                        rpadc(vPDPrt [ i ], 44) || '|';

        i := i + 1;

        if (Length(vRest) > 1)

        then

          vPDPrt [ i ] := '|' || rpadc(' �� ����', 44) || '|' ||

                          rpadc(vRest, 44) || '|';

          i := i + 1;

        else

          vPDPrt [ i ] := '|' || rpadc(' �� ����', 44) || '|' || rpadc(' ', 44) || '|';

          i := i + 1;

        end if;

      end loop;

      for bank_rec in bank(vMunicipality_id)

      loop

        vPDPrt [ i ] := '|' ||

                        rpadc(' ��� ����� �������� ���� � �������� �����', 44) || '|' ||

                        rpadc(bank_rec.name, 44) || '|';

        i := i + 1;

        vPDPrt [ i ] := '|' || rpadc(' �� ������� �������', 44) || '|' ||

                        rpadc('IBAN: ' || bank_rec.iban || '  BIC: ' ||

                              bank_rec.bic, 44) || '|';

        i := i + 1;

        vPDPrt [ i ] := '|' || rpadc(' �� ������ ���', 44) || '|' ||

                        rpadc('��� ������� 442100 /����� ����.����/', 44) || '|';

        i := i + 1;

        vPDPrt [ i ] := '|' || rpadc(' ���� ��������', 44) || '|' ||

                        rpadc('��� ������� 442400 /����� ���.���./', 44) || '|';

        i := i + 1;

      end loop;

      vPDPrt [ i ] := rpadc(' -', 90, '-');

      i := i + 1;

    end loop;

    vPDPrt [ i ] := '���� �������� �� ����� �� ��������� ����� ����������� ���������� �� ��������� �����! ����������';

    i := i + 1;

    vPDPrt [ i ] := '�� ��������� ������ �������� �� ������ �� �����, �� ����� ������ � ������� ���������.';

    i := i + 1;

  

    if iRecap = 1
    then
       vPDPrt [ i ] := ' ';
       i := i + 1;
       for obl in currobl_rest(rec.taxsubject_id) loop
        if (obl.obsto > 0)

        then

          vPDPrt [ i ] := ' ��� ��������� ������ ����� �������� ����������:';

          i := i + 1;

          vPDPrt [ i ] := rpadc(' -', 90, '-');

          i := i + 1;

          vPDPrt [ i ] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';

          i := i + 1;

          vPDPrt [ i ] := rpadc(' -', 90, '-');

          i := i + 1;

          exit;

        end if;

      end loop;

        for obl in currobl_rest(rec.taxsubject_id)

      loop

        if (obl.obsto > 0)

        then

          vPDPrt [ i ] := '|' || rpadc(obl.termpay_date, 10) || '|' ||

                          rpadc(obl.taxname, 25) || '|' ||

                          rpadc(obl.taxcode, 6) || '|' ||

                          rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||

                          lpadc(to_char(obl.gl, '9990.99'), 10) || '|' ||

                          lpadc(to_char(obl.lix, '990.99'), 7) || '|' ||

                          lpadc(to_char(obl.obsto, '99990.99'), 11) || '|';

          i := i + 1;

        end if;

      end loop;

      for obl in currobl_rest(rec.taxsubject_id)

      loop

        if (obl.obsto > 0)

        then

          vPDPrt [ i ] := rpadc(' -', 90, '-');

          i := i + 1;

          exit;

        end if;

      end loop;

      vPDPrt [ i ] := '';

      i := i + 1;

      for ovr in oversum(rec.taxsubject_id)

      loop

        if (ovr.ndvn > 0)

        then

          vPDPrt [ i ] := ' ��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.';

          i := i + 1;

          vPDPrt [ i ] := rpadc(' -', 60, '-');

          i := i + 1;

          vPDPrt [ i ] := '|     ��� ����������      |��� ��|    �������   |    ����   |';

          i := i + 1;

          vPDPrt [ i ] := rpadc(' -', 60, '-');

          i := i + 1;

          exit;

        end if;

      end loop;

      for ovr in oversum(rec.taxsubject_id)

      loop

        if (ovr.ndvn > 0)

        then

          vPDPrt [ i ] := '|' || rpadc(ovr.taxname, 25) || '|' ||

                          rpadc(ovr.taxcode, 6) || '|' ||

                          rpadc(coalesce(ovr.partidano, ' '), 14) || '|' ||

                          lpadc(to_char(ovr.ndvn, '99990.99'), 11) || '|';

          i := i + 1;

        end if;

      end loop;

      for ovr in oversum(rec.taxsubject_id)

      loop

        if (ovr.ndvn > 0)

        then

          vPDPrt [ i ] := rpadc(' -', 60, '-');

          i := i + 1;

          vPDPrt [ i ] := '';

          i := i + 1;
	
          exit;

        end if;

      end loop;

    end if;

    vPDPrt [ i ] := '';

  


  end loop;


  vPD_lob := paydocument_pkg.tblToLob(vPDPrt);



  --commit;

  return_val := 'OK';

  return;

exception

  when others then

    begin

      --rollback;

      perform NOM_PKG.ErrManage(ErrMsg);

      return_val := ErrMsg;

      return;

    

    end;

end;
$function$
; DROP FUNCTION paydocument_pkg.massmsgd14xml(numeric, numeric, character varying, character varying, integer, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.massmsgd14xml(OUT return_val character varying, igroupactionid numeric, itaxperiod_id numeric, ifromseqnom character varying, itotalseqnom character varying, irecap integer, iuser_id numeric, OUT vxmlmess text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
    vPDPrt varchar[];
    vPD_lob text;
    ErrMsg character varying(300);
    XXX    character varying(300);
     subject_fromto cursor(vGroupactionId numeric, vFromSeqNom character varying, vTotalSeqNom character varying) is
        select a.seqnom, max(ts.taxsubject_id) taxsubject_id, 
               max(ts.idn) idn, max(ts.name) ime, max(getaddress(ts.present_clientaddr_id)) address,        
               count(a.taxdoc_id) brojImoti   
          from action a
               inner join taxsubject ts on a.taxsubject_id = ts.taxsubject_id
         where a.seqnom >= vFromSeqNom and a.seqnom <= (vTotalSeqNom + vFromSeqNom - 1)  
           and a.groupaction_id = vGroupactionId
           and ts.taxsubject_id != to_numeric((select c.configvalue from config c where upper(c.name) = 'TAXSUBJECT_ID'))      
         group by a.seqnom, a.taxdoc_id  
         order by ime, a.seqnom;
    -- municipality logo
     logo cursor(vUser_id numeric) is
      select nvl(m1.fullname,m.fullname) fullname, nvl(m1.ebk_code,m.ebk_code) ebk_code,
             case when m1.municipality_id is not null then m.fullname else null end region,             
             getaddress(ts.present_clientaddr_id) addr,
             m.municipality_id
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      left outer join config c on m.municipality_id = c.municipality_id
      left outer join taxsubject ts on to_numeric(c.configvalue) = ts.taxsubject_id
      where u.user_id = vUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';
    -- message
     message cursor(vGroupaction_id numeric, vtaxsubject_id numeric, vtaxperiod_id numeric) is
      select distinct --         ('���������') Label,
                      ('������: ' || p.name) province,
                      ('������: ' || m.fullname) municipality,
                      ('���������� ��.�  ' || td.docno || '/' ||
                       to_char(td.doc_date, 'dd.mm.yyyy') || ' �.') msgnum,
                      dt.docname, ds.document_id, act.seqnom,
                      -- TaxSubject
                      (select d.value
                        from   decode d
                        where  upper(d.columnname) = 'KIND_IDN'
                        and    d.code = ts.kind_idn) || ' ' || ts.idn idn,
                      ('���: ' || ts.name) tsname,
                      ('������� ������: ' || ts.taxsubjectno) taxsubj,
                      ('�����: ' || GetAddress(ts.post_clientaddr_id)) tsaddr,
                      ('������: ' ||
                       (select mu.fullname
                          from municipality mu inner join Address adr on mu.municipality_id = adr.municipality_id
                         where adr.address_id = ts.post_clientaddr_id)) tsmunicipality,
                      -- TaxObject
                      ('������� �: ' || td.partidano) partidano,
                      td.partidano partidanom,
                      ('��� �� �����: ' ||
                       (select d.value
                         from   decode d
                         where  upper(d.columnname) = 'KINDPROPERTY'
                         and    d.code = tobj.kindproperty)) kindprop,
                      ('�����: ' || getaddress(tobj.address_id)) propaddr,
                      ('������:  ' ||
                       (select mu.fullname
                         from   municipality mu
                         where  mu.municipality_id = tobj.municipality_id)) objmunicipality
      from   Taxdoc td
      inner  join Taxobject tobj on td.taxobject_id = tobj.taxobject_id
      inner  join Documenttype dt on td.documenttype_id = dt.documenttype_id
      inner  join Debtsubject ds on td.taxdoc_id = ds.document_id
      left   outer join Taxsubject ts on nvl(ds.taxsubject_id, td.taxsubject_id) = ts.taxsubject_id
      left   outer join Municipality m on td.municipality_id = m.municipality_id
      left   outer join Province p on m.province_id = p.province_id      
      inner  join (select min(a.seqnom) seqnom, a.taxsubject_id, a.taxdoc_id 
                     from action a 
                    where a.groupaction_id = vGroupaction_id 
                    group by a.taxsubject_id, a.taxdoc_id ) act on act.taxsubject_id = ts.taxsubject_id       
                                                               and act.taxdoc_id = td.taxdoc_id  
      where td.documenttype_id in (21,22) -- Decl 14, 17  
        and td.taxdoc_id = ds.document_id
        and ts.taxsubject_id = vtaxsubject_id
        and ds.taxperiod_id = vtaxperiod_id
      Order by act.seqnom;

     periods cursor(vTaxDoc_id numeric, vTaxSubject_id numeric) is
      select distinct to_char(max(ds.tax_begidate), 'yyyy') taxperiod, 
                      max((select to_char(nvl(sum(dp.sumval), 0), '9999999990.99')
                           from   Debtpartproperty dp
                           where  ds.debtsubject_id = dp.debtsubject_id
                           and    nvl(ds.corrno, 0) =
                                  (select max(nvl(ds_.corrno, 0))
                                    from   debtsubject ds_
                                    where  ds_.document_id = td.taxdoc_id
                                    and    ds_.taxsubject_id = ds.taxsubject_id
                                    and    nvl(ds_.typecorr, 0) <> 2))) totalval,
                      ds.taxperiod_id, max(ds.doccode) doccode,
                      max(to_char(dis.termdisc, 'dd.mm.yyyy') || ' ' ||
                           (select to_char(di.termpay_date, 'dd.mm.yyyy')
                            from   debtinstalment di
                            where  di.debtsubject_id = ds.debtsubject_id
                            and    di.instno = '1')) period,
                      max(nvl(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                                         from   debtinstalment di
                                                         where  di.debtsubject_id =
                                                                ds.debtsubject_id
                                                         and    di.instno = '4'),
                                                         trunc(sysdate)), 0)) dis,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '1')) tdate1,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '2')) tdate2,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '3')) tdate3,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '4')) tdate4,
                      max(ds.debtsubject_id) debtsubj_id,
                      max(ds.parent_debtsubject_id) parent_debtsubject_id,
                      max(dr.name) kdrname
      from   TaxDoc td
      inner join Debtsubject ds on td.taxdoc_id = ds.document_id
                               and td.docno = ds.docno
                               and nvl(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
                                   nvl(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
      inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
      inner join kinddebtreg dr on ds.kinddebtreg_id = dr.kinddebtreg_id
      left outer join discount dis on td.documenttype_id = dis.documenttype_id
                                  and ds.taxperiod_id = dis.taxperiod_id
      where  td.taxdoc_id = vTaxDoc_id
        and  ds.taxsubject_id = vTaxSubject_id
        and  ds.prtdate is null
        and  ds.taxperiod_id = itaxperiod_id
      group  by ts.taxsubject_id, ds.taxperiod_id
      order  by taxperiod;
    -- installments
     inst cursor(vTaxDoc_id numeric, vTaxSubject_id numeric, vTaxPeriod_id numeric) is
      select decode(trim(dr.code), '2400', '���', dr.name) label1,
             ds.totaltax sumall, to_char(ds.tax_begidate, 'yyyy') taxperiod,
             (' �� ' || (select to_char(di.termpay_date, 'dd.mm.yyyy')
                          from   debtinstalment di
                          where  di.debtsubject_id = ds.debtsubject_id
                          and    di.instno = '1')) period,
             nvl(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                            from   debtinstalment di
                                            where  di.debtsubject_id =
                                                   ds.debtsubject_id
                                            and    di.instno = '4'),
                                            trunc(sysdate)), 0) dis,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '1') v1,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2') v2,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '3') v3,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '4') v4,
             (select to_char(di.termpay_date, 'dd.mm.yyyy')
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '4') tdate2,
             (select nvl(b.interestsum, 0) +
                       sanction_pkg.tempint(di.debtinstalment_id, trunc(sysdate))
               from   debtinstalment di, baldebtinst b
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '1'
               and    b.debtinstalment_id = di.debtinstalment_id) lixv1,
             (select nvl(b.interestsum, 0) +
                       sanction_pkg.tempint(di.debtinstalment_id, trunc(sysdate))
               from   debtinstalment di, baldebtinst b
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2'
               and    b.debtinstalment_id = di.debtinstalment_id) lixv2,
             (select nvl(b.interestsum, 0) +
                       sanction_pkg.tempint(di.debtinstalment_id, trunc(sysdate))
               from   debtinstalment di, baldebtinst b
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '3'
               and    b.debtinstalment_id = di.debtinstalment_id) lixv3,
             (select nvl(b.interestsum, 0) +
                       sanction_pkg.tempint(di.debtinstalment_id, trunc(sysdate))
               from   debtinstalment di, baldebtinst b
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '4'
               and    b.debtinstalment_id = di.debtinstalment_id) lixv4,
             ds.debtsubject_id
      from   TaxDoc td
             inner join Debtsubject ds on td.taxdoc_id = ds.document_id
                                      and ds.docno = td.docno
                                      and ds.doc_date = td.doc_date
             inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
             inner join kinddebtreg dr on ds.kinddebtreg_id = dr.kinddebtreg_id
      where  td.taxdoc_id = vTaxDoc_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    ds.taxperiod_id = vtaxperiod_id
      and    ds.prtdate is null
      order  by ds.tax_begidate, ds.kinddebtreg_id;
     offices cursor(vMunicipality_id numeric) is
      select o.fullname, nvl(o.address, '') address
      from   Users u
             inner join Office o on o.office_id = u.office_id
      where  o.isactive = 1
      and    u.user_id = iUser_id;
     bank cursor(vMunicipality_id numeric) is
      select b.name, a.iban, b.bic
      from   baccount a
             inner join bank b on b.bank_id = a.bank_id
      where  a.isactive = 1
      and    a.isbase = 1
      and    a.municipality_id = vMunicipality_id;
    --��� ��������� ������ ������������ �� �� ��������:
     currobl cursor(vTaxSubject_id numeric) is
      select min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(nvl(bdi.instsum, 0)) gl,
             sum(round(nvl(bdi.interestsum, 0) +
                        nvl(sanction_pkg.TempInt(di.debtinstalment_id, sysdate),
                            0), 2)) lix,
             sum(nvl(bdi.instsum, 0) +
                  round(nvl(bdi.interestsum, 0) +
                        nvl(sanction_pkg.TempInt(di.debtinstalment_id, sysdate),
                            0), 2)) obsto
      from   debtsubject ds
             inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
             inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
             inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <= TO_Date('01.05.2008', 'dd.mm.yyyy') --trunc(sysdate)
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(nvl(bdi.instsum, 0)) gl,
             sum(round(nvl(bdi.interestsum, 0) +
                        nvl(sanction_pkg.TempInt(di.debtinstalment_id, sysdate),
                            0), 2)) lix,
             sum(nvl(bdi.instsum, 0) +
                  round(nvl(bdi.interestsum, 0) +
                        nvl(sanction_pkg.TempInt(di.debtinstalment_id, sysdate),
                            0), 2)) obsto
      from   debtsubject ds
             inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
             inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
             inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date > TO_Date('01.05.2008', 'dd.mm.yyyy') --trunc(sysdate)
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 5, 4; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
     currobl_rest cursor(vTaxSubject_id numeric) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.name) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(nvl(bdi.instsum, 0)) gl,
             sum(round(nvl(bdi.interestsum, 0) +
                        nvl(sanction_pkg.TempInt(di.debtinstalment_id, sysdate),
                            0), 2)) lix,
             sum(nvl(bdi.instsum, 0) +
                  round(nvl(bdi.interestsum, 0) +
                        nvl(sanction_pkg.TempInt(di.debtinstalment_id, sysdate),
                            0), 2)) obsto
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id  
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id      
      where  --ds.partidano != vPartidaNo
             kdr.code not in ('2100','2400') 
      and    ds.taxsubject_id = vTaxSubject_id      
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.name),
             max(kdr.acc), ds.partidano, sum(nvl(bdi.instsum, 0)) gl,
             sum(round(nvl(bdi.interestsum, 0) +
                        nvl(sanction_pkg.TempInt(di.debtinstalment_id, sysdate),
                            0), 2)) lix,
             sum(nvl(bdi.instsum, 0) +
                  round(nvl(bdi.interestsum, 0) +
                        nvl(sanction_pkg.TempInt(di.debtinstalment_id, sysdate),
                            0), 2)) obsto
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id  
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id      
      where  --ds.partidano != vPartidaNo
             kdr.code not in ('2100','2400')
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_idsmpInt(di.debtinstalment_id,sysdate),0),2)) obsto
    --��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.
     oversum cursor(vTaxSubject_id numeric) is
      select max(kdr.fullname) taxname, max(kdr.acc) taxcode, os.partidano,
             sum(nvl(boi.oversum, 0)) ndvn
      from   baloverinst boi
             inner join oversubject os on os.oversubject_id = boi.oversubject_id
             inner join kinddebtreg kdr on os.kinddebtreg_id = kdr.kinddebtreg_id
      where  os.taxsubject_id = vTaxSubject_id
      group  by os.partidano, os.kinddebtreg_id;
     promtbo cursor(vdebtssubj_id numeric) is
      select p.debtsubject_id, p.taxperiod_id,
             decode(sign(h.kindhomeobjreg_id - 6), -1, 0, 1) kod,
             min(p.promiltbo) promil
      from   debtpartproperty p inner join homeobj h on h.homeobj_id = p.homeobj_id
      where  p.debtsubject_id = vdebtssubj_id
      group  by p.debtsubject_id, p.taxperiod_id,
                decode(sign(h.kindhomeobjreg_id - 6), -1, 0, 1)
      order  by p.debtsubject_id,
                decode(sign(h.kindhomeobjreg_id - 6), -1, 0, 1);
    i                numeric;
    j                numeric;
    vRest            character varying(300);
    vRest1           character varying(300);
    vMunicipality_id numeric;
    vSumDis          numeric(18, 2);
    vSumv1           numeric(18, 2);
    vSumv2           numeric(18, 2);
    vSumv3           numeric(18, 2);
    vSumv4           numeric(18, 2);
    vSumAll          numeric(18, 2);
    vSumLix          numeric(18, 2);
    vOperator        character varying(200);
    xmlmass14        xml;    
    r record;
  begin
    i := 1; -- �����
    j := 1;
    for rec in subject_fromto(iGroupactionId, iFromSeqNom, iTotalSeqNom) loop
      vSumDis := 0;
      vSumv1  := 0;
      vSumv2  := 0;
      vSumv3  := 0;
      vSumv4  := 0;
      vSumAll := 0;
      vRest   := '';
      vRest1  := '';
      j       := 1;
      if subject_fromto%rowcount > 1 then
        vPDPrt[i] := chr(12);-- form feed character code 12(0xC in hexadecimal or '\f')
        i := i + 1;        
        vPDPrt[i] := ''; -- Line Feed
        i := i + 1;
      end if;
      select u.username || '/' || u.fullname
      into   voperator
      from   users u
      where  u.user_id = iuser_id;
      vPDPrt[i] := center('���������', 80);
      i := i + 1;
      for log1 in logo(iUser_id) loop
        vMunicipality_id := log1.municipality_id;
        vPDPrt[i] := rpadc(' ������ ' || log1.fullname, 80);
        i := i + 1;
      end loop;
      for msg in message(iGroupactionId, rec.taxsubject_id , iTaxPeriod_id) loop
        if message%rowcount > 1 then
         -- vPDPrt[i] := ' ';
         -- i := i + 1;
          if j > 60 then
            vPDPrt[i] := chr(12);-- form feed character code 12(0xC in hexadecimal or '\f')
            i := i + 1;
            j := 1;
          end if;
        end if;
        vPDPrt[i] := rpadc(' ' || msg.idn || '   ' || msg.partidano, 60) || lpadc(msg.seqnom , 30);
        i := i + 1;
        vPDPrt[i] := rpadc(' -', 90, '-');
        i := i + 1;
        r := wordwrap(vPDPrt[i], msg.tsname, 44, 1, vRest);
        vPDPrt[i] := r.return_val;
	vRest := r.strrest;

        vPDPrt[i] := '|' || rpadc(msg.kindprop, 44) || '|' ||
                     rpadc(vPDPrt[i], 44) || '|';
        i := i + 1;
        if (Length(vRest) > 1) then
          vPDPrt[i] := '|' || rpadc(msg.msgnum, 44) || '|' || rpadc(vRest, 44) || '|';
          i := i + 1;
        else
          vPDPrt[i] := '|' || rpadc(msg.msgnum, 44) || '|' || rpadc(' ', 44) || '|';
          i := i + 1;
        end if;
        r:=wordwrap(vPDPrt[i], msg.propaddr, 43, 1, vRest);
        vPDPrt[i] := r.return_val;
	vRest := r.strrest;
        r:=wordwrap(XXX, msg.tsaddr, 44, 1, vRest1);
        vPDPrt[i] := r.return_val;
	vRest1 := r.strrest;
        vPDPrt[i] := '|' || rpadc(vPDPrt[i], 44) || '|' || rpadc(XXX, 44) || '|';
        i := i + 1;
        if ((Length(vRest) > 1) or (Length(vRest1) > 1)) then
          vPDPrt[i] := '|' || rpadc(case when vRest is null then ' ' else vRest end, 44) || '|' ||
                              rpadc(case when vRest1 is null then ' ' else vRest1 end, 44) || '|';
          i := i + 1;
        end if;
        vPDPrt[i] := '|' || rpadc(msg.objmunicipality, 44) || '|' || rpadc(msg.tsmunicipality, 44) || '|';
        i := i + 1;
        vPDPrt[i] := '|' || rpad(' ', 44) || '|' || rpad(' ', 44) || '|';
        i := i + 1;
        vPDPrt[i] := '|' || rpadc('-', 89, '-') || '|';
        i := i + 1;
        for per_rec in periods(msg.Document_id, rec.taxsubject_id) loop
          vSumDis := 0;
          vSumv1 := 0;
          vSumv2 := 0;
          vSumv3 := 0;
          vSumv4 := 0;
          vSumAll := 0;
          vSumLix := 0;
          vPDPrt[i] := ' ';
          for promtbo_rec in promtbo(per_rec.debtsubj_id) loop
            if nvl(promtbo_rec.promil, 0) > 0 then
              vPDPrt[i]:= '' || decode(promtbo_rec.kod, 0, '������� ����� ', '��������� ����� ') ||
                      nvl(promtbo_rec.promil, 0) || '   ';
              
              

            end if;
          end loop;
          if vPDPrt[i] <> ' ' then
            vPDPrt[i] := '|' || rpadc('������� �� ��� :' || vPDPrt[i], 89) || '|';
            i := i + 1;
            vPDPrt[i] := '|' || rpadc('-', 89, '-') || '|';
            i := i + 1;
          end if;
          --      vPDPrt[i]  := rpadc(' ------------------------------------------------',90,'-');
          --      i          := i + 1;
          vPDPrt[i] := '|' || '������� ������:      ' || '|' || 
                       rpadc(' ', 35) || '|' ||
                       rpadc(' ', 31) || '|';
          i := i + 1;
          vPDPrt[i] := '|' || lpadc(per_rec.totalval, 21) || '|' ||
                       lpadc('� ��������  I ������        ', 35) || '|' ||
                       lpadc(' II ������            ', 31) || '|';
          i := i + 1;
          vPDPrt[i] := '|' || rpadc('���������� ��        |           ���� �� �������         |        ���� �� �������         ', 89) || '|';
          i := i + 1;
          vPDPrt[i] := '|' || lpadc(per_rec.taxperiod || ' � ����', 20) || ' |' ||
                       lpadc(per_rec.period||'       ', 34, ' ') || ' |' ||
                       lpadc(per_rec.tdate2||'          ', 31) || '|';
          i := i + 1;
          vPDPrt[i] := '|' || rpadc('-', 89, '-') || '|';
          i := i + 1;
          -- Installments
          for inst_rec in inst(msg.document_id, rec.taxsubject_id, itaxperiod_id) loop
            vPDPrt[i] := '|' || rpadc(inst_rec.label, 10) ||
                         lpadc(to_char(inst_rec.sumall, '9999990.99'), 11) || '|' ||
                         lpadc(to_char(inst_rec.sumall - nvl(inst_rec.dis, 0),'999999990.99'), 12, ' ') ||
                         lpadc(to_char(nvl(inst_rec.v1, 0), '9999990.99'), 22) || ' |' ||
                         lpadc(to_char(nvl(inst_rec.v2, 0), '9999990.99'), 30) || ' |';
            i := i + 1;
            vSumLix := nvl(inst_rec.lixv1, 0) + nvl(inst_rec.lixv2, 0) +
                       nvl(inst_rec.lixv3, 0) + nvl(inst_rec.lixv4, 0);
            if vSumLix > 0 then
              vPDPrt[i] := '|' || rpadc('�����', 10) ||
                           lpadc(to_char(vSumLix, '9990.99'), 11) || '|' ||
                           lpadc(to_char(nvl(inst_rec.dis, 0), '999999990.99'), 12) ||
                           lpadc(to_char(nvl(inst_rec.lixv1, 0), '9999990.99'), 22) || ' |' ||
                           lpadc(to_char(nvl(inst_rec.lixv2, 0), '9999990.99'), 30) || ' |';
              i := i + 1;
            end if;
            vPDPrt[i] := '|' || rpadc('-', 89, '-') || '|';
            i := i + 1;
            vSumAll := vSumAll + inst_rec.sumall + vSumLix;
            vSumDis := vSumDis + nvl(inst_rec.dis, 0);
            vSumv1 := vSumv1 + nvl(inst_rec.v1, 0) + nvl(inst_rec.lixv1, 0);
            vSumv2 := vSumv2 + nvl(inst_rec.v2, 0) + nvl(inst_rec.lixv2, 0);
          end loop;
          vPDPrt[i] := '|' || rpadc(' ������ ', 10) ||
                       lpadc(to_char(vSumAll, '9999990.99'), 11) || '|' ||
                       lpadc(to_char(nvl(vSumDis, 0), '999999990.99'), 12) ||
                       lpadc(to_char(nvl(vSumv1, 0), '99999990.99'), 22) || ' |' ||
                       lpadc(to_char(nvl(vSumv2, 0), '99999990.99'), 30) || ' |';
          i := i + 1;
          vPDPrt[i] := '|' || rpadc('-', 89, '-') || '|';
          i := i + 1;
        end loop;
        for rec in offices(vMunicipality_id) loop
          r:=wordwrap(vPDPrt[i], 'K���: ' || rec.address, 43, 1, vrest);
          vPDPrt[i] := r.return_val;
	  vRest := r.strrest;
          vPDPrt[i] := '|' || rpadc(' ���� �� ���������:', 44) || '|' || rpadc(vPDPrt[i], 44) || '|';
          i := i + 1;
          if (Length(vRest) > 1) then
            vPDPrt[i] := '|' || rpadc(' �� ����', 44) || '|' || rpadc(vRest, 44) || '|';
            i := i + 1;
          else
            vPDPrt[i] := '|' || rpadc(' �� ����', 44) || '|' || rpadc(' ', 44) || '|';
            i := i + 1;
          end if;
        end loop;
        for bank_rec in bank(vMunicipality_id) loop
          vPDPrt[i] := '|' ||
                       rpadc(' ��� ����� �������� ���� � �������� �����', 44) || '|' ||
                       rpadc(bank_rec.name, 44) || '|';
          i := i + 1;
          vPDPrt[i] := '|' || rpadc(' �� ������� �������', 44) || '|' ||
                       rpadc('IBAN: ' || bank_rec.iban || '  BIC: ' ||
                             bank_rec.bic, 44) || '|';
          i := i + 1;
          vPDPrt[i] := '|' || rpadc(' �� ������ ���', 44) || '|' ||
                       rpadc('��� ������� 442100 /����� ����.����/', 44) || '|';
          i := i + 1;
          vPDPrt[i] := '|' || rpadc(' ���� ��������', 44) || '|' ||
                       rpadc('��� ������� 442400 /����� ���.���./', 44) || '|';
          i := i + 1;
        end loop;
        vPDPrt[i] := rpadc(' -', 90, '-');
        i := i + 1;
        if mod(message%rowcount,2) = 0 then 
         j := i - j;
        end if;
      end loop;
      vPDPrt[i] := '���� �������� �� ����� �� ��������� ����� ����������� ���������� �� ��������� �����! ����������';
      i := i + 1;
      vPDPrt[i] := '�� ��������� ������ �������� �� ������ �� �����, �� ����� ������ � ������� ���������.';
      i := i + 1;

      if iRecap = 1 then
        vPDPrt[i] := ' ';
        i := i + 1;
        for obl in currobl_rest(rec.taxsubject_id) loop
          if (obl.obsto > 0) then
            vPDPrt[i] := ' ��� ��������� ������ ����� �������� ����������:';
            i := i + 1;
            vPDPrt[i] := rpadc(' -', 90, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' -', 90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl_rest(rec.taxsubject_id) loop
          if (obl.obsto > 0) then
            vPDPrt[i] := '|' || rpadc(obl.termpay_date, 10) || '|' ||
                         rpadc(obl.taxname, 25) || '|' ||
                         rpadc(obl.taxcode, 6) || '|' ||
                         rpadc(nvl(obl.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(obl.gl, '9990.99'), 10) || '|' ||
                         lpadc(to_char(obl.lix, '990.99'), 7) || '|' ||
                         lpadc(to_char(obl.obsto, '99990.99'), 11) || '|';
            i := i + 1;
          end if;
        end loop;
        for obl in currobl_rest(rec.taxsubject_id) loop
          if (obl.obsto > 0) then
            vPDPrt[i] := rpadc(' -', 90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        for ovr in oversum(rec.taxsubject_id) loop
          if (ovr.ndvn > 0) then
            vPDPrt[i] := ' ��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.';
            i := i + 1;
            vPDPrt[i] := rpadc(' -', 60, '-');
            i := i + 1;
            vPDPrt[i] := '|     ��� ����������      |��� ��|    �������   |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' -', 60, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for ovr in oversum(rec.taxsubject_id) loop
          if (ovr.ndvn > 0) then
            vPDPrt[i] := '|' || rpadc(ovr.taxname, 25) || '|' ||
                         rpadc(ovr.taxcode, 6) || '|' ||
                         rpadc(nvl(ovr.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(ovr.ndvn, '99990.99'), 11) || '|';
            i := i + 1;
          end if;
        end loop;
        for ovr in oversum(rec.taxsubject_id) loop
          if (ovr.ndvn > 0) then
            vPDPrt[i] := rpadc(' -', 60, '-');
            i := i + 1;
            vPDPrt[i] := '';
            i := i + 1;
            exit;
          end if;
        end loop;
      end if;
      vPDPrt[i] := '';

      --tblToLob(vPDPrt, vPD_lob);

      if (vPDPrt.COUNT > 0) then
        vPD_lob := to_clob(''); 
        for indx in j .. vPDPrt.COUNT loop
          vPD_lob := vPD_lob || TO_CHAR(vPDPrt(indx)) || chr(13) || chr(10);
        end loop;
        j := i;
      end if; 

      select xmlconcat(xmlmass14, 
                       xmlelement(name "��", Xmlattributes(rec.idn as "���"), 
                                        xmlelement(name "���������", Xmlattributes(rec.seqnom as "�����"), vPD_lob) )) 
        into xmlmass14 
        from dual;     


    end loop;

    select xmlelement(name "���������", xmlmass14)
      into xmlmass14
      from dual;        

    vXMlmess := to_clob('');
    select XMLSerialize(DOCUMENT XMLROOT ( xmlmass14 , VERSION '1.0', STANDALONE YES) AS CLOB)
      into vXMlmess
      from DUAL;

  -- tblToLob(vPDPrt, vPD_lob);
  -- vXMlmess := vXMlmess || vPD_lob; 
   -- select xmlmass14.getClobVal() into vXMlmess from dual;
    --vXMlmess := xmlmass14;

    commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        rollback;
       perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;

      end;
  end;
  
$function$
; DROP FUNCTION paydocument_pkg.messaged32(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.messaged32(OUT return_val character varying, itaxdoc_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                        

    vPDPrt varchar[];

    ErrMsg varchar(300);

  

    -- taxsubject report
    tsreport cursor(vTaxDoc_id numeric) is
      select max((select d.value
                  from   decode d
                  where  upper(d.columnname) = 'KIND_IDN'
                  and    d.code = ts.kind_idn)) kindidn, min(ts.idn) idn,
             min(ts.name) custname,
             to_char(sum(ds.totaltax), '99999990.99') sumall,
             max(to_char(ds.tax_begidate, 'yyyy')) taxperiod, ds.debtsubject_id
      from   debtsubject ds
      inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
      inner join taxdoc td on ds.document_id = td.taxdoc_id
                          and ds.docno = td.docno
                          and coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
                              coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
                          and ds.kinddoc = 1
      where
            --         ds.prtdate is null and
             td.taxdoc_id = vTaxDoc_id
      group  by ds.taxsubject_id, ds.debtsubject_id, ds.calcdate, coalesce(ds.corrno, 0)
      order  by custname, taxperiod;
    -- municipality logo
    logo cursor(vUser_id numeric) is
      select coalesce(m1.fullname,m.fullname) fullname,
             case when m1.municipality_id is not null then m.fullname else null end region,
             getaddress(ts.present_clientaddr_id) addr,
             m.municipality_id
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      left outer join config c on m.municipality_id = c.municipality_id
      left outer join taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id
      where u.user_id = vUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';
    -- message
    msg cursor(vTaxDoc_id numeric) is
      select distinct ('���������') Label1, ('������: ' || p.name) province,
                      ('������: ' || m.fullname) ts_municipality,
                      (td.docno || '/' || to_char(td.doc_date, 'dd.mm.yyyy') ||
                       ' �.') msgnum, dt.docname, ds.taxsubject_id, dt.doccode,
                      -- TaxSubject
                      (select d.value
                        from   decode d
                        where  upper(d.columnname) = 'KIND_IDN'
                        and    d.code = ts.kind_idn) || ' ' || ts.idn idn,
                      (ts.name) tsname,
                      ('������� ������: ' || ts.taxsubjectno) taxsubj,
                      ('������� �����: ' || tobj.taxobjno) taxobj,
                      ('�����: ' || GetAddress(ts.present_clientaddr_id)) Address,
                      -- TaxObject
                      ('�������: ' || td.partidano) partidano,
                      td.partidano partidanom,
                      ('��� �� �����: ' ||
                       (select d.value
                         from   decode d
                         where  upper(d.columnname) = 'KINDPROPERTY'
                         and    d.code = tobj.kindproperty)) kindprop,
                      ('����� �� �����: ' || getaddress(tobj.address_id)) propaddr,
                      ('���. N: ' || tobj.registerno) regno,
                      ('���.���: ' || tobj.registername) regname,
                      -- User
                      (u.fullname) operator1
      from Taxdoc td
      left outer join Debtsubject ds on td.taxdoc_id = ds.document_id
      inner join Taxsubject ts on  coalesce(ds.taxsubject_id, td.taxsubject_id) = ts.taxsubject_id
      inner join users u on td.user_id = u.user_id
      left outer join Taxobject tobj on td.taxobject_id = tobj.taxobject_id
      left outer join Documenttype dt on td.documenttype_id = dt.documenttype_id
      left outer join Address adr on adr.address_id = ts.present_clientaddr_id
      left outer join Municipality m on m.municipality_id = adr.municipality_id
      left outer join Province p on m.province_id = p.province_id
      where  td.taxdoc_id = vTaxDoc_id;
    -- tax installments
    inst cursor(vTaxDoc_id numeric, vTaxSubject_id numeric) is
      select to_char(coalesce(ds.totaltax, 0), '99990.99') sumall,
             to_char(ds.tax_begidate, 'yyyy') taxperiod,
             (' �� ' || (select to_char(di.termpay_date, 'dd.mm.yyyy')
                          from   debtinstalment di
                          where  di.debtsubject_id = ds.debtsubject_id
                          and    di.instno = '1')) period,
             coalesce(ds.totaltax, 0) -
              coalesce(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                            from   debtinstalment di
                                            where  di.debtsubject_id =
                                                   ds.debtsubject_id
                                            and    di.instno = '2'),
                                            trunc(current_date)), 0) dis,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '1') v1,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2') v2,
             (select to_char(di.termpay_date, 'dd.mm.yyyy')
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2') tdate2,
             --       (select di.instsum from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '4') v4
             ds.debtsubject_id
      from   TaxDoc td, Debtsubject ds, taxsubject ts
      where  td.taxdoc_id = vTaxDoc_id
      and    ds.taxsubject_id = vTaxSubject_id
      and
            --         ds.prtdate is null and
             td.taxdoc_id = ds.document_id
      and    ds.docno = td.docno
      and    coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
             coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
      and    ds.kinddoc = 1
      and    ds.taxsubject_id = ts.taxsubject_id
      order  by ds.tax_begidate;
    offices cursor(vMunicipality_id numeric) is
      select o.fullname, coalesce(o.address, '') address
      from   Users u, Office o
      where  o.isactive = 1
      and    o.office_id = u.office_id
      and    u.user_id = iUser_id;
    bank cursor(vMunicipality_id numeric) is
      select b.name, a.iban
      from   baccount a, bank b
      where  b.bank_id = a.bank_id
      and    a.isactive = 1
      and    a.isbase = 1
      and    a.municipality_id = vMunicipality_id;
    --��� ��������� ������ ������������ �� �� ��������:
    currobl cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds, debtinstalment di, baldebtinst bdi, kinddebtreg kdr
      where  ds.debtsubject_id = di.debtsubject_id
      and    ds.partidano = vPartidaNo
      and    di.debtinstalment_id = bdi.debtinstalment_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds, debtinstalment di, baldebtinst bdi, kinddebtreg kdr
      where  ds.debtsubject_id = di.debtsubject_id
      and    ds.partidano = vPartidaNo
      and    di.debtinstalment_id = bdi.debtinstalment_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    --��� ��������� ������ ������ �������� ���������� �� �� ��������:
    currobl_rest cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds, debtinstalment di, baldebtinst bdi, kinddebtreg kdr
      where  ds.debtsubject_id = di.debtsubject_id
      and    ds.partidano <> vPartidaNo
      and    di.debtinstalment_id = bdi.debtinstalment_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds, debtinstalment di, baldebtinst bdi, kinddebtreg kdr
      where  ds.debtsubject_id = di.debtsubject_id
      and    ds.partidano <> vPartidaNo
      and    di.debtinstalment_id = bdi.debtinstalment_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    --��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.
    oversum cursor(vTaxSubject_id numeric) is
      select max(kdr.fullname) taxname, max(kdr.acc) taxcode, os.partidano,
             sum(coalesce(boi.oversum, 0)) ndvn
      from   baloverinst boi, oversubject os, kinddebtreg kdr
      where  os.oversubject_id = boi.oversubject_id
      and    os.kinddebtreg_id = kdr.kinddebtreg_id
      and    os.taxsubject_id = vTaxSubject_id
      group  by os.partidano, os.kinddebtreg_id;

    i                numeric;

    vRest            varchar(300);

    vMunicipality_id numeric;

    vTaxCode         varchar(10);
    
    r record;

    d varchar;

    rowcount integer;

  begin

    if (iTaxDoc_id > 0) then

      i := 1; -- �����
      -- ======= Part 1 =========
      -- Report Obligations
      for msg_rec in msg(iTaxDoc_id) loop
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := center('������� �����', 70);
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.partidano, 42);
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.kindprop, 42);
        i := i + 1;
        r := wordwrap(msg_rec.propaddr, 70, 1);
        vPDPrt[i] := r.return_val;
        vrest := r.strrest;
        vPDPrt[i] := rpadc(vPDPrt[i], 80);
        i := i + 1;
        /*
        case trim(msg_rec.doccode)
        when '54P' then
          vPDPrt[i]  := rpadc(msg_rec.partidano,40);
          i          := i + 1;
          vPDPrt[i]  := rpadc('��� ��: '||msg_rec.kindpc,40)||rpadc(msg_rec.regname,38);
          i          := i + 1;
          vPDPrt[i]  := rpadc(msg_rec.crmark,40)||rpadc(msg_rec.regno,38);
          i          := i + 1;
        when '54V' then
          vPDPrt[i]  := rpadc(msg_rec.partidano,40);
          i          := i + 1;
          vPDPrt[i]  := rpadc('��� ��: '||msg_rec.kindpc,40)||rpadc(msg_rec.regname,38);
          i          := i + 1;
          vPDPrt[i]  := rpadc(msg_rec.crmark,40)||rpadc(msg_rec.regno,38);
          i          := i + 1;
        else
          vPDPrt[i]  := rpadc(msg_rec.partidano,40)||rpadc(msg_rec.motorno,38,' ');
          i          := i + 1;
          vPDPrt[i]  := rpadc('��� ��: '||msg_rec.kindpc,40)||rpadc(msg_rec.ramano,38);
          i          := i + 1;
          vPDPrt[i]  := rpadc(msg_rec.crmark,40)||rpadc(msg_rec.regno,38);
          i          := i + 1;
        end case; */
        exit;
      end loop;
      vPDPrt[i] := rpadc('����������', 70);
      i := i + 1;
      vPDPrt[i] := rpadc(' ---------------', 60, '-');
      i := i + 1;
      vPDPrt[i] := '| ���/�������� |      ���                |������|    �����  ' || '|';
      i := i + 1;
      vPDPrt[i] := rpadc(' ---------------', 60, '-');
      i := i + 1;
      for ts in tsreport(iTaxDoc_id)
      loop
        vPDPrt[i] := rpadc('| ' || ts.idn, 15) || '|' || rpadc(ts.custname, 25) || '|' ||
                     rpadc(ts.taxperiod, 6) || '|' || lpadc(ts.sumall, 11) || '|';
        i := i + 1;
        vPDPrt[i] := rpadc(' ---------------', 60, '-');
        i := i + 1;
      end loop;
      -- ======= End Part 1 =========

      -- ======= Part 2 =========
      vPDPrt[i] := 'ff';
      i := i + 1;
      vPDPrt[i] := 'p2';
      i := i + 1;
      -- !!!!!!!!!!!!!!!!!!!!!!
      rowcount := 1;
      for msg_rec in msg(iTaxDoc_id) loop
        if rowcount > 1
        then
          vPDPrt[i] := 'ff';
          i := i + 1;
          vPDPrt[i] := 'p2';
          i := i + 1;
        end if;
        rowcount := rowcount + 1;
        for logo_rec in logo(iUser_id) loop
          vMunicipality_id := logo_rec.municipality_id;
          vPDPrt[i] := rpadc(' ------------------------------------------------',80, '-');
          i := i + 1;
          if (logo_rec.region is not null) then
           vPDPrt[i] := center(logo_rec.fullname ||' '|| '������', 80);
           i := i + 1;
           vPDPrt[i] := center('�������� ������� � ������������� �� ���', 80);
           i := i + 1;
           vPDPrt[i] := center('����� ���', 80);
           i := i + 1;
           vPDPrt[i] := center('� � � � �  ' || upper(logo_rec.region), 80);
           i := i + 1;
          else
           vPDPrt[i] := center('� � � � � �  ' || logo_rec.fullname, 80);
           i := i + 1;
           vPDPrt[i] := center('������ ������ � �����', 80);
           i := i + 1;
          end if;
          vPDPrt[i] := center(logo_rec.addr, 80);
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------',80, '-');
          i := i + 1;
          vPDPrt[i] := '';
          i := i + 1;
        end loop;
        vPDPrt[i] := center('���������', 80);
        i := i + 1;
        vPDPrt[i] := center(msg_rec.msgnum, 80);
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := rpadc('������� ������� �����:', 42) || '��:';
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.partidano, 42) || rpadc(msg_rec.idn, 40);
        i := i + 1;
        vPDPrt[i] := rpadc('', 42) || rpadc('���:' || msg_rec.tsname, 38);
        i := i + 1;
        r := wordwrap(msg_rec.address, 37, 1);
        vPDPrt[i] := r.return_val;
        vrest := r.strrest;
        vPDPrt[i] := rpadc('', 42) || vPDPrt[i];
        if (Length(vRest) > 1)
        then
          i := i + 1;
          vPDPrt[i] := rpadc('', 42, ' ') || rpadc(vRest, 38, ' ');
        end if;
        i := i + 1;
        vPDPrt[i] := rpadc('', 42) || rpadc(msg_rec.ts_municipality, 38);
        i := i + 1;
        vPDPrt[i] := rpadc('  �������� ' || msg_rec.docname ||
                           ' �� ����,', 80);
        i := i + 1;
        vPDPrt[i] := rpadc('� ��.� ' || msg_rec.msgnum ||
                           ' �� �� ���������� �������� ������� ����������', 80,
                           ' ');
        /* if (msg_rec.partt <> '1') and (msg_rec.partt <> '1/1') then
         i          := i + 1;
         vPDPrt[i]  := rpadc('�� ������������ ' || msg_rec.partt || ' �� ' || msg_rec.kindpc,80,' ');
        end if; */
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        -- Installments
        for inst_rec in inst(iTaxDoc_id, msg_rec.taxsubject_id) loop
          vPDPrt[i] := rpadc(' ------------------------------------------------',
                             66, '-');
          i := i + 1;
          vPDPrt[i] := '   �����        |     ���� �� �������    |   ���� �� �������     ' || '|';
          i := i + 1;
          ----------------
          vPDPrt[i] := rpadc('    �� ' || inst_rec.taxperiod, 16) || '|' ||
                       rpadc(' � ��������  I ������ ', 24, ' ') || '|' ||
                       rpadc('         II ������', 23, ' ') || '|';
          ----------------
          i := i + 1;
          vPDPrt[i] := rpadc('     � ���� ', 16, ' ') || '|' ||
                       lpadc(inst_rec.period || ' ', 24, ' ') || '|' ||
                       lpadc(inst_rec.tdate2 || ' ', 20) || lpadc(' ', 3, ' ') || '|';
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------',
                             66, '-');
          i := i + 1;
          vPDPrt[i] := ' ���� ' || lpadc(inst_rec.sumall, 10) || '|' ||
                       lpadc(to_char(coalesce(inst_rec.dis, 0), '999990.99'), 10, ' ') ||
                       lpadc(to_char(coalesce(inst_rec.v1, 0), '999990.99'), 12, ' ') ||
                       lpadc(' ', 2, ' ') || '|' ||
                       lpadc(to_char(coalesce(inst_rec.v2, 0), '999990.99'), 20, ' ') ||
                       '   |';
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------',
                             66, '-');
          i := i + 1;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '���������� ��������� �� � ��������������� ��� � �� ������� �� ���������.';
        i := i + 1;
        /*  vPDPrt[i]  := '��� �� ��� �������� � ������������ �� ���������� ������ �� �������� �������� �� ';
        i          := i + 1;
        vPDPrt[i]  := '��� �� ������������ �� ������������ �� ������ ����� ������ �� ��������� � ';
        i          := i + 1;
        vPDPrt[i]  := '14-������ ���� �� ������������ ��.';
        i          := i + 1;*/
        vPDPrt[i] := '���� �������� �� ����� �� ��������� ����� ����������� ���������� �� ��������� �����!';
        i := i + 1;
        vPDPrt[i] := '���������� �� ������ �������� �� ������ �� �� �� ����� ������ � ������� ���������.';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := '��� ��������� ������ ����� �������� ���������� ' ||
                         msg_rec.partidano;
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0) then
            vTaxCode := obl.taxcode;
            vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||
                         rpadc(obl.taxname, 25) || '|' ||
                         rpadc(obl.taxcode, 6) || '|' ||
                         rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(obl.gl, '9999990.99'), 10) || '|' ||
                         lpadc(to_char(obl.lix, '9990.99'), 7) || '|' ||
                         lpadc(to_char(obl.obsto, '99990.99'), 11);
            i := i + 1;
            
          end if;
        end loop;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '���� �� ���������:';
        for rec in offices(0) loop
          r := wordwrap(rpadc(vPDPrt[i],30)||' ����� �� ����: ' || rec.address, 80, 1);
          vPDPrt[i] := r.return_val;
          vrest := r.strrest;          
          vPDPrt[i] := rpadc(vPDPrt[i],80);
          i := i + 1;
          if (Length(vRest) > 1)
          then
            vPDPrt[i] := lpadc(' ', 46) || rpadc(trim(vRest), 34, ' ');
            i := i + 1;
          end if;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        for bank_rec in bank(vMunicipality_id)
        loop
          vPDPrt[i] := lpadc(' ', 30) || ' ���� �� �����: ' ||
                       rpadc(bank_rec.name, 45);
          i := i + 1;
          vPDPrt[i] := lpadc(' ', 39) || rpadc(' IBAN: ' || bank_rec.iban, 45);
          i := i + 1;
          vPDPrt[i] := lpadc(' ', 39) ||
                       rpadc(' ��� ������� '|| vTaxCode ||'/����� ������/', 40, ' ');
          i := i + 1;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := lpadc('���������� ����: .............................', 80);
        i := i + 1;
        vPDPrt[i] := lpadc('(��� �������� ������ �����)', 80);
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '��������: ' || msg_rec.operator1;
        i := i + 1;
        -- ======= End Part 2 =========

        -- ======= Part 3 =========
        vPDPrt[i] := 'ff';
        i := i + 1;
        vPDPrt[i] := 'p3';
        i := i + 1;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom) loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := rpadc(' ', 42) || rpadc(msg_rec.idn, 40);
            i := i + 1;
            vPDPrt[i] := rpadc(' ', 42) || rpadc('���:' || msg_rec.tsname, 38);
            i := i + 1;
            r := wordwrap(msg_rec.address, 37, 1);
            vPDPrt[i] := r.return_val;
            vrest := r.strrest;
            vPDPrt[i] := rpadc(' ', 42) || vPDPrt[i];
            if (Length(vRest) > 1)
            then
              i := i + 1;
              vPDPrt[i] := rpadc('', 42, ' ') || rpadc(vRest, 38, ' ');
            end if;
            i := i + 1;
            vPDPrt[i] := rpadc('', 42) || rpadc(msg_rec.ts_municipality, 38);
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := '��� ��������� ������ ����� �������� ����������:';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||
                         rpadc(obl.taxname, 25) || '|' || rpadc(obl.taxcode, 6) || '|' ||
                         rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(obl.gl, '9999990.99'), 10) || '|' ||
                         lpadc(to_char(obl.lix, '9990.99'), 7) || '|' ||
                         lpadc(to_char(obl.obsto, '99990.99'), 11);
            i := i + 1;
          end if;
        end loop;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0) then
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0) then
            vPDPrt[i] := '';
            i := i + 1;
            vPDPrt[i] := '��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               60, '-');
            i := i + 1;
            vPDPrt[i] := '|     ��� ����������      |��� ��|    �������   |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               60, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0) then
            vPDPrt[i] := ' ' || rpadc(ovr.taxname, 25) || '|' ||
                         rpadc(ovr.taxcode, 6) || '|' ||
                         rpadc(coalesce(ovr.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(ovr.ndvn, '99990.99'), 11);
            i := i + 1;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0) then
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               60, '-');
            i := i + 1;
            vPDPrt[i] := '';
            i := i + 1;
            exit;
          end if;
        end loop;

        -- Check for rows after p3 else delete p3  

        if vPDPrt[i-1] = 'p3' then

 		 vPDPrt := vPDPrt[array_lower(vPDPrt,1) : array_upper(vPDPrt,1)-2];
  --        vPDPrt.DELETE(vPDPrt.LAST);
  --        vPDPrt.DELETE(vPDPrt.LAST);
         i := i - 2;

        end if;

        -- ======= End Part 3 =========

      end loop;

    end if;

    

    vPD_lob :=  paydocument_pkg.tblToLob(vPDPrt );

  

    --commit;

    return_val := 'OK';

    return;

  exception

    when others then

      begin

        --rollback;

        perform NOM_PKG.ErrManage(ErrMsg);

        return_val := ErrMsg;

        return;

      

      end;

end;
$function$
; DROP FUNCTION paydocument_pkg.messaged54_vehicle(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.messaged54_vehicle(OUT return_val character varying, itaxdoc_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                               

    vPDPrt varchar[];

    ErrMsg varchar(300);

    brsm   integer;
    -- taxsubject report
    tsreport cursor(vTaxDoc_id numeric) is
      select max((select d.value
                  from   decode d
                  where  upper(d.columnname) = 'KIND_IDN'
                  and    d.code = ts.kind_idn)) kindidn, min(ts.idn) idn,
             min(ts.name) custname,
             to_char(sum(ds.totaltax), '99999990.99') sumall,
             max(to_char(ds.tax_begidate, 'yyyy')) taxperiod, ds.debtsubject_id
      from   debtsubject ds
      inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
      inner join taxdoc td on ds.document_id = td.taxdoc_id
                          and ds.docno = td.docno
                          and coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
                              coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
                          and ds.kinddoc = 1
      where
             td.taxdoc_id = vTaxDoc_id
      group  by ds.taxsubject_id, ds.debtsubject_id, ds.calcdate,
                coalesce(ds.corrno, 0)
      order  by custname, taxperiod;
    -- municipality logo
    logo cursor(vUser_id numeric) is
      select coalesce(m1.fullname,m.fullname) fullname,
             case when m1.municipality_id is not null then m.fullname else null end region,
             getaddress(ts.present_clientaddr_id) addr,
             m.municipality_id
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      left outer join config c on m.municipality_id = c.municipality_id
      left outer join taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id
      where u.user_id = vUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';
    -- message
    msg cursor(vTaxDoc_id numeric) is
      select distinct ('���������') Label1, ('������: ' || p.name) province,
                      ('������: ' || m.fullname) municipality,
                      (td.docno || '/' || to_char(td.doc_date, 'dd.mm.yyyy') ||
                       ' �.') msgnum, dt.docname, ds.taxsubject_id, dt.doccode,
                      -- TaxSubject
                      (select d.value
                        from   decode d
                        where  upper(d.columnname) = 'KIND_IDN'
                        and    d.code = ts.kind_idn) || ' ' || ts.idn idn,
                      (ts.name) tsname,
                      ('������� ������: ' || ts.taxsubjectno) taxsubj,
                      ('������� �����: ' || tobj.taxobjno) taxobj,
                      ('�����: ' || GetAddress(ts.present_clientaddr_id)) Address,
                      -- TaxObject
                      ('�������: ' || td.partidano) partidano,
                      td.partidano partidanom,
                      /*(select d.value
                        from   decode d
                        where  upper(d.columnname) = 'TYPETRANSP'
                        and    d.code = trreg.type) 02.08.2011*/ trreg.name kindpc,
                      ('�����: ' || cm.mark_name || ' �����: ' ||
                       cmd.model_name) crmark,
                      ('� ��������: ' || tobj.motorno) motorno,
                      ('� ����: ' || tobj.ramano) ramano,
                      ('���. N: ' || tobj.registerno) regno,
                      case when coalesce(pt.part,0) = 0 then to_char(pt.divident) || '/' || to_char(pt.divisor)
                           else to_char(pt.part) end partt,                      
                      --decode(coalesce(pt.part, 0), 0,
                      --        pt.divident || '/' || pt.divisor, pt.part) partt,
                      -- 54P
                      ('���.���: ' || tobj.registername) regname,
                      -- User
                      (u.fullname) operator1
      from Taxdoc td
      left outer join Debtsubject ds on td.taxdoc_id = ds.document_id
      inner join Taxsubject ts on coalesce(ds.taxsubject_id, td.taxsubject_id) = ts.taxsubject_id
      inner join transport tt on tt.taxdoc_id = td.taxdoc_id
      inner join parttransport pt on pt.transport_id = tt.transport_id
                                 and pt.taxsubject_id = ts.taxsubject_id
      inner join users u on td.user_id = u.user_id
      left outer join Taxobject tobj on td.taxobject_id = tobj.taxobject_id
      left outer join Documenttype dt on td.documenttype_id = dt.documenttype_id
      left outer join Transpmeansreg trreg on tobj.transpmeansreg_id = trreg.transpmeansreg_id
      left outer join Carreg cr on tobj.carreg_id = cr.carreg_id
      left outer join Carmodel cmd on cr.carmodel_id = cmd.carmodel_id
      left outer join Carmark cm on cmd.carmark_id = cm.carmark_id
      left outer join Address adr on adr.address_id = ts.present_clientaddr_id
      left outer join Municipality m on m.municipality_id = adr.municipality_id
      left outer join Province p on m.province_id = p.province_id
      where  td.taxdoc_id = vTaxDoc_id
      and    pt.enddate is null;
    -- tax installments
    inst cursor(vTaxDoc_id numeric, vTaxSubject_id numeric) is
      select to_char(coalesce(ds.totaltax, 0), '999990.99') sumall,
             to_char(ds.tax_begidate, 'yyyy') taxperiod,
             (to_char(dis.termdisc, 'dd.mm.yyyy') || ' ' ||
              (select to_char(di.termpay_date, 'dd.mm.yyyy')
                from   debtinstalment di
                where  di.debtsubject_id = ds.debtsubject_id
                and    di.instno = '1')) period,
             case /*when (select trim(c.configvalue) otstypkata e prosledena v tempdiscount function
                       from   config c
                       where  upper(c.name) = 'TAXYEAR') = to_char(td.earn_date,'yyyy') then coalesce(ds.totaltax, 0)*/
                  when  exists(select * from taxperiod tp 
                         where tp.taxperiod_id = ds.taxperiod_id 
                           and to_char(tp.begin_date,'yyyy') < 
                               (select trim(c.configvalue)
                                  from config c
                                 where upper(c.name) = 'TAXYEAR')) then 0                       
             else
               coalesce(ds.totaltax, 0) -
                coalesce(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                              from   debtinstalment di
                                              where  di.debtsubject_id =
                                                     ds.debtsubject_id
                                              and    di.instno = '2'),
                                              trunc(CURRENT_DATE)), 0) end dis,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '1') v1,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2') v2,
             (select to_char(di.termpay_date, 'dd.mm.yyyy')
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2') tdate2,
             --       (select di.instsum from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '4') v4
             ds.debtsubject_id, ds.parent_debtsubject_id
      from   TaxDoc td
      inner join Debtsubject ds on  td.taxdoc_id = ds.document_id
                                and ds.docno = td.docno
                                and coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
                                    coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
      inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
      inner join Discount dis on dis.documenttype_id = td.documenttype_id 
                             and dis.taxperiod_id = ds.taxperiod_id 
      where  td.taxdoc_id = vTaxDoc_id
      and    ds.taxsubject_id = vTaxSubject_id
            --         ds.prtdate is null and
      and    ds.kinddoc = 1
      order  by ds.parent_debtsubject_id, ds.tax_begidate, coalesce(ds.corrno, 0);
    offices cursor(vMunicipality_id numeric) is
      select o.fullname, coalesce(o.address, '') address
      from   Users u 
      inner join Office o on o.office_id = u.office_id
      where  o.isactive = 1
      and    u.user_id = iUser_id;
    bank cursor(vMunicipality_id numeric) is
      select b.name, a.iban
      from   baccount a inner join bank b on b.bank_id = a.bank_id
      where  a.isactive = 1
      and    a.isbase = 1
      and    a.municipality_id = vMunicipality_id;
    --��� ��������� ������ ������������ �� �� ��������:
    currobl cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano = vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on di.debtsubject_id = ds.debtsubject_id
      inner join baldebtinst bdi on bdi.debtinstalment_id = di.debtinstalment_id
      inner join kinddebtreg kdr on kdr.kinddebtreg_id = ds.kinddebtreg_id
      where  ds.partidano = vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    currobl_rest cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on di.debtsubject_id = ds.debtsubject_id
      inner join baldebtinst bdi on bdi.debtinstalment_id = di.debtinstalment_id
      inner join kinddebtreg kdr on kdr.kinddebtreg_id = ds.kinddebtreg_id
      where  ds.partidano <> vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on di.debtsubject_id = ds.debtsubject_id
      inner join baldebtinst bdi on bdi.debtinstalment_id = di.debtinstalment_id
      inner join kinddebtreg kdr on kdr.kinddebtreg_id = ds.kinddebtreg_id
      where  ds.partidano <> vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    crpartidi_amount cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) totAmount, count(distinct ds.partidano) parNum
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano != vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id;
    --��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.
    oversum cursor(vTaxSubject_id numeric) is
      select max(kdr.fullname) taxname, max(kdr.acc) taxcode, os.partidano,
             sum(coalesce(boi.oversum, 0)) ndvn
      from   baloverinst boi, oversubject os, kinddebtreg kdr
      where  os.oversubject_id = boi.oversubject_id
      and    os.kinddebtreg_id = kdr.kinddebtreg_id
      and    os.taxsubject_id = vTaxSubject_id
      group  by os.partidano, os.kinddebtreg_id;

    i                numeric;

    vRest            varchar(300);

    vMunicipality_id numeric;
    r record;

    d varchar;

    rowcount integer;

  begin

    if (iTaxDoc_id > 0)

    then

      i := 1; -- �����

      -- ======= Part 1 =========  

      -- Report Obligations

      for msg_rec in msg(iTaxDoc_id)

      loop

        vPDPrt[i] := center('������� �����', 70);

        i := i + 1;

        case trim(msg_rec.doccode)

          when '54P' then

            vPDPrt[i] := rpadc(msg_rec.partidano, 40);

            i := i + 1;

            vPDPrt[i] := rpadc('��� ��: ' || msg_rec.kindpc, 40) ||

                         rpadc(msg_rec.regname, 38);

            i := i + 1;

            vPDPrt[i] := rpadc(msg_rec.crmark, 40) || rpadc(msg_rec.regno, 38);

            i := i + 1;

          when '54V' then

            vPDPrt[i] := rpadc(msg_rec.partidano, 40);

            i := i + 1;

            vPDPrt[i] := rpadc('��� ��: ' || msg_rec.kindpc, 40) ||

                         rpadc(msg_rec.regname, 38);

            i := i + 1;

            vPDPrt[i] := rpadc(msg_rec.crmark, 40) || rpadc(msg_rec.regno, 38);

            i := i + 1;

          else

            vPDPrt[i] := rpadc(msg_rec.partidano, 40) ||

                         rpadc(msg_rec.motorno, 38, ' ');

            i := i + 1;

            vPDPrt[i] := rpadc('��� ��: ' || msg_rec.kindpc, 40) ||

                         rpadc(msg_rec.ramano, 38);

            i := i + 1;

            vPDPrt[i] := rpadc(msg_rec.crmark, 40) || rpadc(msg_rec.regno, 38);

            i := i + 1;

        end case;

        exit;

      end loop;

      vPDPrt[i] := rpadc('����������', 70);

      i := i + 1;

      vPDPrt[i] := rpadc(' ---------------', 60, '-');

      i := i + 1;

      vPDPrt[i] := '| ���/�������� |      ���                |������|    �����  ' || '|';

      i := i + 1;

      vPDPrt[i] := rpadc(' ---------------', 60, '-');

      i := i + 1;

      for ts in tsreport(iTaxDoc_id) loop

        vPDPrt[i] := rpadc('| ' || ts.idn, 15) || '|' || rpadc(ts.custname, 25) || '|' ||

                     rpadc(ts.taxperiod, 6) || '|' || lpadc(ts.sumall, 11) || '|';

        i := i + 1;

        vPDPrt[i] := rpadc(' ---------------', 60, '-');

        i := i + 1;

      end loop;

      -- ======= End Part 1 =========  

    

      -- ======= Part 2 =========  

      vPDPrt[i] := 'ff';

      i := i + 1;

      vPDPrt[i] := 'p2';

      i := i + 1;

      -- !!!!!!!!!!!!!!!!!!!!!!    

      rowcount := 1;

      for msg_rec in msg(iTaxDoc_id) loop

        if rowcount > 1

        then

          vPDPrt[i] := 'ff';

          i := i + 1;

          vPDPrt[i] := 'p2';

          i := i + 1;

        end if;

        rowcount := 2;

        for logo_rec in logo(iUser_id)

        loop

          vMunicipality_id := logo_rec.municipality_id;

          vPDPrt[i] := rpadc(' ------------------------------------------------', 80, '-');

          i := i + 1;

          vPDPrt[i] := center('� � � � � �  ' || logo_rec.fullname, 80);

          i := i + 1;

          if (logo_rec.region is not null) then
           vPDPrt[i] := center('� � � � �  ' || upper(logo_rec.region), 80);
           i := i + 1;
          end if; 
          vPDPrt[i] := center('������ ������ � �����', 80);

          i := i + 1;

          vPDPrt[i] := center(logo_rec.addr, 80);

          i := i + 1;

          vPDPrt[i] := rpadc(' ------------------------------------------------', 80, '-');

          i := i + 1;

          vPDPrt[i] := '';

          i := i + 1;

        end loop;

        vPDPrt[i] := center('���������', 80);

        i := i + 1;

        vPDPrt[i] := center(msg_rec.msgnum, 80);

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := rpadc('������� ������� �����:', 42) || '��:';

        i := i + 1;

        vPDPrt[i] := rpadc(msg_rec.partidano, 42) || rpadc(msg_rec.idn, 40);

        i := i + 1;

        vPDPrt[i] := rpadc('��� ��: ' || msg_rec.kindpc, 42) || rpadc('���:' || msg_rec.tsname, 38);

        i := i + 1;

        r := wordwrap( msg_rec.address, 37, 1 );

        vPDPrt[i] := r.return_val;

        vrest := r.strrest;

        vPDPrt[i] := rpadc(msg_rec.crmark, 42) || vPDPrt[i];

        case trim(msg_rec.doccode)

          when '54P' then

            if (Length(vRest) > 1)

            then

              vPDPrt[i] := rpadc('', 42, ' ') || rpadc(vRest, 38, ' ');

            end if;

            i := i + 1;

            vPDPrt[i] := rpadc(msg_rec.regname, 42) ||

                         rpadc(msg_rec.municipality, 38);

          when '54V' then

            if (Length(vRest) > 1)

            then

              vPDPrt[i] := rpadc('', 42, ' ') || rpadc(vRest, 38, ' ');

            end if;

            i := i + 1;

            vPDPrt[i] := rpadc('', 42) || rpadc(msg_rec.municipality, 38);

          else

            i := i + 1;

            vPDPrt[i] := rpadc(msg_rec.motorno, 42, ' ');

            if (Length(vRest) > 1)

            then

              vPDPrt[i] := vPDPrt[i] || rpadc(vRest, 38, ' ');

            end if;

            i := i + 1;

            vPDPrt[i] := rpadc(msg_rec.ramano, 42) ||

                         rpadc(msg_rec.municipality, 38);

        end case;

        i := i + 1;

        vPDPrt[i] := rpadc(msg_rec.regno, 42);

        i := i + 1;

        vPDPrt[i] := rpadc('  �������� ' || msg_rec.docname ||

                           ' �� ����,', 80);

        i := i + 1;

        vPDPrt[i] := rpadc('� ��.� ' || msg_rec.msgnum ||

                           ' �� �� ���������� �������� ������� ����������', 80,

                           ' ');

        if (msg_rec.partt <> '1') and (msg_rec.partt <> '1/1')

        then

          i := i + 1;

          vPDPrt[i] := rpadc('�� ������������ ' || msg_rec.partt || ' �� ' ||

                             msg_rec.kindpc, 80, ' ');

        end if;

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        -- Installments     

        rowcount := 1;

        for inst_rec in inst(iTaxDoc_id, msg_rec.taxsubject_id)

        loop

          if inst_rec.parent_debtsubject_id is not null

          then

            if rowcount = 1

            then

              vPDPrt[i] := ' �������� �� ��������� ����������';

              i := i + 1;

              vPDPrt[i] := rpadc(' ------------------------------------------------',

                                 49, '-');

              i := i + 1;

              vPDPrt[i] := '|  ��� ���������� ������   |   ���� ��������     |';

              i := i + 1;

              vPDPrt[i] := rpadc(' ------------------------------------------------',

                                 49, '-');

              i := i + 1;

            end if;

            rowcount := 2;

            vPDPrt[i] := rpadc('|  ����� ���  ' || inst_rec.taxperiod, 26) || ' |' ||

                         lpadc(inst_rec.sumall, 20) || ' |';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               49, '-');

            i := i + 1;

          else

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               65, '-');

            i := i + 1;

            vPDPrt[i] := '|  ����� ���    |     ���� �� �������    |   ���� �� �������     ' || '|';

            i := i + 1;

            ----------------

            vPDPrt[i] := rpadc('|   �� ' || inst_rec.taxperiod, 16) || '|' ||

                         rpadc(' � ��������  I ������ ', 24, ' ') || '|' ||

                         rpadc('         II ������', 23, ' ') || '|';

            ----------------

            i := i + 1;

            vPDPrt[i] := rpadc('|    � ���� ', 16, ' ') || '|' ||

                         center(inst_rec.period, 24) || '|' ||

                         lpadc(inst_rec.tdate2 || ' ', 20) ||

                         lpadc(' ', 3, ' ') || '|';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               65, '-');

            i := i + 1;

            vPDPrt[i] := '|���� ' || lpadc(inst_rec.sumall, 10) || '|' ||

                         lpadc(to_char(coalesce(inst_rec.dis, 0.0), '999990.99'), 10,

                               ' ') ||

                         lpadc(to_char(coalesce(inst_rec.v1, 0.0), '999990.99'), 12,

                               ' ') || lpadc(' ', 2, ' ') || '|' ||

                         lpadc(to_char(coalesce(inst_rec.v2, 0.0), '999990.99'), 20,

                               ' ') || '   |';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               65, '-');

            i := i + 1;

          end if;

        end loop;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '���������� ��������� �� � ��������������� ��� � �� ������� �� ���������.';

        i := i + 1;

        vPDPrt[i] := '���� �������� �� ����� �� ��������� ����� ����������� ���������� �� ��������� �����!';

        i := i + 1;

        vPDPrt[i] := '���������� �� ������ �������� �� ������ �� �� �� ����� ������ � ������� ���������.';

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := '��� ��������� ������ ����� �������� ���������� �� ' ||

                         msg_rec.partidano;

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               90, '-');

            i := i + 1;

            vPDPrt[i] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               90, '-');

            i := i + 1;

            exit;

          end if;

        end loop;

        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||

                         rpadc(obl.taxname, 25) || '|' || rpadc(obl.taxcode, 6) || '|' ||

                         rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||

                         lpadc(to_char(obl.gl, '9999990.99'), 10) || '|' ||

                         lpadc(to_char(obl.lix, '9990.99'), 7) || '|' ||

                         lpadc(to_char(obl.obsto, '99999990.99'), 11);

            i := i + 1;

          end if;

        end loop;

        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               90, '-');

            i := i + 1;

            exit;

          end if;

        end loop;

      

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '���� �� ���������:';

        for rec in offices(0)

        loop

          r:= wordwrap( ' ����� �� ����: ' || rec.address, 45, 1 );

          vPDPrt[i] := r.return_val;

	  vrest := r.strrest;



          vPDPrt[i] := rpadc(vPDPrt[i], 30) || vPDPrt[i];

          i := i + 1;

          if (Length(vRest) > 1)

          then

            vPDPrt[i] := lpadc(' ', 46) || rpadc(vRest, 34, ' ');

            i := i + 1;

          end if;

        end loop;

        vPDPrt[i] := '';

        i := i + 1;

        for bank_rec in bank(vMunicipality_id)

        loop

          vPDPrt[i] := lpadc(' ', 30) || ' ���� �� �����: ' ||

                       rpadc(bank_rec.name, 45);

          i := i + 1;

          vPDPrt[i] := lpadc(' ', 39) || rpadc(' IBAN: ' || bank_rec.iban, 45);

          i := i + 1;

          vPDPrt[i] := lpadc(' ', 39) ||

                       rpadc(' ��� ������� 442300/����� ���/', 40, ' ');

          i := i + 1;

        end loop;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := lpadc('���������� ����: .............................', 80);

        i := i + 1;

        vPDPrt[i] := lpadc('(��� �������� ������ �����)', 80);

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '��������: ' || msg_rec.operator1;

        i := i + 1;

        -- ======= End Part 2 =========  

      

        -- ======= Part 3 ========= 

        vPDPrt[i] := 'ff';

        i := i + 1;

        vPDPrt[i] := 'p3';

        i := i + 1;

        for res in crpartidi_amount(msg_rec.taxsubject_id, msg_rec.partidanom) loop
       -- for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom) loop
          if (res.totAmount > 0) then
            vPDPrt[i] := rpadc(' ', 42) || rpadc(msg_rec.idn, 40);
            i := i + 1;
            vPDPrt[i] := rpadc(' ', 42) || rpadc('���:' || msg_rec.tsname, 38);
            i := i + 1;
            r := wordwrap(msg_rec.address, 37, 1);
            vPDPrt[i] := r.return_val;
            vrest := r.strrest;
            vPDPrt[i] := rpadc(' ', 42) || vPDPrt[i];
            case trim(msg_rec.doccode)
              when '54P' then
                if (Length(vRest) > 1) then
                  vPDPrt[i] := rpadc('', 42, ' ') || rpadc(vRest, 38, ' ');
                end if;
                i := i + 1;
                vPDPrt[i] := rpadc(' ', 42) || rpadc(msg_rec.municipality, 38);
              when '54V' then
                if (Length(vRest) > 1) then
                  vPDPrt[i] := rpadc('', 42, ' ') || rpadc(vRest, 38, ' ');
                end if;
                i := i + 1;
                vPDPrt[i] := rpadc('', 42) || rpadc(msg_rec.municipality, 38);
              else
                i := i + 1;
                vPDPrt[i] := rpadc('', 42, ' ');
                if (Length(vRest) > 1)
                then
                  vPDPrt[i] := vPDPrt[i] || rpadc(vRest, 38, ' ');
                end if;
                i := i + 1;
                vPDPrt[i] := rpadc(' ', 42) || rpadc(msg_rec.municipality, 38);
            end case;
            --exit;
       -- end loop;
        ---------  ������ ���������� �� ������� ----------
            vPDPrt[i] := '��� ��������� ������ ����� �������� ����������: ';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |     ��� ����������     |��� ��|   �������   |  �������� |  ����� |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
        --  ��� � ���� ���������� > 50 ������� ������� �� ������ ������. �� V �������
            if (res.parnum > 50) then
                vPDPrt[i] := ' ' || rpadc(' ', 10) || '|' ||
                             rpadc(' ', 24) || '|' ||
                             rpadc(' ', 6) || '|' ||
                             rpadc(' ', 13) || '|' ||
                             lpadc(to_char(res.gl, '999999990.99'), 11) || '|' ||
                             lpadc(to_char(res.lix, '99999990.99'), 8) || '|' ||
                             lpadc(to_char(res.totAmount, '99999990.99'), 11);
                i := i + 1;
            else
              for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom) loop
                if (obl.obsto > 0) then
                  vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||
                               rpadc(obl.taxname, 24) || '|' ||
                               rpadc(obl.taxcode, 6) || '|' ||
                               rpadc(coalesce(obl.partidano, ' '), 13) || '|' ||
                               lpadc(to_char(obl.gl, '99999990.99'), 11) || '|' ||
                               lpadc(to_char(obl.lix, '99990.99'), 8) || '|' ||
                               lpadc(to_char(obl.obsto, '99999990.99'), 11);
                  i := i + 1;
                end if;
              end loop;
            end if;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;

         end if;

        end loop;


        -------- �������� ���� ---------   

        for ovr in oversum(msg_rec.taxsubject_id)

        loop

          if (ovr.ndvn > 0)

          then

            vPDPrt[i] := '';

            i := i + 1;

            vPDPrt[i] := '';

            i := i + 1;

            vPDPrt[i] := '��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               60, '-');

            i := i + 1;

            vPDPrt[i] := '|     ��� ����������      |��� ��|    �������   |    ����   |';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               60, '-');

            i := i + 1;

            exit;

          end if;

        end loop;

        for ovr in oversum(msg_rec.taxsubject_id)

        loop

          if (ovr.ndvn > 0)

          then

            vPDPrt[i] := ' ' || rpadc(ovr.taxname, 25) || '|' ||

                         rpadc(ovr.taxcode, 6) || '|' ||

                         rpadc(coalesce(ovr.partidano, ' '), 14) || '|' ||

                         lpadc(to_char(ovr.ndvn, '99999990.99'), 11);

            i := i + 1;

          end if;

        end loop;

        for ovr in oversum(msg_rec.taxsubject_id)

        loop

          if (ovr.ndvn > 0)

          then

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               60, '-');

            i := i + 1;

            vPDPrt[i] := '';

            i := i + 1;

            exit;

          end if;

        end loop;

        -- Check for rows after p3 else delete p3  

        if vPDPrt[i-1] = 'p3' then

		 vPDPrt := vPDPrt[array_lower(vPDPrt,1) : array_upper(vPDPrt,1)-2];

        --  vPDPrt.DELETE[vPDPrt.LAST];

        --  vPDPrt.DELETE[vPDPrt.LAST];

          i := i - 2;

        end if;

        -- ======= End Part 3 =========

      

      end loop;

    end if;

    

    vPD_lob := paydocument_pkg.tblToLob(vPDPrt );

  

    --commit;

    return_val := 'OK';

    return;

  exception

    when others then

      begin

        --rollback;

        perform NOM_PKG.ErrManage(ErrMsg);

        return_val := ErrMsg;

        return;

      

      end;

end;
$function$
; DROP FUNCTION paydocument_pkg.messaged61(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.messaged61(OUT return_val character varying, itaxdoc_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                       
    vPDPrt varchar[];
    ErrMsg varchar(300);
    -- taxsubject report
    tsreport cursor(vTaxDoc_id numeric) is
      select max((select d.value
                  from   decode d
                  where  upper(d.columnname) = 'KIND_IDN'
                  and    d.code = ts.kind_idn)) kindidn, min(ts.idn) idn,
             min(ts.name) custname,
             to_char(sum(ds.totaltax), '99999990.99') sumall,
             max(to_char(ds.tax_begidate, 'yyyy')) taxperiod, ds.debtsubject_id
      from   debtsubject ds
      inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
      inner join taxdoc td on ds.document_id = td.taxdoc_id
                          and ds.docno = td.docno
                          and coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
                              coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
                          and ds.kinddoc = 1
      where
            --         ds.prtdate is null and
             td.taxdoc_id = vTaxDoc_id
      group  by ds.taxsubject_id, ds.debtsubject_id, ds.calcdate,
                coalesce(ds.corrno, 0)
      order  by custname, taxperiod;
    -- municipality logo
    logo cursor(vUser_id numeric) is
      select coalesce(m1.fullname,m.fullname) fullname,
             case when m1.municipality_id is not null then m.fullname else null end region,
             getaddress(ts.present_clientaddr_id) addr,
             m.municipality_id
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      left outer join config c on m.municipality_id = c.municipality_id
      left outer join taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id
      where u.user_id = vUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';
    -- message
    msg cursor(vTaxDoc_id numeric) is
      select ('���������') Label1, ('������: ' || p.name) province,
             ('������: ' || m.fullname) municipality,
             (td.docno || '/' || to_char(td.doc_date, 'dd.mm.yyyy') || ' �.') msgnum,
             dt.docname, ts.taxsubject_id,
             -- ds.taxsubject_id,
             -- TaxSubject
             (select d.value
               from   decode d
               where  upper(d.columnname) = 'KIND_IDN'
               and    d.code = ts.kind_idn) || ': ' || ts.idn idn,
             ('���: ' || ts.name) tsname,
             ('������� ������: ' || ts.taxsubjectno) taxsubj,
             ('�����: ' || GetAddress(ts.present_clientaddr_id)) Address,
             -- TaxObject
             ('�������: ' || td.partidano) partidano, td.partidano partidanom,
             -- User
             (u.fullname) operator1
      from Taxdoc td
      inner join Taxsubject ts on coalesce(td.taxsubject_id, td.ettaxsubject_id) = ts.taxsubject_id
      inner join users u on td.user_id = u.user_id
      left outer join Documenttype dt on td.documenttype_id = dt.documenttype_id
      left outer join Municipality m on td.municipality_id = m.municipality_id
      left outer join Province p on  m.province_id = p.province_id
      where  td.taxdoc_id = vTaxDoc_id;
    -- tax installments
    inst cursor(vTaxDoc_id numeric, vTaxSubject_id numeric) is
      select to_char(coalesce(ds.totaltax, 0), '9999990.99') sumall,
             to_char(ds.tax_begidate, 'yyyy') taxperiod,
             ( /*'�� '||to_char(ds.tax_begidate,'dd.mm.yyyy')||*/
               ' �� ' || (select to_char(di.termpay_date, 'dd.mm.yyyy')
                          from   debtinstalment di
                          where  di.debtsubject_id = ds.debtsubject_id
                          and    di.instno = '1')) period,
             case when exists(select * from taxperiod tp 
                         where tp.taxperiod_id = ds.taxperiod_id 
                           and to_char(tp.begin_date,'yyyy') = 
                               (select trim(c.configvalue)
                                  from config c
                                 where upper(c.name) = 'TAXYEAR')) then   
                           coalesce(ds.totaltax, 0) -
                            coalesce(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                                             from debtinstalment di
                                                            where di.debtsubject_id = ds.debtsubject_id
                                                              and di.instno = '2'),
                                                          trunc(current_date)), 0) else 0 end dis,
             (select di.instsum from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '1') v1,
             (select di.instsum from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '2') v2,
             (select di.instsum from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '3') v3,
             (select di.instsum from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '4') v4,
             -- srok do
             (select to_char(di.termpay_date, 'dd.mm.yyyy') from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '2') tdate2,
             (select to_char(di.termpay_date, 'dd.mm.yyyy') from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '3') tdate3,
             (select to_char(di.termpay_date, 'dd.mm.yyyy') from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '4') tdate4,
             --       (select di.instsum from debtinstalment di where di.debtsubject_id = ds.debtsubject_id and di.instno = '4') v4
             ds.debtsubject_id, ds.parent_debtsubject_id
      from   TaxDoc td
      inner join Debtsubject ds on ds.document_id = td.taxdoc_id
                               and ds.docno = td.docno
                               and coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
                                   coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
      inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
      where  td.taxdoc_id = vTaxDoc_id
      and    ds.taxsubject_id = vTaxSubject_id
      --and    ds.prtdate is null and
      and    ds.kinddoc = 1
      order  by ds.parent_debtsubject_id, ds.tax_begidate;
    offices cursor(vMunicipality_id numeric) is
      select o.fullname, coalesce(o.address, '') address
      from   Users u 
      inner join Office o on o.office_id = u.office_id
      where  o.isactive = 1
      and    u.user_id = iUser_id;
    bank cursor(vMunicipality_id numeric) is
      select b.name, a.iban
      from   baccount a inner join bank b on b.bank_id = a.bank_id
      where  a.isactive = 1
      and    a.isbase = 1
      and    a.municipality_id = vMunicipality_id;
    --��� ��������� ������ ������������ �� �� ��������:
    currobl cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano = vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano = vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    --��� ��������� ������ ������ �������� ���������� �� �� ��������:
    currobl_rest cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano != vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano != vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    --��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.
    oversum cursor(vTaxSubject_id numeric) is
      select max(kdr.fullname) taxname, max(kdr.acc) taxcode, os.partidano,
             sum(coalesce(boi.oversum, 0)) ndvn
      from   baloverinst boi
      inner join oversubject os on os.oversubject_id = boi.oversubject_id
      inner join kinddebtreg kdr on kdr.kinddebtreg_id = os.kinddebtreg_id
      where  os.taxsubject_id = vTaxSubject_id
      group  by os.partidano, os.kinddebtreg_id;
    i                numeric;
    vRest            varchar(300);
    vMunicipality_id numeric;
    --vMunicipality    varchar(100);  
    r record;
    d varchar;
    rowcount integer;
  begin
    if (iTaxDoc_id > 0) then
      i := 1; -- �����
      -- ======= Part 1 =========
      -- Report Obligations
      for msg_rec in msg(iTaxDoc_id)
      loop
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := center('�������� �������', 70);
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.partidano, 40);
        i := i + 1;
        exit;
      end loop;
      vPDPrt[i] := rpadc('����������', 70);
      i := i + 1;
      vPDPrt[i] := rpadc(' ---------------', 60, '-');
      i := i + 1;
      vPDPrt[i] := '| ���/�������� |      ���                |������|    �����  ' || '|';
      i := i + 1;
      vPDPrt[i] := rpadc(' ---------------', 60, '-');
      i := i + 1;
      for ts in tsreport(iTaxDoc_id)
      loop
        vPDPrt[i] := rpadc('| ' || ts.idn, 15) || '|' || rpadc(ts.custname, 25) || '|' ||
                     rpadc(ts.taxperiod, 6) || '|' || lpadc(ts.sumall, 11) || '|';
        i := i + 1;
        vPDPrt[i] := rpadc(' ---------------', 60, '-');
        i := i + 1;
      end loop;
      -- ======= End Part 1 =========

      -- ======= Part 2 =========
      vPDPrt[i] := 'ff';
      i := i + 1;
      vPDPrt[i] := 'p2';
      i := i + 1;
      -- !!!!!!!!!!!!!!!!!!!!!!
      rowcount := 1;
      for msg_rec in msg(iTaxDoc_id)
      loop
        if rowcount > 1 then
          vPDPrt[i] := 'ff';
          i := i + 1;
          vPDPrt[i] := 'p2';
          i := i + 1;
        end if;
        rowcount := rowcount + 1;
        for logo_rec in logo(iUser_id) loop
          vMunicipality_id := logo_rec.municipality_id;
          vPDPrt[i] := rpadc(' ------------------------------------------------',80, '-');
          i := i + 1;
          if (logo_rec.region is not null) then
           vPDPrt[i] := center(logo_rec.fullname ||' '|| '������', 80);
           i := i + 1;
           vPDPrt[i] := center('�������� ������� � ������������� �� ���', 80);
           i := i + 1;
           vPDPrt[i] := center('����� ���', 80);
           i := i + 1;
           vPDPrt[i] := center('� � � � �  ' || upper(logo_rec.region), 80);
           i := i + 1;
          else
           vPDPrt[i] := center('� � � � � �  ' || logo_rec.fullname, 80);
           i := i + 1;
           vPDPrt[i] := center('������ ������ � �����', 80);
           i := i + 1;
          end if;
          vPDPrt[i] := center(logo_rec.addr, 80);
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------',80, '-');
          i := i + 1;
          vPDPrt[i] := '';
          i := i + 1;
        end loop;
        vPDPrt[i] := center('���������', 80);
        i := i + 1;
        vPDPrt[i] := center(msg_rec.msgnum, 80);
        i := i + 1;
        vPDPrt[i] := rpadc('������� �������� �������:', 40) || '�� ';
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.partidano, 40) || rpadc(msg_rec.idn, 40);
        i := i + 1;
        vPDPrt[i] := lpadc(' ', 40) || rpadc(msg_rec.tsname, 40);
        i := i + 1;
        r := wordwrap(msg_rec.address, 40, 1);
        vPDPrt[i] := r.return_val;
        vrest := r.strrest;
        vPDPrt[i] := lpadc(' ', 40) || vPDPrt[i];
        i := i + 1;
        vPDPrt[i] := lpadc(' ', 40);
        if (Length(vRest) > 1) then
          vPDPrt[i] := vPDPrt[i] || rpadc(vRest, 40, ' ');
        end if;
        i := i + 1;
        --    vPDPrt[i]  := lpadc(' ',40)||rpadc(msg_rec.municipality,40);
        --    i          := i + 1;
        vPDPrt[i] := rpadc('  �������� ' || msg_rec.docname ||
                           ' �� ����,', 80);
        i := i + 1;
        vPDPrt[i] := rpadc('� ��.� ' || msg_rec.msgnum ||
                           ' �� �� ���������� �������� ������� ����������:', 80,
                           ' ');
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        -- Installments
        rowcount := 1;
        for inst_rec in inst(iTaxDoc_id, msg_rec.taxsubject_id)
        loop
          if inst_rec.parent_debtsubject_id is not null then
            if rowcount = 1 then
              vPDPrt[i] := ' �������� �� ��������� ����������';
              i := i + 1;
              vPDPrt[i] := rpadc(' ------------------------------------------------',
                                 49, '-');
              i := i + 1;
              vPDPrt[i] := '|  ��� ���������� ������   |   ���� ��������     |';
              i := i + 1;
              vPDPrt[i] := rpadc(' ------------------------------------------------',
                                 49, '-');
              i := i + 1;
            end if;
            rowcount := rowcount + 1;
            vPDPrt[i] := rpadc('| ����� ������  ' || inst_rec.taxperiod, 26) || ' |' ||
                         lpadc(inst_rec.sumall, 20) || ' |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               49, '-');
            i := i + 1;
            exit;
          else
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            vPDPrt[i] := '     ������     |   ���� �� �������  |���� �� �������|���� �� �������|���� �� ������� ';
            i := i + 1;
            vPDPrt[i] := rpadc('    �� ' || inst_rec.taxperiod, 16, ' ') || '|' ||
                         lpadc(inst_rec.period, 17, ' ') ||
                         lpadc(' ', 3) || '|' ||
                         lpadc(coalesce(inst_rec.tdate2, ' '), 13) || '  |' ||
                         lpadc(coalesce(inst_rec.tdate3, ' '), 13) || '  |' ||
                         lpadc(coalesce(inst_rec.tdate4, ' '), 13);
            i := i + 1;
            vPDPrt[i] := rpadc('     � ���� ', 16) || '|' ||
                         lpadc('� ��������  I ������', 20, ' ') || '|' ||
                         lpadc(' II ������  ', 15, ' ') || '|' ||
                         lpadc(' III ������  ', 15, ' ') || '|' ||
                         lpadc(' IV ������  ', 15, ' ');
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            vPDPrt[i] := ' ���� ' || lpadc(inst_rec.sumall, 10) || '|' ||
                         lpadc(to_char(coalesce(inst_rec.dis, 0), '99990.99'), 8, ' ') ||
                         lpadc(to_char(coalesce(inst_rec.v1, 0), '99990.99'), 12, ' ') || '|' ||
                         lpadc(to_char(coalesce(inst_rec.v2, 0), '999990.99'), 15,
                               ' ') || '|' ||
                         lpadc(to_char(coalesce(inst_rec.v3, 0), '999990.99'), 15,
                               ' ') || '|' ||
                         lpadc(to_char(coalesce(inst_rec.v4, 0), '999990.99'), 15,
                               ' ');
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
          end if;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '���������� ��������� �� � ��������������� ��� � �� ������� �� ���������.';
        i := i + 1;
        /*  vPDPrt[i]  := '��� �� ��� �������� � ������������ �� ����������, ������ �� �������� �������� �� ';
        i          := i + 1;
        vPDPrt[i]  := '��� �� ������������ �� ������������ �� ������, ����� ������ �� ��������� � ';
        i          := i + 1;
        vPDPrt[i]  := '14-������ ���� �� ������������ ��.';
        i          := i + 1;*/
        vPDPrt[i] := '���� �������� �� ����� �� ��������� ����� ����������� ���������� �� ��������� �����.';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := '��� ��������� ������ ����� �������� ���������� �� ' ||
                         msg_rec.partidano;
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||
                         rpadc(obl.taxname, 25) || '|' || rpadc(obl.taxcode, 6) || '|' ||
                         rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(obl.gl, '9999990.99'), 10) || '|' ||
                         lpadc(to_char(obl.lix, '990.99'), 7) || '|' ||
                         lpadc(to_char(obl.obsto, '99990.99'), 11);
            i := i + 1;
          end if;
        end loop;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '���� �� ���������:';
        for rec in offices(vMunicipality_id) loop
          r := wordwrap(rpadc(vPDPrt[i],30)||' ����� �� ����: ' || rec.address, 80, 1);
          vPDPrt[i] := r.return_val;
          vrest := r.strrest;          
          vPDPrt[i] := rpadc(vPDPrt[i],80);
          i := i + 1;
          if (Length(vRest) > 1) then
            vPDPrt[i] := lpadc(' ', 46) || rpadc(trim(vRest), 34, ' ');
            i := i + 1;
          end if;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        for bank_rec in bank(vMunicipality_id)
        loop
          vPDPrt[i] := lpadc(' ', 30) || ' ���� �� �����: ' ||
                       rpadc(bank_rec.name, 45);
          i := i + 1;
          vPDPrt[i] := lpadc(' ', 39) || rpadc(' IBAN: ' || bank_rec.iban, 45);
          i := i + 1;
          vPDPrt[i] := lpadc(' ', 39) ||
                       rpadc(' ��� ������� 441400/�������� �����/', 40, ' ');
          i := i + 1;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := lpadc('���������� ����: .............................', 80);
        i := i + 1;
        vPDPrt[i] := lpadc('(���, ��������, ������, �����)', 80);
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '��������: ' || msg_rec.operator1;
        i := i + 1;
        -- ======= End Part 2 =========

        -- ======= Part 3 =========
        vPDPrt[i] := 'ff';
        i := i + 1;
        vPDPrt[i] := 'p3';
        i := i + 1;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := rpadc(' ', 40) || rpadc(msg_rec.idn, 40);
            i := i + 1;
            vPDPrt[i] := lpadc(' ', 40) || rpadc(msg_rec.tsname, 40);
            i := i + 1;
            r := wordwrap(msg_rec.address, 40, 1);
            vPDPrt[i] := r.return_val;
            vrest := r.strrest;            
            vPDPrt[i] := lpadc(' ', 40) || vPDPrt[i];
            i := i + 1;
            vPDPrt[i] := lpadc(' ', 40);
            if (Length(vRest) > 1)
            then
              vPDPrt[i] := vPDPrt[i] || rpadc(vRest, 40, ' ');
              i := i + 1;
            end if;
            vPDPrt[i] := '';
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := '��� ��������� ������ ����� �������� ����������:';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||
                         rpadc(obl.taxname, 25) || '|' || rpadc(obl.taxcode, 6) || '|' ||
                         rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(obl.gl, '9999990.99'), 10) || '|' ||
                         lpadc(to_char(obl.lix, '990.99'), 7) || '|' ||
                         lpadc(to_char(obl.obsto, '99990.99'), 11);
            i := i + 1;
          end if;
        end loop;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0)
          then
            vPDPrt[i] := '';
            i := i + 1;
            vPDPrt[i] := '��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               60, '-');
            i := i + 1;
            vPDPrt[i] := '|     ��� ����������      |��� ��|    �������   |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               60, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0)
          then
            vPDPrt[i] := ' ' || rpadc(ovr.taxname, 25) || '|' ||
                         rpadc(ovr.taxcode, 6) || '|' ||
                         rpadc(coalesce(ovr.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(ovr.ndvn, '99990.99'), 11);
            i := i + 1;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0)
          then
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               60, '-');
            i := i + 1;
            vPDPrt[i] := '';
            i := i + 1;
            exit;
          end if;
        end loop;
        -- Check for rows after p3 else delete p3  
        if vPDPrt[i-1] = 'p3' then
        	vPDPrt := vPDPrt[array_lower(vPDPrt,1) : array_upper(vPDPrt,1)-2];
 --         vPDPrt.DELETE(vPDPrt.LAST);
 --         vPDPrt.DELETE(vPDPrt.LAST);
          i := i - 2;
        end if;
      
      end loop;
    end if;
    
    vPD_lob := paydocument_pkg.tblToLob(vPDPrt);
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;
      end;
end;
$function$
; DROP FUNCTION paydocument_pkg.messaged61r(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.messaged61r(OUT return_val character varying, itaxdoc_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                        

    vPDPrt varchar[];

    ErrMsg varchar(300);


    -- taxsubject report

    tsreport cursor(vTaxDoc_id numeric) is
      select max((select d.value
                  from   decode d
                  where  upper(d.columnname) = 'KIND_IDN'
                  and    d.code = ts.kind_idn)) kindidn, min(ts.idn) idn,
             min(ts.name) custname,
             to_char(sum(ds.totaltax), '99999990.99') sumall,
             max(to_char(ds.tax_begidate, 'yyyy')) taxperiod, ds.debtsubject_id
      from   debtsubject ds
      inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
      inner join taxdoc td on ds.document_id = td.taxdoc_id
                          and ds.docno = td.docno
                          and ds.kinddoc = 1
      where
            --         ds.prtdate is null and
            td.taxdoc_id = vTaxDoc_id
      group  by ds.taxsubject_id, ds.debtsubject_id, ds.calcdate, coalesce(ds.corrno, 0)
      order  by custname, taxperiod;
    -- municipality logo
    logo cursor(vUser_id numeric) is
      select coalesce(m1.fullname,m.fullname) fullname,
             case when m1.municipality_id is not null then m.fullname else null end region,
             getaddress(ts.present_clientaddr_id) addr,
             m.municipality_id
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      left outer join config c on m.municipality_id = c.municipality_id
      left outer join taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id
      where u.user_id = vUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';
    -- message
    msg cursor(vTaxDoc_id numeric) is
      select distinct ('���������') Label1, ('������: ' || p.name) province,
                      ('������: ' || m.fullname) municipality,
                      (td.docno || '/' || to_char(td.doc_date, 'dd.mm.yyyy') ||
                       ' �.') msgnum, dt.docname, ds.taxsubject_id, dt.doccode,
                      -- TaxSubject
                      (select d.value
                        from   decode d
                        where  upper(d.columnname) = 'KIND_IDN'
                        and    d.code = ts.kind_idn) || ' ' || ts.idn idn,
                      (ts.name) tsname,
                      ('������� ������: ' || ts.taxsubjectno) taxsubj,
                      ('������� �����: ' || tobj.taxobjno) taxobj,
                      ('�����: ' || GetAddress(ts.present_clientaddr_id)) Address,
                      -- TaxObject
                      ('�������: ' || td.partidano) partidano,
                      td.partidano partidanom,
                      ('��� �� �����: ' || tt.nameproperty) propname,
                      ('����� �� �����: ' || getaddress(tt.address_id)) propaddr,
                      -- User
                      (u.fullname) operator1
      from Taxdoc td
      inner join users u on td.user_id = u.user_id
      left outer join Taxobject tobj on td.taxobject_id = tobj.taxobject_id
      left outer join Documenttype dt on td.documenttype_id = dt.documenttype_id
      left outer join Debtsubject ds on td.taxdoc_id = ds.document_id
      left outer join Taxsubject ts on coalesce(ds.taxsubject_id, td.taxsubject_id) = ts.taxsubject_id
      left outer join Touristtax tt on td.taxdoc_id = tt.taxdoc_id
      left outer join Municipality m on td.municipality_id = m.municipality_id
      left outer join Province p on m.province_id = p.province_id
      where  td.taxdoc_id = vTaxDoc_id;
    -- tax installments
    inst cursor(vTaxDoc_id numeric, vTaxSubject_id numeric) is
      select coalesce(ds.totaltax, 0) sumall,
             to_char(ds.tax_begidate, 'yyyy') taxperiod,
             (' �� ' || (select to_char(di.termpay_date, 'dd.mm.yyyy')
                          from   debtinstalment di
                          where  di.debtsubject_id = ds.debtsubject_id
                          and    di.instno = (select max(x.instno) from debtinstalment x
                                               where x.debtsubject_id = di.debtsubject_id))) period,
             '    '||(select max(x.instno) from debtinstalment x where x.debtsubject_id = ds.debtsubject_id)||' ������' vnum,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = (select max(x.instno) from debtinstalment x
                                    where x.debtsubject_id = di.debtsubject_id)) v1, ds.debtsubject_id
      from   TaxDoc td
      inner join Debtsubject ds on td.taxdoc_id = ds.document_id
                               and td.docno = ds.docno
      inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
      where  td.taxdoc_id = vTaxDoc_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    ds.kinddoc = 1
            --         ds.prtdate is null and
      order  by ds.tax_begidate;
    offices cursor(vMunicipality_id numeric) is
      select o.fullname, coalesce(o.address, '') address
      from   Users u
      inner join Office o on o.office_id = u.office_id
      where  o.isactive = 1
      and    u.user_id = iUser_id;
    bank cursor(vMunicipality_id numeric) is
      select b.name, a.iban
      from   baccount a
      inner join bank b on b.bank_id = a.bank_id
      where  a.isactive = 1
      and    a.isbase = 1
      and    a.municipality_id = vMunicipality_id;
    --��� ��������� ������ ������������ �� �� ��������:
    currobl cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano = vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano = vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    --��� ��������� ������ ������ �������� ���������� �� �� ��������:
    currobl_rest cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano <> vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano <> vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    --��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.
    oversum cursor(vTaxSubject_id numeric) is
      select max(kdr.fullname) taxname, max(kdr.acc) taxcode, os.partidano,
             sum(coalesce(boi.oversum, 0)) ndvn
      from   baloverinst boi
      inner join oversubject os on os.oversubject_id = boi.oversubject_id
      inner join kinddebtreg kdr on kdr.kinddebtreg_id = os.kinddebtreg_id
      where  os.taxsubject_id = vTaxSubject_id
      group  by os.partidano, os.kinddebtreg_id;

    i                numeric;

    vRest            varchar(300);

    vRest1           varchar(300);
    
    www              varchar(300);

    vMunicipality_id numeric;

    r record;

    d varchar;

    rowcount integer;

  begin

    if (iTaxDoc_id > 0) then

      i := 1; -- �����
      -- ======= Part 1 =========
      -- Report Obligations
      for msg_rec in msg(iTaxDoc_id)
      loop
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := center('������� �����', 70);
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.partidano, 42);
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.propname, 42);
        i := i + 1;
        r := wordwrap(msg_rec.propaddr, 70, 1);
        vPDPrt[i] := r.return_val;
        vrest := r.strrest;
        vPDPrt[i] := rpadc(vPDPrt[i], 80);
        i := i + 1;
        exit;
      end loop;
      vPDPrt[i] := rpadc(' ---------------', 60, '-');
      i := i + 1;
      vPDPrt[i] := '| ���/�������� |      ���                |������|    �����  ' || '|';
      i := i + 1;
      vPDPrt[i] := rpadc(' ---------------', 60, '-');
      i := i + 1;
      for ts in tsreport(iTaxDoc_id)
      loop
        vPDPrt[i] := rpadc('| ' || ts.idn, 15) || '|' || rpadc(ts.custname, 25) || '|' ||
                     rpadc(ts.taxperiod, 6) || '|' || lpadc(ts.sumall, 11) || '|';
        i := i + 1;
        vPDPrt[i] := rpadc(' ---------------', 60, '-');
        i := i + 1;
      end loop;
      -- ======= End Part 1 =========

      -- ======= Part 2 =========
      vPDPrt[i] := 'ff';
      i := i + 1;
      vPDPrt[i] := 'p2';
      i := i + 1;
      -- !!!!!!!!!!!!!!!!!!!!!!
      rowcount := 1;
      for msg_rec in msg(iTaxDoc_id)
      loop
        if rowcount > 1
        then
          vPDPrt[i] := 'ff';
          i := i + 1;
          vPDPrt[i] := 'p2';
          i := i + 1;
        end if;
        rowcount := rowcount + 1;
        for logo_rec in logo(iUser_id)
        loop
          vMunicipality_id := logo_rec.municipality_id;
          vPDPrt[i] := rpadc(' ------------------------------------------------',80, '-');
          i := i + 1;
          if (logo_rec.region is not null) then
           vPDPrt[i] := center(logo_rec.fullname ||' '|| '������', 80);
           i := i + 1;
           vPDPrt[i] := center('�������� ������� � ������������� �� ���', 80);
           i := i + 1;
           vPDPrt[i] := center('����� ���', 80);
           i := i + 1;
           vPDPrt[i] := center('� � � � �  ' || upper(logo_rec.region), 80);
           i := i + 1;
          else
           vPDPrt[i] := center('� � � � � �  ' || logo_rec.fullname, 80);
           i := i + 1;
           vPDPrt[i] := center('������ ������ � �����', 80);
           i := i + 1;
          end if;
          vPDPrt[i] := center(logo_rec.addr, 80);
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------',80, '-');
          i := i + 1;
          vPDPrt[i] := '';
          i := i + 1;
        end loop;
        vPDPrt[i] := center('�������', 80);
        i := i + 1;
       -- vPDPrt[i] := center(msg_rec.msgnum, 80);
       -- i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := rpadc('������� ������� �����:', 42) || ' ';
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.partidano, 42) || rpadc(msg_rec.idn, 40);
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.propname, 42) ||
                     rpadc('���:' || msg_rec.tsname, 38);
        i := i + 1;
        r := wordwrap(msg_rec.propaddr, 42, 1);
        www := r.return_val;
        vrest := r.strrest; 
        r := wordwrap(msg_rec.address, 40, 1);
        vPDPrt[i] := r.return_val;
        vrest1 := r.strrest;        
        vPDPrt[i] := rpadc(www, 42) || rpadc(vPDPrt[i], 40);
        i := i + 1;
        if (Length(vRest) > 1) or (Length(vRest1) > 1) then
          vPDPrt[i] := case when (Length(vRest) > 1) then rpadc(trim(vrest), 42) else rpadc('', 42) end ||
                       case when (Length(vRest1) > 1) then rpadc(trim(vrest1), 40) else rpadc('', 40) end;
          i := i + 1;
        end if;
        vPDPrt[i] := '';
        i := i + 1;
      /*  vPDPrt[i] := rpadc('  �������� ' || msg_rec.docname ||
                           ' �� ����,', 80);
        i := i + 1;
        vPDPrt[i] := rpadc('� ��.� ' || msg_rec.msgnum ||
                           ' �� �� ���������� �������� ������� ����������', 80,
                           ' ');
        i := i + 1; */
        vPDPrt[i] := '';
        i := i + 1;
        -- Installments
        for inst_rec in inst(iTaxDoc_id, msg_rec.taxsubject_id)
        loop
          vPDPrt[i] := rpadc(' ------------------------------------------------',
                             49, '-');
          i := i + 1;
          vPDPrt[i] := '|  ������������ �����   |     ���� �� �������    |';
          i := i + 1;
          ----------------
          vPDPrt[i] := rpadc('|      �� ' || inst_rec.taxperiod, 24) || '|' ||
                       center(inst_rec.vnum, 24) || '|';
          ----------------
          i := i + 1;
          vPDPrt[i] := rpadc('|       � ���� ', 24, ' ') || '|' ||
                       center(inst_rec.period || ' ', 24) || '|';
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------', 49, '-');
          i := i + 1;
          vPDPrt[i] := ' ���� ' || lpadc(to_char(inst_rec.sumall,'999999990.99'), 17) || ' |' ||
                       lpadc(to_char(coalesce(inst_rec.v1, 0), '999999990.99'), 24, ' ');
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------', 49, '-');
          i := i + 1;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
       /* vPDPrt[i] := '���������� ��������� �� � ��������������� ��� � �� ������� �� ���������.';
        i := i + 1;
        vPDPrt[i]  := '��� �� ��� �������� � ������������ �� ���������� ������ �� �������� �������� �� ';
        i          := i + 1;
        vPDPrt[i]  := '��� �� ������������ �� ������������ �� ������ ����� ������ �� ��������� � ';
        i          := i + 1;
        vPDPrt[i]  := '14-������ ���� �� ������������ ��.';
        i          := i + 1;
        vPDPrt[i] := '���� �������� �� ����� �� ��������� ����� ����������� ���������� �� ��������� �����!';
        i := i + 1;
        vPDPrt[i] := '���������� �� ������ �������� �� ������ �� �� �� ����� ������ � ������� ���������.';
        i := i + 1; */
        vPDPrt[i] := '';
        i := i + 1;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := '��� ��������� ������ ��� �������� ������� ������ �� ' || msg_rec.partidano;
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |     ��� ����������    |��� ��|    �������   | �������� | �����   |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||
                         rpadc(obl.taxname, 23) || '|' ||
                         rpadc(obl.taxcode, 6) || '|' ||
                         rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(obl.gl, '9999990.99'), 10) || '|' ||
                         lpadc(to_char(obl.lix, '999990.99'), 9) || '|' ||
                         lpadc(to_char(obl.obsto, '99999990.99'), 11);
            i := i + 1;
          end if;
        end loop;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
     /*   vPDPrt[i] := '���� �� ���������:';
        for rec in offices(0) loop
          wordwrap(vPDPrt[i], rpadc(vPDPrt[i],30)||' ����� �� ����: ' || rec.address, 80, 1, vrest);
          vPDPrt[i] := rpadc(vPDPrt[i],80);
          i := i + 1;
          if (Length(vRest) > 1)
          then
            vPDPrt[i] := lpadc(' ', 46) || rpadc(trim(vRest), 34, ' ');
            i := i + 1;
          end if;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        for bank_rec in bank(vMunicipality_id) loop
          vPDPrt[i] := lpadc(' ', 30) || ' ���� �� �����: ' ||
                       rpadc(bank_rec.name, 45);
          i := i + 1;
          vPDPrt[i] := lpadc(' ', 39) || rpadc(' IBAN: ' || bank_rec.iban, 45);
          i := i + 1;
          vPDPrt[i] := lpadc(' ', 39) ||
                       rpadc(' ��� ������� 442800/������.�����/', 40, ' ');
          i := i + 1;
        end loop; */
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := lpadc('���������� ����: .............................', 80);
        i := i + 1;
        vPDPrt[i] := lpadc('(��� �������� ������ �����)', 80);
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '��������: ' || msg_rec.operator1;
        i := i + 1;
        -- ======= End Part 2 =========

        -- ======= Part 3 =========
       /* vPDPrt[i] := 'ff';
        i := i + 1;
        vPDPrt[i] := 'p3';
        i := i + 1;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := rpadc('������� ������� �����:', 42) || '��:';
            i := i + 1;
            vPDPrt[i] := rpadc(msg_rec.partidano, 42) || rpadc(msg_rec.idn, 40);
            i := i + 1;
            vPDPrt[i] := rpadc(msg_rec.propname, 42) ||
                         rpadc('���:' || msg_rec.tsname, 38);
            i := i + 1;
            wordwrap(vPDPrt[i], msg_rec.propaddr, 41, 1, vrest);
            wordwrap(www, msg_rec.address, 40, 1, vrest1);
            vPDPrt[i] := rpadc(vPDPrt[i], 41) || ' ' || rpadc(www, 40);
            i := i + 1;
            if (Length(vrest) > 1) or (Length(vrest1) > 1)
            then
              vPDPrt[i] := lpadc(vrest, 41) || ' ' || rpadc(vrest1, 34, ' ');
              i := i + 1;
            end if;
            vPDPrt[i] := '';
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := '��� ��������� ������ ����� �������� ����������:';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||
                         rpadc(obl.taxname, 25) || '|' || rpadc(obl.taxcode, 6) || '|' ||
                         rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(obl.gl, '9999990.99'), 10) || '|' ||
                         lpadc(to_char(obl.lix, '990.99'), 7) || '|' ||
                         lpadc(to_char(obl.obsto, '99990.99'), 11);
            i := i + 1;
          end if;
        end loop;
        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        -------- �������� ���� ---------
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0)
          then
            vPDPrt[i] := '';
            i := i + 1;
            vPDPrt[i] := '��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               60, '-');
            i := i + 1;
            vPDPrt[i] := '|     ��� ����������      |��� ��|    �������   |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               60, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0)
          then
            vPDPrt[i] := ' ' || rpadc(ovr.taxname, 25) || '|' ||
                         rpadc(ovr.taxcode, 6) || '|' ||
                         rpadc(coalesce(ovr.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(ovr.ndvn, '99990.99'), 11);
            i := i + 1;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0)
          then
            vPDPrt[i] := rpadc(' ------------------------------------------------',
                               60, '-');
            i := i + 1;
            vPDPrt[i] := '';
            i := i + 1;
            exit;
          end if;
        end loop;
  
        -- Check for rows after p3 else delete p3  
        if vPDPrt[i-1] = 'p3' then
  		vPDPrt := vPDPrt[array_lower(vPDPrt,1) : array_upper(vPDPrt,1)-2];
         -- vPDPrt.DELETE(vPDPrt.LAST);
         -- vPDPrt.DELETE(vPDPrt.LAST);
          i := i - 2;
        end if;  */

        -- ======= End Part 3 ========= 

      

      end loop;

    end if;

    

    vPD_lob :=  paydocument_pkg.tblToLob(vPDPrt );

  

    --commit;

    return_val := 'OK';

    return;

  exception

    when others then

      begin

        --rollback;

        perform NOM_PKG.ErrManage(ErrMsg);

        return_val := ErrMsg;

        return;

      

      end;

end;
$function$
; DROP FUNCTION paydocument_pkg.moneyorder(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.moneyorder(OUT return_val character varying, vuser_id numeric, vpdocument_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  vPDPrt varchar [ ];
  ErrMsg varchar(300);

  getPD         cursor(vPDocument_id paydocument.paydocument_id%type) is
    select ('�� ' || b.fullname || ' �������� �������������� �����') tobank,
           ('���� ' || b.name || lpadc('���� �� �����������', 40, ' ')) bbranch,
           ('����� ' || b.address) baddress,
           ('������� ������: ' || ts.name) taxsubj,
           
           ('���������: ' || ts.name) arr_name,
           ('IBAN �� ���������� ' || pd.tsaccount) arr_iban,
           ('BIC �� ���������� ' || pd.tsbic) arr_bic,
           ('��� ������� ' || kdr.acc) arr_debtreg,
           ('��� ����� ' || b.fullname) arr_bankname,
           
           to_char(pd.docsum, '99990.99') docsum,
           
           ('��������� �� �������: ' || pd.reason1) reas1, pd.reason2 reas2,
           ('��� ���. 9') ::varchar kinddoc,
           ('� �� ���. ' || coalesce(pd.documentno, '')) docno,
           ('���� �� ���. ' || to_char(pd.paydate, 'dd.mm.yyyy')) docdate,
           ('������, �� ����� �� �����   �� ' ||
            to_char(pd.docfromdate, 'dd.mm.yyyy') || ' �� ���� ' ||
            to_char(pd.doctodate, 'dd.mm.yyyy')) period,
           
           coalesce(u.fullname/*ts1.name 27.07.2012 Mantis N:11565*/, '') rec_name, 
           coalesce(p.identdocno, ' ') rec_identno,
           coalesce(ts1.idn, ' ') rec_idn
    from   Paydocument pd
    left   outer join Taxsubject ts
    on     pd.taxsubject_id = ts.taxsubject_id
    left   outer join Taxsubject ts1
    on     pd.receive_taxsubject_id = ts1.taxsubject_id
    left   outer join Person p
    on     ts1.taxsubject_id = p.taxsubject_id
    left   outer join Baccount ba
    on     pd.baccount_id = ba.baccount_id
    left   outer join Bank b
    on     ba.bank_id = b.bank_id
    left   outer join Kinddebtreg kdr
    on     pd.from_kinddebtreg_id = kdr.kinddebtreg_id
    left   outer join Users u
    on     pd.user_id = u.user_id
    where  pd.paydocument_id = vPDocument_id
    and    pd.kindpaydoc = '624'
    order  by pd.paydate;
  i             integer;
  vRest         varchar(300);
  vTotalInstSum numeric(18, 2);
  r             record;
  d             varchar;
begin
  i             := 1; -- ����� 
  vTotalInstSum := 0;
  for getPD_rec in getPD(vPDocument_id)
  loop
    vPDPrt [ i ] := rpadc(getPD_rec.tobank,50) ||
                    lpadc('����� � ���� �� ��������', 30, ' ');
    i := i + 1;
    vPDPrt [ i ] := '����    ';
    i := i + 1;
    vPDPrt [ i ] := rpadc(getPD_rec.baddress,42) ||
                    lpadc('.....................................', 48, ' ');
    i := i + 1;
    vPDPrt [ i ] := lpadc('������� �� ������, ����� ����� �� �� �����������', 80,
                          ' ');
    i := i + 1;
    vPDPrt [ i ] := '--------------------------------------------------------------------------------';
    i := i + 1;
      vPDPrt[i] := rpadc(getPD_rec.arr_name, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(getPD_rec.arr_iban, 50) ||' '|| lpadc(getPD_rec.arr_bic,29);
      i := i + 1;
      vPDPrt[i] := rpadc(getPD_rec.arr_bankname,60) ||' '|| lpadc(getPD_rec.arr_debtreg,19);

    i := i + 1;
    vPDPrt [ i ] := '--------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt [ i ] := '      ���������     | ������� |   ��� ������    |          ����  ';
    i := i + 1;
  
    vPDPrt [ i ] := '      ��������      | � ����  |      BGN        |' ||
                    lpadc(getPD_rec.docsum || '��.', 25, ' ');
    i := i + 1;
    vPDPrt [ i ] := '--------------------------------------------------------------------------------'; --80
    i := i + 1;
    vPDPrt [ i ] := '� ����: ' || rpadc(advance_pkg.Slovom(trim(getPD_rec.docsum)),
                                        70, ' ');
    i := i + 1;
    r := wordwrap(getPd_rec.reas1, 80, 1);
    vPDPrt [ i ] := r.return_val;
    vRest := r.strrest;
    i := i + 1;
    if (Length(vRest) > 1)
    then
      vPDPrt [ i ] := rpadc(vRest, 80, ' ');
      i := i + 1;
    end if;
    r := wordwrap(getPd_rec.reas2, 80, 1);
    vPDPrt [ i ] := r.return_val;
    vRest := r.strrest;
  
    i := i + 1;
    if (Length(vRest) > 1)
    then
      vPDPrt [ i ] := rpadc(vRest, 80, ' ');
      i := i + 1;
    end if;
    vPDPrt [ i ] := getPD_rec.kinddoc || ' ' || getPD_rec.docno || ' ' ||
                    getPD_rec.docdate;
    i := i + 1;
    vPDPrt [ i ] := getPD_rec.period;
    i := i + 1;
    vPDPrt [ i ] := '================================================================================';
    i := i + 1;
    vPDPrt [ i ] := '������������� - ����� ����� �� ������, ������������ �� ������ ������';
    i := i + 1;
    vPDPrt [ i ] := getPD_rec.rec_name;
    i := i + 1;
    vPDPrt [ i ] := '--------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt [ i ] := '�������� �� ����������� �  |        ���        | ���������';
    i := i + 1;
    vPDPrt [ i ] := rpadc(getPD_rec.rec_identno, 27, ' ') || '|' ||
                    rpadc(getPD_rec.rec_idn, 19, ' ') || '|';
    i := i + 1;
    vPDPrt [ i ] := '--------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt [ i ] := '������� ������             | ��������� ������  | ������������      | ������';
    i := i + 1;
    vPDPrt [ i ] := '                           |                   |                   |       ';
    i := i + 1;
    vPDPrt [ i ] := '--------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt [ i ] := '- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ';
    i := i + 1;
    vPDPrt [ i ] := '';
  end loop;

  vPD_lob := paydocument_pkg.tblToLob(vPDPrt);

  --commit;
  return_val := 'OK';
  return;
exception
  when others then
    begin
      --rollback;
      d := sqlerrm ::varchar;
      perform NOM_PKG.ErrManage(ErrMsg);
      return_val := ErrMsg;
      return;
    end;
end;
$function$
; DROP FUNCTION paydocument_pkg.obligationchroniclebypartida(numeric, numeric, numeric, character varying); 
CREATE OR REPLACE FUNCTION paydocument_pkg.obligationchroniclebypartida(OUT return_val character varying, vuser_id numeric, vtaxsubject_id numeric, vmunicipalityid numeric, vpartidano character varying, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                                         
    vPDPrt varchar[];
    ErrMsg varchar(100);
     chro cursor (ptaxsubject_id numeric) is
--���������� �� ������� -- OBLIGATIONS ----
 select  1 ordered,
         null SrokPl, --max(ds.calcdate) SrokPl,
         ds.partidano partidano,
         max(ki.kinddebtreg_id),
         max(ki.name) zadalz,
         To_Char(max(ds.tax_begidate),'yyyy') godina,
         max(coalesce(ds.docno,td.docno))||'/'||max(to_char(coalesce(ds.doc_date,td.doc_date),'dd.mm.yyyy')) novn,
         sum(coalesce(di.instsum,0)) DalzimaGl,
         -- include exception on paragraph 6500
         sum(case when trim(ki.code) = '6500' then round((select coalesce(bdi.interestsum,0) from baldebtinst bdi
                                              where bdi.debtinstalment_id = di.debtinstalment_id) +
                                              coalesce(sanction_pkg.TempInt(di.debtinstalment_id, CURRENT_DATE),0),2)
              else Round((coalesce(idb.intdebtsum,0)+coalesce(sanction_pkg.TempInt(di.debtinstalment_id,CURRENT_DATE),0)),2)
         end) lixva,
         --sum(Round((coalesce(idb.intdebtsum,0)+coalesce(sanction_pkg.TempInt(di.debtinstalment_id,CURRENT_DATE),0)),2)) lixva,
         sum((coalesce(di.instsum,0)+ Round(coalesce(idb.intdebtsum,0)+
              coalesce(sanction_pkg.TempInt(di.debtinstalment_id,CURRENT_DATE),0),2)-
              coalesce(Sanction_Pkg.tempdiscount(di.debtinstalment_id,CURRENT_DATE),0))) ObstoDalzimo,
         max(/*case when (select sum(p2.paydiscsum)
            from paydocument p1, paydebt p2, paytransaction p3
           where p1.paydocument_id = p2.paydocument_id
             and p1.taxsubject_id = ptaxsubject_id
             and decode(vPartidaNo,'0','0',coalesce(p1.partidano,'0')) = vPartidaNo
             and p1.paytransaction_id = p3.paytransaction_id
             and p3.trtype in ('1','2','4','9','33')) is not null then null
         else*/ coalesce(Sanction_Pkg.tempdiscount(di.debtinstalment_id,CURRENT_DATE),0) /*end*/) otstp,
         null sumpl,
         null oversum,
         max(ki.code)||max(kpr.parreg_code) kodpl
    from debtsubject ds
    inner join kinddebtreg ki on ds.kinddebtreg_id = ki.kinddebtreg_id
    inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
    inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
    left outer join taxdoc td on ds.document_id = td.taxdoc_id
    left outer join Kindparreg kpr on ds.kindparreg_id = kpr.kindparreg_id
    left outer join interestdebt idb on idb.debtinstalment_id = di.debtinstalment_id
   where case when vPartidaNo = '0' then '0' else coalesce(coalesce(ds.partidano,td.partidano),'0') end = vPartidaNo
     and ds.taxsubject_id = ptaxsubject_id
   group by ds.partidano, ds.tax_begidate, ds.kinddebtreg_id
        --  and ds.partidano =
    ---------- Payments -----------
    union all
    select 2 ordered,trunc(pd.paydate) SrokPl, nullif(trim(pd.partidano),'') partidano,ki.kinddebtreg_id,
          coalesce((select d.value from decode d where upper(d.columnname) = 'KINDPAYDOC' and d.code = pd.kindpaydoc),'') zadalz,
           null godina,
           (/*pd.series||*/trim(pd.documentno)||'/'||to_char(pd.user_date,'dd.mm.yyyy')) novn, --null novn,
           null dalzimaGL, null lixva, null ObstoDalzimo,
           coalesce(padt.otstp,0) otstp,
--           decode(pd.kindpaydoc,'621',-pd.docsum,'622',-pd.docsum,pd.docsum) sumPl, -- 11.11.2010 changed
--           decode(pd.kindpaydoc,'621',-coalesce(padt.instsum,pd.docsum),'622',-coalesce(padt.instsum,pd.docsum),coalesce(padt.instsum,pd.docsum)) sumPl, -- 16.05.2011 changed
           case pd.kindpaydoc when '621' then -1*pd.docsum when '622' then -1*pd.docsum else pd.docsum end sumPl, --17.04.2012 changed po mant.N:0010942 
           coalesce(pd.overpaysum,0) oversum,
           case when  (select count(*) from paydebt px 
                        where px.paydocument_id = pd.paydocument_id
                          and px.kinddebtreg_id in (2,5) and ptr.trtype = '1') > 1 then '21/2400' else ki.code end kodPL --****
     from paydocument pd
     inner join paytransaction ptr on pd.paytransaction_id = ptr.paytransaction_id
--          (select pdt.paydocument_id pdd, sum(pdt.paydiscsum) otstp, max(pdt.kinddebtreg_id) kdr -- 11.11.2010 changed
--             from paydebt pdt group by pdt.paydocument_id) padt, kinddebtreg ki
        /*  (select pdt.paydocument_id pdd, sum(pdt.paydiscsum) otstp, sum(pdt.payinstsum + pdt.payinterestsum) instsum, pdt.kinddebtreg_id kdr
             from paydebt pdt group by pdt.paydocument_id, pdt.kinddebtreg_id) padt, kinddebtreg ki 16.05.2011 changed*/
      left outer join (select pdt.paydocument_id pdd, sum(pdt.paydiscsum) otstp, max(pdt.kinddebtreg_id) kdr --, sum(pdt.payinstsum+pdt.payinterestsum) instsum
                         from paydebt pdt group by pdt.paydocument_id) padt on pd.paydocument_id = padt.pdd
      inner join kinddebtreg ki on case when padt.kdr is null then coalesce(pd.over_kinddebtreg_id,24) else padt.kdr end = ki.kinddebtreg_id --****
    where pd.taxsubject_id = ptaxsubject_id
      and case when vPartidaNo = '0' then '0' else coalesce(pd.partidano,'0') end = vPartidaNo
      and ptr.trtype in ('1','2','4','9','33','1P')
      --------- �� �����. ---------------
   /* union all
    select 3 ordered,
           case when pd.paydocument_id is not null then trunc(pd.paydate) else op.oper_date end  SrokPl,
           nullif(case when pd.paydocument_id is not null then trim(pd.partidano) else opd.partidano end,'') partidano,
           ki.kinddebtreg_id,
           case when op.opercode = '22' then
                (select d.value from decode d where upper(d.columnname) = 'KINDPAYDOC' and d.code = '630') else '' end zadalz,
           null godina,
           case when pd.paydocument_id is not null then trim(pd.documentno)||'/'||to_char(pd.user_date,'dd.mm.yyyy')
                else op.operdocno||'/'||to_char(op.oper_date,'dd.mm.yyyy') end novn,
           null dalzimaGL, null lixva, null ObstoDalzimo,
           opd.discsum otstp,
    --       decode(pd.kindpaydoc,'621',-1*pd.docsum,'622',-1*pd.docsum,pd.docsum) sumPl,
           coalesce(op.opersum,0) sumPl,
           null oversum,
           opd.code
      from operation op
      inner join paytransaction ptr on ptr.paytransaction_id = op.paytransaction_id
      inner join oversubject os on os.oversubject_id = op.oversubject_id
      left outer join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id
      inner join kinddebtreg ki on ki.kinddebtreg_id = os.kinddebtreg_id
      inner join (select od.operation_id, max(ki2.code) code, sum(od.discsum) discsum, max(ds.partidano) partidano
                    from operdebt od
                    inner join kinddebtreg ki2 on ki2.kinddebtreg_id = od.kinddebtreg_id
                    inner join debtinstalment di on di.debtinstalment_id = od.debtinstalment_id
                    inner join  debtsubject ds on ds.debtsubject_id = di.debtsubject_id
                    group by od.operation_id, od.kinddebtreg_id) opd on opd.operation_id = op.operation_id
     where os.taxsubject_id = ptaxsubject_id
       and case when vPartidaNo = '0' then '0'
                when pd.paydocument_id is not null then coalesce(pd.partidano,'0')
                when pd.paydocument_id is null then coalesce(opd.partidano,'0') end = vPartidaNo
       --and decode(vPartidaNo,'0','0',coalesce(opd.partidano,'0')) = vPartidaNo*/
    -------- STORNO -----------
    union all
    select 4 ordered,
           trunc(pd.paydate) SrokPl,
           nullif(trim(pd.partidano),'') partidano,
           ki.kinddebtreg_id,
          (coalesce((select d.value from decode d where upper(d.columnname) = 'KINDPAYDOC' and d.code = pd.kindpaydoc),'')||'*') zadalz,
           null godina,
           (/*pd.series||*/trim(pd.documentno)||'/'||to_char(pd.user_date,'dd.mm.yyyy')) novn, --null novn,
           null dalzimaGL,
           null lixva,
           null ObstoDalzimo,
           coalesce(padt.otstp,0)*-1 otstp,
           decode(pd.kindpaydoc,'621',pd.docsum,'622',pd.docsum,-1*pd.docsum) sumPl,
           coalesce(pd.overpaysum,0)*-1 oversum,
           /*ki.code*/'' kodPL
     from paydocument pd
     inner join paytransaction ptr on pd.paytransaction_id = ptr.paytransaction_id
     left outer join (select pdt.paydocument_id pdd, sum(pdt.paydiscsum) otstp, max(pdt.kinddebtreg_id) kdr
                        from paydebt pdt group by pdt.paydocument_id) padt on pd.paydocument_id = padt.pdd
     inner join kinddebtreg ki on decode(padt.kdr,null,coalesce(pd.over_kinddebtreg_id,24),padt.kdr) = ki.kinddebtreg_id --****
    where pd.taxsubject_id = ptaxsubject_id --11919
      and decode(vPartidaNo,'0','0',coalesce(pd.partidano,'0')) = vPartidaNo
      and ptr.trtype in ('1','2','4','9','33','1P')
      and pd.null_date is not null
   /* union all -- STORNO �����.
    select 5 ordered,
           case when pd.paydocument_id is not null then trunc(pd.paydate) else op.oper_date end  SrokPl,
           nullif(case when pd.paydocument_id is not null then trim(pd.partidano) else opd.partidano end,'') partidano,
           ki.kinddebtreg_id,
           case when op.opercode = '22' then
                (select d.value from decode d where upper(d.columnname) = 'KINDPAYDOC' and d.code = '630')||'*' else '' end zadalz,
           null godina,
           case when pd.paydocument_id is not null then trim(pd.documentno)||'/'||to_char(pd.user_date,'dd.mm.yyyy')
                else op.operdocno||'/'||to_char(op.oper_date,'dd.mm.yyyy') end novn,
           null dalzimaGL, 
           null lixva, 
           null ObstoDalzimo,
           coalesce(opd.discsum,0)*-1 otstp,
    --       decode(pd.kindpaydoc,'621',-1*pd.docsum,'622',-1*pd.docsum,pd.docsum) sumPl,
           -1*op.opersum sumPl,
           null oversum,
           opd.code
      from operation op
      inner join paytransaction ptr on ptr.paytransaction_id = op.paytransaction_id
      inner join oversubject os on os.oversubject_id = op.oversubject_id
      left outer join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id
      inner join kinddebtreg ki on ki.kinddebtreg_id = os.kinddebtreg_id
      inner join (select od.operation_id, max(ki2.code) code, sum(od.discsum) discsum, max(ds.partidano) partidano
                    from operdebt od
                    inner join kinddebtreg ki2 on ki2.kinddebtreg_id = od.kinddebtreg_id
                    inner join debtinstalment di on di.debtinstalment_id = od.debtinstalment_id
                    inner join  debtsubject ds on ds.debtsubject_id = di.debtsubject_id
                    group by od.operation_id, od.kinddebtreg_id) opd on opd.operation_id = op.operation_id
     where os.taxsubject_id = ptaxsubject_id
       and case when vPartidaNo = '0' then '0'
                when pd.paydocument_id is not null then coalesce(pd.partidano,'0')
                when pd.paydocument_id is null then coalesce(opd.partidano,'0') end = vPartidaNo
       and op.null_date is not null           
       --and decode(vPartidaNo,'0','0',coalesce(opd.partidano,'0')) = vPartidaNo*/
-- Order By 3,2,6,4,1  --partidano,srokpl,godina,ki.kinddebtreg_id,ordered  srokpl sotira null nai otdoly
   Order By 3,6,4,2,1 --partidano, godina, kinddebtreg, srokpl, ordered
 ;
    i             integer;
    vMunicipality varchar(100);
    vProvince     varchar(100);
    vime          varchar(100);
    veik          varchar(100);
    vdalzimagl    numeric(18, 2);
    vlixva        numeric(18, 2);
    vobstodalzimo numeric(18, 2);
    vtotal        numeric(18, 2);
    votstp        numeric(18, 2);
    vcalcotstp    numeric(18, 2);
    vrealotstp    numeric(18, 2);
    vsumpl        numeric(18, 2);
    voversum      numeric(18, 2);
    vostatyk      numeric(18, 2);
    v_region varchar(10) := ', �-� '; 
    d varchar;
  begin
    i             := 1; -- ����� 
    vdalzimagl    := 0;
    vlixva        := 0;
    vobstodalzimo := 0;
    vtotal        := 0;
    votstp        := 0;
    vcalcotstp    := 0;
    vrealotstp    := 0;
    vsumpl        := 0;
    voversum      := 0;
    vostatyk      := 0;
    if (vMunicipalityID = 0) then
      select coalesce(m1.fullname,m.fullname) ||
             case when m1.municipality_id is not null then v_region || m.fullname else '' end, p.name 
        into vMunicipality, vProvince
        from users u
        left outer join municipality m on u.municipality_id = m.municipality_id
        left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id      
        left outer join province p on m.province_id = p.province_id
       where u.user_id = vUser_id;
    else
      select m.fullname, p.name
      into   vMunicipality, vProvince
      from   municipality m, province p
      where  m.municipality_id = vMunicipalityId
      and    m.province_id = p.province_id;
    end if;
    select t.idn, t.name
    into   veik, vime
    from   taxsubject t
    where  t.taxsubject_id = vTaxSubject_id;
    vPDPrt[i] := rpadc('������: ' || vProvince, 70) ||
                 lpadc('����: ' || to_char(current_date, 'dd.mm.yyyy'), 50);
    i := i + 1;
    vPDPrt[i] := rpadc('������: ' || vMunicipality, 70) ||
                 lpadc('      ' || to_char(current_timestamp, 'HH24:MI:SS'), 50);
    i := i + 1;
    vPDPrt[i] := center('���������� �� ���������� � �������� �� ������� ��� ����: ' ||
                        to_char(current_date, 'dd.mm.yyyy'), 120);
    i := i + 1;
    vPDPrt[i] := center(veik || ' - ' || vime, 120);
    i := i + 1;
  
    vPDPrt[i] := ' ---------------------------------------------------------------------------------------------------------------------------------------------'; --142  
    i := i + 1;
    vPDPrt[i] := '| ����     |                       |             |���        |      |����        |����    |����      |����    | ���� ����.��������    |��� ���|';
    i := i + 1;
    vPDPrt[i] := '|�������   |�����/���� ��������    |����� �������|���������� |������|��������    |�����   |�������   |��������|  ����    |� �.�.�����.|�������|';
    i := i + 1;
    vPDPrt[i] := ' ---------------------------------------------------------------------------------------------------------------------------------------------';
    i := i + 1;
    for chro_rec in chro(vTaxSubject_id)
    loop
      vPDPrt[i] := ' ' || rpadc(coalesce(to_char(chro_rec.srokpl, 'dd.mm.yyyy'), ' '),
                                10, ' ') || ' ' ||
                   rpadc(coalesce(chro_rec.novn, '') || ' ', 23, ' ') || ' ' ||
                   rpadc(coalesce(chro_rec.partidano, ' '), 13, ' ') || ' ' ||
                   rpadc(chro_rec.zadalz, 11, ' ') || ' ' ||
                   rpadc(coalesce(chro_rec.godina, ' '), 6, ' ') || ' ' ||
                   lpadc(to_char(coalesce(chro_rec.dalzimagl, 0), '999990.99'), 12,
                         ' ') || ' ' ||
                   lpadc(to_char(coalesce(chro_rec.lixva, 0), '9990.99'), 8, ' ') || ' ' ||
                   lpadc(to_char(coalesce(chro_rec.obstodalzimo, 0), '999990.99'), 10,
                         ' ') || ' ' ||
                   lpadc(to_char(coalesce(chro_rec.otstp, 0), '9990.99'), 8, ' ') || ' ' ||
                   lpadc(to_char(coalesce(chro_rec.sumpl, 0), '9999990.99'), 10, ' ') || ' ' ||
                   lpadc(to_char(coalesce(chro_rec.oversum, 0), '999990.99'), 12, ' ') || ' ' ||
                   rpadc(chro_rec.kodpl, 7, ' ');
      i := i + 1;
      vdalzimagl := vdalzimagl + coalesce(chro_rec.dalzimagl, 0);
      vlixva := vlixva + coalesce(chro_rec.lixva, 0);
      vobstodalzimo := vobstodalzimo + coalesce(chro_rec.obstodalzimo, 0);
      -- case when (chro_rec.ordered <> '1') then coalesce(chro_rec.otstp,0) else coalesce(chro_rec.otstp,0) end;
      votstp     := votstp + coalesce(chro_rec.otstp, 0);
      vcalcotstp := vcalcotstp + case
                      when (chro_rec.ordered = '1') then
                       coalesce(chro_rec.otstp, 0)
                      else
                       0
                    end;
      vrealotstp := vrealotstp + case
                      when (chro_rec.ordered <> '1') then
                       coalesce(chro_rec.otstp, 0)
                      else
                       0
                    end;
      vsumpl     := vsumpl + coalesce(chro_rec.sumpl, 0);
      voversum   := voversum + coalesce(chro_rec.oversum, 0);
    end loop;
    vPDPrt[i] := ' --------------------------------------------------------------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := rpadc('����:', 61, ' ') ||
                 lpadc(to_char(vdalzimagl, '999990.99'), 20, ' ') || ' ' ||
                 lpadc(to_char(vlixva, '9990.99'), 8, ' ') || ' ' ||
                 lpadc(to_char(vobstodalzimo, '999990.99'), 10, ' ') || ' ' ||
                 lpadc(to_char(votstp, '990.99'), 8, ' ') || ' ' ||
                 lpadc(to_char(vsumpl, '9999990.99'), 10, ' ') || ' ' ||
                 lpadc(to_char(voversum, '999990.99'), 12, ' ');
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '������� ���� ��������:' ||
                 lpadc(to_char(vdalzimagl, '999990.99'), 23, ' ');
    i := i + 1;
    vPDPrt[i] := '������� ���� �����:' ||
                 lpadc(to_char(vlixva, '9990.99'), 26, ' ');
    i := i + 1;
    vPDPrt[i] := '---------------------------------------------'; -- 45 
    i := i + 1;
    vtotal := vdalzimagl + vlixva;
    vPDPrt[i] := '���� ����������:' ||
                 lpadc(to_char(vtotal, '99999990.99'), 29, ' ');
    i := i + 1;
    vPDPrt[i] := '����������� ���� ��������:' ||
                 lpadc(to_char(vcalcotstp, '99990.99'), 19, ' ');
    i := i + 1;
    vPDPrt[i] := '����������� ��������:' ||
                 lpadc(to_char(vrealotstp, '99990.99'), 24, ' ');
    i := i + 1;
    vPDPrt[i] := '���� ��������:' ||
                 lpadc(to_char(vsumpl /*+ voversum*/, '99999990.99'), 31, ' ');
    i := i + 1;
    vPDPrt[i] := '---------------------------------------------';
    i := i + 1;
    vostatyk := vtotal - (vrealotstp + vsumpl /*+ voversum*/);
    vPDPrt[i] := '�������:' ||
                 lpadc(to_char(abs(vostatyk), '9999990.99'), 37, ' ');
    i := i + 1;
    
     vPD_lob := paydocument_pkg.tblToLob(vPDPrt );
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        --d := sqlerrm;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;
      
      end;
end;
$function$
; DROP FUNCTION paydocument_pkg.obligationschronicle(numeric, numeric, numeric, character varying); 
CREATE OR REPLACE FUNCTION paydocument_pkg.obligationschronicle(OUT return_val character varying, vuser_id numeric, vtaxsubject_id numeric, vmunicipalityid numeric, vpartidano character varying, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
    vPDPrt varchar[];
    ErrMsg varchar(100);
  chro Cursor (ptaxsubject_id Numeric, ppartidaNo varchar) is
 --- obligations
  select 1 ordered,
         di.termpay_date SrokPl,
         ds.partidano partidano, ki.kinddebtreg_id,
         ki.name zadalz, To_Char(ds.tax_begidate,'yyyy') godina, 
         di.instno NoVn,
         di.instsum DalzimaGl,
         -- include exception on paragraph 6500
         case when trim(ki.code) = '6500' then round((select coalesce(bdi.interestsum,0) from baldebtinst bdi
                                              where bdi.debtinstalment_id = di.debtinstalment_id) +
                                              coalesce(sanction_pkg.TempInt(di.debtinstalment_id,CURRENT_DATE),0),2)
              else Round((coalesce(idb.intdebtsum,0)+coalesce(sanction_pkg.TempInt(di.debtinstalment_id,CURRENT_DATE),0)),2)
         end lixva,
         --Round((coalesce(idb.intdebtsum,0)+coalesce(sanction_pkg.TempInt(di.debtinstalment_id,CURRENT_DATE),0)),2) lixva,
         (coalesce(di.instsum,0)+ Round(coalesce(idb.intdebtsum,0)+
          coalesce(sanction_pkg.TempInt(di.debtinstalment_id,CURRENT_DATE),0),2)-
          coalesce(Sanction_Pkg.tempdiscount(di.debtinstalment_id,CURRENT_DATE),0)) ObstoDalzimo,
         /*case when (select sum(p2.paydiscsum)
            from paydocument p1, paydebt p2, paytransaction p3
           where p1.paydocument_id = p2.paydocument_id
             and p1.taxsubject_id = ptaxsubject_id
             and decode(vPartidaNo,'0','0',coalesce(p1.partidano,'0')) = vPartidaNo
             and p1.paytransaction_id = p3.paytransaction_id
             and p3.trtype in ('1','2','4','9','33')) is not null then null
         else*/ coalesce(Sanction_Pkg.tempdiscount(di.debtinstalment_id,CURRENT_DATE),0) /*end*/ otstp,
         null::numeric sumpl,
         null::numeric oversum,
         ki.code||kpr.parreg_code kodpl
   from debtsubject ds
   inner join kinddebtreg ki on ds.kinddebtreg_id = ki.kinddebtreg_id
   inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
   inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
   left outer join taxdoc td on ds.document_id = td.taxdoc_id
   left outer join Kindparreg kpr on ds.kindparreg_id = kpr.kindparreg_id
   left outer join interestdebt idb on idb.debtinstalment_id = di.debtinstalment_id
   where ds.taxsubject_id = ptaxsubject_id
     and case when vPartidaNo = '0' then '0' else coalesce(coalesce(ds.partidano,td.partidano),'0') end = vPartidaNo
    ------------------------------------------------
    union all
    select 2 ordered, trunc(pd.paydate) SrokPl, nullif(trim(pd.partidano),'') partidano, ki.kinddebtreg_id,
          (coalesce((select d.value from decode d where upper(d.columnname) = 'KINDPAYDOC' and d.code = pd.kindpaydoc),'')||' '||(pd.series||pd.documentno)) zadalz,
           null::varchar godina, 
           null::numeric novn, 
           null::numeric dalzimaGL, 
           null::numeric lixva,
           null::numeric ObstoDalzimo,
           coalesce(padt.otstp,0) otstp,
--           decode(pd.kindpaydoc,'621',-pd.docsum,'622',-pd.docsum,pd.docsum) sumPl,
--           decode(pd.kindpaydoc,'621',-coalesce(padt.instsum,pd.docsum),'622',-coalesce(padt.instsum,pd.docsum),coalesce(padt.instsum,pd.docsum)) sumPl, --16.05.2011 changed
           case pd.kindpaydoc when '621' then -1*pd.docsum
                              when '622' then -1*pd.docsum else pd.docsum end sumPl, --17.04.2012 changed po mant.N:0010942 
           coalesce(pd.overpaysum,0) oversum,
           case when (select count(*) from paydebt px 
                       where px.paydocument_id = pd.paydocument_id
                         and px.kinddebtreg_id in (2,5) and ptr.trtype = '1') > 1 then '21/2400' else ki.code end kodPL --****
     from paydocument pd
     inner join paytransaction ptr on pd.paytransaction_id = ptr.paytransaction_id
--          (select pdt.paydocument_id pdd, sum(pdt.paydiscsum) otstp, max(pdt.kinddebtreg_id) kdr -- 11.11.2010 changed
--             from paydebt pdt group by pdt.paydocument_id) padt, kinddebtreg ki
/*          (select pdt.paydocument_id pdd, sum(pdt.paydiscsum) otstp, sum(pdt.payinstsum + pdt.payinterestsum) instsum, pdt.kinddebtreg_id kdr
             from paydebt pdt group by pdt.paydocument_id, pdt.kinddebtreg_id) padt, kinddebtreg ki 16.05.2011 changed*/
     left outer join (select pdt.paydocument_id pdd, sum(pdt.paydiscsum) otstp, max(pdt.kinddebtreg_id) kdr, sum(pdt.payinstsum+pdt.payinterestsum) instsum
                        from paydebt pdt group by pdt.paydocument_id) padt on pd.paydocument_id = padt.pdd
     inner join kinddebtreg ki on case when padt.kdr is null then coalesce(pd.over_kinddebtreg_id,24) else padt.kdr end = ki.kinddebtreg_id  --****
    where pd.taxsubject_id = ptaxsubject_id
      and case when vPartidaNo = '0' then '0' else coalesce(pd.partidano,'0') end = vPartidaNo
      and ptr.trtype in ('1','2','4','9','33','1P')
    -----------------------------------------�� �����.
    /*union all 26.06.2012
    select 3 ordered,
           case when pd.paydocument_id is not null then trunc(pd.paydate) else op.oper_date end  SrokPl,
           nullif(case when pd.paydocument_id is not null then trim(pd.partidano) else opd.partidano end,'') partidano,
           ki.kinddebtreg_id,
           case when op.opercode = '22' then
                (select d.value from decode d where upper(d.columnname) = 'KINDPAYDOC' and d.code = '630') else '' end zadalz,
           null godina,
           null novn,
           null dalzimaGL, null lixva, null ObstoDalzimo,
           opd.discsum otstp,
    --       decode(pd.kindpaydoc,'621',-1*pd.docsum,'622',-1*pd.docsum,pd.docsum) sumPl,
           coalesce(op.opersum,0) sumPl,
           null oversum,
           opd.code
      from operation op
      inner join paytransaction ptr on ptr.paytransaction_id = op.paytransaction_id
      inner join oversubject os on os.oversubject_id = op.oversubject_id
      left outer join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id
      inner join kinddebtreg ki on ki.kinddebtreg_id = os.kinddebtreg_id
      inner join (select od.operation_id, max(ki2.code) code, sum(od.discsum) discsum, max(ds.partidano) partidano
                    from operdebt od
                    inner join kinddebtreg ki2 on ki2.kinddebtreg_id = od.kinddebtreg_id
                    inner join debtinstalment di on di.debtinstalment_id = od.debtinstalment_id
                    inner join  debtsubject ds on ds.debtsubject_id = di.debtsubject_id
                    group by od.operation_id, od.kinddebtreg_id) opd on opd.operation_id = op.operation_id
     where os.taxsubject_id = ptaxsubject_id
       and case when vPartidaNo = '0' then '0'
                when pd.paydocument_id is not null then coalesce(pd.partidano,'0')
                when pd.paydocument_id is null then coalesce(opd.partidano,'0') end = vPartidaNo
       --and decode(vPartidaNo,'0','0',coalesce(opd.partidano,'0')) = vPartidaNo */
    -----------------------------------------storno
    union all
    select 4 ordered, trunc(pd.paydate) SrokPl, nullif(trim(pd.partidano),'') partidano, ki.kinddebtreg_id,
          (coalesce((select d.value from decode d where upper(d.columnname) = 'KINDPAYDOC' and d.code = pd.kindpaydoc),'')||' '||(pd.series||pd.documentno)||'*') zadalz,
           null::varchar godina,
           null::numeric novn,
           null::numeric dalzimaGL,
           null::numeric lixva,
           null::numeric ObstoDalzimo,
           coalesce(padt.otstp,0)*-1 otstp,
           case pd.kindpaydoc when '621' then pd.docsum
                              when '622' then pd.docsum else pd.docsum*-1 end sumPl,
           coalesce(pd.overpaysum,0)*-1 oversum,
           /*ki.code*/'' kodPL
     from paydocument pd
     inner join paytransaction ptr on pd.paytransaction_id = ptr.paytransaction_id
     left outer join (select pdt.paydocument_id pdd, sum(pdt.paydiscsum) otstp, max(pdt.kinddebtreg_id) kdr
                        from paydebt pdt group by pdt.paydocument_id) padt on pd.paydocument_id = padt.pdd
     inner join kinddebtreg ki on case when padt.kdr is null then coalesce(pd.over_kinddebtreg_id,24) else padt.kdr end = ki.kinddebtreg_id  --****
    where pd.taxsubject_id = ptaxsubject_id --11919
      and case when vPartidaNo = '0' then '0' else coalesce(pd.partidano,'0') end = vPartidaNo
      and ptr.trtype in ('1','2','4','9','33','1P')
      and pd.null_date is not null
   /* union all -- STORNO �����.
    select 5 ordered,
           case when pd.paydocument_id is not null then trunc(pd.paydate) else op.oper_date end  SrokPl,
           nullif(case when pd.paydocument_id is not null then trim(pd.partidano) else opd.partidano end,'') partidano,
           ki.kinddebtreg_id,
           case when op.opercode = '22' then
                (select d.value from decode d where upper(d.columnname) = 'KINDPAYDOC' and d.code = '630')||'*' else '' end zadalz,
           null godina,
           null novn,
           null dalzimaGL, 
           null lixva, 
           null ObstoDalzimo,
           coalesce(opd.discsum,0)*-1 otstp,
    --       decode(pd.kindpaydoc,'621',-1*pd.docsum,'622',-1*pd.docsum,pd.docsum) sumPl,
           -1*op.opersum sumPl,
           null oversum,
           opd.code
      from operation op
      inner join paytransaction ptr on ptr.paytransaction_id = op.paytransaction_id
      inner join oversubject os on os.oversubject_id = op.oversubject_id
      left outer join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id
      inner join kinddebtreg ki on ki.kinddebtreg_id = os.kinddebtreg_id
      inner join (select od.operation_id, max(ki2.code) code, sum(od.discsum) discsum, max(ds.partidano) partidano
                    from operdebt od
                    inner join kinddebtreg ki2 on ki2.kinddebtreg_id = od.kinddebtreg_id
                    inner join debtinstalment di on di.debtinstalment_id = od.debtinstalment_id
                    inner join  debtsubject ds on ds.debtsubject_id = di.debtsubject_id
                    group by od.operation_id, od.kinddebtreg_id) opd on opd.operation_id = op.operation_id
     where os.taxsubject_id = ptaxsubject_id
       and case when vPartidaNo = '0' then '0'
                when pd.paydocument_id is not null then coalesce(pd.partidano,'0')
                when pd.paydocument_id is null then coalesce(opd.partidano,'0') end = vPartidaNo
       and op.null_date is not null           
       --and decode(vPartidaNo,'0','0',coalesce(opd.partidano,'0')) = vPartidaNo */
-- Order By 3,2,4,1  --partidano,srokpl,ki.kinddebtreg_id,ordered 
 Order By 3,4,7,2,1
 ;
  i             Integer;
  vReadingDate  VarChar(18);
  vTheScales    VarChar(50);
  vMunicipality varchar(200);
  vProvince     varchar(200);
  vime          varchar(200);
  veik          varchar(100);
  vdalzimagl    Numeric(18,2);
  vlixva        Numeric(18,2);
  vobstodalzimo Numeric(18,2);
  vtotal        Numeric(18,2);
  votstp        Numeric(18,2);
  vcalcotstp    Numeric(18,2);
  vrealotstp    Numeric(18,2);
  vsumpl        Numeric(18,2);
  voversum      Numeric(18,2);
  vostatyk      Numeric(18,2);
  v_region varchar(10) := ', �-� '; 
  d varchar;  
  BEGIN
  i              := 1;                -- �����
  vdalzimagl     := 0;
  vlixva         := 0;
  vobstodalzimo  := 0;
  vtotal         := 0;
  votstp         := 0;
  vcalcotstp     := 0;
  vrealotstp     := 0;
  vsumpl         := 0;
  voversum       := 0;
  vostatyk       := 0;
  if (vMunicipalityID = 0) then
      select coalesce(m1.fullname,m.fullname) ||
             case when m1.municipality_id is not null then v_region || m.fullname else '' end, p.name
        into vMunicipality, vProvince
        from users u
        left outer join municipality m on u.municipality_id = m.municipality_id
        left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
        left outer join province p on m.province_id = p.province_id
       where u.user_id = vUser_id;
  else
    select m.fullname, p.name into vMunicipality, vProvince from municipality m, province p
     where m.municipality_id = vMunicipalityId and
           m.province_id = p.province_id;
  end if;
  select t.idn, t.name into veik, vime from taxsubject t where t.taxsubject_id = vTaxSubject_id;
  vPDPrt[i]  := rpadc('������: '||vProvince,70)||lpadc('����: '||to_char(CURRENT_DATE,'dd.mm.yyyy'),50);
  i          := i + 1;
  vPDPrt[i]  := rpadc('������: '||vMunicipality,70)||lpadc('      '||to_char(CURRENT_DATE,'hh24:mi:ss'),50);
  i          := i + 1;
  vPDPrt[i]  := center('���������� �� ���������� � �������� �� ������ ��� ����: '||to_char(CURRENT_DATE,'dd.mm.yyyy'),120);
  i          := i + 1;
  vPDPrt[i]  := center(veik||' - '||vime,120);
  i          := i + 1;

  vPDPrt[i]  := ' -----------------------------------------------------------------------------------------------------------------------------------'; --132
  i          := i + 1;
  vPDPrt[i]  := '|����/����   |             |                    |    |���.|����        |����       |����      |����    |���� ����.��������  |��� ���|';
  i          := i + 1;
  vPDPrt[i]  := '|�������     |����� �������|��� ������./��.���. |���.|��. |��������    |�����      |�������   |��������|  �����   | �����.  |�������| ';
  i          := i + 1;
  vPDPrt[i]  := ' -----------------------------------------------------------------------------------------------------------------------------------';
  i          := i + 1;
   FOR chro_rec in chro(vTaxSubject_id, vPartidaNo) LOOP
    vPDPrt[i]  := ' '||
                  lpadc(coalesce(to_char(chro_rec.srokpl,'dd.mm.yyyy'),' '),12,' ')||' '||
                  rpadc(coalesce(chro_rec.partidano,' '),13,' ')||' '||
                  rpadc(chro_rec.zadalz,20,' ')||' '||
                  rpadc(coalesce(chro_rec.godina,' '),4,' ')||' '||
                  rpadc(coalesce(chro_rec.novn,0)||' ',4,' ')||' '||
                  lpadc(to_char(coalesce(chro_rec.dalzimagl,0),'999999990.99'),12,' ')||' '||
                  lpadc(to_char(coalesce(chro_rec.lixva,0),'99999990.99'),11,' ')||' '||
                  lpadc(to_char(coalesce(chro_rec.obstodalzimo,0),'9999990.99'),10,' ')||' '||
                  lpadc(to_char(coalesce(chro_rec.otstp,0),'99990.99'),8,' ')||' '||
                  lpadc(to_char(coalesce(chro_rec.sumpl,0),'9999990.99'),10,' ')||' '||
                  lpadc(to_char(coalesce(chro_rec.oversum,0),'999990.99'),9,' ')||' '||
                  rpadc(chro_rec.kodpl,7,' ')
                  ;
    i             :=  i + 1;
    vdalzimagl    := vdalzimagl + coalesce(chro_rec.dalzimagl,0);
    vlixva        := vlixva + coalesce(chro_rec.lixva,0);
    vobstodalzimo := vobstodalzimo + coalesce(chro_rec.obstodalzimo,0);
    votstp        := votstp + coalesce(chro_rec.otstp,0);
    vcalcotstp    := vcalcotstp + case when (chro_rec.ordered = '1') then coalesce(chro_rec.otstp,0) else 0 end;
    vrealotstp    := vrealotstp + case when (chro_rec.ordered <> '1') then coalesce(chro_rec.otstp,0) else 0 end;
    vsumpl        := vsumpl + coalesce(chro_rec.sumpl,0);
    voversum      := voversum + coalesce(chro_rec.oversum,0);
   END LOOP;
   vPDPrt[i]  := ' ----------------------------------------------------------------------------------------------------------------------------------';
   i          := i + 1;
   vPDPrt[i]  := rpadc('����:',51,' ')||
                 lpadc(to_char(vdalzimagl,'9999999990.99'),20,' ')||' '||
                 lpadc(to_char(vlixva,'99999990.99'),11,' ')||' '||
                 lpadc(to_char(vobstodalzimo,'9999990.99'),10,' ')||' '||
                 lpadc(to_char(votstp,'99990.99'),8,' ')||' '||
                 lpadc(to_char(vsumpl,'9999990.99'),10,' ')||' '||
                 lpadc(to_char(voversum,'999990.99'),9,' ');
   i          := i + 1;
   vPDPrt[i]  := '';
   i          := i + 1;
   vPDPrt[i]  := '';
   i          := i + 1;
   vPDPrt[i]  := '������� ���� ��������:'||lpadc(to_char(vdalzimagl,'9999999990.99'),23,' ');
   i          := i + 1;
   vPDPrt[i]  := '������� ���� �����:'||lpadc(to_char(vlixva,'99999990.99'),26,' ');
   i          := i + 1;
   vPDPrt[i]  := '---------------------------------------------'; -- 45
   i          := i + 1;
   vtotal     := vdalzimagl + vlixva;
   vPDPrt[i]  := '���� ����������:'||lpadc(to_char(vtotal,'99999990.99'),29,' ');
   i          := i + 1;
   vPDPrt[i]  := '����������� ���� ��������:'||lpadc(to_char(vcalcotstp,'99990.99'),19,' ');
   i          := i + 1;
   vPDPrt[i]  := '����������� ��������:'||lpadc(to_char(vrealotstp,'99990.99'),24,' ');
   i          := i + 1;
   vPDPrt[i]  := '���� ��������:'||lpadc(to_char(vsumpl /*+ voversum*/,'99999990.99'),31,' ');
   i          := i + 1;
   vPDPrt[i]  := '---------------------------------------------';
   i          := i + 1;
   vostatyk   := vtotal - (vrealotstp + vsumpl /*+ voversum*/);
   vPDPrt[i]  := '�������:'||lpadc(to_char(abs(vostatyk),'9999990.99'),37,' ');
   i          := i + 1;

    vpd_lob := paydocument_pkg.tblToLob(vPDPrt);

    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        errmsg := sqlerrm;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;

      end;
  end;
$function$
; DROP FUNCTION paydocument_pkg.paydocument_prt(numeric, integer); 
CREATE OR REPLACE FUNCTION paydocument_pkg.paydocument_prt(OUT return_val character varying, vpdocument_id numeric, visoriginal integer, OUT vpd_receipt text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  vPDPrt        varchar [ ];
  ErrMsg        varchar(300);
  XXX           varchar(300);
  v_region varchar(15) := ', �-� '; 
  GetPD         cursor(vPDocument_id paydocument.paydocument_id%type) is
    select tobj.kindtaxobject, pd.paydate, pd.null_date, tobj.taxobject_id,
           ('�����: ' || pd.series || '  �����: ' || pd.documentno || '/' ||
            to_char(coalesce(pd.documentdate, pd.paydate), 'dd.mm.yyyy')) docno,
           ('������: ' || p.name) province,
             ('������: ' || nvl(m1.fullname,m.fullname)) ||
               case when m1.municipality_id is not null then v_region || m.fullname else '' end municipality,
           
           ('������� ������: ' || ts.taxsubjectno) taxsubj,
           ('������� �����: ' || tobj.taxobjno) taxobj,
           ('�������: ' || pd.partidano ||
            decode(trim(nvl(tobj.registerno, '')), '', '',
                    '  ���.� ' || tobj.registerno)) partidano,
           
           (select d.value
             from   decode d
             where  upper(d.columnname) = 'KIND_IDN'
             and    d.code = ts.kind_idn) || ': ' || ts.idn idn,
           ('��� ��: ' || (select d.value
                            from   decode d
                            where  upper(d.columnname) = 'TYPE'
                            and    d.code = trreg.type)) kindpc,
           ('��� �� �����: ' ||
            (select d.value
              from   decode d
              where  upper(d.columnname) = 'KINDPROPERTY'
              and    d.code = tobj.kindproperty)) kindprop,
           
           ('���: ' || ts.name) tsname,
           ('�����: ' || cm.mark_name || ' �����: ' || cmd.model_name) crmark,
           ('�������� �: ' || tobj.kadastrno) kadastrno,
           
           -- ('��������: '||u.fullname) Employee,
           u.fullname,
           --('�������: '||u.username||' '||u.fullname) receiver,
           ('�����: ' || GetAddress(ts.present_clientaddr_id)) Address,
           ('� ��������: ' || tobj.motorno) motorno,
           ('� ����: ' || tobj.ramano) ramano,
           ('����� �� �����: ' || getaddress(tobj.address_id)) propaddr, pd.bin,
           decode(pd.reason1, null, null, '���������: ' || pd.reason1) pdreason,
             pt.trtype trtype
    
    from   Paydocument pd
      left   outer join Taxsubject ts 
      on pd.taxsubject_id = ts.taxsubject_id
      left   outer join Taxobject tobj 
      on pd.taxobject_id = tobj.taxobject_id
      left   outer join Debtsubject ds 
      on ts.taxsubject_id = ds.debtsubject_id
      left   outer join Transpmeansreg trreg 
      on tobj.transpmeansreg_id = trreg.transpmeansreg_id
      left   outer join Paytransaction pt 
      on pd.paytransaction_id = pt.paytransaction_id
      left   outer join Carreg cr 
      on tobj.carreg_id = cr.carreg_id
      left   outer join Carmodel cmd 
      on cr.carmodel_id = cmd.carmodel_id
      left   outer join Carmark cm 
      on cmd.carmark_id = cm.carmark_id
      left   outer join Municipality m 
      on pt.municipality_id = m.municipality_id
      left   outer join Municipality m1 
      on m.parentmunicipality_id = m1.municipality_id
      left   outer join Province p 
      on m.province_id = p.province_id
      left   outer join Users u 
      on pd.user_id = u.user_id
    where  pd.paydocument_id = vPDocument_id
    order  by pd.paydate;

  GetPayments   cursor(vPDocument_id paydocument.paydocument_id%type) is
    select 1 ord, kdreg.code kcode, to_char(ds.tax_begidate, 'yyyy') period,
           kdreg.code || kpr.parreg_code || (di.instno * 10) ordered,
           (ds.docno || decode(ds.doc_date, null, '', '/') ||
            to_char(ds.doc_date, 'dd.mm.yy')) dekl,
           to_char(di.termpay_date, 'dd.mm.yy') srok,
           to_char(di.instno, '99990') instno, di.debtsubject_id,
           to_char(pdt.balinstsum, '999999990.99')  dyljimo,
           to_char(pdt.payinstsum, '999999990.99')  plateno, 
           pdt.payinstsum paid, kdreg.code || kpr.parreg_code code, 
           kdreg.name kdregname, di.termpay_date sr
    from   Paydebt pdt
    left   outer join Debtinstalment di
    on     pdt.debtinstalment_id = di.debtinstalment_id
    left   outer join Debtsubject ds
    on     di.debtsubject_id = ds.debtsubject_id
    left   outer join Kindparreg kpr
    on     pdt.kindparreg_id = kpr.kindparreg_id
    left   outer join Kinddebtreg kdreg
    on     pdt.kinddebtreg_id = kdreg.kinddebtreg_id
    where  pdt.paydocument_id = vPDocument_id
    and    pdt.payinstsum > 0
    union all
    select 2 ord, kdreg.code kcode, to_char(ds.tax_begidate, 'yyyy') period,
           kdreg.code || kpr.parreg_code || (di.instno * 10 + di.instno) ordered,
           (ds.docno || decode(ds.doc_date, null, '', '/') ||
            to_char(ds.doc_date, 'dd.mm.yy')) dekl,
           to_char(di.termpay_date, 'dd.mm.yy') srok,
           to_char(di.instno, '99990') instno, di.debtsubject_id,
             to_char(pdt.balinterestsum, '999999990.99') dyljimo,
             to_char(pdt.payinterestsum, '999999990.99') plateno,
           pdt.payinterestsum paid,
           (kdreg.code || (select kpr.parreg_code
                            from   kindparreg kpr
                            where  kpr.kindparreg_id = 1)) code,
           ('���. ') || kdreg.name kdregname, di.termpay_date sr
    from   Paydebt pdt
    left   outer join Debtinstalment di
    on     pdt.debtinstalment_id = di.debtinstalment_id
    left   outer join Debtsubject ds
    on     di.debtsubject_id = ds.debtsubject_id
    left   outer join Kindparreg kpr
    on     pdt.kindparreg_id = kpr.kindparreg_id
    left   outer join Kinddebtreg kdreg
    on     pdt.kinddebtreg_id = kdreg.kinddebtreg_id
    
    
    where  pdt.paydocument_id = vPDocument_id
    and    pdt.payinterestsum > 0
    union
    select 3 ord, kdreg.code kcode, ('- 5%') period,
           kdreg.code || kpr.parreg_code || (di.instno * 10 + di.instno) ordered,
           (ds.docno || decode(ds.doc_date, null, '', '/') ||
            to_char(ds.doc_date, 'dd.mm.yy')) dekl,
           /*to_char(di.termpay_date, 'dd.mm.yy')*/ '' srok, 
           ' ' instno,
           di.debtsubject_id, to_char(pdt.paydiscsum * -1, '9999990.99') dyljimo,
           to_char(pdt.payinterestsum, '999999990.99')  plateno,
           pdt.payinterestsum paid, ' ' code, kdreg.name kdregname,
           di.termpay_date sr
    from   Paydebt pdt
    left   outer join Debtinstalment di
    on     pdt.debtinstalment_id = di.debtinstalment_id
    left   outer join Debtsubject ds
    on     di.debtsubject_id = ds.debtsubject_id
    left   outer join Kindparreg kpr
    on     ds.kindparreg_id = kpr.kindparreg_id
    left   outer join Kinddebtreg kdreg
    on     pdt.kinddebtreg_id = kdreg.kinddebtreg_id
    where  pdt.paydocument_id = vPDocument_id
    and    pdt.paydiscsum > 0
    order  by sr, kcode, ord;

  i             integer;
  vRest         varchar(300);
  vRes          varchar(300);
  vTotalInstSum numeric(18, 2);
  r             record;
  d             varchar;

  --GetPD_rec  GetPD%ROWTYPE;
begin
  i     := 1; -- ����� 
  vRest := '';
  vRes  := '';
  for GetPD_rec in GetPD(vPDocument_id) loop
    --  Open GetPD(vPDocument_id); 
    --  FETCH GetPD INTO GetPD_rec;     
    vTotalInstSum := 0;
    --vPDPrt [ i ] := center('�������� ���������', 60) ||
   --                 lpadc('����: ' || to_char(current_timestamp, 'dd.mm.yyyy'), 20); -- �������     
   if (GetPD_rec.trtype = '1') then
       vPDPrt[i]  := center('�������� ���������',60)||lpadc('����: '||to_char(current_timestamp,'dd.mm.yyyy'),20);
    end if;
    if (GetPD_rec.trtype = '1P') then
        vPDPrt[i]  := center('�������� ��������� - ���',60)||lpadc('����: '||to_char(current_timestamp,'dd.mm.yyyy'),20);
    end if;
    i := i + 1;
    vPDPrt [ i ] := center(GetPD_rec.docno, 60) ||
                    lpadc(to_char(current_timestamp, 'hh24:mi:ss'), 20); -- �������     
    i := i + 1;
    vPDPrt [ i ] := '';
  
    i := i + 1;
    if (vIsOriginal = 0)
    then
      if ((GetPD_rec.null_date is not null) and (GetPD_rec.bin = '1'))
      then
        vPDPrt [ i ] := center('� � � � � � � �', 70);
        i := i + 1;
      elsif ((GetPD_rec.null_date is not null) and (GetPD_rec.bin = '2'))
      then
        vPDPrt [ i ] := center('� � � � � � � � �', 70);
        i := i + 1;
      else
        vPDPrt [ i ] := center('� � � � � � � �', 70);
        i := i + 1;
      end if;
    end if;
    vPDPrt [ i ] := GetPD_rec.province;
    i := i + 1;
    vPDPrt [ i ] := GetPD_rec.municipality;
    i := i + 1;
    vPDPrt [ i ] := rpadc(GetPD_rec.taxsubj, 40) || rpadc(GetPD_rec.taxobj, 40);
    i := i + 1;
    vPDPrt [ i ] := rpadc(GetPD_rec.IDN, 40) || rpadc(GetPD_rec.partidano, 40);
    i := i + 1;
    if (GetPD_rec.kindtaxobject = '2')
    then
      vPDPrt [ i ] := rpadc(GetPD_rec.tsname, 40) ||
                      rpadc(GetPD_rec.kindpc, 40);
      i := i + 1;
      r := wordwrap(GetPD_rec.Address, 38, 1);
      vPDPrt [ i ] := r.return_val;
      vRest := r.strrest;
      vPDPrt [ i ] := rpadc(vPDPrt [ i ], 39) || ' ' ||
                      rpadc(GetPD_rec.crmark, 40);
      i := i + 1;
      vPDPrt [ i ] := rpadc(nvl(ltrim(vRest), ' '), 39) || ' ' ||
                      rpadc(GetPD_rec.motorno, 40);
      i := i + 1;
      vPDPrt [ i ] := rpadc(' ', 40) || rpadc(GetPD_rec.ramano, 40);
      i := i + 1;
    elsif (GetPD_rec.kindtaxobject = '1') and
          (nvl(GetPD_rec.taxobject_id, 0.0) > 0)
    then
      vPDPrt [ i ] := rpadc(GetPD_rec.tsname, 40) ||
                      rpadc(GetPD_rec.kindprop, 40);
      i := i + 1;
      r := wordwrap(GetPD_rec.Address, 38, 1);
      vPDPrt [ i ] := r.return_val;
      vRest := r.strrest;
    
      r    := wordwrap(GetPD_rec.propaddr, 40, 1);
      XXX  := r.return_val;
      vRes := r.strrest;
    
      vPDPrt [ i ] := rpadc(vPDPrt [ i ], 39) || ' ' || XXX;
      i := i + 1;
      vPDPrt [ i ] := rpadc(ltrim(vRest), 39) || ' ' || rpadc(ltrim(vRes), 40);
      i := i + 1;
    elsif (nvl(GetPD_rec.taxobject_id, 0.0) > 0)
    then
      vPDPrt [ i ] := rpadc(GetPD_rec.tsname, 40) ||
                      rpadc(GetPD_rec.kindprop, 40);
      i := i + 1;
      r := wordwrap(GetPD_rec.Address, 38, 1);
      vPDPrt [ i ] := r.return_val;
      vRest := r.strrest;
    
      r := wordwrap(GetPD_rec.propaddr, 40, 1);
      XXX := r.return_val;
      vRes := r.strrest;
        vPDPrt [ i ] := rpadc(vPDPrt [ i ], 39) || ' ' || XXX;
      i := i + 1;
      vPDPrt [ i ] := rpadc(vRest, 39) || ' ' || rpadc(vRes, 40);
      i := i + 1;
    else
      vPDPrt [ i ] := rpadc(GetPD_rec.tsname, 40);
      i := i + 1;
    end if;
   vPDPrt[i]  := '-----------------------------------------------------------------------------------';--83
   i          := i + 1;
   vPDPrt[i]  := '���    |��� ������.|���.|���� ��.|�����/���� ����.   |��|  �������   |  �������   ';
   i          := i + 1;
   vPDPrt[i]  := '-----------------------------------------------------------------------------------';
      i := i + 1;
      for GetPayments_rec in GetPayments(vPDocument_id) 
    loop
      vPDPrt [ i ] :=   lpadc(GetPayments_rec.Code, 7, ' ') || ' ' ||
                      rpadc(GetPayments_rec.Kdregname, 11, ' ') || ' ' ||
                      lpadc(GetPayments_rec.Period, 4, ' ') || ' ' ||
                      lpadc(GetPayments_rec.Srok, 8, ' ') || ' ' ||
                      rpadc(nvl(GetPayments_rec.Dekl, ' '), 19, ' ') || ' ' ||
                      lpadc(nvl(GetPayments_rec.Instno, ' '), 2, ' ') || ' ' ||
                      lpadc(GetPayments_rec.Dyljimo, 12, ' ') || ' ' ||
                      lpadc(GetPayments_rec.Plateno, 12, ' ');
      vTotalInstSum := vTotalInstSum + GetPayments_rec.plateno ::numeric;
      i := i + 1;
    end loop;
    vPDPrt[i] := '-----------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt [ i ] := rpadc(' ���� �������:', 58, ' ') ||
                    lpadc(to_char(vTotalInstSum, '999999990.99'), 24, ' ');
    i := i + 1;
    vPDPrt [ i ] := ' ������: ' || rpadc(advance_pkg.Slovom(trim(to_char(vTotalInstSum,
                                                                         '999999990.99'))),
                                         93, ' ');
    i := i + 1;
    if (GetPD_rec.trtype = '1P') then
            vPDPrt[i] := '';
            i := i + 1;
            vPDPrt[i] := rpadc('� ������ �� ������������ �� ��������� �� ���������� ������� ������� �� ���� ��', 80, ' ');
            i := i + 1;
            vPDPrt[i] := rpadc('��. 4, ��. 1 �� ���� �� � ������ ���������� �� ������������!', 80, ' ');
            i := i + 1;
     end if;
    vPDPrt [ i ] := '';
    if (GetPD_rec.pdreason is not null)
    then
      i := i + 1;
      r := wordwrap(GetPD_rec.pdreason, 78, 1);
      vPDPrt [ i ] := r.return_val;
      vRest := r.strrest;
      vPDPrt [ i ] := rpadc(' ' || vPDPrt [ i ], 80);
      if (Length(vRest) > 1)
      then
        i := i + 1;
        vPDPrt [ i ] := rpadc(vRest, 80);
      end if;
    end if;
    i := i + 1;
    vPDPrt [ i ] := '';
    i := i + 1;
    vPDPrt [ i ] := ' ��������: .......................          ' ||
                    '������:........................';
    i := i + 1;
    vPDPrt [ i ] := lpadc(' ', 10) || center(GetPD_rec.fullname, 22);
    i := i + 1;
    vPDPrt [ i ] := '';
    i := i + 1;
    vPDPrt[i] := ' - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ';
    i := i + 1;
    --  Close GetPD;  
  end loop;

  vpd_receipt := paydocument_pkg.tblToLob(vPDPrt);
  --tblToVarChar(vPDPrt, vPD_Receipt);

  --commit;
  return_val := 'OK';
  return;

exception
  when others then
    begin
      --rollback;
      d := sqlerrm;
      perform NOM_PKG.ErrManage(ErrMsg);
      return_val := ErrMsg;
      return;
    end;
end;
$function$
; DROP FUNCTION paydocument_pkg.paydocumentdeclmsg(numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.paydocumentdeclmsg(OUT return_val character varying, itaxdoc_id numeric, iuser_id numeric, ikindmsg numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare r record;
  begin
   
    IF (iKindMsg = 1) THEN
      r := paydocument_pkg.TalonStandart(iTaxDoc_id, iUser_id);
    ELSIF (iKindMsg = 2) THEN
        r := paydocument_pkg.TalonWide(iTaxDoc_id, iUser_id);
    ELSIF (iKindMsg = 3) THEN
        r := paydocument_pkg.MessageD54_Vehicle(iTaxDoc_id, iUser_id);
    ELSIF (iKindMsg = 4) THEN
        r := paydocument_pkg.MessageD61(iTaxDoc_id, iUser_id);
    ELSIF (iKindMsg = 5) THEN
        r := paydocument_pkg.MessageD14(iTaxDoc_id, iUser_id);
    ELSIF (iKindMsg = 6) THEN
        r := paydocument_pkg.MessageD117(iTaxDoc_id, iUser_id);
    ELSIF (iKindMsg = 7) THEN
        r := paydocument_pkg.MessageD32(iTaxDoc_id, iUser_id);
    ELSE
        r := paydocument_pkg.MessageD61R(iTaxDoc_id, iUser_id);
    END IF;      
    return_val := r.return_val;
    vPD_lob := r.vpd_lob;
end; 
   

$function$
; DROP FUNCTION paydocument_pkg.messaged14(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.messaged14(OUT return_val character varying, itaxdoc_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare

  vPDPrt varchar [];

  ErrMsg varchar(300);

  brsm   integer;

  XXX    varchar(300);

    -- taxsubject report
    tsreport cursor(vTaxDoc_id numeric) is
      select distinct case when trim(max(kdr.code)) = '2400' then '���' else max(kdr.name) end label1,
                      max((select d.value
                           from   decode d
                           where  upper(d.columnname) = 'KIND_IDN'
                           and    d.code = ts.kind_idn)) kindidn,
                      min(ts.idn) idn, min(ts.name) custname,
                      to_char(sum(ds.totaltax), '99999990.99') sumall,
                      max(to_char(ds.tax_begidate, 'yyyy')) taxperiod,
                      ds.debtsubject_id
      from   debtsubject ds
      inner  join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
      inner  join taxdoc td on ds.document_id = td.taxdoc_id
                           and coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) = coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
                           and ds.docno = td.docno
                           and ds.kinddoc = 1
      left   outer join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  td.taxdoc_id = vTaxDoc_id
      group  by ds.taxsubject_id, ds.debtsubject_id, ds.calcdate, coalesce(ds.corrno, 0)
      order  by custname, taxperiod;
    -- municipality logo
    logo cursor(vUser_id numeric) is
      select coalesce(m1.fullname,m.fullname) fullname,
             case when m1.municipality_id is not null then m.fullname else null end region,
             getaddress(ts.present_clientaddr_id) addr,
             m.municipality_id,
             case when m1.municipality_id is not null then 1 else 0 end issofia
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      left outer join config c on m.municipality_id = c.municipality_id
      left outer join taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id
      where u.user_id = vUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';
    -- message
    msg cursor(vTaxDoc_id numeric) is
      select distinct ('���������') Label1, ('������: ' || p.name) province,
                      ('������: ' || m.fullname) ts_municipality,
                      (td.docno || '/' || to_char(td.doc_date, 'dd.mm.yyyy') ||
                       ' �.') msgnum, dt.docname, ds.taxsubject_id, to_char(td.begintaxdate,'dd.mm.yyyy') begintaxdate, dt.doccode,
                      -- TaxSubject
                      (select d.value
                        from   decode d
                        where  upper(d.columnname) = 'KIND_IDN'
                        and    d.code = ts.kind_idn) || ' ' || ts.idn idn,
                      ('���: ' || ts.name) tsname,
                      ('������� ������: ' || ts.taxsubjectno) taxsubj,
                      ('������� �����: ' || tobj.taxobjno) taxobj,
                      ('�����: ' || GetAddress(ts.present_clientaddr_id)) Address,
                      -- TaxObject
                      ('�������: ' || td.partidano) partidano,
                      td.partidano partidanom,
                      ('��� �� �����: ' ||
                       (select d.value
                         from   decode d
                         where  upper(d.columnname) = 'KINDPROPERTY'
                         and    d.code = tobj.kindproperty)) kindprop,
                      ('����� �� �����: ' || getaddress(tobj.address_id)) propaddr,
                      -- User
                      (u.fullname) operator1, td.decl14to17
      from Taxdoc td
      inner join Taxobject tobj on td.taxobject_id = tobj.taxobject_id
      left outer join Documenttype dt on td.documenttype_id = dt.documenttype_id
      left outer join Debtsubject ds on td.taxdoc_id = ds.document_id
      left outer join Taxsubject ts on coalesce(ds.taxsubject_id, td.taxsubject_id) = ts.taxsubject_id
      left outer join Address adr on adr.address_id = ts.present_clientaddr_id
      left outer join Municipality m on m.municipality_id = adr.municipality_id
      left outer join Province p on m.province_id = p.province_id
      left outer join Users u on td.user_id = u.user_id
      where  td.taxdoc_id = vTaxDoc_id
      order  by tsname;
    periods cursor(vTaxDoc_id numeric, vTaxSubject_id numeric) is
      select distinct to_char(max(ds.tax_begidate), 'yyyy') taxperiod,
                      max((select to_char(coalesce(sum(dp.sumval), 0), '9999999990.99')
                           from   Debtpartproperty dp
                           where  ds.debtsubject_id = dp.debtsubject_id
                           and    coalesce(ds.corrno, 0) =
                                  (select max(coalesce(ds_.corrno, 0))
                                    from   debtsubject ds_
                                    where  ds_.document_id = td.taxdoc_id
                                    and    ds_.taxsubject_id = ds.taxsubject_id
                                    and    coalesce(ds_.typecorr, '0') != '2'))) totalval,
                      ds.taxperiod_id, max(ds.doccode) doccode,
                      max(case when exists(select * from taxperiod tp 
                                            where tp.taxperiod_id = ds.taxperiod_id 
                                              and to_char(tp.begin_date,'yyyy') = 
                                                  (select trim(c.configvalue)
                                                     from config c
                                                    where upper(c.name) = 'TAXYEAR')) then to_char(dis.termdisc, 'dd.mm.yyyy') 
                          else ' ' end) period,
                      max(coalesce(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                                         from   debtinstalment di
                                                         where  di.debtsubject_id =
                                                                ds.debtsubject_id
                                                         and    di.instno = '4'),
                                                         trunc(current_date)), 0)) dis,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '1')) tdate1,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '2')) tdate2,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '3')) tdate3,
                      max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                           from   debtinstalment di
                           where  di.debtsubject_id = ds.debtsubject_id
                           and    di.instno = '4')) tdate4,
                      max(ds.debtsubject_id) debtsubj_id,
                      max(ds.parent_debtsubject_id) parent_debtsubject_id,
                      max(dr.name) kdrname
      from   TaxDoc td
      inner join Debtsubject ds on td.taxdoc_id = ds.document_id
                               and td.docno = ds.docno
                               and coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
                                   coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
                               and ds.kinddoc = 1
      inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
      inner join kinddebtreg dr on ds.kinddebtreg_id = dr.kinddebtreg_id
      left outer join discount dis on td.documenttype_id = dis.documenttype_id
                                  and ds.taxperiod_id = dis.taxperiod_id
      where  td.taxdoc_id = vTaxDoc_id
      and    ds.taxsubject_id = vTaxSubject_id
            --         ds.prtdate is null and
      and    ds.kinddebtreg_id = 2
      group  by ts.taxsubject_id, ds.taxperiod_id
      order  by taxperiod;
    -- installments
    inst cursor(vTaxDoc_id numeric, vTaxSubject_id numeric, vTaxPeriod_id numeric) is
      select case when trim(dr.code) = '2400' then '���' else dr.name end label1,
             coalesce(ds.totaltax, 0) sumall,
             to_char(ds.tax_begidate, 'yyyy') taxperiod,
             (select to_char(di.termpay_date, 'dd.mm.yyyy')
                          from   debtinstalment di
                          where  di.debtsubject_id = ds.debtsubject_id
                          and    di.instno = '1') period,
             case when exists(select * from taxperiod tp 
                         where tp.taxperiod_id = ds.taxperiod_id 
                           and to_char(tp.begin_date,'yyyy') = 
                               (select trim(c.configvalue)
                                  from config c
                                 where upper(c.name) = 'TAXYEAR')) then   
                         coalesce(ds.totaltax, 0) -
                          coalesce(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                                        from   debtinstalment di
                                                        where  di.debtsubject_id =
                                                               ds.debtsubject_id
                                                        and    di.instno = '2'),
                                                        trunc(current_date)), 0)  else 0 end dis,
            (select to_char(di.termpay_date, 'dd.mm.yyyy')
                 from   debtinstalment di
                 where  di.debtsubject_id = ds.debtsubject_id
                 and    di.instno = '1') tdate1,
            (select to_char(di.termpay_date, 'dd.mm.yyyy')
                 from   debtinstalment di
                 where  di.debtsubject_id = ds.debtsubject_id
                 and    di.instno = '2') tdate2,
            (select to_char(di.termpay_date, 'dd.mm.yyyy')
                 from   debtinstalment di
                 where  di.debtsubject_id = ds.debtsubject_id
                 and    di.instno = '3') tdate3,
            (select to_char(di.termpay_date, 'dd.mm.yyyy')
                 from   debtinstalment di
                 where  di.debtsubject_id = ds.debtsubject_id
                 and    di.instno = '4') tdate4,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '1') v1,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2') v2,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '3') v3,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '4') v4,
             (select coalesce(b.interestsum, 0) +
                       sanction_pkg.tempint(di.debtinstalment_id, trunc(current_date))
               from   debtinstalment di, baldebtinst b
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '1'
               and    b.debtinstalment_id = di.debtinstalment_id) lixv1,
             (select coalesce(b.interestsum, 0) +
                       sanction_pkg.tempint(di.debtinstalment_id, trunc(current_date))
               from   debtinstalment di, baldebtinst b
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2'
               and    b.debtinstalment_id = di.debtinstalment_id) lixv2,
             (select coalesce(b.interestsum, 0) +
                       sanction_pkg.tempint(di.debtinstalment_id, trunc(current_date))
               from   debtinstalment di, baldebtinst b
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '3'
               and    b.debtinstalment_id = di.debtinstalment_id) lixv3,
             (select coalesce(b.interestsum, 0) +
                       sanction_pkg.tempint(di.debtinstalment_id, trunc(current_date))
               from   debtinstalment di, baldebtinst b
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '4'
               and    b.debtinstalment_id = di.debtinstalment_id) lixv4,
             ds.debtsubject_id, ds.parent_debtsubject_id, dr.name kdrname, ds.kinddebtreg_id
      from   TaxDoc td
      inner  join Debtsubject ds on td.taxdoc_id = ds.document_id
                                and ds.docno = td.docno
                                and coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) = coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
                                and ds.kinddoc = 1
      inner  join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
      inner  join kinddebtreg dr on ds.kinddebtreg_id = dr.kinddebtreg_id
      where  td.taxdoc_id = vTaxDoc_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    ds.taxperiod_id = vtaxperiod_id
      and    ds.kinddoc = 1
      --and         ds.prtdate is null
      order  by  ds.kinddebtreg_id, ds.tax_begidate;
    offices cursor(vMunicipality_id numeric) is
      select o.fullname, coalesce(o.address, '') address
      from   Users u inner join Office o on o.office_id = u.office_id
      where  o.isactive = 1
      and    u.user_id = iUser_id;
    bank cursor(vMunicipality_id numeric) is
      select b.name, a.iban
      from   baccount a inner join bank b on b.bank_id = a.bank_id
      where  a.isactive = 1
      and    a.isbase = 1
      and    a.municipality_id = vMunicipality_id;
    --��� ��������� ������ ������������ �� �� ��������� �� ��������:
    currobl cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.name) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano = vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.name),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano = vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    currobl1 cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano = vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id;
    --��� ��������� ������ ������ �������� ���������� �� �� ��������:
    crpartidi_amount cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) totAmount, count(distinct ds.partidano) parNum
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano != vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id;
    currobl_rest cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.name) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano <> vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.name),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds
      inner  join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      inner  join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
      inner  join kinddebtreg kdr on ds.kinddebtreg_id = kdr.kinddebtreg_id
      where  ds.partidano <> vPartidaNo
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_idsmpInt(di.debtinstalment_id,current_date),0),2)) obsto
    --��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.
     oversum cursor(vTaxSubject_id numeric) is
      select max(kdr.fullname) taxname, max(kdr.acc) taxcode, os.partidano,
             sum(coalesce(boi.oversum, 0)) ndvn
      from   baloverinst boi
      inner  join oversubject os on os.oversubject_id = boi.oversubject_id
      inner  join kinddebtreg kdr on os.kinddebtreg_id = kdr.kinddebtreg_id
      where  os.taxsubject_id = vTaxSubject_id
      group  by os.partidano, os.kinddebtreg_id;
    promtbo cursor(vdebtssubj_id numeric) is
      select p.debtsubject_id, p.taxperiod_id,
             case when sign(h.kindhomeobjreg_id - 6) = -1 then 0 else 1 end kod,
             min(round(p.promiltbo, 3)) promil
      from   debtpartproperty p
      left   outer join homeobj h on h.homeobj_id = p.homeobj_id
      where  p.debtsubject_id = vdebtssubj_id
      group  by p.debtsubject_id, p.taxperiod_id,
                case when sign(h.kindhomeobjreg_id - 6) = -1 then 0 else 1 end, p.promiltbo
      order  by p.debtsubject_id,
                case when sign(h.kindhomeobjreg_id - 6) = -1 then 0 else 1 end;



  i                numeric;

  vRest            varchar(300);

  vRest1           varchar(300);

  vMunicipality_id numeric;

  vSumDis          numeric(18, 2);

  vSumv1           numeric(18, 2);

  vSumv2           numeric(18, 2);

  vSumv3           numeric(18, 2);

  vSumv4           numeric(18, 2);

  vSumAll          numeric(18, 2);

  vSumLix          numeric(18, 2);

  vTotalDO         numeric(12, 2);

  vOwnerDO         numeric(12, 2);

  vDebtSubjectId   numeric;

  vProm0           varchar(50);

  vProm1           varchar(50);

  r                record;

  d                varchar;

  rowcount         integer;

  vRunPeriods      boolean = false;    

  vIsSofia         boolean = false;  
  
begin

vRunPeriods :=FALSE;

  vSumDis := 0;

  vSumv1  := 0;

  vSumv2  := 0;

  vSumv3  := 0;

  vSumv4  := 0;

  vSumAll := 0;

  if (iTaxDoc_id > 0) then

      i := 1; -- �����
      -- ======= Part 1 =========
      ------ ���������� ------
      for msg_rec in msg(iTaxDoc_id) loop
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := center('������� �����', 70);
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.partidano, 42);
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.kindprop, 42);
        i := i + 1;
        r := wordwrap(msg_rec.propaddr, 70, 1);
        vPDPrt[i] := r.return_val;
        vrest := r.strrest;
        vPDPrt[i] := rpadc(vPDPrt[i], 80);
        i := i + 1;
        exit;
      end loop;
      vPDPrt[i] := rpadc('����������', 70);
      i := i + 1;
      vPDPrt[i] := rpadc(' ---------------', 69, '-');
      i := i + 1;
      vPDPrt[i] := '| ���/�������� |      ���                |������|    ������� ����    ' || '|';
      i := i + 1;
      vPDPrt[i] := rpadc(' ---------------', 69, '-');
      for ts in tsreport(iTaxDoc_id) loop
        i := i + 1;
        vPDPrt[i] := rpadc('| ' || ts.idn, 15) || '|' || rpadc(ts.custname, 25) || '|' ||
                     rpadc(ts.taxperiod, 6) || '|' || rpadc(' ' || ts.label1, 7) ||
                     lpadc(ts.sumall, 13) || '|';
        i := i + 1;
        vPDPrt[i] := rpadc(' ---------------', 69, '-');
      end loop;
      -- ======= End Part 1 =========


      -- ======= Part 2 =========
      i := i + 1;
      vPDPrt[i] := 'ff';
      i := i + 1;
      vPDPrt[i] := 'p2';
      i := i + 1;
      -- !!!!!!!!!!!!!!!!!!!!!!
      rowcount := 1;
      for msg_rec in msg(iTaxDoc_id) loop
        vRunPeriods := false;
        if /*msg%rowcount*/ rowcount > 1 then
          vPDPrt[i] := 'ff';
          i := i + 1;
          vPDPrt[i] := 'p2';
          i := i + 1;
        end if;
        -- GET DIAGNOSTICS rowcount = ROW_COUNT;
        rowcount := rowcount + 1;
        for logo_rec in logo(iUser_id) loop
          vMunicipality_id := logo_rec.municipality_id;
          vIsSofia := logo_rec.issofia > 0;
          vPDPrt[i] := rpadc(' ------------------------------------------------', 80, '-');
          i := i + 1;
          if (logo_rec.region is not null) then
           vPDPrt[i] := center(logo_rec.fullname ||' '|| '������', 80);
           i := i + 1;
           vPDPrt[i] := center('�������� ������� � ������������� �� ���', 80);
           i := i + 1;
           vPDPrt[i] := center('����� ���', 80);
           i := i + 1;
           vPDPrt[i] := center('� � � � �  ' || upper(logo_rec.region), 80);
           i := i + 1;
          else
           vPDPrt[i] := center('� � � � � �  ' || logo_rec.fullname, 80);
           i := i + 1;
           vPDPrt[i] := center('������ ������ � �����', 80);
           i := i + 1;
          end if;
          vPDPrt[i] := center(logo_rec.addr, 80);
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------', 80, '-');
          i := i + 1;
          vPDPrt[i] := '';
          i := i + 1;
        end loop;
        vPDPrt[i] := center('���������', 80);
        i := i + 1;
        vPDPrt[i] := center(msg_rec.msgnum, 80);
        i := i + 1;
        vPDPrt[i] := rpadc('������� ������� �����:', 42) || '��:';
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.partidano, 42) || rpadc(msg_rec.idn, 40);
        i := i + 1;
        vPDPrt[i] := rpadc(msg_rec.kindprop, 42) || rpadc(msg_rec.tsname, 38);
        i := i + 1;
        r := wordwrap(msg_rec.propaddr, 30, 1);
        vPDPrt[i] := r.return_val;
        vrest := r.strrest;
        r := wordwrap(msg_rec.address, 35, 1);
        XXX := r.return_val;
        vrest1 := r.strrest;        
        vPDPrt[i] := rpadc(vPDPrt[i], 42) || XXX;
        i := i + 1;
        --    vPDPrt[i]  := wordwrap(msg_rec.propaddr,40,2,vrest);
        --    i          := i + 1;
        if (Length(vRest) > 1) or (Length(vRest1) > 1) then
          vPDPrt[i] := rpadc(vrest, 42) || rpadc(vRest1, 38, ' ');
          i := i + 1;
        end if;
        vPDPrt[i] := lpadc(' ', 42) || rpadc(msg_rec.ts_municipality, 38);
        i := i + 1;
        vPDPrt[i] := rpadc('  �������� ' || msg_rec.docname ||
                           ' �� ����,', 80);
        i := i + 1;
        if (trim(msg_rec.doccode) = '14') then
          select sum(pp.sumval),
                 sum(case when ds.taxsubject_id = msg_rec.taxsubject_id then pp.sumval else 0 end)
          into   vTotalDO, vOwnerDO
          from   debtsubject ds
          inner  join taxdoc td on ds.document_id = td.taxdoc_id
          inner  join debtpartproperty pp on pp.debtsubject_id = ds.debtsubject_id
          where
                 coalesce(ds.docno, '*') = coalesce(td.docno, '*')
          and    ds.doc_date = td.doc_date
          and    td.documenttype_id = 21
          and    ds.kinddebtreg_id = 2
          and    td.taxdoc_id = iTaxDoc_id
          and    coalesce(ds.corrno, 0) =
                 (select max(coalesce(ds_.corrno, 0))
                   from   debtsubject ds_
                   where  ds_.document_id = td.taxdoc_id
                   and    ds_.taxsubject_id = ds.taxsubject_id
                   and    coalesce(ds_.typecorr, '0') != '2')
          and    ds.taxperiod_id =
                 (select max(dd.taxperiod_id)
                   from   debtsubject dd
                   where  dd.document_id = iTaxDoc_id
                   and    dd.kinddebtreg_id = 2);
          if msg_rec.decl14to17 = 2 then
            vPDPrt[i] := rpadc(' � ��.� ' || msg_rec.msgnum || ' � ������� ������(��)' ||
                               to_char(coalesce(vTotalDO, 0), '9999999990.99') || ' ��.',
                               80, ' ');
          else
            vPDPrt[i] := rpadc(' � ��.� ' || msg_rec.msgnum || ' � ������� ������(��) �� ����� ' ||
                               to_char(coalesce(vTotalDO, 0), '9999999990.99') || ' ��.',
                               80, ' ');
          end if;
          i := i + 1;
          vPDPrt[i] := rpadc(' �� �� ���������� �������� ������� ����������:',
                             80, ' ');
          i := i + 1;
        else
          vPDPrt[i] := rpadc('� ��.� ' || msg_rec.msgnum ||
                             ' �� �� ���������� �������� ������� ����������:', 80,
                             ' ');
          i := i + 1;
        end if;
        vPDPrt[i] := '';
        i := i + 1;
        /*   for inst_rec in inst(iTaxDoc_id, msg_rec.taxsubject_id, per_rec.taxperiod_id) loop
          if inst%Rowcount = 1 then
            vPDPrt[i]  := ' �������� �� ��������� ����������';
            i          := i + 1;
            vPDPrt[i]  := rpadc(' ------------------------------------------------',49,'-');
            i          := i + 1;
            vPDPrt[i]  := '|  ��� ���������� ������   |   ���� ��������     |';
            i          := i + 1;
            vPDPrt[i]  := rpadc(' ------------------------------------------------',49,'-');
            i          := i + 1;
          end if;
          if inst_rec.parent_debtsubject_id is not null then
            vPDPrt[i]  := rpadc('| '||inst_rec.kdrname||'  '||inst_rec.taxperiod,26)||' |'||
                          lpadc(inst_rec.sumall,20)||' |';
            i          := i + 1;
            vPDPrt[i]  := rpadc(' ------------------------------------------------',49,'-');
            i          := i + 1;
          end if;
        end loop;  */
        BEGIN
        for per_rec in periods(iTaxDoc_id, msg_rec.taxsubject_id) loop
          vRunPeriods := true;
          vSumDis := 0;
          vSumv1 := 0;
          vSumv2 := 0;
          vSumv3 := 0;
          vSumv4 := 0;
          vSumAll := 0;
          vSumLix := 0;
          vPDPrt[i] := ' ';
          vProm0 := null;
          vProm1 := null;
          -->>> debtsubject_id za TBO �������
          select max(d_.debtsubject_id)
          into   vDebtSubjectId
          from   debtsubject d_
          where  d_.document_id = iTaxDoc_id
          and    d_.taxsubject_id = msg_rec.taxsubject_id
          and    d_.kinddebtreg_id = 5
          and    d_.taxperiod_id = per_rec.taxperiod_id;
          if per_rec.parent_debtsubject_id is not null then
            vPDPrt[i] := ' �������� �� ��������� ����������';
            i := i + 1;
          end if;

          for promtbo_rec in promtbo(vDebtSubjectId) loop
            if coalesce(promtbo_rec.promil, 0) > 0 then
              case promtbo_rec.kod
                when 0 then  -- �������
                  if (vProm0 is null) then
                    vProm0 := coalesce(promtbo_rec.promil, 0);
                  else
                    vProm0 := vProm0 || ', ' || coalesce(promtbo_rec.promil, 0);
                  end if;
                when 1 then -- ���������
                  if (vProm1 is null) then
                    vProm1 := coalesce(promtbo_rec.promil, 0);
                  else
                    vProm1 := vProm1 || ', ' || coalesce(promtbo_rec.promil, 0);
                  end if;
              end case;
            end if;
          end loop;
          if (vProm0 is not null) or (vProm1 is not null) then
            vPDPrt[i] := ' ������� �� ��� : ';
            if (trim(per_rec.doccode) = '17') then
              case
                when (vProm1 is null) and (vProm0 is null) then
                  vPDPrt[i] := vPDPrt[i];
                else
                  vPDPrt[i] := vPDPrt[i] || ' ' || ' ��������� ����� ' || vProm1;
              end case;
            else
              case
                when (vProm0 is null) then
                  vPDPrt[i] := vPDPrt[i];
                else
                  vPDPrt[i] := vPDPrt[i] || ' ������� ����� ' || vProm0;
              end case;
              case
                when (vProm1 is null) then
                  vPDPrt[i] := vPDPrt[i];
                else
                  vPDPrt[i] := vPDPrt[i] || ' ' || ' ��������� ����� ' || vProm1;
              end case;
            end if;
            i := i + 1;
          end if;
          -- <<<<< ------------------
          vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
          i := i + 1;
          --if (trim(msg_rec.doccode) = '14') then
            vPDPrt[i] := ' �� �� ������.:    |'||center('���������� �� '||per_rec.taxperiod||' � ����',72);
                        -- '|                      |               |               |';
         /* elsif (trim(msg_rec.doccode) = '17') then
            vPDPrt[i] := ' ������� ��-��:    |'||center('���������� �� '||per_rec.taxperiod||' � ����',72);
                         --'|                      |               |               |';
          end if; */
          i := i + 1;
          vPDPrt[i] := lpadc(per_rec.totalval, 18)||' ' || '|' ||
                       center('� �������� ', 13) || '|' ||
                       center('I-�� ������ ', 13) || '|' ||
                       center('II-�� ������ ', 13) || '|' ||
                       center('III-�� ������', 13) || '|' ||
                       center('IV-�� ������ ', 13);
          i := i + 1;
         -- vPDPrt[i] := ' ���������� ��   |   ���� �� �������    |���� �� �������|���� �� �������|���� �� �������';
         -- i := i + 1;
          vPDPrt[i] := rpadc(' ��� �������', 19) || '|' ||
                       center(per_rec.period, 13) || '|' ||
                       center(per_rec.tdate1, 13) || '|' ||
                       center(per_rec.tdate2, 13) || '|' ||
                       center(per_rec.tdate3, 13) || '|' ||
                       center(per_rec.tdate4, 13);
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
          i := i + 1;
          -- Installments
          vRest := '0';
          for inst_rec in inst(iTaxDoc_id, msg_rec.taxsubject_id, per_rec.taxperiod_id) loop

            if (inst_rec.kinddebtreg_id = 5) and (vRest = '0') then
              vRest := '1';
              vPDPrt[i] := rpadc(' ��� ������� ', 19) || '|' ||
                           center(per_rec.period, 13) || '|' ||
                           center(inst_rec.tdate1, 13) || '|' ||
                           center(inst_rec.tdate2, 13) || '|' ||
                           center(inst_rec.tdate3, 13) || '|' ||
                           center(inst_rec.tdate4, 13);
              i := i + 1;
              vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
              i := i + 1;
            end if;
            vPDPrt[i] := rpadc(' ' || inst_rec.label1, 7) ||
                         lpadc(to_char(coalesce(inst_rec.sumall, 0), '999999990.99'), 12) || '|' ||
                         lpadc(to_char(coalesce(inst_rec.dis, 0), '999999990.99'), 13, ' ') ||'|'||
                         lpadc(to_char(coalesce(inst_rec.v1, 0), '999999990.99'), 13, ' ') || '|' ||
                         lpadc(to_char(coalesce(inst_rec.v2, 0), '999999990.99'), 13, ' ') || '|' ||
                         lpadc(to_char(coalesce(inst_rec.v3, 0), '999999990.99'), 13, ' ') || '|' ||
                         lpadc(to_char(coalesce(inst_rec.v4, 0), '999999990.99'), 13, ' ');
            i := i + 1;
            vSumLix := coalesce(inst_rec.lixv1, 0) + coalesce(inst_rec.lixv2, 0) +
                       coalesce(inst_rec.lixv3, 0) + coalesce(inst_rec.lixv4, 0);
            if vSumLix > 0 then
              vPDPrt[i] := rpadc(' ' || '�����', 7) ||
                           lpadc(to_char(vSumLix, '99999990.99'), 12) || '|' ||
                           lpadc(to_char(0, '99999990.99'), 13, ' ') ||'|'||
                           lpadc(to_char(coalesce(inst_rec.lixv1, 0), '99999990.99'), 13, ' ') || '|' ||
                           lpadc(to_char(coalesce(inst_rec.lixv2, 0), '99999990.99'), 13, ' ') || '|' ||
                           lpadc(to_char(coalesce(inst_rec.lixv3, 0), '99999990.99'), 13, ' ') || '|' ||
                           lpadc(to_char(coalesce(inst_rec.lixv4, 0), '99999990.99'), 13, ' ');
              i := i + 1;
            end if;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
            vSumAll := vSumAll + inst_rec.sumall + vSumLix;
            vSumDis := vSumDis + coalesce(inst_rec.dis, 0);
            vSumv1 := vSumv1 + coalesce(inst_rec.v1, 0) + coalesce(inst_rec.lixv1, 0);
            vSumv2 := vSumv2 + coalesce(inst_rec.v2, 0) + coalesce(inst_rec.lixv2, 0);
            vSumv3 := vSumv3 + coalesce(inst_rec.v3, 0) + coalesce(inst_rec.lixv3, 0);
            vSumv4 := vSumv4 + coalesce(inst_rec.v4, 0) + coalesce(inst_rec.lixv4, 0);
          end loop;
          vPDPrt[i] := rpadc(' ������ ', 7) ||
                       lpadc(to_char(vSumAll, '999999990.99'), 12) || '|' ||
                       lpadc(to_char(coalesce(vSumDis, 0), '999999990.99'), 13, ' ') ||'|'||
                       lpadc(to_char(coalesce(vSumv1, 0), '999999990.99'), 13, ' ') || '|' ||
                       lpadc(to_char(coalesce(vSumv2, 0), '999999990.99'), 13, ' ') || '|' ||
                       lpadc(to_char(coalesce(vSumv3, 0), '999999990.99'), 13, ' ') || '|' ||
                       lpadc(to_char(coalesce(vSumv4, 0), '999999990.99'), 13, ' ');
          i := i + 1;
          vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
          i := i + 1;
        end loop;
        EXCEPTION
          when others then begin
            vPDPrt[i] := '';
            i := i + 1;
            perform NOM_PKG.ErrManage(ErrMsg);
            vPDPrt[i] := UPPER(ErrMsg);
            i := i + 1;
            ErrMsg := '';
            vRunPeriods := true;
          end;
        END;
        if (not vRunPeriods) then
         vPDPrt[i] := '';
         i := i + 1;
         vPDPrt[i] := '���� ���������� ���������� �� ������ � ���� �� �������� '|| msg_rec.begintaxdate;
         i := i + 1;
         vPDPrt[i] := '';
         i := i + 1;
        end if;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '���������� ��������� �� � ��������������� ��� � �� ������� �� ���������.';
        i := i + 1;
        /* vPDPrt[i]  := '��� �� ��� �������� � ������������ �� ����������, ������ �� �������� �������� �� ';
        i          := i + 1;
        vPDPrt[i]  := '��� �� ������������ �� ������������ �� ������, ����� ������ �� ��������� � ';
        i          := i + 1;
        vPDPrt[i]  := '14-������ ���� �� ������������ ��.';
        i          := i + 1;*/
        vPDPrt[i] := '���� �������� �� ����� �� ��������� ����� ����������� ���������� �� ��������� �����!';
        i := i + 1;
        vPDPrt[i] := '���������� �� ������ �������� �� ������ �� �����, �� ����� ������ � ������� ���������.';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := '��� ��������� ������ ����� �������� ���������� �� ' || msg_rec.partidano;
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |     ��� ����������    |��� ��|    �������   | �������� |  �����  |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        brsm := 0;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          brsm := brsm + 1;
          if brsm > 50
          then
            exit;
          end if;
        end loop;
        if brsm > 50
        then
          for obl in currobl1(msg_rec.taxsubject_id, msg_rec.partidanom)
          loop
            vPDPrt[i] := ' ' || rpadc(' ', 10) || '|' || rpadc(' ', 23) || '|' ||
                         rpadc(' ', 6) || '|' || rpadc(' ', 14) || '|' ||
                         lpadc(to_char(obl.gl, '999990.99'), 10) || '|' ||
                         lpadc(to_char(obl.lix, '999990.99'), 9) || '|' ||
                         lpadc(to_char(obl.obsto, '99999990.99'), 11);
            i := i + 1;
          end loop;
        else
          for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
          loop
            if (obl.obsto > 0)
            then
              vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||
                           rpadc(obl.taxname, 23) || '|' ||
                           rpadc(obl.taxcode, 6) || '|' ||
                           rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||
                           lpadc(to_char(obl.gl, '9999990.99'), 10) || '|' ||
                           lpadc(to_char(obl.lix, '999990.99'), 9) || '|' ||
                           lpadc(to_char(obl.obsto, '99999990.99'), 11);
              i := i + 1;
            end if;
          end loop;
        end if;
        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)
        loop
          if (obl.obsto > 0)
          then
            vPDPrt[i] := rpadc(' ------------------------------------------------', 90, '-');
            i := i + 1;
            exit;
          end if;
        end loop;

        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '���� �� ���������:';
        for rec in offices(vMunicipality_id)
        loop
          r := wordwrap(rpadc(vPDPrt[i],30)||' ����� �� ����: ' || rec.address, 80, 1);
          vPDPrt[i] := r.return_val;
          vrest := r.strrest;
          vPDPrt[i] := rpadc(vPDPrt[i],80);
          i := i + 1;
          if (Length(vRest) > 1)
          then
            vPDPrt[i] := lpadc(' ', 46) || rpadc(trim(vRest), 34, ' ');
            i := i + 1;
          end if;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        for bank_rec in bank(vMunicipality_id)
        loop
          vPDPrt[i] := lpadc(' ', 30) || ' ���� �� �����: ' ||
                       rpadc(bank_rec.name, 45);
          i := i + 1;
          vPDPrt[i] := lpadc(' ', 39) || rpadc(' IBAN: ' || bank_rec.iban, 45);
          i := i + 1;
          vPDPrt[i] := lpadc(' ', 39) ||
                       rpadc(' ��� ������� 442100 /����� ����.����/', 40, ' ');
          i := i + 1;
          vPDPrt[i] := lpadc(' ', 39) ||
                       rpadc(' ��� ������� 442400 /����� ���.���./', 40, ' ');
          i := i + 1;
        end loop;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := lpadc('���������� ����: .............................', 80);
        i := i + 1;
        vPDPrt[i] := lpadc('(���, ��������, ������, �����)', 80);
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '';
        i := i + 1;
        vPDPrt[i] := '��������: ' || msg_rec.operator1;
        i := i + 1;
        -- ======= End Part 2 =========

        -- ======= Part 3 =========
        vPDPrt[i] := 'ff';
        i := i + 1;
        vPDPrt[i] := 'p3';
        i := i + 1;
        for res in crpartidi_amount(msg_rec.taxsubject_id, msg_rec.partidanom) loop
          if (res.totamount > 0) then
            vPDPrt[i] := rpadc(' ', 42) || rpadc(msg_rec.idn, 40);
            i := i + 1;
            vPDPrt[i] := rpadc(' ', 42) || rpadc(msg_rec.tsname, 40);
            i := i + 1;
            r := wordwrap(msg_rec.address, 35, 1);
            vPDPrt[i] := r.return_val;
            vrest := r.strrest;
            vPDPrt[i] := rpadc(' ', 42) || vPDPrt[i];
            i := i + 1;
            if (Length(vRest) > 1) or (Length(vRest1) > 1) then
              vPDPrt[i] := rpadc(' ', 42) || rpadc(vRest1, 40, ' ');
              i := i + 1;
            end if;
            vPDPrt[i] := lpadc(' ', 42) || rpadc(msg_rec.ts_municipality, 40);
            i := i + 1;
            vPDPrt[i] := '';
            i := i + 1;
          ---------  ������ ���������� �� ������� ----------
            vPDPrt[i] := '��� ��������� ������ ����� �������� ����������:';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 89, '-');
            i := i + 1;
            vPDPrt[i] := '|    ����  |   ��� ����������  |��� ��|    �������   |  �������� |   �����   |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 89, '-');
            i := i + 1;
          --  ��� � ���� ���������� > 50 ������� ������� �� ������ ������. �� V �������
            if (res.parnum > 50) then
                vPDPrt[i] := ' ' || rpadc(' ', 10) || '|' ||
                             rpadc(' ', 19) || '|' ||
                             rpadc(' ', 6) || '|' || rpadc(' ', 14) || '|' ||
                             lpadc(to_char(res.gl, '99999990.99'), 11) || '|' ||
                             lpadc(to_char(res.lix, '99999990.99'), 11) || '|' ||
                             lpadc(to_char(res.totamount, '99999990.99'), 11);
                i := i + 1;
            else
              for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom) loop
                if (obl.obsto > 0) then
                  vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||
                               rpadc(obl.taxname, 19) || '|' ||
                               rpadc(obl.taxcode, 6) || '|' ||
                               rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||
                               lpadc(to_char(obl.gl, '99999990.99'), 11) || '|' ||
                               lpadc(to_char(obl.lix, '99999990.99'), 11) || '|' ||
                               lpadc(to_char(obl.obsto, '99999990.99'), 11);
                  i := i + 1;
                end if;
              end loop;
            end if;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 89, '-');
            i := i + 1;

          end if;
        end loop;
        -------- �������� ���� ---------
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0)
          then
            vPDPrt[i] := '';
            i := i + 1;
            vPDPrt[i] := '��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 60, '-');
            i := i + 1;
            vPDPrt[i] := '|     ��� ����������      |��� ��|    �������   |    ����   |';
            i := i + 1;
            vPDPrt[i] := rpadc(' ------------------------------------------------', 60, '-');
            i := i + 1;
            exit;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0)
          then
            vPDPrt[i] := ' ' || rpadc(ovr.taxname, 25) || '|' ||
                         rpadc(ovr.taxcode, 6) || '|' ||
                         rpadc(coalesce(ovr.partidano, ' '), 14) || '|' ||
                         lpadc(to_char(ovr.ndvn, '99999990.99'), 11);
            i := i + 1;
          end if;
        end loop;
        for ovr in oversum(msg_rec.taxsubject_id)
        loop
          if (ovr.ndvn > 0)
          then
            vPDPrt[i] := rpadc(' ------------------------------------------------', 60, '-');
            i := i + 1;
            vPDPrt[i] := '';
            i := i + 1;
            exit;
          end if;
        end loop;

      -- Check for rows after p3 else delete p3  

      if vPDPrt [ i - 1 ] = 'p3' then
        vPDPrt := vPDPrt [ array_lower(vPDPrt, 1) :array_upper(vPDPrt, 1) - 2 ];
        --   vPDPrt.DELETE(vPDPrt.LAST);
        --   vPDPrt.DELETE(vPDPrt.LAST);
        i := i - 2;
        --vPDPrt[i-2]  := '';
      end if;

      -- ======= End Part 3 =========

    

    end loop;

  end if;



  vPD_lob := paydocument_pkg.tblToLob(vPDPrt);

  --commit;

  return_val := 'OK';

  return;

exception

  when others then

    begin

      --rollback;

      perform NOM_PKG.ErrManage(ErrMsg);
      
      ErrMsg := sqlerrm;

      return_val := ErrMsg;

      return;

    

    end;

end;
$function$
; DROP FUNCTION paydocument_pkg.messaged117(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.messaged117(OUT return_val character varying, itaxdoc_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                        

    vPDPrt varchar[];

    ErrMsg varchar(300);

  
    -- taxsubject report
     tsreport cursor (vTaxDoc_id numeric) is
      select max((select d.value
                  from   decode d
                  where  upper(d.columnname) = 'KIND_IDN'
                  and    d.code = ts.kind_idn)) kindidn, min(ts.idn) idn,
             min(ts.name) custname,
             to_char(sum(ds.totaltax), '99999990.99') sumall,
             max(to_char(ds.tax_begidate, 'yyyy')) taxperiod, ds.debtsubject_id
      from   taxdoc td
      inner  join debtsubject ds on ds.document_id = td.taxdoc_id
                                and ds.docno = td.docno
                                and coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
                                    coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
                                and ds.kinddoc = 1
      inner  join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
      where  td.taxdoc_id = vTaxDoc_id
      group  by ds.taxsubject_id, ds.debtsubject_id, ds.calcdate,
                coalesce(ds.corrno, 0)
      order  by custname, taxperiod;
    -- municipality logo
    logo cursor(vUser_id numeric) is
      select coalesce(m1.fullname,m.fullname) fullname,
             case when m1.municipality_id is not null then m.fullname else null end region,
             getaddress(ts.present_clientaddr_id) addr,
             m.municipality_id
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      left outer join config c on m.municipality_id = c.municipality_id
      left outer join taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id
      where u.user_id = vUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';

    -- message
     msg cursor(vTaxDoc_id numeric) is
      select distinct ('���������') Label1, ('������: ' || p.name) province,
                      ('������: ' || m.fullname) municipality,
                      (td.docno || '/' || to_char(td.doc_date, 'dd.mm.yyyy') ||
                       ' �.') msgnum, dt.docname, ds.taxsubject_id, dt.doccode,
                      -- TaxSubject
                      (select d.value
                        from   decode d
                        where  upper(d.columnname) = 'KIND_IDN'
                        and    d.code = ts.kind_idn) || ' ' || ts.idn idn,
                      (ts.name) tsname,
                      ('������� ������: ' || ts.taxsubjectno) taxsubj,
                      ('������� �����: ' || tobj.taxobjno) taxobj,
                      ('�����: ' || GetAddress(ts.present_clientaddr_id)) Address,
                      -- TaxObject
                      ('�������: ' || td.partidano) partidano,
                      td.partidano partidanom,
                      ('���. N: ' || tobj.registerno) regno,
                      ('���.���: ' || tobj.registername) regname,
                      ('������: ' || dog.breed) breed,
                      -- User
                      (u.fullname) operator1
      from Taxdoc td
      inner join users u on td.user_id = u.user_id
      inner join Dog on td.taxobject_id = dog.taxobject_id
      left outer join Taxobject tobj on td.taxobject_id = tobj.taxobject_id
      left outer join Documenttype dt on td.documenttype_id = dt.documenttype_id
      left outer join Debtsubject ds on td.taxdoc_id = ds.document_id
      left outer join Taxsubject ts on coalesce(ds.taxsubject_id, td.taxsubject_id) = ts.taxsubject_id
      left outer join Municipality m on td.municipality_id = m.municipality_id
      left outer join Province p on m.province_id = p.province_id
      where  td.taxdoc_id = vTaxDoc_id;
    -- tax installments
    inst cursor(vTaxDoc_id numeric, vTaxSubject_id numeric) is
      select to_char(coalesce(ds.totaltax, 0), '99990.99') sumall,
             to_char(ds.tax_begidate, 'yyyy') taxperiod,
             (' �� ' || (select to_char(di.termpay_date, 'dd.mm.yyyy')
                          from   debtinstalment di
                          where  di.debtsubject_id = ds.debtsubject_id
                          and    di.instno = '1')) period,
             case when exists(select * from taxperiod tp 
                           where tp.taxperiod_id = ds.taxperiod_id 
                             and to_char(tp.begin_date,'yyyy') < 
                                 (select trim(c.configvalue)
                                    from config c
                                   where upper(c.name) = 'TAXYEAR')) then 0
                  else                  
                   coalesce(ds.totaltax, 0) -
                    coalesce(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                                  from   debtinstalment di
                                                  where  di.debtsubject_id =
                                                         ds.debtsubject_id
                                                  and    di.instno = '2'),
                                                  trunc(current_date)), 0) end dis,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '1') v1,
             (select di.instsum
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2') v2,
             (select to_char(di.termpay_date, 'dd.mm.yyyy')
               from   debtinstalment di
               where  di.debtsubject_id = ds.debtsubject_id
               and    di.instno = '2') tdate2, ds.debtsubject_id
      from   TaxDoc td, Debtsubject ds, taxsubject ts
      where  td.taxdoc_id = vTaxDoc_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    td.taxdoc_id = ds.document_id
      and    ds.docno = td.docno
      and    coalesce(ds.doc_date, to_date('01.01.1999', 'dd.mm.yyyy')) =
             coalesce(td.doc_date, to_date('01.01.1999', 'dd.mm.yyyy'))
      and    ds.kinddoc = 1
      and    ds.taxsubject_id = ts.taxsubject_id
      order  by ds.tax_begidate;
    offices cursor(vMunicipality_id numeric) is
      select o.fullname, coalesce(o.address, '') address
      from   Users u, Office o
      where  o.isactive = 1
      and    o.office_id = u.office_id
      and    u.user_id = iUser_id;
    bank cursor(vMunicipality_id numeric) is
      select b.name, a.iban
      from   baccount a, bank b
      where  b.bank_id = a.bank_id
      and    a.isactive = 1
      and    a.isbase = 1
      and    a.municipality_id = vMunicipality_id;
    --��� ��������� ������ ������������ �� �� ��������:
    currobl cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds, debtinstalment di, baldebtinst bdi, kinddebtreg kdr
      where  ds.debtsubject_id = di.debtsubject_id
      and    ds.partidano = vPartidaNo
      and    di.debtinstalment_id = bdi.debtinstalment_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds, debtinstalment di, baldebtinst bdi, kinddebtreg kdr
      where  ds.debtsubject_id = di.debtsubject_id
      and    ds.partidano = vPartidaNo
      and    di.debtinstalment_id = bdi.debtinstalment_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    --��� ��������� ������ ������ �������� ���������� �� �� ��������:
    currobl_rest cursor(vTaxSubject_id numeric, vPartidaNo varchar) is
      select min(di.termpay_date) termdate,
             min(to_char(di.termpay_date, 'dd.mm.yyyy')) termpay_date,
             '���������' SrokPl, max(kdr.fullname) taxname, max(kdr.acc) taxcode,
             ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds, debtinstalment di, baldebtinst bdi, kinddebtreg kdr
      where  ds.debtsubject_id = di.debtsubject_id
      and    ds.partidano <> vPartidaNo
      and    di.debtinstalment_id = bdi.debtinstalment_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date <=
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id
      union all
      select min(di.termpay_date) termdate,
             to_char(di.termpay_date, 'dd.mm.yyyy') termpay_date,
             To_char(di.termpay_date, 'dd.mm.yyyy') SrokPl, max(kdr.fullname),
             max(kdr.acc), ds.partidano, sum(coalesce(bdi.instsum, 0)) gl,
             sum(round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) lix,
             sum(coalesce(bdi.instsum, 0) +
                  round(coalesce(bdi.interestsum, 0) +
                        coalesce(sanction_pkg.TempInt(di.debtinstalment_id, current_date),
                            0), 2)) obsto
      from   debtsubject ds, debtinstalment di, baldebtinst bdi, kinddebtreg kdr
      where  ds.debtsubject_id = di.debtsubject_id
      and    ds.partidano <> vPartidaNo
      and    di.debtinstalment_id = bdi.debtinstalment_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.taxsubject_id = vTaxSubject_id
      and    di.termpay_date >
             TO_Date('01.01.' ||
                      (select trim(c.configvalue)
                       from   config c
                       where  upper(c.name) = 'TAXYEAR'), 'dd.mm.yyyy')
      group  by ds.partidano, ds.kinddebtreg_id, di.termpay_date
      order  by 1, 6, 5; --di.termpay_date,ds.partidano, ds.kinddebtreg_id
    --��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.
    oversum cursor(vTaxSubject_id numeric) is
      select max(kdr.fullname) taxname, max(kdr.acc) taxcode, os.partidano,
             sum(coalesce(boi.oversum, 0)) ndvn
      from   baloverinst boi, oversubject os, kinddebtreg kdr
      where  os.oversubject_id = boi.oversubject_id
      and    os.kinddebtreg_id = kdr.kinddebtreg_id
      and    os.taxsubject_id = vTaxSubject_id
      group  by os.partidano, os.kinddebtreg_id;

    i                numeric;

    vRest            varchar(300);

    vMunicipality_id numeric;

    rowcount integer;

    r record;

  begin

    if (iTaxDoc_id > 0)

    then

      i := 1; -- �����

      -- ======= Part 1 =========  

      -- Report Obligations

      for msg_rec in msg(iTaxDoc_id)

      loop

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := center('������� �����', 70);

        i := i + 1;

        vPDPrt[i] := rpadc(msg_rec.partidano, 40) || rpadc(msg_rec.regno, 38);

        i := i + 1;

        vPDPrt[i] := rpadc(msg_rec.breed, 40) || rpadc(msg_rec.regname, 38);

        i := i + 1;

        exit;

      end loop;

      vPDPrt[i] := rpadc('����������', 70);

      i := i + 1;

      vPDPrt[i] := rpadc(' ---------------', 60, '-');

      i := i + 1;

      vPDPrt[i] :=  '| ���/������� |      ���                |������|    �����  ' || '|';

      i := i + 1;

      vPDPrt[i] := rpadc(' ---------------', 60, '-');

      i := i + 1;

      for ts in tsreport(iTaxDoc_id)

      loop

        vPDPrt[i] := rpadc('| ' || ts.idn, 15) || '|' || rpadc(ts.custname, 25) || '|' ||

                     rpadc(ts.taxperiod, 6) || '|' || lpadc(ts.sumall, 11) || '|';

        i := i + 1;

        vPDPrt[i] := rpadc(' ---------------', 60, '-');

        i := i + 1;

      end loop;

      -- ======= End Part 1 =========  

    

      -- ======= Part 2 =========  

      vPDPrt[i] := 'ff';

      i := i + 1;

      vPDPrt[i] := 'p2';

      i := i + 1;

      -- !!!!!!!!!!!!!!!!!!!!!!    

      rowcount := 1;

      for msg_rec in msg(iTaxDoc_id) loop

        

        if rowcount > 1 then

          vPDPrt[i] := 'ff';

          i := i + 1;

          vPDPrt[i] := 'p2';

          i := i + 1;

        end if;

        rowcount := 2;

        for logo_rec in logo(iUser_id)

        loop

          vMunicipality_id := logo_rec.municipality_id;

          vPDPrt[i] := rpadc(' ------------------------------------------------',

                             80, '-');

          i := i + 1;

          vPDPrt[i] := center('� � � � � �  ' || logo_rec.fullname, 80);

          i := i + 1;

          if (logo_rec.region is not null) then
           vPDPrt [i] := center('� � � � �  ' || upper(logo_rec.region), 80);
           i := i + 1;
          end if; 
          vPDPrt[i] := center('������ ������ � �����', 80);

          i := i + 1;

          vPDPrt[i] := center(logo_rec.addr, 80);

          i := i + 1;

          vPDPrt[i] := rpadc(' ------------------------------------------------',

                             80, '-');

          i := i + 1;

          vPDPrt[i] := '';

          i := i + 1;

        end loop;

        vPDPrt[i] := center('���������', 80);

        i := i + 1;

        vPDPrt[i] := center(msg_rec.msgnum, 80);

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := rpadc('������� ������� �����:', 42) || '��:';

        i := i + 1;

        vPDPrt[i] := rpadc(msg_rec.partidano, 42) || rpadc(msg_rec.idn, 40);

        i := i + 1;

        vPDPrt[i] := rpadc(msg_rec.regno, 42) ||

                     rpadc('���:' || msg_rec.tsname, 38);

        i := i + 1;

        r :=  wordwrap(  msg_rec.address, 37, 1 );

        vPDPrt[i] := r.return_val;

        vrest := r.strrest;

        vPDPrt[i] := rpadc(msg_rec.regname, 42) || vPDPrt[i];

        i := i + 1;

        if (Length(vRest) > 1) then          
          vPDPrt[i] := case when (Length(vRest) > 1) then rpadc('', 42) || rpadc(trim(vrest), 40) end;
          i := i + 1;
        end if;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := rpadc('  �������� ' || msg_rec.docname ||

                           ' �� ����,', 80);

        i := i + 1;

        vPDPrt[i] := rpadc('� ��.� ' || msg_rec.msgnum ||

                           ' �� �� ���������� �������� ������� ����������', 80,

                           ' ');

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        -- Installments    

        for inst_rec in inst(iTaxDoc_id, msg_rec.taxsubject_id)

        loop

          vPDPrt[i] := rpadc(' ------------------------------------------------',

                             66, '-');

          i := i + 1;

          vPDPrt[i] := '   ����� ����   |     ���� �� �������    |   ���� �� �������     ' || '|';

          i := i + 1;

          ----------------

          vPDPrt[i] := rpadc('    �� ' || inst_rec.taxperiod, 16) || '|' ||

                       rpadc(' � ��������  I ������ ', 24, ' ') || '|' ||

                       rpadc('         II ������', 23, ' ') || '|';

          ----------------

          i := i + 1;

          vPDPrt[i] := rpadc('     � ���� ', 16, ' ') || '|' ||

                       lpadc(inst_rec.period || ' ', 24, ' ') || '|' ||

                       lpadc(inst_rec.tdate2 || ' ', 20) || lpadc(' ', 3, ' ') || '|';

          i := i + 1;

          vPDPrt[i] := rpadc(' ------------------------------------------------',

                             66, '-');

          i := i + 1;

          vPDPrt[i] := ' ���� ' || lpadc(inst_rec.sumall, 10) || '|' ||

                       lpadc(to_char(coalesce(inst_rec.dis, 0.0), '999990.99'), 10, ' ') ||

                       lpadc(to_char(coalesce(inst_rec.v1, 0.0), '999990.99'), 12, ' ') ||

                       lpadc(' ', 2, ' ') || '|' ||

                       lpadc(to_char(coalesce(inst_rec.v2, 0.0), '999990.99'), 20, ' ') ||

                       '   |';

          i := i + 1;

          vPDPrt[i] := rpadc(' ------------------------------------------------',

                             66, '-');

          i := i + 1;

        end loop;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '���������� ��������� �� � ��������������� ��� � �� ������� �� ���������.';

        i := i + 1;

        

        vPDPrt[i] := '���� �������� �� ����� �� ��������� ����� ����������� ���������� �� ��������� �����!';

        i := i + 1;

        vPDPrt[i] := '���������� �� ������ �������� �� ������ �� �� �� ����� ������ � ������� ���������.';

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := '��� ��������� ������ ����� �������� ���������� ' ||

                         msg_rec.partidano;

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               90, '-');

            i := i + 1;

            vPDPrt[i] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               90, '-');

            i := i + 1;

            exit;

          end if;

        end loop;

        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||

                         rpadc(obl.taxname, 25) || '|' || rpadc(obl.taxcode, 6) || '|' ||

                         rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||

                         lpadc(to_char(obl.gl, '9990.99'), 10) || '|' ||

                         lpadc(to_char(obl.lix, '990.99'), 7) || '|' ||

                         lpadc(to_char(obl.obsto, '99990.99'), 11);

            i := i + 1;

          end if;

        end loop;

        for obl in currobl(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               90, '-');

            i := i + 1;

            exit;

          end if;

        end loop;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '���� �� ���������:';

        for rec in offices(0)

        loop

          r :=  wordwrap(  ' ����� �� ����: ' || rec.address, 45, 1);

          vPDPrt[i] := r.return_val;

          vrest := r.strrest;



          vPDPrt[i] := rpadc(vPDPrt[i], 30) || vPDPrt[i];

          i := i + 1;

          if (Length(vRest) > 1)

          then

            vPDPrt[i] := lpadc(' ', 46) || rpadc(vRest, 34, ' ');

            i := i + 1;

          end if;

        end loop;

        vPDPrt[i] := '';

        i := i + 1;

        for bank_rec in bank(vMunicipality_id)

        loop

          vPDPrt[i] := lpadc(' ', 30) || ' ���� �� �����: ' ||

                       rpadc(bank_rec.name, 45);

          i := i + 1;

          vPDPrt[i] := lpadc(' ', 39) || rpadc(' IBAN: ' || bank_rec.iban, 45);

          i := i + 1;

          vPDPrt[i] := lpadc(' ', 39) ||

                       rpadc(' ��� ������� 448013/����� ����/', 40, ' ');

          i := i + 1;

        end loop;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := lpadc('���������� ����: .............................', 80);

        i := i + 1;

        vPDPrt[i] := lpadc('(��� �������� ������ �����)', 80);

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '';

        i := i + 1;

        vPDPrt[i] := '��������: ' || msg_rec.operator1;

        i := i + 1;

        -- ======= End Part 2 =========  

      

        -- ======= Part 3 ========= 

        vPDPrt[i] := 'ff';

        i := i + 1;

        vPDPrt[i] := 'p3';

        i := i + 1;

        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := rpadc('������� ������� �����:', 42) || '��:';

            i := i + 1;

            vPDPrt[i] := rpadc(msg_rec.partidano, 42) || rpadc(msg_rec.idn, 40);

            i := i + 1;

            vPDPrt[i] := rpadc(msg_rec.regno, 42) ||

                         rpadc('���:' || msg_rec.tsname, 38);

            i := i + 1;

            r :=  wordwrap(  msg_rec.address, 37, 1 );

            vPDPrt[i] := r.return_val;

	    vrest := r.strrest;



            vPDPrt[i] := rpadc(msg_rec.regname, 42) || vPDPrt[i];

            i := i + 1;

            vPDPrt[i] := '';

            i := i + 1;

            exit;

          end if;

        end loop;

        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := '��� ��������� ������ ����� �������� ����������:';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               90, '-');

            i := i + 1;

            vPDPrt[i] := '|    ����  |     ��� ����������      |��� ��|    �������   | �������� | ����� |    ����   |';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               90, '-');

            i := i + 1;

            exit;

          end if;

        end loop;

        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := ' ' || rpadc(obl.termpay_date, 10) || '|' ||

                         rpadc(obl.taxname, 25) || '|' || rpadc(obl.taxcode, 6) || '|' ||

                         rpadc(coalesce(obl.partidano, ' '), 14) || '|' ||

                         lpadc(to_char(obl.gl, '9990.99'), 10) || '|' ||

                         lpadc(to_char(obl.lix, '990.99'), 7) || '|' ||

                         lpadc(to_char(obl.obsto, '99990.99'), 11);

            i := i + 1;

          end if;

        end loop;

        for obl in currobl_rest(msg_rec.taxsubject_id, msg_rec.partidanom)

        loop

          if (obl.obsto > 0)

          then

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               90, '-');

            i := i + 1;

            exit;

          end if;

        end loop;

        -------- �������� ���� ---------   

        for ovr in oversum(msg_rec.taxsubject_id)

        loop

          if (ovr.ndvn > 0)

          then

            vPDPrt[i] := '';

            i := i + 1;

            vPDPrt[i] := '��� ����� ���������� ����. ����, ������� �� ������ �� ����������/��������������.';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               60, '-');

            i := i + 1;

            vPDPrt[i] := '|     ��� ����������      |��� ��|    �������   |    ����   |';

            i := i + 1;

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               60, '-');

            i := i + 1;

            exit;

          end if;

        end loop;

        for ovr in oversum(msg_rec.taxsubject_id)

        loop

          if (ovr.ndvn > 0)

          then

            vPDPrt[i] := ' ' || rpadc(ovr.taxname, 25) || '|' ||

                         rpadc(ovr.taxcode, 6) || '|' ||

                         rpadc(coalesce(ovr.partidano, ' '), 14) || '|' ||

                         lpadc(to_char(ovr.ndvn, '99990.99'), 11);

            i := i + 1;

          end if;

        end loop;

        for ovr in oversum(msg_rec.taxsubject_id)

        loop

          if (ovr.ndvn > 0)

          then

            vPDPrt[i] := rpadc(' ------------------------------------------------',

                               60, '-');

            i := i + 1;

            vPDPrt[i] := '';

            i := i + 1;

            exit;

          end if;

        end loop;

        -- Check for rows after p3 else delete p3  

        if vPDPrt[i-1] = 'p3'

        then

     		vPDPrt := vPDPrt[array_lower(vPDPrt,1) : array_upper(vPDPrt,1)-2];

	--vPDPrt.DELETE(vPDPrt.LAST);

        -- vPDPrt.DELETE(vPDPrt.LAST);

          i := i - 2;

        end if;

        -- ======= End Part 3 ========= 

      

      end loop;

    end if;

    

    vPD_lob :=  paydocument_pkg.tblToLob(vPDPrt);

  

    --commit;

    return_val := 'OK';

    return;

  exception

    when others then

      begin

        --rollback;

        perform NOM_PKG.ErrManage(ErrMsg, SQLErrM);

        return_val := ErrMsg;

        return;

      

      end;

end;
$function$
; DROP FUNCTION paydocument_pkg.reportcalcinterest(character varying, character varying, numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.reportcalcinterest(OUT return_val character varying, ifrom character varying, ito character varying, isum numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  vPDPrt varchar [ ];
  crlist cursor(pFrom varchar, pTo varchar, pSum numeric) is
    select max(ip.begin_date) begin_date,
           --       max(round(ip.interestpct / to_char(LAST_DAY(ip.begin_date),'dd'),5)) interestpct,
           --       min(to_char(ip.begin_date,'dd.mm.yyyy'))||' / '||
           --       max(to_char(ip.begin_date+getperioddays(pFrom,pTo,ip.begin_date),'dd.mm.yyyy')) period,
           min(to_char(case
                          when ip.begin_date < to_date(pFrom, 'dd.mm.yyyy') then
                           to_date(pFrom, 'dd.mm.yyyy')
                          else
                           ip.begin_date
                        end, 'dd.mm.yyyy')) || ' / ' ||
            max(case
                  when ip.begin_date > to_date(pFrom, 'dd.mm.yyyy') then
                   to_char(ip.begin_date + (getperioddays(pFrom, pTo, trunc(ip.begin_date))||' days')::interval,
                           'dd.mm.yyyy')
                  else
                   to_char(to_date(pFrom, 'dd.mm.yyyy') +
                           getperioddays(pFrom, pTo, trunc(ip.begin_date)), 'dd.mm.yyyy')
                end) period, max(getperioddays(pFrom, pTo, trunc(ip.begin_date))) broi,
           max(round(((ip.interestpct + ip.interestpctadd) * pSum) / 36000, 5)) daypct,
           max(ip.interestpct + ip.interestpctadd) mainpct,
           max(round(((ip.interestpct + ip.interestpctadd) * pSum *
                      getperioddays(pFrom, pTo, trunc(ip.begin_date))) / 36000, 2)) sumint
    from   interestpct ip
    --  where ip.begin_date between to_date(iFrom,'dd.mm.yyyy')-
    --                  and to_date(iTo,'dd.mm.yyyy')
    where  ip.begin_date between
           (select max(ib.begin_date)
            from   interestpct ib
            where  ib.begin_date <= to_date(pFrom, 'dd.mm.yyyy')) and
           (select max(ie.begin_date)
            from   interestpct ie
            where  ie.begin_date <= trunc(to_date(pTo, 'dd.mm.yyyy')))
    
    group  by ip.begin_date
    order  by ip.begin_date;


  ErrMsg       varchar(100);
  i            numeric;
  vtotalintsum numeric(18, 2);
  vusername    varchar(100);
  d            varchar;
begin
  i            := 1;
  vtotalintsum := 0;

  select u.username || ' ' || u.fullname
  into   vusername
  from   users u
  where  u.user_id = iUser_id;
  vPDPrt [ i ] := ' �������� ����� ����� ' || iSum || ' ��. �� ������ ' ||
                  iFrom || ' �� ' || ito;
  i := i + 1;
  vPDPrt [ i ] := ' -----------------------------------------------------------------';
  i := i + 1;
  vPDPrt [ i ] := '|        ������         |����|��.�����    | ������     |�����     |';
  i := i + 1;
  vPDPrt [ i ] := '|  ��              ��   |��� |            | �������    |          |';
  i := i + 1;
  vPDPrt [ i ] := ' ------------------------------------------------------------------';
  i := i + 1;
  for cr in crList(iFrom, iTo, iSum) loop
    vPDPrt [ i ] := '  ' || rpadc(nvl(cr.period, ' '), 23) || ' ' ||
                    lpadc(cr.broi ::varchar, 4) || ' ' ||
                    lpadc(to_char(cr.daypct, '999990.99999'), 12) || ' ' ||
                    lpadc(to_char(cr.mainpct, '99999990.999'), 12) || ' ' ||
                    lpadc(to_char(cr.sumint, '9999990.99'), 10);
    i := i + 1;
    vtotalintsum := vtotalintsum + cr.sumint;
  end loop;
  vPDPrt [ i ] := ' ------------------------------------------------------------------';
  i := i + 1;
  vPDPrt [ i ] := rpadc(' ', 56, ' ') ||
                  lpadc(to_char(vtotalintsum, '99990.99'), 11, ' ');
  i := i + 1;
  vPDPrt [ i ] := ' ��������: ' || vusername;
  i := i + 1;
  vPDPrt [ i ] := '';

  vPD_lob := paydocument_pkg.tblToLob(vPDPrt);

  --commit;
  return_val := 'OK';
  return;
exception
  when others then
    begin
      --rollback;
      d := sqlerrm;
      perform NOM_PKG.ErrManage(ErrMsg);
      --RAISE NOTICE 'exception (code=%): %', SQLCODE, SQLERRM;
      return_val := ErrMsg;
      return;
    end;
end;
$function$
; DROP FUNCTION paydocument_pkg.reportcashier(numeric, character varying, character varying, numeric, character varying); 
CREATE OR REPLACE FUNCTION paydocument_pkg.reportcashier(OUT return_val character varying, iuser_id numeric, ifromdate character varying, itodate character varying, imunicipalityid numeric, itrtype character varying, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
    vPDPrt varchar[ ];
    ErrMsg varchar(300);
    getObl cursor(pUser_id      numeric,
                  pFromDate     varchar,
                  pToDate       varchar,
                  pMunicipality numeric) is

    --sumarno po kod vid plastane
      select 1, max(m.ebk_code) obstina, max(ptr.paytransaction_Id) ptrid,
             pd.paydocument_Id pdid, max(pd.partidano) parnom,
             max(kdreg.code || kpr.parreg_code) kodplast,
             max(ptr.transactionno) nomop, max(pd.series) seria,
             max(pd.documentno) dokno, max(pd.paytime) caspl, max(ts.idn) eik,
             max(case pd.kindpaydoc when '600' then '��' 
                                    when '621' then '���' end) kinddoc,
             max(pd.kindpaydoc), max(pd.null_date),
             sum(round(coalesce(pdt.payinstsum, 0), 2) *
                  (case when pd.kindpaydoc = '621' then -1 else 1 end)) plGl,
             sum(round(coalesce((pdt.payinterestsum), 0), 2)) plLix,
             sum(round(coalesce(pdt.paydiscsum, 0), 2)) otstp, 
             null::numeric pkosuma,
             null::numeric kvit, 
             case when max(pd.null_date) is null then null else '��������' end status,
             pdt.kinddebtreg_id, pdt.kindparreg_id, 
             null ac, null rrn
      from   Paytransaction ptr
      inner  join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id
      inner  join Paydebt pdt on pdt.paydocument_Id = pd.paydocument_Id
      left   outer join Kindparreg kpr on pdt.kindparreg_id = kpr.kindparreg_id
      left   outer join Kinddebtreg kdreg on pdt.kinddebtreg_id = kdreg.kinddebtreg_id
      inner  join municipality m on ptr.municipality_id = m.municipality_Id
      inner  join taxsubject ts on ts.taxsubject_Id = pd.taxsubject_Id
      where  (ptr.trtype = iTrType or ptr.trtype = case when iTrType = '1P' then '1P' else '32' end)
      and    ptr.municipality_id = case when pMunicipality = 0 then ptr.municipality_id else pMunicipality end
      and    pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss')
      and    to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
      and    pd.user_id = pUser_id
      group  by pd.paydocument_id, pdt.kinddebtreg_id, pdt.kindparreg_id
      union all
      --stornirani dokumenti
      select 2, max(m.ebk_code) obstina, max(ptr.paytransaction_Id) ptrid,
             pd.paydocument_Id pdid, max(pd.partidano) parnom,
             max(kdreg.code || kpr.parreg_code) kodplast,
             max(ptr.transactionno) nomop, max(pd.series) seria,
             max(pd.documentno) dokno, max(pd.paytime) caspl, max(ts.idn) eik,
             case max(pd.kindpaydoc) when '600' then '��'
                                     when '621' then '���' end kinddoc,
             max(pd.kindpaydoc), max(pd.null_date),
             sum(round(coalesce(pdt.payinstsum, 0), 2) *
                  case when pd.kindpaydoc = '621' then 1 else -1 end) plGl,
             sum(round(coalesce(pdt.payinterestsum, 0), 2) *
                  case when pd.kindpaydoc = '621' then 1 else -1 end) plLix,
             sum(round(coalesce(pdt.paydiscsum, 0), 2)) otstp, 
             null::numeric pkosuma,
             null::numeric kvit, 
             case when max(pd.null_date) is null then null else '��������' end status,
             pdt.kinddebtreg_id, pdt.kindparreg_id, 
             null, 
             null
      from   Paytransaction ptr
      inner  join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id
      inner  join Paydebt pdt on pdt.paydocument_Id = pd.paydocument_Id
      left   outer join Kindparreg kpr on pdt.kindparreg_id = kpr.kindparreg_id
      left   outer join Kinddebtreg kdreg on pdt.kinddebtreg_id = kdreg.kinddebtreg_id
      inner  join municipality m on ptr.municipality_id = m.municipality_Id
      inner  join taxsubject ts on ts.taxsubject_Id = pd.taxsubject_Id
      where  (ptr.trtype = iTrType or ptr.trtype = case when iTrType = '1P' then '1P' else '32' end)
      and    pd.null_date is not null
      and    ptr.municipality_id = case when pMunicipality = 0 then ptr.municipality_id else pMunicipality end
      and    pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
             to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
      and    pd.user_id = pUser_id
      group  by pd.paydocument_id, pdt.kinddebtreg_id, pdt.kindparreg_id
      -- kvitancia
      union all
      select 1, max(m.ebk_code) obstina, max(ptr.paytransaction_Id) ptrid,
             pd.paydocument_Id pdid, max(pd.partidano) parnom, null kodplast,
             max(ptr.transactionno) nomop, max(pd.series) seria,
             max(pd.documentno) dokno, max(pd.paytime) caspl, max(ts.idn) eik,
             max(case pd.kindpaydoc when '600' then '��'
                                    when '621' then '���' end) kinddoc,
             max(pd.kindpaydoc) kindpaydoc, max(pd.null_date) null_date,
             null plGl, null plLix, null otstp,
             sum(case when pd.kindpaydoc = '621' then coalesce(pd.docsum, 0) * -1 else 0 end) pkosuma,
             sum(case when pd.kindpaydoc = '600' then coalesce(pd.docsum, 0) else 0 end) kvit,
             case when max(pd.null_date) is null then null else '��������' end status, 
             null::numeric, null::numeric, 
             max(ptr.ac), 
             max(ptr.rrn)
      from   Paytransaction ptr
      inner join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id
      inner join municipality m on ptr.municipality_id = m.municipality_id
      inner join taxsubject ts on ts.taxsubject_Id = pd.taxsubject_Id
      where (ptr.trtype = iTrType or ptr.trtype = case when iTrType = '1P' then '1P' else '32' end)
      and   ptr.municipality_id = case when pMunicipality = 0 then ptr.municipality_id else pMunicipality end
      and   pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
            -- and pd.paytime between to_timestamp('01.01.2009 00:00:00','dd.mm.yyyy hh24:mi:ss') and to_timestamp('01.03.2009 00:00:00','dd.mm.yyyy hh24:mi:ss')
      and   pd.user_id = pUser_id
      group by pd.paydocument_id
      -- storno kvitancia
      union all
      select 2, max(m.ebk_code) obstina, max(ptr.paytransaction_Id) ptrid,
             pd.paydocument_Id pdid, max(pd.partidano) parnom, null kodplast,
             max(ptr.transactionno) nomop, max(pd.series) seria,
             max(pd.documentno) dokno, max(pd.paytime) caspl, max(ts.idn) eik,
             max(case pd.kindpaydoc when '600' then '��'
                                    when '621' then '���' end) kinddoc,
             max(pd.kindpaydoc) kindpaydoc, max(pd.null_date) null_date,
             null plGl, null plLix, null otstp,
             sum(case when pd.kindpaydoc = '621' then coalesce(pd.docsum, 0) else 0 end) pkosuma,
             sum(case when pd.kindpaydoc = '600' then -1 * coalesce(pd.docsum, 0) else 0 end) kvit,
             case when max(pd.null_date) is null then null else '��������' end status, 
             null::numeric, null::numeric,
             null, 
             null
      from   Paytransaction ptr
      inner join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id
      inner join municipality m on ptr.municipality_id = m.municipality_Id
      inner join taxsubject ts on ts.taxsubject_Id = pd.taxsubject_Id
      where (ptr.trtype = iTrType or ptr.trtype = case when iTrType = '1P' then '1P' else '32' end)
      and   ptr.municipality_id = case when pMunicipality = 0 then ptr.municipality_id else pMunicipality end
      and   pd.null_date is not null
      and   pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
            --  and pd.paytime between to_timestamp('01.01.2009 00:00:00','dd.mm.yyyy hh24:mi:ss') and to_timestamp('01.03.2009 00:00:00','dd.mm.yyyy hh24:mi:ss')
      and   pd.user_id = pUser_id
      group by pd.paydocument_id
      order  by 2, 3, 4, 5, 6, 1;
    --Order by 2,9,3,4,1,21;
    i             integer;
    vUser         varchar(100);
    vMunicipality varchar(100);
    vProvince     varchar(100);
    vPKO          numeric;
    vPK           numeric;
    vTotalPlgl    numeric(18, 2);
    vTotalPllix   numeric(18, 2);
    vTotalOtstp   numeric(18, 2);
    vTotalPKO     numeric(18, 2);
    vTotalKvit    numeric(18, 2);
begin
    i           := 1; -- �����
    vTotalPlgl  := 0;
    vTotalPllix := 0;
    vTotalOtstp := 0;
    vTotalPKO   := 0;
    vTotalKvit  := 0;
    vPKO        := 0;
    vPK         := 0;
    if (iMunicipalityId = 0) then
      select m.fullname , p.name
        into vMunicipality, vProvince
        from users u
        left outer join municipality m on u.municipality_id = m.municipality_id
        left outer join province p on m.province_id = p.province_id
       where u.user_id = iUser_id;
    else
      select m.fullname, p.name
      into   vMunicipality, vProvince
      from   municipality m, province p
      where  m.municipality_id = iMunicipalityId
      and    m.province_id = p.province_id;
    end if;

    select count(case when p.kindpaydoc = '600' then p.paydocument_id end
                         /*p.paytransaction_id*/),
           count(case when p.kindpaydoc = '621' then p.paydocument_id end
                         /*p.paytransaction_id*/)
    into   vPK, vPKO
    from   (select ptr.paytransaction_id, pd.paydocument_id, pd.kindpaydoc
             from   Paytransaction ptr, paydocument pd
             where  pd.paytransaction_id = ptr.paytransaction_id
             and    ptr.trtype = '1'
             and    ptr.municipality_id = case when iMunicipalityID = 0 then ptr.municipality_id else iMunicipalityID end
             and    pd.paytime between to_timestamp(iFromDate, 'dd.mm.yyyy hh24:mi:ss') and to_timestamp(iToDate, 'dd.mm.yyyy hh24:mi:ss')
             and    pd.user_id = iUser_id
             group  by ptr.paytransaction_id, pd.paydocument_id, pd.kindpaydoc) p;

    vPDPrt[i] := rpadc('������: ' || vProvince, 70, ' ') ||
                 lpadc('����: ' || to_char(CURRENT_DATE, 'dd.mm.yyyy'), 35,' ');
    i := i + 1;
    vPDPrt[i] := rpadc('������: ' || vMunicipality, 70, ' ') ||
                 lpadc('      ' || to_char(CURRENT_TIMESTAMP, 'hh24:mi:ss'), 35,' ');
    i := i + 1;
    if (iTrType = '1') then
      vPDPrt[i] := center('������ ���� �� ������ �������', 100);
    end if;
    if (iTrType = '1P') then
      vPDPrt[i] := center('������ ���� - ������� ���� ��� ��������', 100);
    end if;
    i := i + 1;
    select u.username || ' ' || u.fullname
    into   vUser
    from   users u
    where  u.user_id = iUser_id;
    vPDPrt[i] := center('���� �� ������: ' || vUser, 100);
    i := i + 1;
    vPDPrt[i] := center('�� ����: �� ' || iFromDate || ' �� ' || iToDate, 100);
    i := i + 1;
    vPDPrt[i] := '------------------------------------------------------------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := '      ��������        ���� � ���                   �����           ��� ��� ��.����                 ����                ���� ����.         ';
    i := i + 1;
    vPDPrt[i] := '���. ��� ����� �����    �������      ���           �������         ������� ����������  ���� �����  �������� ���� ���   ���������  ���.    ';
    i := i + 1;
    vPDPrt[i] := '------------------------------------------------------------------------------------------------------------------------------------------';
    i := i + 1;
    for getObl_rec in getObl(iUser_id, iFromDate, iToDate,
                             coalesce(iMunicipalityID, 0))
    loop
    if(getObl_rec.ac is null) then
      vPDPrt[i] := rpadc(getObl_rec.obstina, 4, ' ') || ' ' ||
                  -- rpadc(getObl_rec.Nomop,5,' ')||' '||
                   lpadc(coalesce(getObl_rec.kinddoc, '') || ' ', 3, ' ') || ' ' ||
                   lpadc(coalesce(getObl_rec.Seria, '') || ' ', 5, ' ') || ' ' ||
                   lpadc(coalesce(getObl_rec.Dokno, '') || ' ', 6, ' ') || ' ' ||
                   rpadc(to_char(getObl_rec.Caspl, 'dd.mm.yy hh24:mi'), 14, ' ') || ' ' ||
                   rpadc(getObl_rec.Eik, 13, ' ') || ' ' ||
                   rpadc(coalesce(getObl_rec.Parnom, '') || ' ', 15, ' ') || ' ' ||
                   rpadc(coalesce(getObl_rec.Kodplast, '') || ' ', 7, ' ') || ' ' ||
                   lpadc(to_char(coalesce(getObl_rec.Plgl, 0), '999990.99') || ' ',
                         11, ' ') || ' ' ||
                   lpadc(to_char(coalesce(getObl_rec.Pllix, 0), '999990.99') || ' ',
                         11, ' ') || ' ' ||
                   lpadc(to_char(coalesce(getObl_rec.Otstp, 0), '9990.99') || ' ', 8,
                         ' ') || ' ' ||
                   lpadc(to_char(coalesce(getObl_rec.pkosuma, 0), '999990.99') || ' ',
                         10, ' ') || ' ' ||
                   lpadc(to_char(coalesce(getObl_rec.Kvit, 0), '999990.99') || ' ',
                         10, ' ') || ' ' ||
                   rpadc(coalesce(getObl_rec.Status, ''), 9, ' ');
       else
      vPDPrt[i] := rpadc(getObl_rec.obstina, 4, ' ') || ' ' ||
                  -- rpadc(getObl_rec.Nomop,5,' ')||' '||
                   lpadc(coalesce(getObl_rec.kinddoc, '') || ' ', 3, ' ') || ' ' ||
                   lpadc(coalesce(getObl_rec.Seria, '') || ' ', 5, ' ') || ' ' ||
                   lpadc(coalesce(getObl_rec.Dokno, '') || ' ', 6, ' ') || ' ' ||
                   rpadc(to_char(getObl_rec.Caspl, 'dd.mm.yy hh24:mi'), 14, ' ') || ' ' ||
                   rpadc(getObl_rec.Eik, 13, ' ') || ' ' ||
                   rpadc(coalesce(getObl_rec.Parnom, '') || ' ', 15, ' ') || ' ' ||
                   'AC: ' || getObl_rec.ac || ' RRN# ' ||
                   rpadc(getObl_rec.rrn, 25, ' ') ||
                   lpadc(to_char(coalesce(getObl_rec.pkosuma, 0), '999990.99') || ' ',
                         10, ' ') || ' ' ||
                   lpadc(to_char(coalesce(getObl_rec.Kvit, 0), '999990.99') || ' ',
                         10, ' ') || ' ' ||
                   rpadc(coalesce(getObl_rec.Status, ''), 9, ' ');
      end if;
      i := i + 1;
      vTotalPlgl := vTotalPlgl + coalesce(getObl_rec.Plgl, 0);
      vTotalPllix := vTotalPllix + coalesce(getObl_rec.Pllix, 0);
      vTotalOtstp := vTotalOtstp + coalesce(getObl_rec.Otstp, 0);
      vTotalPKO := vTotalPKO + coalesce(getObl_rec.pkosuma, 0);
      vTotalKvit := vTotalKvit + coalesce(getObl_rec.Kvit, 0);
    end loop;
    vPDPrt[i] := '------------------------------------------------------------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := '���� ��: ' || rpadc(coalesce(vPK, 0)||' ', 10, ' ') || ' ' ||
                 '���� ���: ' || rpadc(coalesce(vPKO, 0)||' ', 10, ' ') ||
                 lpadc('���� ����: ', 34, ' ') ||
                 lpadc(to_char(coalesce(vTotalPlgl, 0), '99990.99'), 11, ' ') ||
                 lpadc(to_char(coalesce(vTotalPllix, 0), '99990.99'), 12, ' ') ||
                 lpadc(to_char(coalesce(vTotalOtstp, 0), '99990.99'), 9, ' ') ||
                 lpadc(to_char(coalesce(vTotalPKO, 0), '99990.99'), 11, ' ') ||
                 lpadc(to_char(coalesce(vTotalKvit, 0), '999990.99'), 11, ' ');
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := lpadc('', 80, ' ') || '������:........................';
    i := i + 1;

    Vpd_LOB := paydocument_pkg.tblToLob(vPDPrt);

    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        ErrMsg := sqlerrm;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;
      end;
end;
$function$
; DROP FUNCTION paydocument_pkg.reportcashierrecap(numeric, character varying, character varying, numeric, character varying); 
CREATE OR REPLACE FUNCTION paydocument_pkg.reportcashierrecap(OUT return_val character varying, iuser_id numeric, ifromdate character varying, itodate character varying, imunicipality_id numeric, itrtype character varying, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                               
    vPDPrt varchar[];
    ErrMsg varchar(300);
    getObl cursor (pUser_id      numeric,
                   pFromDate     varchar,
                   pToDate       varchar,
                   pMunicipality numeric,
                   pTrType       varchar) is
      select max(m.ebk_code) code,
             max((select d.value
                  from   decode d
                  where  upper(d.columnname) = 'KINDPAYDOC'
                  and    d.code = rec.kindpaydoc)) kinddoc,
             count(distinct coalesce(rec.pdid,0)) kvitnum,
             sum(coalesce(rec.kvit,0)) kvitsum,
             count(distinct coalesce(srec.pdid,0)) skvitnum,
             sum(coalesce(srec.kvit, 0)) ssumkvit,
             (count(distinct coalesce(rec.pdid,0)) - count(distinct coalesce(srec.pdid,0))) inknum,
             (sum(coalesce(rec.kvit,0)) + sum(coalesce(srec.kvit, 0))) inksum
      from   paytransaction pt
      inner  join municipality m
      on     pt.municipality_id = m.municipality_id
      inner  join (select tbl.ptrid, sum(tbl.kvit) kvit, tbl.kindpaydoc, tbl.pdid --count(pdid) cpdid
                   from   (select ptr.paytransaction_Id ptrid,
                                   pd.paydocument_Id pdid,
                                   coalesce(pd.docsum, 0) *
                                   case when pd.kindpaydoc = '621' then -1 else 1 end kvit,
                                   pd.kindpaydoc
                            from   Paytransaction ptr, paydocument pd
                            where  pd.paytransaction_id = ptr.paytransaction_id
                            and    (ptr.trtype = pTrType or ptr.trtype = case when pTrType = '1P' then '1P' else '32' end)
                            and    pd.paytime between
                                   to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
                                   to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
                            and    pd.user_id = pUser_id) tbl
                   group  by ptrid, pdid, kindpaydoc) rec
      on     pt.paytransaction_id = rec.ptrid
      left   outer join (select tbl1.ptrid, sum(tbl1.kvit) kvit, tbl1.kindpaydoc, tbl1.pdid -- RKO
                         from   (select ptr.paytransaction_Id ptrid,
                                         pd.paydocument_Id pdid,
                                         coalesce(pd.docsum, 0) *
                                         case when pd.kindpaydoc = '621' then 1 else -1 end kvit,
                                         pd.kindpaydoc
                                  from   Paytransaction ptr, paydocument pd
                                  where  pd.paytransaction_id =
                                         ptr.paytransaction_id
                                  and    (ptr.trtype = pTrType or ptr.trtype = case when pTrType = '1P' then '1P' else '32' end)
                                  and    pd.null_date is not null
                                  and    pd.paytime between
                                         to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
                                         to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
                                  and    pd.user_id = pUser_id) tbl1
                         group  by ptrid, pdid, kindpaydoc) srec
      on     rec.pdid = srec.pdid
      where  pt.municipality_id = case when pMunicipality = 0 then pt.municipality_id else pMunicipality end
      group  by pt.municipality_id, rec.kindpaydoc;
    i              integer;
    vUser          varchar(100);
    vMunicipality  varchar(200);
    vProvince      varchar(100);
    vTotalKvitnum  numeric;
    vTotaKvitSum   numeric(18, 2);
    vTotalSKvitnum numeric;
    vTotalSKvitSum numeric(18, 2);
    vTotalInstSum  numeric(18, 2);
  begin
    i              := 1; -- �����
    vTotalKvitnum  := 0;
    vTotaKvitSum   := 0;
    vTotalSKvitnum := 0;
    vTotalSKvitSum := 0;
    vTotalInstSum  := 0;
    if (iMunicipality_id = 0) then
      select m.fullname, p.name
        into vMunicipality, vProvince
        from users u
        left outer join municipality m on u.municipality_id = m.municipality_id
        left outer join province p on m.province_id = p.province_id
       where u.user_id = iUser_id;
    else
      select m.fullname, p.name
      into   vMunicipality, vProvince
      from   municipality m, province p
      where  m.municipality_id = iMunicipality_id
      and    m.province_id = p.province_id;
    end if;
    vPDPrt[i] := rpadc('������: ' || vProvince, 50, ' ') ||
                 lpadc('����: ' || to_char(current_date, 'dd.mm.yyyy'), 30);
    i := i + 1;
    vPDPrt[i] := rpadc('������: ' || vMunicipality, 50, ' ') ||
                 lpadc('      ' || to_char(CURRENT_TIMESTAMP, 'hh24:mi:ss'), 30, ' ');
    i := i + 1;
    if (iTrType = '1') then
     vPDPrt[i] := center('������������� �� ������ �������', 80);
    end if;
    if (iTrType = '1P') then
      vPDPrt[i] := center('������������� �� ������ ������� ���� ��� ��������', 100);
    end if;
    i := i + 1;
    select u.username || ' ' || u.fullname
    into   vUser
    from   users u
    where  u.user_id = iUser_id;
    vPDPrt[i] := center('�� ������: ' || vUser, 80);
    i := i + 1;
    vPDPrt[i] := center('�� ����: �� ' || iFromDate || ' �� ' || iToDate, 80);
    i := i + 1;
    vPDPrt[i] := ' -------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := '               ���      ����      ����         ����      ����       ����������  ';
    i := i + 1;
    vPDPrt[i] := ' ������        �������� ��������� ���������    ��������� ���������  ����        ';
    i := i + 1;
    vPDPrt[i] := ' -------------------------------------------------------------------------------';
    i := i + 1;
    for getObl_rec in getObl(iUser_id, iFromDate, iToDate, iMunicipality_id, iTrType) loop
      vPDPrt[i] := ' ' || rpadc(getObl_rec.code, 13, ' ') || ' ' ||
                   rpadc(getObl_rec.kinddoc, 8, ' ') || ' ' ||
                   lpadc(to_char(getObl_rec.kvitnum), 9, ' ') || ' ' ||
                   lpadc(to_char(getObl_rec.kvitsum, '999999990.99'), 12, ' ') || ' ' ||
                   lpadc(to_char(getObl_rec.skvitnum), 9, ' ') || ' ' ||
                   lpadc(to_char(getObl_rec.ssumkvit, '9999990.99'), 10, ' ') || ' ' ||
                   lpadc(to_char(getObl_rec.inksum, '999999990.99'), 12, ' ') || ' ';
      i := i + 1;
      vTotalKvitnum := vTotalKvitnum + getObl_rec.kvitnum;
      vTotaKvitSum := vTotaKvitSum + getObl_rec.kvitsum;
      vTotalSKvitnum := vTotalSKvitnum + getObl_rec.skvitnum;
      vTotalSKvitSum := vTotalSKvitSum + getObl_rec.ssumkvit;
      vTotalInstSum := vTotalInstSum + getObl_rec.inksum;
    end loop;
    vPDPrt[i] := ' -------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := rpadc(' ����: ', 23, ' ') || ' ' ||
                 lpadc(to_char(vTotalKvitnum,'999990.99'), 9, ' ') || ' ' ||
                 lpadc(to_char(coalesce(vTotaKvitSum, 0), '99999990.99'), 12, ' ') || ' ' ||
                 lpadc(to_char(vTotalSKvitnum,'999990.99'), 9, ' ') || '' ||
                 lpadc(to_char(coalesce(vTotalSKvitSum, 0), '99999990.99'), 11, ' ') || ' ' ||
                 lpadc(to_char(vTotalInstSum, '99999990.99'), 12, ' ');
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := lpadc(' ', 50, ' ') || '������:......................';
    i := i + 1;

    vPD_lob := paydocument_pkg.tblToLob(vPDPrt);

    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        errmsg := sqlerrm;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;
      end;
  end;
$function$
; DROP FUNCTION paydocument_pkg.reportclaimsdd(numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.reportclaimsdd(OUT return_val character varying, ibankfiletransfer_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  vPDPrt  varchar [ ];
  ErrMsg  varchar(300);
  getHead cursor(pBankFileTransfer_id numeric) is
    select bft.bankfiletransfer_id,
           ('��� �����: ' || b.fullname || '   ������ �� ������� ������: ' ||
            ba.iban) banka,
           ('���� ������: ' || to_char(bft.docdate, 'dd.mm.yyyy')) docdate,
           ('��� ��� �������: ' || kdr.code || ' - ' || upper(kdr.name)) kdrname,
           ('��� �� ����: ' || bft.filename) filename, bft.sum suma, m.ebk_code
    from   Bankfiletransfer bft
    inner  join Users u
    on     bft.user_id = u.user_id
    inner  join Municipality m
    on     bft.municipality_id = m.municipality_id
    left   outer join Kinddebtreg kdr
    on     bft.kinddebtreg_id = kdr.kinddebtreg_id
    left   outer join Baccount ba
    on     bft.baccount_id = ba.baccount_id
    left   outer join Bank b
    on     ba.bank_id = b.bank_id
    where  bft.bankfiletransfer_id = pBankFileTransfer_id;



  getDetails cursor(pBankFileTransfer_id numeric) is
    select dd.directdebit_id, ts.idn, ts.name tsname, dd.tsaccountno, dd.reason2,
           (dd.instsum + dd.interestsum) suma
    from   Bankfiletransfer bft
    left   outer join DirectDebit dd
    on     bft.bankfiletransfer_id = dd.bankfiletransfer_id
    left   outer join Taxsubject ts
    on     dd.taxsubject_id = ts.taxsubject_id
    where  bft.bankfiletransfer_id = pBankFileTransfer_id;



  i      numeric;
  j      numeric;
  vTotal numeric(18, 2);
begin
  i      := 1; -- ����� 
  vTotal := 0;


  vPDPrt [ i ] := center('���� ������� �� �������� �����', 100);
  i := i + 1;
  for head in getHead(iBankFileTransfer_id)
  loop
    vPDPrt [ i ] := rpadc(head.banka, 80);
    i := i + 1;
    vPDPrt [ i ] := rpadc(head.docdate, 80);
    i := i + 1;
    vPDPrt [ i ] := rpadc(head.kdrname, 80);
    i := i + 1;
    vPDPrt [ i ] := rpadc(head.filename, 80);
    i := i + 1;
    vTotal := head.suma;
    exit;
  end loop;

  vPDPrt [ i ] := '----------------------------------------------------------------------------------------------------------------';
  i := i + 1;
  vPDPrt [ i ] := '���.���. ���             ��� ������                 ������� ������          ���������            ���� ����      ';
  i := i + 1;
  vPDPrt [ i ] := '----------------------------------------------------------------------------------------------------------------';
  i := i + 1;
  j := 0;
  for details in getDetails(iBankFileTransfer_id)
  loop
    j := j + 1;
    vPDPrt [ i ] := lpadc(j ::varchar, 8, ' ') || ' ' ||
                    rpadc(details.idn || ' ', 15, ' ') || ' ' ||
                    rpadc(details.tsname || ' ', 26, ' ') || ' ' ||
                    lpadc(details.tsaccountno || ' ', 23, ' ') || ' ' ||
                    rpadc(details.reason2, 20, ' ') || ' ' ||
                    lpadc(to_char(details.suma, '999990.99') || ' ', 15, ' ');
    i := i + 1;
    --vTotal  := vTotal + nvl(detail.suma,0);   
  end loop;
  vPDPrt [ i ] := '----------------------------------------------------------------------------------------------------------------';
  i := i + 1;
  vPDPrt [ i ] := '����: ' || lpadc(to_char(vTotal, '999990.99'), 105, ' ');
  i := i + 1;
  vPDPrt [ i ] := '';
  i := i + 1;
  vPDPrt [ i ] := '';
  i := i + 1;
  vPDPrt [ i ] := '������������:........................';
  i := i + 1;

  vPD_lob := paydocument_pkg.tblToLob(vPDPrt);

  --commit;
  return_val := 'OK';
  return;
exception
  when others then
    begin
      --rollback;
      return_val := sqlerrm;
      perform NOM_PKG.ErrManage(ErrMsg);
      return_val := ErrMsg;
      return;
    end;
end;
$function$
; DROP FUNCTION paydocument_pkg.reportclaimsddanswer(numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.reportclaimsddanswer(OUT return_val character varying, ibankfiletransfer_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                                 
    vPDPrt varchar[];
    ErrMsg varchar(100);
     getHead cursor (pBankFileTransfer_id numeric) is
      select bft.bankfiletransfer_id,
             ('��� �����: ' || b.fullname || '   ������ �� ������� ������: ' ||
              ba.iban) banka,
             ('���� ������: ' || to_char(bft.docdate, 'dd.mm.yyyy')) docdate,
             ('��� ��� �������: ' || kdr.code || ' - ' || upper(kdr.name)) kdrname,
             ('��� �� ����: ' || bft.filename) filename, bft.sum suma,
             m.ebk_code
      from   Bankfiletransfer bft
      inner  join Users u
      on     bft.user_id = u.user_id
      inner  join Municipality m
      on     bft.municipality_id = m.municipality_id
      left   outer join Kinddebtreg kdr
      on     bft.kinddebtreg_id = kdr.kinddebtreg_id
      left   outer join Baccount ba
      on     bft.baccount_id = ba.baccount_id
      left   outer join Bank b
      on     ba.bank_id = b.bank_id
      where  bft.bankfiletransfer_id = pBankFileTransfer_id;
  
     getDetails cursor (pBankFileTransfer_id numeric) is
      select dd.directdebit_id, ts.idn, ts.name tsname, dd.tsaccountno,
             dd.reason2, (dd.instsum + dd.interestsum) suma,
             to_char(dd.paydate, 'dd.mm.yyyy') paydate,
             decode(dd.answer_code::integer, 99, '�������', '���������') answercode
      from   Bankfiletransfer bft
      left   outer join DirectDebit dd
      on     bft.bankfiletransfer_id = dd.answer_bankfiletransfer_id
      left   outer join Taxsubject ts
      on     dd.taxsubject_id = ts.taxsubject_id
      where  bft.bankfiletransfer_id = pBankFileTransfer_id;
  
    i             numeric;
    j             numeric;
    vTotal        numeric(18, 2);
  begin
    i      := 1; -- ����� 
    vTotal := 0;
  
  
    vPDPrt[i] := center('���� �� �������� �� ������� �� �������� �����', 100);
    i := i + 1;
    for head in getHead(iBankFileTransfer_id)
    loop
      vPDPrt[i] := rpadc(head.banka, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(head.docdate, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(head.kdrname, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(head.filename, 80);
      i := i + 1;
      vTotal := head.suma;
      exit;
    end loop;
  
    vPDPrt[i] := '-------------------------------------------------------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := '���.���. ���             ��� ������                 ������� ������          ���������            ���� ����       ���� ������ ������� ';
    i := i + 1;
    vPDPrt[i] := '-------------------------------------------------------------------------------------------------------------------------------------';
    i := i + 1;
    j := 0;
    for details in getDetails(iBankFileTransfer_id)
    loop
      j := j + 1;
      vPDPrt[i] := lpadc(j::varchar, 8, ' ') || ' ' ||
                   rpadc( details.idn  || ' ', 15, ' ') || ' ' ||
                   rpadc( details.tsname || ' ', 26, ' ') || ' ' ||
                   lpadc( details.tsaccountno  || ' ', 23, ' ') || ' ' ||
                   rpadc(details.reason2, 20, ' ') || ' ' ||
                   lpadc(to_char(details.suma, '999990.99') || ' ', 15,
                         ' ') || ' ' || rpadc(details.paydate, 11, ' ') || ' ' ||
                   rpadc(details.answercode, 8, ' ');
      i := i + 1;
      --vTotal  := vTotal + nvl(detail.suma,0);   
    end loop;
    vPDPrt[i] := '-------------------------------------------------------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := '����: ' || lpadc(to_char(vTotal, '999990.99'), 105, ' ');
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '������������:........................';
    i := i + 1;
    
    vPD_lob :=  paydocument_pkg.tblToLob(vPDPrt );
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        return_val := sqlerrm;
        errmsg :=  NOM_PKG.ErrManage(sqlstate, sqlerrm);
        return_val := ErrMsg;
        return;
      end;
end;

$function$
; DROP FUNCTION paydocument_pkg.reportoffice(numeric, numeric, character varying, character varying, numeric, character varying); 
CREATE OR REPLACE FUNCTION paydocument_pkg.reportoffice(OUT return_val character varying, iuser_id numeric, ioffice_id numeric, ifromdate character varying, itodate character varying, imunicipality_id numeric, itrtype character varying, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  vPDPrt varchar [ ];
  ErrMsg varchar(300);
  getObl cursor(pOffice_id integer, pFromDate varchar, pToDate varchar, pMunicipality integer) is
  
   select m.ebk_code municipality, 1 sort, max('7311') accountcode,
             k.kinddebtreg_id, max(k.code) || max(kp.parreg_code) kinddebtcode,
             max(k.name) kinddebtname, max(kp.parreg_name) period,
             max(((select d.value
                    from   decode d
                    where  upper(d.columnname) = 'KINDPAYDOC'
                    and    d.code = pd.kindpaydoc))) kindpaydoc,
             sum(Coalesce(pdt.payinstsum, 0)) instsum,
             null outgosum,
             null totalsum
      from   paydocument pd
      inner join paydebt pdt on pd.paydocument_id = pdt.paydocument_id
      inner join paytransaction pt on pd.paytransaction_id = pt.paytransaction_id
      inner join municipality m on pt.municipality_id = m.municipality_id
      inner join kinddebtreg k on pdt.kinddebtreg_id = k.kinddebtreg_id
      inner join kindparreg kp on pdt.kindparreg_id = kp.kindparreg_id
      where (pt.trtype = iTrType or pt.trtype = case when iTrType = '1P' then '1P' else '32' end)
        and pt.office_id = pOffice_id
        and pt.municipality_id = case when pMunicipality = 0 then pt.municipality_id else pMunicipality end
        and pd.kindpaydoc = '600'
        and Coalesce(pdt.payinstsum, 0) > 0
        and pd.null_date is null
        and pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
             to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
      group  by m.ebk_code, k.kinddebtreg_id, kp.kindparreg_id

      union all
      --- lixva ��
      select m.ebk_code municipality, 2 sort, max('7311') accountcode,
             k.kinddebtreg_id, max(k.code) || '865' kinddebtcode,
             max(k.name) kinddebtname, '�����' period,
             max(((select d.value
                    from   decode d
                    where  upper(d.columnname) = 'KINDPAYDOC'
                    and    d.code = pd.kindpaydoc))) kindpaydoc,
             sum(Coalesce(pdt.payinterestsum, 0)) instsum,
             null::numeric outgosum,
             null::numeric totalsum
      from   paydocument pd
      inner join paydebt pdt on pd.paydocument_id = pdt.paydocument_id
      inner join paytransaction pt on pd.paytransaction_id = pt.paytransaction_id
      inner join municipality m on pt.municipality_id = m.municipality_id
      inner join kinddebtreg k on pdt.kinddebtreg_id = k.kinddebtreg_id
      where (pt.trtype = iTrType or pt.trtype = case when iTrType = '1P' then '1P' else '32' end)
        and pt.office_id = pOffice_id
        and pt.municipality_id = case when pMunicipality = 0 then pt.municipality_id else pMunicipality end
        and pd.kindpaydoc = '600'
        and Coalesce(pdt.payinterestsum, 0) > 0
        and pd.null_date is null
        and pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
             to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
      group  by m.ebk_code, k.kinddebtreg_id

      union all
      -- ���
      select m.ebk_code municipality, 3 sort, max('7311') accountcode,
             k.kinddebtreg_id, max(k.code) || '899' kinddebtcode,
             max(k.name) kinddebtname, '�����.' period,
             max(((select d.value
                    from   decode d
                    where  upper(d.columnname) = 'KINDPAYDOC'
                    and    d.code = pd.kindpaydoc))) kindpaydoc,
             null::numeric instsum,
             sum(Coalesce(pd.docsum, 0)) outgosum,
             null::numeric totalsum
      from   paydocument pd
      inner join paytransaction pt on pd.paytransaction_id = pt.paytransaction_id
      inner join municipality m on pt.municipality_id = m.municipality_id
      inner join kinddebtreg k on pd.over_kinddebtreg_id = k.kinddebtreg_id
      where  (pt.trtype = iTrType or pt.trtype = case when iTrType = '1P' then '1P' else '32' end)
         and pt.office_id = pOffice_id
         and pt.municipality_id = case when pMunicipality = 0 then pt.municipality_id else pMunicipality end
         and pd.kindpaydoc = '621'
         and pd.null_date is null
        and pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
             to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
      group  by m.ebk_code, k.kinddebtreg_id

      union all
      select m.ebk_code municipality, 4 sort, max('7311') accountcode,
             k.kinddebtreg_id, max(k.acc) kinddebtcode, max(k.name) kinddebtname,
             '�����.' period,
             max(((select d.value
                    from   decode d
                    where  upper(d.columnname) = 'KINDPAYDOC'
                    and    d.code = pd.kindpaydoc))) kindpaydoc, 
             null::numeric instsum,
             sum(Coalesce(pd.docsum, 0)) outgosum,
             sum(Coalesce(pd.docsum, 0)) totalsum
      from   paydocument pd
      inner join paytransaction pt on pd.paytransaction_id = pt.paytransaction_id
      inner join municipality m on pt.municipality_id = m.municipality_id
      inner join kinddebtreg k on pd.over_kinddebtreg_id = k.kinddebtreg_id
      where  (pt.trtype = iTrType or pt.trtype = case when iTrType = '1P' then '1P' else '32' end)
         and pt.office_id = pOffice_id
         and pt.municipality_id = case when pMunicipality = 0 then pt.municipality_id else pMunicipality end
         and pd.kindpaydoc = '622'
         and pd.null_date is null
         and pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
             to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
      group  by m.ebk_code, k.kinddebtreg_id

      union all
      select m.ebk_code municipality, 4 sort, max('7311') accountcode,
             k.kinddebtreg_id, max(k.acc) kinddebtcode, max(k.name) kinddebtname,
             '�����.' period,
             max(((select d.value
                    from   decode d
                    where  upper(d.columnname) = 'KINDPAYDOC'
                    and    d.code = pd.kindpaydoc))) kindpaydoc, 
             null::numeric instsum,
             sum(Coalesce(pd.docsum, 0)) outgosum,
             sum(Coalesce(pd.docsum, 0)) totalsum
      from   paydocument pd
      inner join paytransaction pt on pd.paytransaction_id = pt.paytransaction_id
      inner join municipality m on pt.municipality_id = m.municipality_id
      inner join kinddebtreg k on pd.over_kinddebtreg_id = k.kinddebtreg_id
      where  (pt.trtype = iTrType or pt.trtype = case when iTrType = '1P' then '1P' else '32' end)
         and pt.office_id = pOffice_id
         and pt.municipality_id = case when pMunicipality = 0 then pt.municipality_id else pMunicipality end
         and pd.kindpaydoc = '624'
         and pd.null_date is null
         and pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
             to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
      group  by m.ebk_code, k.kinddebtreg_id

      union all
      select m.ebk_code municipality, 4 sort, max('7311') accountcode,
             k.kinddebtreg_id, max(k.acc) kinddebtcode, max(k.name) kinddebtname,
             '����' period,
             max(((select d.value
                    from   decode d
                    where  upper(d.columnname) = 'KINDPAYDOC'
                    and    d.code = pd.kindpaydoc))) kindpaydoc, 
             null::numeric instsum,
             null::numeric outgosum,
             sum(Coalesce(pdt.payinstsum, 0) + Coalesce(pdt.payinterestsum, 0)) totalsum
      from   paydocument pd
      inner join paydebt pdt on pd.paydocument_id = pdt.paydocument_id
      inner join paytransaction pt on pd.paytransaction_id = pt.paytransaction_id
      inner join municipality m on pt.municipality_id = m.municipality_id
      inner join kinddebtreg k on pdt.kinddebtreg_id = k.kinddebtreg_id
      where  (pt.trtype = iTrType or pt.trtype = case when iTrType = '1P' then '1P' else '32' end)
         and pt.office_id = pOffice_id
         and pt.municipality_id = case when pMunicipality = 0 then pt.municipality_id else pMunicipality end 
         and pd.kindpaydoc = '600'
         and pd.null_date is null
         and pd.paytime between to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
             to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')
      group  by m.ebk_code, k.kinddebtreg_id


      order  by 1, 4, sort;
    -----
  i             integer;
  vOffice       varchar(100);
  vMunicipality varchar(100);
  vProvince     varchar(100);
  vTotalInstSum numeric(18, 2);
  vTotalOutSum  numeric(18, 2);
  vTotaSum      numeric(18, 2);
begin
  i             := 1; -- ����� 
  vTotalInstSum := 0.0;
  vTotalOutSum  := 0.0;
  vTotaSum      := 0.0;
  if (iMunicipality_id = 0)
  then
      select m.fullname, p.name 
        into vMunicipality, vProvince
        from users u
        left outer join municipality m on u.municipality_id = m.municipality_id
        left outer join province p on m.province_id = p.province_id
       where u.user_id = iUser_id;
  else
    select m.fullname, p.name
    into   vMunicipality, vProvince
    from   municipality m, province p
    where  m.municipality_id = iMunicipality_id
    and    m.province_id = p.province_id;
  end if;

  vPDPrt [ i ] := rpadc('������: ' || vProvince, 65) ||
                  lpadc('����: ' || to_char(current_date, 'dd.mm.yyyy'), 25);
  i := i + 1;
  vPDPrt [ i ] := rpadc('������: ' || vMunicipality, 65) ||
                  lpadc('      ' || to_char(current_timestamp, 'hh24:mi:ss'), 25);
  i := i + 1;
  if (iTrType = '1') then
       vPDPrt[i] := lpadc('������ ������ ����', 50);
       end if;
        if (iTrType = '1P') then
       vPDPrt[i] := lpadc('������ ������ ���� - ������� ���� ��� ��������', 60);
       end if;
  i := i + 1;
  select o.fullname
  into   vOffice
  from   office o
  where  o.office_id = iOffice_id;
  vPDPrt [ i ] := lpadc('�� ����� �����: ' || vOffice, 50);
  i := i + 1;
  vPDPrt [ i ] := lpadc('�� ����: �� ' || iFromDate || ' �� ' || iToDate, 65);
  i := i + 1;
  vPDPrt [ i ] := ' -------------------------------------------------------------------------------------------------';
  i := i + 1;
  vPDPrt [ i ] := '|      |      |��� ��� |               |����������|���     | ����       | ����       | ���� ��    |';
  i := i + 1;
  vPDPrt [ i ] := '|������|������|������� |��� ���������� |��        |��������| ������     | ������     | ��� �������|';
  i := i + 1;
  vPDPrt [ i ] := ' -------------------------------------------------------------------------------------------------';
  i := i + 1;
  for getObl_rec in getObl(iOffice_id, iFromDate, iToDate, iMunicipality_id)
  loop
    vPDPrt [ i ] := ' ' || rpadc(getObl_rec.Municipality, 6, ' ') || ' ' ||
                    lpadc(getObl_rec.Accountcode, 6, '  ') || ' ' ||
                    lpadc(getObl_rec.Kinddebtcode, 8, ' ') || ' ' ||
                    rpadc(getObl_rec.Kinddebtname, 15, ' ') || ' ' ||
                    rpadc(getObl_rec.Period, 10, ' ') || ' ' ||
                    rpadc(getObl_rec.kindpaydoc, 8, ' ') || ' ' ||
                    lpadc(to_char(getObl_rec.Instsum, '999999990.99') || ' ', 12,
                          ' ') || ' ' ||
                    lpadc(to_char(getObl_rec.outgosum, '999999990.99') || ' ',
                          12, ' ') || ' ' ||
                    lpadc(to_char(getObl_rec.Totalsum, '999999990.99') || ' ',
                          12, ' ') || ' ';
  
    i             := i + 1;
    vTotalInstSum := vTotalInstSum + Coalesce(getObl_rec.Instsum, 0.0);
    vTotalOutSum  := vTotalOutSum + Coalesce(getObl_rec.outgosum, 0.0);
    vTotaSum      := vTotaSum + Coalesce(getObl_rec.Totalsum, 0.0);
  end loop;
  vPDPrt [ i ] := ' -------------------------------------------------------------------------------------------------';
  i := i + 1;
  vPDPrt [ i ] := rpadc(' ���� ����: ', 59, ' ') || ' ' ||
                  lpadc(to_char(Coalesce(vTotalInstSum, 0.0), '999999990.99'), 12, ' ') || ' ' ||
                  lpadc(to_char(Coalesce(vTotalOutSum, 0.0), '999999990.99'), 12, ' ') || ' ' ||
                  lpadc(to_char(Coalesce(vTotaSum, 0.0), '999999990.99'), 12, ' ');


  i := i + 1;
  vPDPrt [ i ] := '';
  i := i + 1;
  vPDPrt [ i ] := '';
  i := i + 1;
  vPDPrt [ i ] := lpadc('', 50, ' ') || '������������:........................';
  i := i + 1;

  vPD_lob := paydocument_pkg.tblToLob(vPDPrt);

  --commit;
  return_val := 'OK';
  return;
exception
  when others then
    begin
      --rollback;
      return_val := sqlerrm;
      errmsg     := NOM_PKG.ErrManage(sqlstate, sqlerrm);
      return_val := ErrMsg;
      return;
    end;
end;
$function$
; DROP FUNCTION paydocument_pkg.reportofficerecap(numeric, numeric, character varying, character varying, numeric, character varying); 
CREATE OR REPLACE FUNCTION paydocument_pkg.reportofficerecap(OUT return_val character varying, iuser_id numeric, ioffice_id numeric, ifromdate character varying, itodate character varying, imunicipality_id numeric, itrtype character varying, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                              
    vPDPrt varchar[];
    ErrMsg varchar(300);
     getObl cursor (pOffice_id    integer,
                  pFromDate     varchar,
                  pToDate       varchar,
                  pMunicipality  integer) is
      select max(m.ebk_code) code,
             max((select d.value
                  from   decode d
                  where  upper(d.columnname) = 'KINDPAYDOC'
                  and    d.code = rec.kindpaydoc)) kinddoc,
             count(distinct rec.pdid) kvitnum,
             sum(nvl(rec.kvit,0.0)) kvitsum,
             count(distinct srec.pdid) skvitnum,
             sum(nvl(srec.kvit, 0.0)) ssumkvit,
             (count(distinct rec.pdid) - count(distinct srec.pdid)) inknum,
             sum(nvl(rec.kvit,0.0)) + sum(nvl(srec.kvit, 0.0)) inksum,
             max(u.username || ':' || u.fullname) ufullname
      from   paytransaction pt
      inner  join municipality m
      on     pt.municipality_id = m.municipality_id
      inner  join (select ptrid, sum(kvit) kvit, kindpaydoc, pdid, user_id
                   from   (select ptr.paytransaction_Id ptrid,
                                   pd.paydocument_Id pdid, pd.kindpaydoc,
                                   nvl(pd.docsum, 0.0) *
                                    decode(pd.kindpaydoc, '621', -1, 1) kvit,
                                   pd.user_id
                            from   Paytransaction ptr 
                            inner join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id
                            where  pd.kindpaydoc != '624'
                            and    (ptr.trtype = iTrType or ptr.trtype = case when iTrType = '1P' then '1P' else '32' end)
                            and    pd.paytime between
                                   to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and
                                   to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')) t
                   group  by user_id, ptrid, kindpaydoc, pdid) rec
      on     pt.paytransaction_id = rec.ptrid
      inner  join users u
      on     rec.user_id = u.user_id
      -- stornirani  
      left outer join (select ptrid, sum(kvit) kvit, kindpaydoc, pdid, user_id
                         from   (select ptr.paytransaction_Id ptrid,
                                         pd.paydocument_Id pdid, pd.kindpaydoc,
                                         nvl(pd.docsum, 0.0) *
                                          decode(pd.kindpaydoc, '621', 1, -1) kvit,
                                         pd.user_id
                                  from   Paytransaction ptr inner join paydocument pd on pd.paytransaction_id = ptr.paytransaction_id --, paydebt pdt                 
                                  where  
                                        (ptr.trtype = iTrType or ptr.trtype = case when iTrType = '1P' then '1P' else '32' end)
                                  and    pd.null_date is not null
                                  and    pd.paytime between
                                         to_timestamp(pFromDate, 'dd.mm.yyyy hh24:mi:ss') and to_timestamp(pToDate, 'dd.mm.yyyy hh24:mi:ss')) t1
                         group  by user_id, ptrid, kindpaydoc, pdid) srec
      on     rec.pdid = srec.pdid
      where  pt.municipality_id = decode(pMunicipality, 0, pt.municipality_id, pMunicipality)
      group  by rec.user_id, rec.kindpaydoc
      order  by rec.user_id, rec.kindpaydoc;
    i                integer;
    vOffice          varchar(100);
    vMunicipality    varchar(100);
    vProvince        varchar(100);
    vTotalKvitnum    numeric;
    vTotaKvitSum     numeric(18, 2);
    vTotalPdnullnum  numeric;
    vTotalDocnullSum numeric(18, 2);
    vTotalInstSum    numeric(18, 2);
  begin
    i                := 1; -- ����� 
    vTotalKvitnum    := 0;
    vTotaKvitSum     := 0;
    vTotalPdnullnum  := 0;
    vTotalDocnullSum := 0;
    vTotalInstSum    := 0;
    if (iMunicipality_id = 0)
    then
      select m.fullname, p.name 
      into vMunicipality, vProvince
      from users u
      left outer join municipality m on u.municipality_id = m.municipality_id
      left outer join province p on m.province_id = p.province_id
      where u.user_id = iUser_id;
    else
      select m.fullname, p.name
      into   vMunicipality, vProvince
      from   municipality m, province p
      where  m.municipality_id = iMunicipality_id
      and    m.province_id = p.province_id;
    end if;
  
    vPDPrt[i] := rpadc('������: ' || vProvince, 65) ||
                 lpadc('����: ' || to_char(current_date, 'dd.mm.yyyy'), 25);
    i := i + 1;
    vPDPrt[i] := rpadc('������: ' || vMunicipality, 65) ||
                 lpadc('      ' || to_char(current_timestamp, 'hh24:mi:ss'), 25);
    i := i + 1;
   if (iTrType = '1') then
      vPDPrt[i] := center('������������� �� ������ ������� �� �������', 80);
    end if; 
    if (iTrType = '1P') then
      vPDPrt[i] := center('������������� �� ������ ������� �� ������� ���� ��� ��������', 80);
    end if;
    i := i + 1;
    select o.fullname
    into   vOffice
    from   office o
    where  o.office_id = iOffice_id;
    vPDPrt[i] := center('�� ����� �����: ' || vOffice, 80);
    i := i + 1;
    vPDPrt[i] := center('�� ����: �� ' || iFromDate || ' �� ' || iToDate, 80);
    i := i + 1;
    vPDPrt[i] := ' -----------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := '                                 ���  ����  ����         ����      ����       ����������  ';
    i := i + 1;
    vPDPrt[i] := ' ������                   ������ ���. ����. ���������    ��������� ���������  ����        ';
    i := i + 1;
    vPDPrt[i] := ' -----------------------------------------------------------------------------------------';
    i := i + 1;
    for getObl_rec in getObl(iOffice_id, iFromDate, iToDate, iMunicipality_id)
    loop
      vPDPrt[i] := ' ' || rpadc(getObl_rec.Ufullname, 24, ' ') || ' ' ||
                   rpadc(getObl_rec.code, 6, ' ') || ' ' ||
                   rpadc(getObl_rec.kinddoc, 4, ' ') || ' ' ||
                   lpadc(to_char(getObl_rec.kvitnum, '999990'), 5, ' ') || ' ' ||
                   lpadc(to_char(getObl_rec.kvitsum, '999999990.99'), 12, ' ') || ' ' ||
                   lpadc(to_char(getObl_rec.skvitnum, '999990'), 9, ' ') || ' ' ||
                   lpadc(to_char(nvl(getObl_rec.ssumkvit, 0.0), '9999990.99'), 10,
                         ' ') || ' ' || lpadc(to_char(getObl_rec.inksum, '999999990.99'), 12, ' ') || ' ';
      i := i + 1;
      vTotalKvitnum := vTotalKvitnum + getObl_rec.kvitnum;
      vTotaKvitSum := vTotaKvitSum + getObl_rec.kvitsum;
      vTotalPdnullnum := vTotalPdnullnum + getObl_rec.skvitnum;
      vTotalDocnullSum := vTotalDocnullSum + getObl_rec.ssumkvit;
      vTotalInstSum := vTotalInstSum + getObl_rec.inksum;
    end loop;
    vPDPrt[i] := ' -----------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := rpadc(' ����: ', 37, ' ') || ' ' ||
                 lpadc(to_char(vTotalKvitnum, '999990'), 5, ' ') || ' ' ||
                 lpadc(to_char(vTotaKvitSum, '999999990.99'), 12, ' ') || ' ' ||
                 lpadc(to_char(vTotalPdnullnum, '999990'), 9, ' ') || ' ' ||
                 lpadc(to_char(nvl(vTotalDocnullSum, 0.0), '9999990.99'), 10, ' ') || ' ' ||
                 lpadc(to_char(nvl(vTotalInstSum, 0.0), '999999990.99'), 12, ' ');
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := lpadc('', 50, ' ') || '������������:........................';
    i := i + 1;
    
    vPD_lob :=  paydocument_pkg.tblToLob(vPDPrt );
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        return_val := sqlerrm;
        ErrMsg :=  NOM_PKG.ErrManage(sqlstate, sqlerrm);
        return_val := ErrMsg;
        return;
      end;
end;
$function$
; DROP FUNCTION paydocument_pkg.reportregdecl(); 
CREATE OR REPLACE FUNCTION paydocument_pkg.reportregdecl(OUT return_val character varying, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
    vPDPrt varchar[];
    
    decl cursor is
      select ts.idn, ts.name, dt.doccode, td.docno,
             to_char(td.doc_date, 'dd.mm.yyyy') doc_date
      from   taxdoc td, taxsubject ts, documenttype dt
      where  td.docstatus = '10'
      and    td.taxsubject_id = ts.taxsubject_id
      and    td.documenttype_id = dt.documenttype_id
      and    nvl(td.decl14to17, 0.0) <> 1
      and    trim(dt.doccode) not in ('19', '71')
      and    td.doc_date between
             add_months(to_date('01.01.' || extract(year from current_date),
                                 'dd.mm.yyyy'), -12) and trunc(current_date)
      and    td.endtaxdate is null;
    ErrMsg varchar(100);
    i      numeric;
  begin
    i := 1;
    vPDPrt[i] := center('������� ������������ ����������', 82);
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := ' ---------------------------------------------------------------------------------'; --82 cols 
    i := i + 1;
    vPDPrt[i] := '|     ���   |               ���            |��� ����.|     ��.�      |  ��.����   |';
    i := i + 1;
    vPDPrt[i] := ' ---------------------------------------------------------------------------------';
    i := i + 1;
    for cr in decl
    loop
      vPDPrt[i] := '  ' || rpadc(nvl(cr.idn, ' '), 10) || ' ' ||
                   rpadc(cr.name, 30) || ' ' || lpadc(cr.doccode, 9) || ' ' ||
                   lpadc(cr.docno, 15) || ' ' || rpadc(cr.doc_date, 10);
      i := i + 1;
    
    end loop;
    vPDPrt[i] := ' ---------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := '';
    
    vPD_lob :=  paydocument_pkg.tblToLob(vPDPrt );
  
    --commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        --rollback;
        return_val := sqlerrm;
        ErrMsg := NOM_PKG.ErrManage(sqlstate, sqlerrm);
        return_val := ErrMsg;
        return;
      end;
end;
$function$
; DROP FUNCTION paydocument_pkg.talonservstdt(numeric, numeric); 
CREATE OR REPLACE FUNCTION paydocument_pkg.talonservstdt(OUT return_val character varying, irequest_id numeric, iuser_id numeric, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  vPDPrt varchar [ ];
  ErrMsg varchar(400);
  prop cursor (vRequest_id numeric) is
    select ('������� � ' || td.partidano) partidano,
           ('����� �� ����: ' || getaddress(tob.address_id)) addrprop
    from   Request r
    left   outer join Tvtaxdoc tvtd on r.tvtaxdoc_id = tvtd.tvtaxdoc_id
    left   outer join Taxdoc td on tvtd.taxdoc_id = td.taxdoc_id
    left   outer join Documenttype dt on td.documenttype_id = dt.documenttype_id
    left   outer join Taxobject tob on td.taxobject_id = tob.taxobject_id
    where  r.request_id = vRequest_id
    and    trim(dt.doccode) in ('14', '17', '32', '54L', '54B', '54P', '54V');
  service cursor(vRequest_id numeric) is
    select distinct ts.idn, ts.name tsname, sg.name docname, r.docno,
             to_char(r.docdate, 'dd.mm.yyyy') docdate, r.sum,
             to_char(r.workdate, 'dd.mm.yyyy') workdate,
             (select dc.value
               from   decode dc
               where  upper(dc.columnname) = 'KIND_SERV'
               and    dc.code = sr.kindserv) vidUsl, u.username, u.fullname
      from   request r
      inner join taxsubject ts on r.taxsubject_id = ts.taxsubject_id
      inner join users u on r.user_id = u.user_id
      left  outer join servicereg sr on r.servicereg_id = sr.servicereg_id
      inner join servgroup sg on sr.servgroup_id = sg.servgroup_id
      left  outer join documenttype d on d.documenttype_id = sg.documenttype_id
      where  r.request_id = irequest_id;
  servicereg cursor (vRequest_id numeric) is 
      select distinct sg.servcode, case when c.name is null then sg.name else c.name end servname, s.ispay,
             c.certreg_id
      from   servicereg s
      inner  join request r on r.servicereg_id = s.servicereg_id
      inner  join servgroup sg on s.servgroup_id = sg.servgroup_id
      left   outer join certreg c on r.certreg_id = c.certreg_id
      where  r.request_id = vrequest_id;        

    i             numeric;
    vMunicipality varchar(200);
    vProvince     varchar(100);
    vMunAddress   varchar(300);
    vRest         varchar(200);
    r             record;
    v_region varchar(10) := ', �-� ';
  begin
    if (iRequest_id > 0) then
      select coalesce(m1.fullname,m.fullname) ||
             case when m1.municipality_id is not null then v_region || m.fullname else '' end,
             getaddress(ts.present_clientaddr_id), p.name
      into   vMunicipality, vMunAddress, vProvince
      from   users u
      inner join municipality m on u.municipality_id = m.municipality_id
      left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id
      inner join config c on m.municipality_id = c.municipality_id
      inner join  taxsubject ts on to_number(c.configvalue) = ts.taxsubject_id
      left outer join province p on m.province_id = p.province_id
      where u.user_id = iUser_id
        and upper(c.name) = 'TAXSUBJECT_ID';

      
      i := 1; -- �����
      vPDPrt[i] := rpadc(' ------------------------------------------------', 60, '-');
      i := i + 1;
      vPDPrt[i] := rpadc('|       ' || '� � � � � �  ' || vProvince, 60, ' ') || '|';
      i := i + 1;
      vPDPrt[i] := rpadc('|       ' || '� � � � � �  ' || vMunicipality, 60, ' ') || '|';
      i := i + 1;
      /*vPDPrt[i] := rpadc('|       ' || '������ ������ � �����', 60, ' ') || '|';
      i := i + 1; changed on 19.07.2011*/
      vPDPrt[i] := rpadc('|       ' || vMunAddress, 60, ' ') || '|';
      i := i + 1;
      vPDPrt[i] := rpadc(' ------------------------------------------------', 60, '-');
      --    i          := i + 1;
      --    vPDPrt[i]  := rpadc('| �������� "���"',60)||'|';
      for srv in service(iRequest_id) loop
        i := i + 1;
        vPDPrt[i] := rpadc('| ���: ' || srv.idn, 60) || '|';
        r := wordwrap('| ���: ' || srv.tsname, 60, 1);
        i := i + 1;        
        vPDPrt[i] := r.return_val;
        vrest := r.strrest;        
        if (Length(vRest) > 1) then
          i := i + 1;
          vPDPrt[i] := rpadc('| ' || trim(vRest), 60, ' ') || '|';
        end if;        
        --vPDPrt[i] := rpadc('| ���: ' || srv.tsname, 60) || '|';
        i := i + 1;
        vPDPrt[i] := rpadc('| �������� ������ �� ' || srv.docname, 60) || '|';
        i := i + 1;
        for sreg in servicereg(iRequest_id) loop
          r := wordwrap(sreg.servname, 56, 1);
          vPDPrt[i] := r.return_val;
          vrest := r.strrest;
          vPDPrt[i] := rpadc('| ' || vPDPrt[i], 60) || '|';
          i := i + 1;
          if (Length(vRest) > 1) then
            vPDPrt[i] := rpadc('| ' || vRest, 60, ' ') || '|';
            i := i + 1;
          end if;
          vPDPrt[i] := rpadc('| �������� ��� �� � : ' || srv.docno || '/' || srv.docdate, 60) || '|';
          i := i + 1;
          if (sreg.certreg_id in (1, 2)) then
            for r in prop(iRequest_id) loop
              vPDPrt[i] := rpadc('| ' || r.partidano, 60, ' ') || '|';
              i := i + 1;
              r := wordwrap(r.addrprop, 56, 1);
              vPDPrt[i] := r.return_val;
              vrest := r.strrest;
              vPDPrt[i] := rpadc('| ' || vPDPrt[i], 60, ' ') || '|';
              i := i + 1;
              if (Length(vRest) > 1) then
                vPDPrt[i] := rpadc('| ' || vRest, 60, ' ') || '|';
                i := i + 1;
              end if;
            end loop;
          end if;
          vPDPrt[i] := rpadc(' ------------------------------------------------', 60, '-');
          i := i + 1;
          vPDPrt[i] := rpadc('| ��� �� �������� ' || srv.vidusl, 60) || '|';
          i := i + 1;
          vPDPrt[i] := rpadc('| ���� �� ���������� ' || srv.workdate, 60) || '|';
          i := i + 1;
          if sreg.ispay = 1 then
            vPDPrt[i] := rpadc('| ������� ���� ' ||
                               to_char(coalesce(srv.sum, 0), '99990.99') || ' ��.', 60) || '|';
            i := i + 1;
          else
            vPDPrt[i] := rpadc('| ��������� ', 60) || '|';
            i := i + 1;
          end if;
        end loop;
        vPDPrt[i] := rpadc('| ����� : '/*<' || vusername || '> '*/ || srv.fullname, 60) || '|';
        i := i + 1;
        vPDPrt[i] := rpadc(' ------------------------------------------------', 60, '-');
        i := i + 1;
        vPDPrt[i] := '';
      end loop;
    end if;

  vPD_lob := paydocument_pkg.tblToLob(vPDPrt);

  --commit;
  return_val := 'OK';
  return;
exception
  when others then
    begin
      --rollback;
      return_val := sqlerrm;
      ErrMsg     := NOM_PKG.ErrManage(sqlstate, sqlerrm);
      return_val := ErrMsg;
      return;
    
    end;
end;
$function$
; DROP FUNCTION paydocument_pkg.paydocumentpn_receipt(numeric, character varying, integer); 
CREATE OR REPLACE FUNCTION paydocument_pkg.paydocumentpn_receipt(OUT return_val character varying, vpdocument_id numeric, vpartidano character varying, visoriginal integer, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare  
  vPDPrt varchar[ ];
  ErrMsg VarChar(200);

  GetPD CURSOR (vPDocument_id paydocument.paydocument_id%Type) is
  Select tobj.kindtaxobject, pd.paydate, pd.null_date, tobj.taxobject_id,
         ('�����: '||pd.series||'  �����: '||pd.documentno||'/'||to_char(coalesce(pd.documentdate,pd.paydate),'dd.mm.yyyy')) docno,
         ('������: '||p.name) province,
         ('������: '||m.fullname) municipality,

         ('������� ������: '||ts.taxsubjectno) taxsubj,
         ('������� �����: '||tobj.taxobjno) taxobj,
         ('�������: '||coalesce(pd.partidano,'')||case when trim(coalesce(tobj.registerno,'')) = '' then '' else'  ���.� '||tobj.registerno end) partidano,

         (select d.value from decode d
             where upper(d.columnname) = 'KIND_IDN' and d.code = ts.kind_idn )||': '||ts.idn idn,
         ('��� ��: '||
            (select d.value from decode d where upper(d.columnname)='TYPE' and d.code=trreg.type)) kindpc,
         ('��� �� �����: '||
            (select d.value from decode d where upper(d.columnname)='KINDPROPERTY' and d.code=tobj.kindproperty)) kindprop,

         ('���: '||ts.name) tsname,
         ('�����: '||cm.mark_name||' �����: '||cmd.model_name) crmark,
         ('�������� �: '||tobj.kadastrno) kadastrno,

        -- ('��������: '||u.fullname) Employee,
         u.fullname, --('�������: '||u.username||' '||u.fullname) receiver,
         ('�����: '||GetAddress(ts.present_clientaddr_id) ) Address,
         ('� ��������: '||tobj.motorno ) motorno,
         ('� ����: '||tobj.ramano ) ramano,
         ('�����: '||getaddress(tobj.address_id)) propaddr, coalesce(pd.bin,'') bin,
         case when pd.reason1 is null then null else '���������: '||pd.reason1 end pdreason

    from Paydocument pd
    left outer join Taxsubject ts on pd.taxsubject_id = ts.taxsubject_id
    left outer join Taxobject tobj on pd.taxobject_id = tobj.taxobject_id
    left outer join Debtsubject ds on ts.taxsubject_id = ds.debtsubject_id
    left outer join Transpmeansreg trreg on tobj.transpmeansreg_id = trreg.transpmeansreg_id
    left outer join Paytransaction pt on pd.paytransaction_id = pt.paytransaction_id
    left outer join Carreg cr on tobj.carreg_id = cr.carreg_id
    left outer join Carmodel cmd on cr.carmodel_id = cmd.carmodel_id
    left outer join Carmark cm on cmd.carmark_id = cm.carmark_id
    left outer join Municipality m on pt.municipality_id = m.municipality_id
    left outer join Province p on m.province_id = p.province_id
    left outer join Users u on pd.user_id = u.user_id
   where pd.paydocument_id = vPDocument_id
   Order by pd.paydate;
  GetPayments CURSOR (vPDocument_id paydocument.paydocument_id%Type) is
  Select 1 ord, kdreg.code kcode,
         to_char(ds.tax_begidate,'yyyy') period, kdreg.code||kpr.parreg_code ||(di.instno*10) ordered,
         (ds.docno||case when ds.doc_date is null then '' else '/' end)||to_char(ds.doc_date,'dd.mm.yy') dekl,
         to_char(di.termpay_date,'dd.mm.yy') srok, to_char(di.instno) instno, di.debtsubject_id,
         to_char(pdt.balinstsum,'9999990.99') dyljimo, to_char(coalesce(pdt.payinstsum,0),'9999990.99') plateno,
         pdt.payinstsum paid,
         kdreg.code||kpr.parreg_code code,
         kdreg.name kdregname, di.termpay_date sr,
         t.registerno
    from Paydebt pdt
    left outer join Debtinstalment di on pdt.debtinstalment_id = di.debtinstalment_id
    inner join Debtsubject ds on di.debtsubject_id = ds.debtsubject_id
    left outer join Kindparreg kpr on pdt.kindparreg_id = kpr.kindparreg_id
    left outer join Kinddebtreg kdreg on pdt.kinddebtreg_id = kdreg.kinddebtreg_id
    left outer join Taxobject t on ds.taxobject_id = t.taxobject_id
   where pdt.paydocument_id = vPDocument_id
         and case when vPartidaNo = '0' then '0' else coalesce(ds.partidano,'0') end = vPartidaNo
     and pdt.payinstsum > 0
  union
  Select 2 ord, kdreg.code kcode,
         to_char(ds.tax_begidate,'yyyy') period, kdreg.code||kpr.parreg_code ||(di.instno*10+di.instno) ordered,
         (ds.docno||case when ds.doc_date is null then '' else '/' end)||to_char(ds.doc_date,'dd.mm.yy') dekl,
         to_char(di.termpay_date,'dd.mm.yy') srok, to_char(di.instno) instno,  di.debtsubject_id,
         to_char(pdt.balinterestsum,'9999990.99') dyljimo, to_char(coalesce(pdt.payinterestsum,0),'9999990.99') plateno,
         pdt.payinterestsum paid,
         (kdreg.code||(select kpr.parreg_code from kindparreg kpr where kpr.kindparreg_id = 1)) code,
         ('���. ')||kdreg.name kdregname, di.termpay_date sr,
         t.registerno
    from Paydebt pdt
    left outer join Debtinstalment di on pdt.debtinstalment_id = di.debtinstalment_id
    inner join Debtsubject ds on di.debtsubject_id = ds.debtsubject_id
    left outer join Kindparreg kpr on pdt.kindparreg_id = kpr.kindparreg_id
    left outer join Kinddebtreg kdreg on pdt.kinddebtreg_id = kdreg.kinddebtreg_id
    left outer join Taxobject t on ds.taxobject_id = t.taxobject_id
   where pdt.paydocument_id = vPDocument_id
     and case when vPartidaNo = '0' then '0' else coalesce(ds.partidano,'0') end = vPartidaNo
     and pdt.payinterestsum > 0
  union
  Select 3 ord, kdreg.code kcode,
         ('- 5%') period, kdreg.code||kpr.parreg_code ||(di.instno*10+di.instno) ordered,
         (ds.docno||case when ds.doc_date is null then '' else '/' end)||to_char(ds.doc_date,'dd.mm.yy') dekl,
         to_char(di.termpay_date,'dd.mm.yy') srok, ' ' instno,  di.debtsubject_id,
         to_char(pdt.paydiscsum*-1,'9999990.99') dyljimo, to_char(coalesce(pdt.payinterestsum,0),'9999990.99') plateno,
         pdt.payinterestsum paid,
         ' ' code, kdreg.name kdregname, di.termpay_date sr,
         t.registerno
    from Paydebt pdt
    left outer join Debtinstalment di on pdt.debtinstalment_id = di.debtinstalment_id
    inner join Debtsubject ds on di.debtsubject_id = ds.debtsubject_id
    left outer join Kindparreg kpr on pdt.kindparreg_id = kpr.kindparreg_id
    left outer join Kinddebtreg kdreg on pdt.kinddebtreg_id = kdreg.kinddebtreg_id
    left outer join Taxobject t on ds.taxobject_id = t.taxobject_id
   where pdt.paydocument_id = vPDocument_id
     and case when vPartidaNo = '0' then '0' else coalesce(ds.partidano,'0') end = vPartidaNo
     and pdt.paydiscsum > 0
  Order by registerno, sr, kcode, ord;
  i              Integer;
  vRest          VarChar(200);
  vRes           Varchar(200);
  vTotalInstSum  Numeric(18,2);
  r              record;
  --GetPD_rec  GetPD%ROWTYPE;
  BEGIN
    i             := 1;                -- �����
    vRest         := '';
    vRes          := '';
    FOR GetPD_rec in GetPD(vPDocument_id) LOOP
  --  Open GetPD(vPDocument_id);
  --  FETCH GetPD INTO GetPD_rec;
     vTotalInstSum := 0;
     vPDPrt[i]  := center('�������� ���������',70)||lpadc('����: '||to_char(current_date,'dd.mm.yyyy'),16);  -- �������
     i          := i + 1;
     vPDPrt[i]  := center(GetPD_rec.docno,70)||lpadc(to_char(current_date,'hh24:mi:ss'),16);  -- �������
     i          := i + 1;
     vPDPrt[i]  := '';
     i          := i + 1;
     if (vIsOriginal = 0) then
      if ((GetPD_rec.null_date is not null) and (GetPD_rec.bin = '1')) then
        vPDPrt[i]  := center('� � � � � � � �',80);
        i          := i + 1;
      elsif ((GetPD_rec.null_date is not null) and (GetPD_rec.bin = '2')) then
        vPDPrt[i]  := center('� � � � � � � � �',80);
        i          := i + 1;
      else
        vPDPrt[i]  := center('� � � � � � � �',80);
        i          := i + 1;
      end if;
     end if;
     vPDPrt[i]  := GetPD_rec.province;
     i          := i + 1;
     vPDPrt[i]  := GetPD_rec.municipality;
     i          := i + 1;
     vPDPrt[i]  := rpadc(GetPD_rec.taxsubj,42)||
                   case when (GetPD_rec.kindtaxobject = '1') and (coalesce(GetPD_rec.taxobject_id,0) > 0) then
                        '  '||rpadc(GetPD_rec.taxobj,42) 
                        else '' 
                   end;
     i          := i + 1;
     vPDPrt[i]  := rpadc(GetPD_rec.IDN,42)||
                   case when (GetPD_rec.kindtaxobject = '1') and (coalesce(GetPD_rec.taxobject_id,0) > 0) then
                        '  �������: '||rpadc(case when vpartidano = '0' then '' else vPartidaNo end,42) 
                        else '' 
                   end;
     i          := i + 1;
     if (GetPD_rec.kindtaxobject = '2') then
      vPDPrt[i]  := rpadc(GetPD_rec.tsname,80);
       i          := i + 1;
       r := WordWrap(GetPD_rec.Address,35,1);
       vPDPrt [ i ] := r.return_val;
       vRest := r.strrest;       
       i          := i + 1;
       if length(vRest) > 0 then
        vPDPrt[i]  := rpadc(coalesce(ltrim(vRest),' '),79); 
        i          := i + 1;
       end if;
     elsif (GetPD_rec.kindtaxobject = '1') and (coalesce(GetPD_rec.taxobject_id,0) > 0) then
       vPDPrt[i]  := rpadc(GetPD_rec.tsname,42)||'  '||rpadc(GetPD_rec.kindprop,42);
       i          := i + 1;
       r := WordWrap(GetPD_rec.Address,42,1);
       vPDPrt [ i ] := r.return_val;
       vRest := r.strrest;       
       r := WordWrap(GetPD_rec.propaddr,42,1);
       vPDPrt [ i + 1 ] := r.return_val;
       vRes := r.strrest;       
       vPDPrt[i]  := rpadc(vPDPrt[i], 42)||'  '||rpadc(vPDPrt[ i+1 ], 42);
       i          := i + 1;
       if (length(vRest) > 0) or (length(vres) > 0) then
        vPDPrt[i]  := rpadc(ltrim(vRest),42)||'  '||rpadc(ltrim(vRes),42);
        i          := i + 1;
       end if;
      elsif (coalesce(GetPD_rec.taxobject_id,0) > 0) then 
       vPDPrt[i]  := rpadc(GetPD_rec.tsname,40);
       i          := i + 1;
       r := WordWrap(GetPD_rec.Address,79,1);
       vPDPrt [ i ] := r.return_val;
       vRest := r.strrest;       
       i          := i + 1;
       if Length(vRest) > 0 then
        vPDPrt[i]  := rpadc(vRest,80);
        i          := i + 1;
       end if;
     else
       vPDPrt[i]  := rpadc(GetPD_rec.tsname,80);
       i          := i + 1;
     end if;
     vPDPrt[i]  := '------------------------------------------------------------------------------------';--84
     i          := i + 1;
     vPDPrt[i]  := '|��� ������. |���.|���.�     |���� ��.|�����/���� ����.    |��.|  ������� |  ������� |';
     i          := i + 1;
     vPDPrt[i]  := '------------------------------------------------------------------------------------';
     i          := i + 1;
     for GetPayments_rec in GetPayments(vPDocument_id) loop
       vPDPrt[i]  := ' '||
                     /*lpadc(GetPayments_rec.Code,7,' ')||' '||*/
                     rpadc(GetPayments_rec.Kdregname,12,' ')||' '||
                     lpadc(GetPayments_rec.Period,4,' ')||' '||
                     rpadc(GetPayments_rec.registerno,10,' ')||' '||
                     lpadc(GetPayments_rec.Srok,8,' ')||' '||
                     rpadc(coalesce(GetPayments_rec.Dekl,' '),20,' ')||' '||
                     lpadc(coalesce(GetPayments_rec.Instno,' '),3,' ')||' '||
                     lpadc(GetPayments_rec.Dyljimo,10,' ')||' '||
                     lpadc(GetPayments_rec.Plateno,10,' ');
       vTotalInstSum := vTotalInstSum + GetPayments_rec.plateno::numeric;
       i          := i + 1;
     end loop;
     vPDPrt[i]  := '-------------------------------------------------------------------------------------';
     i          := i + 1;
     vPDPrt[i]  := rpadc(' ���� �������:',66,' ')||lpadc(to_char(vTotalInstSum,'999999990.99'),19,' ');
     i          := i + 1;
     vPDPrt[i]  := ' ������: '||rpadc(advance_pkg.Slovom(trim(to_char(vTotalInstSum,'999999990.99'))),90,' ');
     i          := i + 1;
     vPDPrt[i]  := '';
     if (GetPD_rec.pdreason is not null) then
       i          := i + 1;
       r := WordWrap(' '||GetPD_rec.pdreason,78,1);
       vPDPrt [ i ] := r.return_val;
       vRes := r.strrest;       
       if (Length(vRest) > 1) then
         i          := i + 1;
         vPDPrt[i]  := rpadc(vRest,80);
       end if;
     end if;
     i          := i + 1;
     vPDPrt[i]  := '';
     i          := i + 1;
     vPDPrt[i]  := ' ��������: .......................          '||'������:........................';
     i          := i + 1;
     vPDPrt[i]  := lpadc(' ',10)||center(GetPD_rec.fullname,30);
     i          := i + 1;
     vPDPrt[i]  := '';
     i          := i + 1;
     vPDPrt[i]  := ' - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -';
     i          := i + 1;
  --  Close GetPD;
   END LOOP;

    vPD_lob :=  paydocument_pkg.tblToLob(vPDPrt);

    --COMMIT;
    return_val := 'OK';
    return;
    
     EXCEPTION
     WHEN OTHERS THEN BEGIN
       perform NOM_PKG.ErrManage(ErrMsg, SqlErrM);
       return_val := ErrMsg;
       RETURN;
     END;
end;
$function$
;
