DROP FUNCTION xmlstructure.addrstr(character varying); 
CREATE OR REPLACE FUNCTION xmlstructure.addrstr(text character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
 res varchar(300);
 a varchar(100);
begin
 select min(c.name) into a
 from country c where c.country_id = to_number(substr(text,1,instr(text,';',1,1)-1));
 res := trim(nvl(a,' '));
 select min(p.name) into a
 from province p where p.province_id = to_number(substr(text,instr(text,';',1,1)+1,(instr(text,';',1,2) - instr(text,';',1,1) -1)))
 ;  
 res := trim(nvl(res,' ') || ' ' || nvl(a,' '));
 select min(m.name) into a 
 from municipality m where m.municipality_id = to_number(substr(text,instr(text,';',1,2)+1,(instr(text,';',1,3) - instr(text,';',1,2) -1)))
 ;
 res := trim(nvl(res,' ') || ' ' || nvl(a,' '));
 select min(d.value) || ' ' || min(c.name) into a
  from city c , decode d
  where c.city_id = to_number(substr(text,instr(text,';',1,3)+1,(instr(text,';',1,4) - instr(text,';',1,3) -1)))
  and d.columnname = 'Kind_City'
  and d.code = c.kind_city
  ;
 res := trim(nvl(res,' ') || ' ' || nvl(a,' '));
 select min(r.name) into a
  from admregion r
  where r.admregion_id = to_number(substr(text,instr(text,';',1,4)+1,(instr(text,';',1,5) - instr(text,';',1,4) -1)))
  ;
 res := trim(nvl(res,' ') || ' ' || nvl(a,' '));
 select min(d.value) || ' ' || min(s.name) into a
  from street s, decode d
  where s.street_id = to_number(substr(text,instr(text,';',1,5)+1,(instr(text,';',1,6) - instr(text,';',1,5) -1)))
  and d.columnname = 'Kind_Street'
  and d.code = s.kind_street
  ;
 res := trim(nvl(res,' ') || ' ' || nvl(a,' '));
 res := trim(nvl(res,' ') || ' ' || nvl(substr(text,instr(text,';',1,6)+1,100),' '));
 return(res);
end;

$function$
; DROP FUNCTION xmlstructure.addrstr2(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.addrstr2(ipadress_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$ 
  declare
  vCountry       varchar(128);
  vShortName      varchar(128);
  vCityName       varchar(128);
  vStreetName     varchar(128);
  vAddrNo         varchar(128);
  vAddrBlock      varchar(128);
  vAddrEntry      varchar(128);
  vAddrFloor      varchar(128);
  vAddrApartment  varchar(128);
BEGIN
    SELECT c.Name, c.shortname, 
    ( nvl(case when St.Kind_street = '0' then ' '
		when St.Kind_street = '1' then '��.'
		when St.Kind_street = '2' then '���.'
		when St.Kind_street = '3' then '��.'
		when St.Kind_street = '4' then '�.�.'
		when St.Kind_street = '5' then '�.�.'
		when St.Kind_street = '6' then '�.��.'		
		else '---' end || st.name, a.street_name::text )) X1,
              a.nom, a.Block, a.Entry, a.Floor, a.Apartment,
      case when Ci.Kind_city = '0' then ' '
	   when Ci.Kind_city = '1' then '��.'
	   when Ci.Kind_city = '2' then '�.'
	   when Ci.Kind_city = '3' then '�.'
	   when Ci.Kind_city = '4' then '��.'
	   else '---' end || ci.Name X2
     INTO   vCountry,vShortName, vStreetName, vAddrNo, vAddrBlock, vAddrEntry, vAddrFloor, vAddrApartment, vCityName
       FROM  address  a
       left outer join Street St
            on a.Street_Id   = st.Street_Id
       left outer join City Ci
            on a.City_Id        = ci.City_Id
       left outer join Country c
            on a.Country_Id = c.Country_Id       
      WHERE  a.Address_id = ipAdress_id ;
     IF vAddrNo  Is Not NULL  THEN
        vStreetName := vStreetName || ' N: ' || vAddrNo;
     END IF;
     IF vAddrBlock  Is Not NULL  THEN
        vStreetName := vStreetName || ' ��.' || vAddrBlock;
     END IF;
     IF vAddrEntry Is Not NULL    THEN
        vStreetName := vStreetName || ' ��.' || vAddrEntry;
     END IF;
     IF vAddrApartment Is Not NULL   THEN
        vStreetName := vStreetName || ' ��.' || vAddrApartment;
     END IF;
     IF vAddrFloor Is Not NULL  THEN
        vStreetName := vStreetName || ' ��.' || vAddrFloor;
     END IF;
     vCityName := vCityName || ' ' || vStreetName;
     If vShortname <> 'BG' then vCityName := vCountry || ' ' || vCityName; end if;
 
  RETURN (vCityName);
	EXCEPTION
             WHEN OTHERS THEN BEGIN
                  RETURN(''||sqlerrm);
             END;
 
end;

$function$
; DROP FUNCTION xmlstructure.addrstr4(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.addrstr4(ipadress_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
  declare
  vCountry varchar(128);
  vShortName varchar(128);
  vCityName varchar(128);
  vStreetName varchar(128);
  vAddrNo varchar(128);
  vAddrBlock varchar(128);
  vAddrEntry varchar(128);
  vAddrFloor varchar(128);
  vAddrApartment varchar(128); BEGIN
    SELECT c.Name, c.shortname,
    ( nvl(case when St.Kind_street = '0' then ' '
		when St.Kind_street = '1' then '��.'
		when St.Kind_street = '2' then '���.'
		when St.Kind_street = '3' then '��.'
		when St.Kind_street = '4' then '�.�.'
		when St.Kind_street = '5' then '�.�.'
		when St.Kind_street = '6' then '�.��.'
		else '---' end || st.name, a.street_name::text )) X1,
              a.nom, a.Block, a.Entry, a.Floor, a.Apartment,
      case when Ci.Kind_city = '0' then ' '
	   when Ci.Kind_city = '1' then '��.'
	   when Ci.Kind_city = '2' then '�.'
	   when Ci.Kind_city = '3' then '�.'
	   when Ci.Kind_city = '4' then '��.'
	   else '---' end || ci.Name X2
     INTO vCountry,vShortName, vStreetName, vAddrNo, vAddrBlock, 
vAddrEntry, vAddrFloor, vAddrApartment, vCityName
       FROM address a
       left outer join Street St
            on a.Street_Id = st.Street_Id
       left outer join City Ci
            on a.City_Id = ci.City_Id
       left outer join Country c
            on a.Country_Id = c.Country_Id
      WHERE a.Address_id = ipAdress_id ;
     IF vAddrNo Is Not NULL THEN
        vStreetName := vStreetName || ' N: ' || vAddrNo;
     END IF;
     IF vAddrBlock Is Not NULL THEN
        vStreetName := vStreetName || ' ��.' || vAddrBlock;
     END IF;
     IF vAddrEntry Is Not NULL THEN
        vStreetName := vStreetName || ' ��.' || vAddrEntry;
     END IF;
     IF vAddrApartment Is Not NULL THEN
        vStreetName := vStreetName || ' ��.' || vAddrApartment;
     END IF;
     IF vAddrFloor Is Not NULL THEN
        vStreetName := vStreetName || ' ��.' || vAddrFloor;
     END IF;
     vCityName := vCityName || ' ' || vStreetName;
     If vShortname <> 'BG' then vCityName := vCountry || ' ' || 
vCityName; end if;
 
  RETURN (vCityName);
	EXCEPTION
             WHEN OTHERS THEN BEGIN
                  RETURN(''||sqlerrm);
             END;
 
end;
$function$
; DROP FUNCTION xmlstructure.xmladdress(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmladdress(ipaddress_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  addr xml;
begin
  select xmlforest(c.name as "COUNTRY", m.name as "MUNICIPALITY", 
  -- decode(ci.kind_city,to_char(0),' ', to_char(1),'��.', to_char(2),'�.', to_char(3),'�.', to_char(4),'��.', '---' ) || ci.name as "CITY",
  (case 
  		when ci.kind_city='0' then ' '
        when ci.kind_city='1' then '��.'
        when ci.kind_city='2' then '�.'
        when ci.kind_city='3' then '�.'
        when ci.kind_city='4' then '��.'
        else '---'
    end) || ci.name as "CITY",  
    -------------------------------------------
  -- nvl(decode(s.kind_street, to_char(0), ' ',   to_char(1), '��.',   to_char(2), '���.',   to_char(3), '��.',   to_char(4),'�.�.',   to_char(5), '�.�.',  to_char(6),'�.��.',  to_char(7),'��.','---') || s.name , a.street_name) as "STREET",    
  (case 
  		when s.kind_street='0' then ' '
        when s.kind_street='1' then '��.'
        when s.kind_street='2' then '���.'
        when s.kind_street='3' then '��.'
        when s.kind_street='4' then '�.�.'
        when s.kind_street='5' then '�.�.'
        when s.kind_street='6' then '�.��.'
        when s.kind_street='7' then '��.'                        
        else '---'
    end) || s.name  as "STREET", 
    --COMMENT nvl  decode - nikoga njama da se izpylni
    -------------------------------------------   
  a.nom as "NOM", a.block as "BLOCK", a.entry as "ENTRY", 
  a.floor as "FLOOR", a.apartment as "APARTMENT",a.postcode as "POSTCODE", 
  a.mailbox as "MAILBOX", a.note as "ADDRNOTE") into addr
   from address a
   inner join city ci
         on a.city_id = ci.city_id
   left outer join municipality m
         on a.municipality_id = m.municipality_id
   left outer join country c
         on a.country_id = c.country_id
   left outer join street s
         on a.street_id = s.street_id
   where a.address_id = ipaddress_id
  ; 
  return(addr);
end;
$function$
; DROP FUNCTION xmlstructure.xmladdrnew(character varying); 
CREATE OR REPLACE FUNCTION xmlstructure.xmladdrnew(iptext character varying)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  addr xml;
  a varchar;
  b integer;
begin
   -- COMMENT  v Oracle ne e neobhodimo
   if nvl(iptext,'') = '' then
   		iptext := '0;0;0;0;;;;;;;;;';
   end if;
   if length(iptext)<12 then
   		iptext := '0;0;0;0;;;;;;;;;';
   end if;
  select xmlforest(
  (select min(c.name) from country c  where c.country_id = to_number('0' || substr(iptext,1,instr(ipText,';',1,1)-1))) as "COUNTRY",
  (select min(p.name) from province p  where p.province_id = to_number('0' || substr(ipText,instr(ipText,';',1,1)+1,(instr(ipText,';',1,2) - instr(ipText,';',1,1) -1)))) as "PROVINCE",
  (select min(m.name) from municipality m where m.municipality_id = to_number(substr(ipText,instr(iptext,';',1,2)+1,(instr(iptext,';',1,3) - instr(iptext,';',1,2) -1))) ) as "MUNICIPALITY",
  (select  min(c.postcode) from city c  where c.city_id = to_number('0' || substr(iptext,instr(iptext,';',1,3)+1,(instr(iptext,';',1,4) - instr(iptext,';',1,3) -1)))   )  as "POSTCODE",
  (select min(d.value) || ' ' || min(c.name)   from city c , decode d  where c.city_id = to_number('0' || substr(iptext,instr(iptext,';',1,3)+1,(instr(iptext,';',1,4) - instr(iptext,';',1,3) -1)))  and d.columnname = 'Kind_City'  and d.code = c.kind_city)  as "CITY",
  (select min(d.value) || ' ' || min(s.name)   from street s, decode d     where s.street_id = to_number('0' || substr(iptext,instr(iptext,';',1,5)+1,(instr(iptext,';',1,6) - instr(iptext,';',1,5) -1)))  and d.columnname = 'Kind_Street'  and d.code = s.kind_street) as "STREET",
  (substr(iptext,instr(iptext,';',1,6)+1,(instr(iptext,';',1,7) - instr(iptext,';',1,6) - 1))) as "NOMER",
  (substr(iptext,instr(iptext,';',1,7)+1,(instr(iptext,';',1,8) - instr(iptext,';',1,7) - 1))) as "BLOK",
  (substr(iptext,instr(iptext,';',1,8)+1,(instr(iptext,';',1,9) - instr(iptext,';',1,8) - 1))) as "VXOD",
  (substr(iptext,instr(iptext,';',1,9)+1,(instr(iptext,';',1,10) - instr(iptext,';',1,9) - 1))) as "ETAJ",
  (substr(iptext,instr(iptext,';',1,10)+1,(instr(iptext,';',1,11) - instr(iptext,';',1,10) - 1))) as "APRT"
  
  )
   into addr; 
  return(addr);
end;
$function$
; DROP FUNCTION xmlstructure.xmlbuilding(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlbuilding(ipproperty_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
   cr cursor is
  select xmlelement(name "BUILDING" , xmlattributes(b.seqnobuilding::integer as "BUN"),xmlforest(
  seqnobuilding::integer as "SEQNOBUILDING", buildingno as "BUILDINGNO", 
  (select d.value from decode d where d.columnname = 'KindFunction' and d.code = kindfunction) as "KINDFUNCTION", floornumber::integer as "FLOORNUMBER", 
  floornumover::integer as "FLOORNUMOVER",
  DECODE(elevator,1.0,'��','��') as "ELEVATOR", 
  DECODE(monument,1.0,'��','��') as "MONUMENT", monumentdoc as "MONUMENTDOC", 
  monumentdate as "MONUMENTDATE", publictransport::integer as "PUBLICTRANSPORT", 
  DECODE(farm,1.0,'��','��') as "FARM", DECODE(damage,1.0,'��','��') as "DAMAGE", 
  damagedoc as "DAMAGEDOC", damagedocdate as "DAMAGEDOCDATE", 
  damagedocpubl as "DAMAGEDOCPUBL", errordata::integer as "ERRORDATA", 
  --user_id, userdate, 
  decode(istemporary,1.0,'��','��') as "ISTEMPORARY", buildyear as "BUILDYEAR", 
  decode(zeesertificat,'1','��','��') as "ZEESERTIFICAT",
  zeecategory as "ZEECATEGORY", 
  zeesertno as "ZEESERTNO", to_char(zeesertdate,'dd.mm.yyyy') as "ZEESERTDATE", 
  zeesertpubl as "ZEESERTPUBL",
  DECODE(bck,1.0,'��','��') as "BCK", 
  DECODE(zeeactivity,1.0,'��','��') as "ZEEACTIVITY",
  DECODE(outland,1.0,'��','��') as "OUTLAND", 
  DECODE(dutyfree,1.0,'��','��') as "DUTYFREE", dutyfreeorder as "DUTYFREEORDER", 
  note as "NOTE",
  DECODE(restorebuild,1.0,'��','��') as "RESTOREBUILD", 
  to_char(restorebuild_date,'dd.mm.yyyy') as "RESTOREBUILD_DATE", 
  restorebuilddoc as "RESTOREBUILDDOC", 
  restoredocissue as "RESTOREDOCISSUE", restoreyear as "RESTOREYEAR", 
  used_from as "USED_FROM",
  xmlstructure.xmlhomeobj(b.building_id) as "HOMES"
  ))
  from building b
  where b.property_id = ipproperty_id
  order by b.seqnobuilding
  ;
building xml;
edifice xml;
begin
edifice := null;
open cr;
loop
fetch cr into building;
exit when not FOUND;

select  XMLConcat(edifice ,building) into edifice  from dual;

end loop;
close cr;
-- select xmlelement(edifice, edifice) into edifice from dual;
return(edifice);
end;
$function$
; DROP FUNCTION xmlstructure.xmlcarreg(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlcarreg(ipcarreg_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  
carregs xml;

begin
select xmlforest(
----  19.03.2009
cm.mark_code as "MARK_CODE", cm.mark_name as "MARK_NAME", 
md.model_code as "MODEL_CODE", md.model_name as "MODEL_NAME", 
cr.seat_number as "SEAT_NUMBER", (cr.weigth_total) as "WEIGTH_TOTAL", 
(cr.weigth_own) as "WEIGTH_OWN", (cr.motor_capacity) as "MOTOR_CAPACITY", 
(cr.horsepower) as "HORSEPOWER", (cr.door_number) as "DOOR_NUMBER", 
cr.carosserie as "CAROSSERIE", (cr.tug_code) as "TUG_CODE", 
cr.kind_kat as "KIND_KAT", cr.kind as "KIND", (cr.isactive) as "ISACTIVE"
)
into carregs
from carreg cr
left outer join carmodel md
     on cr.carmodel_id = md.carmodel_id
left outer join carmark cm
     on md.carmark_id = cm.carmark_id
where cr.carreg_id = ipcarreg_id
;
return(carregs);
end;
$function$
; DROP FUNCTION xmlstructure.xmlfirm14ho(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlfirm14ho(iphomeobject_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$    declare homes xml;
  begin
    select xmlforest(
           o.kindobj as kindobj,
           o.seqnoobject as seqnoobject,
           o.typeprop as typeprop,
           (select d.value
            from decode d
            where d.columnname = 'KindOwner'
            and d.code = o.kindowner) as kindowner,
           o.function as function,
           freereason(o.taxfreereason) as taxfreereason,
           o.accvalue as accvalue
                    )
     into homes
      from firmobj14 o
     where o.homeobj_id = iphomeobject_id;
    return(homes);
  end;$function$
; DROP FUNCTION xmlstructure.xmlfirm14land(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlfirm14land(ipland_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$

declare lands xml;
begin
select xmlforest(
           o.kindobj as kindobj,
           o.seqnoobject as seqnoobject,
           o.typeprop as typeprop,
           (select d.value
            from decode d
            where d.columnname = 'KindOwner'
            and d.code::integer = o.kindowner::integer) as kindowner,
           o.function as function,
           freereason(o.taxfreereason) as taxfreereason,
           o.accvalue as accvalue
                    )
      into lands
      from firmobj14 o
     where o.land_id = ipland_id;
    return(lands);
    end;$function$
; DROP FUNCTION xmlstructure.xmlfirmobj(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlfirmobj(ipfirmproperty_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
 cr cursor  is
select xmlelement(name "FIRMOBJ",xmlattributes(fo.seqno as "FON"),xmlforest(
 seqno as "SEQNO",
  builddate as "BUILDDATE", -- varchar(8)
 typeprop as "TYPEPROP", 
 (select d.value from decode d where d.columnname = 'KindOwner' and d.code::integer = kindowner::integer) as "KINDOWNER", 
 to_char(earn_date,'dd.mm.yyyy') as "EARN_DATE", 
 to_char(circumchange_date,'dd.mm.yyyy') as "CIRCUMCHANGE_DATE", 
 -- ?? smjana na ime na pole
 function as "FUNCTION", 
 freereason(taxfreereason) as "TAXFREEREASON", 
 ---taxfreereason as "TAXFREEREASON",
 DECODE(isbusiness,to_number('1'),'��','��') as "ISBUSINESS", 
  to_char(accvalue,'9999999999.99') as "ACCVALUE", 
 numbertrim(earntaxvalue_decl) as "EARNTAXVALUE_DECL", 
 numbertrim(earntaxvalue_calc) as "EARNTAXVALUE_CALC", 
 isfalse_earntaxvalue::integer as "ISFALSE_EARNTAXVALUE", 
 numbertrim(taxvalue_decl) as "TAXVALUE_DECL",  numbertrim(taxvalue_calc) as "TAXVALUE_CALC", 
 isfalse_taxvalue::integer as "ISFALSE_TAXVALUE", 
 ispublic::integer as "ISPUBLIC",  ismunicip::integer as "ISMUNICIP", 
 istaxfree::integer as "ISTAXFREE",  kindtbo::integer as "KINDTBO", 
 to_char(damagedocdate,'dd.mm.yyyy') as "DAMAGEDOCDATE", 
 monumentdoc as "MONUMENTDOC", 
 to_char(monumentdate,'dd.mm.yyyy') as "MONUMENTDATE", 
 iszee::integer as "ISZEE",  zeecategory as "ZEECATEGORY", 
 zeesertno as "ZEESERTNO",  to_char(zeesertdate,'dd.mm.yyyy') as "ZEESERTDATE", 
 zeesertpubl as "ZEESERTPUBL",  zeesrcenergy as "ZEESRCENERGY", 
 to_char(taxbegindate,'dd.mm.yyyy') as "TAXBEGINDATE", 
 to_char(taxenddate,'dd.mm.yyyy')   as "TAXENDDATE", 
 isactiv::integer as "ISACTIV"
 )) 
 from firmpropobj fo
 where fo.firmproperty_id = ipfirmproperty_id
 ;
  firmobj xml;
  obj xml;
begin 
obj := null;
open cr;
loop
fetch cr into firmobj;
exit when not FOUND;
select  XMLConcat(obj ,firmobj ) into obj  from dual;
end loop;
close cr;
return(obj);

end;
$function$
; DROP FUNCTION xmlstructure.xmlfirmproperty(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlfirmproperty(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  
properties xml; 
begin
select  xmlforest(
firmpropno as "FIRMPROPNO", 
(select d.value from decode d where d.columnname = 'KindProperty' and d.code::integer=p.kindproperty::integer) as "KINDPROPERTY", 
locationproperty as "LOCATIONPROPERTY", 
(select m.name from municipality m where m.municipality_id = location_municipality_id) as "LOCATION_MUNICIPALITY", 
xmlstructure.xmladdress(property_address_id) as "PROPERTY_ADDRESS", 
earnway as "EARNWAY", 
propertydoc as "PROPERTYDOC", propertydocno as "PROPERTYDOCNO", 
to_char(propertydoc_date,'dd.mm.yyyy') as "PROPERTYDOC_DATE", 
-- old_taxsubject_id as , 
oldpropertynote as "OLDPROPERTYNOTE", 
kadastrno as "KADASTRNO", kadastr_year as "KADASTR_YEAR", 
zrpno_district as "ZRPNO_DISTRICT", zrpno_parcel as "ZRPNO_PARCEL", 
to_char(zrp_date,'yyyy') as "ZRP_DATE", note as "NOTE",
--- status as "STATUS", 
(select d.value from decode d where UPPER(d.columnname) = 'STATUS' and d.code = to_char(status::integer)) as "STATUS", 
repl_user_name as "REPL_USER_NAME", 
errordata as "ERRORDATA", partidano as "PARTIDANO", 
taxproperty as "TAXPROPERTY", isfalse_taxproperty::integer as "ISFALSE_TAXPROPERTY", 
numbertrim(taxprop_decl) as "TAXPROP_DECL", numbertrim(taxprop_calc) as "TAXPROP_CALC", 
isfalse_taxprop::integer as "ISFALSE_TAXPROP", numbertrim(taxgarb_decl) as "TAXGARB_DECL", 
numbertrim(taxgarb_calc) as "TAXGARB_CALC", isfalse_taxgarb::integer as "ISFALSE_TAXGARB", 
taxdate_oldprop as "TAXDATE_OLDPROP", -- varchar(6)
(select d.value from decode d where UPPER(d.columnname) = 'CODETBO' and d.code = to_char(codetbo::integer))  as "CODETBO",
	promilly as "PROMILLY", 
user_id as "USER_ID", to_char(user_date,'dd.mm.yyyy') as "USER_DATE", 
ishome::integer as "ISHOME", 
--property_id as , 
xmlstructure.xmlobject14(taxobject_id) as "TAXOBJECT", 
xmlstructure.xmlsubject(owner_taxsubject_id) as "OWNER_TAXSUBJECT",
xmlstructure.xmlfirmobj(p.firmprop_id) as "FIRMOBJNODE" 
)
into properties
from firmproperty p
where p.taxdoc_id = iptaxdoc_id
;
return(properties);
 
end;
$function$
; DROP FUNCTION xmlstructure.xmlgarbtax(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlgarbtax(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor  is
select  xmlelement(name "GARBTAXROWS",xmlattributes(garbtax_id as "PPN"), xmlforest(

-- (select ts.idn from taxsubject ts where ts.taxsubject_id = pp.taxsubject_id) as "IDN",
g.container_number::integer as "CONTAINER_NUMBER",
(select c.name from  container c 
  ----
  where c.container_id = cn.container_id
  and cn.containernorm_id = g.containernorm_id) as "TYPECONTAINER",
  
  
  
  -----
--  where c.code = g.containernorm_id) as "TYPECONTAINER",
numbertrim(g.frequency) as "FREQUENCY"

))
from garbtax g, containernorm cn
where g.taxdoc_id = iptaxdoc_id
and g.containernorm_id = cn.containernorm_id
;
partproperties xml;
garbtaxrows  xml;
begin
open cr;
loop
fetch cr into partproperties;
exit when not FOUND;
select  XMLConcat(garbtaxrows ,partproperties) into garbtaxrows  from dual;
end loop;
close cr;
return(garbtaxrows);
end;
$function$
; DROP FUNCTION xmlstructure.xmlhomeobj(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlhomeobj(ipbuilding_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
 crho cursor  is
select xmlelement(name "HOMEOBJ",xmlattributes(seqnoobj::integer as "HON"),xmlforest(
seqnoobj::integer as "SEQNOOBJ", homeobjno as "HOMEOBJNO", 
function as "FUNCTIONHO", objectarea::integer as "OBJECTAREA", 
(select kr.fullname from kindhomeobjreg kr where kr.kindhomeobjreg_id = h.kindhomeobjreg_id) as "KINDHOMEOBJ", 
cellerarea::integer as "CELLERAREA", atticarea::integer as "ATTICAREA", 
to_char(earn_date,'dd.mm.yyyy') as "EARN_DATE", 
to_char(change_date,'dd.mm.yyyy') as "CHANGE_DATE",  
totalarea::integer as "TOTALAREA", height::integer as "HEIGHT", 
builddate  as "BUILDDATE", -- godina
floor as "FLOOR", 
(select d.value from decode d where d.columnname = 'KindConstruction' and d.code = kindconstruction) as "KINDCONSTRUCTION", 
DECODE(iselectro,1.0,'��','��') as "ISELECTRO",
DECODE(iswater,1.0,'��','��')  as "ISWATER",
DECODE(issewer,1.0,'��','��') as "ISSEWER", 
DECODE(istec,1.0,'��','��')     as "ISTEC",
DECODE(istelefon,1.0,'��','��') as "ISTELEFON", 
DECODE(isbusiness,1.0,'��','��') as "ISBUSINESS", 
repairdate as "REPAIRDATE", -- varchar(8)
DECODE(isheating,1.0,'��','��') as "ISHEATING", 
DECODE(isaircondition,1.0,'��','��') as "ISAIRCONDITION",
DECODE(luxwindow,1.0,'��','��') as "LUXWINDOW", 
DECODE(soundinsulation,1.0,'��','��') as "SOUNDINSULATION", 
DECODE(specialroof,1.0,'��','��') as "SPECIALROOF", 
DECODE(luxdecorate,1.0,'��','��') as "LUXDECORATE",
 errordata::integer as "ERRORDATA", nousedoc as "NOUSEDOC", 
nousedate as "NOUSEDATE", restoreobj as "RESTOREOBJ", restoreobjdate as "RESTOREOBJDATE", 
restoreobjdoc as "RESTOREOBJDOC",
decode(zeesertificat,'1','��','��') as "ZEESERTIFICAT" --, 
--user_id, user_date, 
,to_char(taxbegindate,'dd.mm.yyyy') as "TAXBEGINDATE", 
to_char(taxenddate,'dd.mm.yyyy')   as "TAXENDDATE",
xmlstructure.xmlhomepart(h.homeobj_id) as "HPARTS",
 xmlstructure.xmlfirm14ho(h.homeobj_id) as "HFIRM"
))
from homeobj h
where h.building_id = ipbuilding_id
;  
  homeobj xml;
  homes xml;
begin 
homes := null;
open crho;
loop
fetch crho into homeobj;
exit when not FOUND;
--select xmlelement(homes,homes ,homeobj)into homes  from dual;
select  XMLConcat(homes ,homeobj ) into homes  from dual;
end loop;
close crho;
-- select xmlelement(homes, homes) into homes from dual;
return(homes);
end;
$function$
; DROP FUNCTION xmlstructure.xmlhomepart(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlhomepart(iphomeobj_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
crhp cursor is
select xmlelement(name "HOMEPART",xmlattributes(seqnots as "PHN"),xmlforest(
ob.seqnots as "SEQNOTS",
xmlstructure.xmlsubject(ob.taxsubject_id::integer) as "TAXSUBJECT",
(select d.value from decode d where d.columnname = 'TypeDeclar' and d.code = typedeclar) as "TYPEDECLAR",
ob.divident::integer as "DIVIDENT",
ob.divisor::integer  as "DIVISOR",
ob.area::integer     as "AREA",
ob.part::integer     as "PART",
decode(ob.isbasehome,1.0,'��','��') as "ISBASEHOME"
--decode(ob.part,1,'��','��')    as "PART"
))
from parthomeobj ob
where ob.homeobj_id = iphomeobj_id
order by ob.typedeclar 
;
homeparts xml;
hparts xml; 
begin
open crhp;
loop
fetch crhp into homeparts;
exit when not FOUND;
select  XMLConcat(hparts ,homeparts) into hparts  from dual;
end loop;
close crhp;
return(hparts);
end;
$function$
; DROP FUNCTION xmlstructure.xmlinheritance(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlinheritance(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  
pat xml;

begin
select xmlforest(
(select to_char(p.dead_date,'dd.mm.yyyy')from person p, taxdoc x where p.taxsubject_id = x.taxsubject_id and x.taxdoc_id = iptaxdoc_id) as "DEAD_DATE",
(select c.name from person p, city c, taxdoc x where p.taxsubject_id = x.taxsubject_id and x.taxdoc_id = iptaxdoc_id and p.dead_city_id = c.city_id) as "DEAD_CITY",
(select p.dead_actno  from person p, taxdoc x where p.taxsubject_id = x.taxsubject_id and x.taxdoc_id = iptaxdoc_id) as "DEAD_ACTNO",
(select h.inheritcertifno  from inheritance h where h.taxdoc_id = iptaxdoc_id) as "INHERIT_CERTIFNO",
(select to_char(h.inheritcertif_date,'dd.mm.yyyy')  from inheritance h where h.taxdoc_id = iptaxdoc_id) as "INHERITCERTIFDATE",
(select m.fullname  from inheritance h, municipality m  where h.taxdoc_id = iptaxdoc_id and h.inheritcertif_municipality_id = m.municipality_id) as "INHERITCERTIF_MUNICIPALTY",
-----  naslednici
xmlstructure.xmlpartinheritance1(taxdoc_id) as "PARTINHERITANCE1",
---   zavetnici
xmlstructure.xmlpartinheritance2(taxdoc_id) as "PARTINHERITANCE2",
---    tablici
xmlstructure.xmltabinheritance1(p.inheritance_id) as "TABINHERITANCE1",
xmlstructure.xmltabinheritance2(p.inheritance_id) as "TABINHERITANCE2",
xmlstructure.xmltabinheritance3(p.inheritance_id) as "TABINHERITANCE3",
xmlstructure.xmltabinheritance4(p.inheritance_id) as "TABINHERITANCE4",
xmlstructure.xmltabinheritance5(p.inheritance_id) as "TABINHERITANCE5",
xmlstructure.xmltabinheritance6(p.inheritance_id) as "TABINHERITANCE6",
xmlstructure.xmltabinheritance7(p.inheritance_id) as "TABINHERITANCE7",
xmlstructure.xmltabinheritance8(p.inheritance_id) as "TABINHERITANCE8",
xmlstructure.xmltabinheritance9(p.inheritance_id) as "TABINHERITANCE9",

----  REASON FREE !!!
decode(p.reasonfreesubj,'1','��','��') as "REASONFREESUBJ",
(
select (( select 'T.' || ti.rowno from  tabinheritance ti, tabinhreg reg
where ti.inheritance_id = p.inheritance_id
and ti.tabinhreg_id = reg.tabinhreg_id and reg.tableno = '8'
and ti.reasonfree = 1
and ti.rowno = '1') ||
 (
select ', T.' || ti.rowno from  tabinheritance ti, tabinhreg reg
where ti.inheritance_id = p.inheritance_id
and ti.tabinhreg_id = reg.tabinhreg_id and reg.tableno = '8'
and ti.reasonfree = 1
and ti.rowno = '2'
) ||
( select  ', T.' ||  ti.rowno from tabinheritance ti, tabinhreg reg
where ti.inheritance_id = p.inheritance_id
and ti.tabinhreg_id = reg.tabinhreg_id and reg.tableno = '8'
and ti.reasonfree = 1
and ti.rowno = '3'
) ||
( select  ', T.' ||  ti.rowno from  tabinheritance ti, tabinhreg reg
where ti.inheritance_id = p.inheritance_id
and ti.tabinhreg_id = reg.tabinhreg_id and reg.tableno = '8'
and ti.reasonfree = 1 
and ti.rowno = '4') )  from dual) as "TABLE8FREE"
 )
into pat
from inheritance p
where p.taxdoc_id = iptaxdoc_id
;
return(pat);

end;
$function$
; DROP FUNCTION xmlstructure.xmlland(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlland(ipproperty_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
lands xml;
begin
select xmlforest(
(select d.value from decode d where d.columnname = 'TypeDeclar' and d.code::integer =  typedeclar::integer) as "TYPEDECLAR", landno as "LANDNO", 
DECODE(buildingowner,1.0,'��','��') as "BUILDINGOWNER", 
numbertrim(landarea) as "LANDAREA", numbertrim(builtuparea) as "BUILTUPAREA", to_char(taxbegindate,'dd.mm.yyyy') as "TAXBEGINDATE",
to_char(taxenddate, 'dd.mm.yyyy') as "TAXENDDATE",
to_char(earn_date,'dd.mm.yyyy') as "EARN_DATE", 
to_char(change_date,'dd.mm.yyyy') as "CHANGE_DATE",  
numbertrim(fenceheight) as "FENCEHEIGHT", numbertrim(fencelength) as "FENCELENGTH", 
DECODE(isfence,1.0,'��','��') as "ISFENCE",
 numbertrim(coveringarea) as "COVERINGAREA", 
 numbertrim(sportarea) as "SPORTAREA",
DECODE(iscovering,1.0,'��','��') as "ISCOVERING", 
numbertrim(poolcapacity) as "POOLCAPACITY", numbertrim(greenparking) as "GREENPARKING", 
numbertrim(parkingarea) as "PARKINGAREA",
DECODE(issportcovering,1.0,'��','��')  as "ISSPORTCOVERING", 
DECODE(ispark,1.0,'��','��')   as "ISPARK",
DECODE(ispool,1.0,'��','��')   as "ISPOOL", DECODE(issport,1.0,'��','��') as "ISSPORT", 
DECODE(ispublic,1.0,'��','��') as "ISPUBLIC",
 kindpublicproperty as "KINDPUBLICPROPERTY", 
DECODE(isgreenparking,1.0,'��','��') as "ISGREENPARKING",
  numbertrim(dutyfree) as "DUTYFREE", 
dutyfreeorder as "DUTYFREEORDER", DECODE(isparking,1.0,'��','��') as "ISPARKING", 
DECODE(isbusiness,1.0,'��','��') as "ISBUSINESS",  DECODE(restoreland,1.0,'��','��') as "RESTORELAND", 
restorelanddoc as "RESTORELANDDOC",
 to_char(restorelanddate,'dd.mm.yyyy') as "RESTORELANDDATE", 
--user_id, user_date, 
note as "NOTE", numbertrim(errordata) as "ERRORDATA", used_from as "USED_FROM"
,xmlstructure.xmllandpart(l.land_id) as "LPARTS",
 xmlstructure.xmlfirm14land(l.land_id) as "LFIRM"
)
into lands
from land l where l.property_id = ipproperty_id
; 
return(lands);
end;
$function$
; DROP FUNCTION xmlstructure.xmllandpart(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmllandpart(ipland_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
crpl cursor is
select xmlelement(name "LANDPART",xmlattributes(seqnots  as "PLN"),xmlforest(
ob.seqnots  as "SEQNOTS",
xmlstructure.xmlsubject(ob.taxsubject_id)  as "TAXSUBJECT",
(select d.value from decode d 
	where d.columnname = 'TypeDeclar' and d.code = nvl(ob.typedeclar,'1'))  as "TYPEDECLAR",-- COMMENT d.code = nvl(to_char(ob.typedeclar),'1'))  as "TYPEDECLAR"
 to_char(ob.earn_date, 'dd.mm.yyyy')  as "EARNDATE",
 to_char(ob.end_date, 'dd.mm.yyyy')  as "ENDDATE",
numbertrim(ob.dividentland)  as "DIVIDENT",
numbertrim(ob.divisorland)  as "DIVISOR",
numbertrim(ob.partland)  as "PART",
numbertrim(ob.area)  as "AREA"
))
from partland ob
where ob.land_id = ipland_id
;
landparts xml;
lparts xml; 
begin
open crpl;
loop
fetch crpl into landparts;
exit when not FOUND;
select  XMLConcat(lparts ,landparts) into lparts  from dual;
end loop;
close crpl;
return(lparts);
end;
$function$
; DROP FUNCTION xmlstructure.xmlobject14(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlobject14(iptaxobject_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  objects xml;
begin
select xmlforest(
(select m.fullname from municipality m where o.municipality_id = m.municipality_id)  as "MUNICIPALITY", 
taxobjno  as "TAXOBJECTNO",
(select d.value from decode d where UPPER(d.columnname) = 'KINDTAXOBJECT' and d.code =  to_char(kindtaxobject::integer))  as "KINDTAXOBJECT",
xmlstructure.xmladdress(address_id)  as "OBJADDRESS", 
(select d.value from decode d where UPPER(d.columnname) = 'KINDPROPERTY' and d.code = to_char(kindproperty::integer))  as "KINDPROPERTY",
kadastrno  as "KADASTRNO"
 )
into objects
from taxobject o
where o.taxobject_id = iptaxobject_id
;
return(objects);
end;
$function$
; DROP FUNCTION xmlstructure.xmlobject54(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlobject54(iptaxobject_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  objects xml;
begin
select xmlforest(
(select m.fullname from municipality m where o.municipality_id = m.municipality_id)  as "MUNICIPALITY", 
taxobjno  as "TAXOBJECTNO",
  (select d.value from decode d where UPPER(d.Columnname) = 'KINDTAXOBJECT' and d.Code = kindtaxobject)  as "KINDTAXOBJECT", 
--transpmeansreg_id, 
-- carreg_id, 
motorno  as "MOTORNO", ramano  as "RAMANO")
into objects
from taxobject o
where o.taxobject_id = iptaxobject_id
;
return(objects);
end;
$function$
; DROP FUNCTION xmlstructure.xmlpartgetproperty(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpartgetproperty(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is
select  xmlelement(name "PARTGETROWS",xmlattributes(partgetproperty_id::integer  as "PPN"), xmlforest(

(ts.Name || ', ' || ts.idn ||  ', ' || xmlstructure.addrstr2(ts.post_clientaddr_id))  as "PARTSUBJECT"

))
from partgetproperty g, taxsubject ts, getproperty p
where p.taxdoc_id = iptaxdoc_id
and p.getproperty_id = g.getproperty_id
and g.taxsubject_id = ts.taxsubject_id
and g.taxsubject_id <> (select x.taxsubject_id from taxdoc x where x.taxdoc_id = iptaxdoc_id)
;
partproperties xml;
partgetrows  xml;
begin
open cr;
loop
fetch cr into partproperties;
exit when not FOUND;
select  XMLConcat(partgetrows ,partproperties) into partgetrows  from dual;
end loop;
close cr;
return(partgetrows);
end;
$function$
; DROP FUNCTION xmlstructure.xmlpartinheritance1(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpartinheritance1(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is
select  xmlelement(name "INHERITORS1",xmlattributes(pp.partinheritance_id  as "PPN"), xmlforest(
      ts.name  as "NAME",
      ts.idn  as "IDN",
(select d.value from decode d where  upper(d.columnname ) = 'RELATION' and d.code = to_char(pp.relation::integer))   as "RELATION",   
numbertrim(pp.part)      as "PART",
numbertrim(pp.divident)  as "DIVIDENT",
numbertrim(pp.divisor)   as "DIVISOR",
xmlstructure.addrstr2(ts.present_clientaddr_id)  as "PRESENT_ADDR",
xmlstructure.addrstr2(ts.post_clientaddr_id)  as "POST_ADDR"

))
from partinheritance pp, inheritance ii, taxsubject ts
where ii.taxdoc_id = iptaxdoc_id and ii.inheritance_id = pp.inheritance_id
and pp.taxsubject_id = ts.taxsubject_id
and pp.kindinherit = 1
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmlpartinheritance2(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpartinheritance2(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
crpi2 cursor is
select  xmlelement(name "INHERITORS2",xmlattributes(pp.partinheritance_id  as "PPN"), xmlforest(
      ts.name  as "NAME",
      ts.idn  as "IDN",
xmlstructure.addrstr2(ts.post_clientaddr_id)  as "POST_ADDR",
numbertrim(pp.part)      as "PART",
numbertrim(pp.divident)  as "DIVIDENT",
numbertrim(pp.divisor)   as "DIVISOR"

))
from partinheritance pp, inheritance ii, taxsubject ts
where ii.taxdoc_id = iptaxdoc_id and ii.inheritance_id = pp.inheritance_id
and pp.taxsubject_id = ts.taxsubject_id
and pp.kindinherit = 2
;
partinheritance2 xml;
inheritors  xml;
begin
open crpi2;
loop
fetch crpi2 into partinheritance2;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance2) into inheritors  from dual;
end loop;
close crpi2;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmlpartproperty(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpartproperty(ipproperty_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
 cr  cursor is
select  xmlelement(name "OWNERS",xmlattributes(seqnots  as "PPN"), xmlforest(
seqnots  as "SEQNOTS",
(select ts.idn from taxsubject ts where ts.taxsubject_id = pp.taxsubject_id)  as "IDN",
 (select ts.name from   taxsubject ts where  ts.taxsubject_id = pp.taxsubject_id)  as "NAME",
----xmlstructure.xmladdrnew(post_addr)  as "POST_ADDR",
post_addr   as "POST_ADDR",
telephone  as "TELEPHONE",
--xmlstructure.xmlsubject(pp.taxsubject_id)  as "TAXSUBJECT", 
(select d.value from decode d where d.columnname = 'TypeDeclar' and d.code::integer = typedeclar::integer)  as "TYPEDECLAR", 
decode(relief_id,NULL,'��','��')  as "TELK",
xmlstructure.xmlrelief(pp.relief_id)  as "RELIEF"
))
from partproperty pp
where pp.property_id = ipproperty_id
;
partproperties xml;
owners  xml;
begin
open cr;
loop
fetch cr into partproperties;
exit when not FOUND;
select  XMLConcat(owners ,partproperties) into owners  from dual;
end loop;
close cr;
return(owners);
end;
$function$
; DROP FUNCTION xmlstructure.xmlparttr(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlparttr(iptransport_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  cr cursor is
select xmlelement(name "FIRMOBJ",xmlattributes(pt.taxsubject_id  as "PTR"),xmlforest(
xmlstructure.xmlsubject(taxsubject_id)  as "TAXSUBJECT", 
divident  as "DIVIDENT", 
divisor  as "DIVISOR", 
part  as "PART", 
xmlstructure.xmlrelief(relief_id)  as "RELIEF", 
name  as "SUBJNAME", 
post_addr  as "POST_ADDR", 
telephone  as "TELEPHONE", 
to_char(begindate,'dd.mm.yyyy')  as "BEGINDATE", 
to_char(enddate,'dd.mm.yyyy')  as "ENDDATE"
))
from parttransport pt
where pt.transport_id = iptransport_id
;
parttrans xml;
owners  xml;
begin
open cr;
loop
fetch cr into parttrans;
exit when not FOUND;
select  XMLConcat(owners ,parttrans) into owners  from dual;
end loop;
close cr;
return(owners);
 
end;
$function$
; DROP FUNCTION xmlstructure.xmlpatent(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpatent(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  
pat xml;

begin
select xmlforest(
(select to_char(tp.begin_date,'yyyy') from taxperiod tp where tp.taxperiod_id = p.taxperiod_id)  as "TAXPERIOD", 

--parent_docno, 
--parent_docdate, 
DECODE(isactivityappl4,1.0,'��','��')  as "ISACTIVITYAPPL4", 
DECODE(isturnover,0.0,'��','��')  as "ISTURNOVER",
DECODE(isdds,0.0,'��','��')  as "ISDDS", 
DECODE(ispersonalwork,1.0,'��','��')  as "ISPERSONALWORK",
to_char(begindate,'dd.mm.yyyy')   as "BEGINDATE", 
DECODE(circumstance1,1.0,'��','��')  as "CIRCUMSTANCE1", 
to_char(circumstance1_date,'mm.yyyy')  as "CIRCUMSTANCE1_DATE", 
DECODE(circumstance2,1.0,'��','��')  as "CIRCUMSTANCE2", 
to_char(circumstance2_date,'mm.yyyy')  as "CIRCUMSTANCE2_DATE", 
DECODE(circumstance3,1.0,'��','��')  as "CIRCUMSTANCE3", 
to_char(circumstance3_date,'mm.yyyy')  as "CIRCUMSTANCE3_DATE", 
--user_date, 
--user_id, 
xmlstructure.xmlsubject(taxsubject_id)  as "TAXSUBJECT",
xmlstructure.xmlpatentact(patent_id)  as "PATENTACT",
xmlstructure.xmlpatentobjend(patent_id)  as "PATENTEND",
xmlstructure.xmlpatentother(patent_id)  as "PATENTOTHER" 
) 
into pat
from patent p
where p.taxdoc_id = iptaxdoc_id
;
return(pat);

end;
$function$
; DROP FUNCTION xmlstructure.xmlpatentact(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpatentact(ippatent_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
    maincr Cursor  is
      select pa.*, pareg.tableno
        from patentactivity pa, PatentActivityreg pareg
       where pa.patent_id = ippatent_id
         and pa.patentactivityreg_id = pareg.patentactivityreg_id;
    mcrow     record;
    patentact xml;
    owners    xml;
  begin
    owners := null;
    --open cr;
    Open maincr;
    loop
      fetch maincr
        into mcrow;
      exit when not FOUND;
    
      select xmlstructure.xmlpatentact1(ippatent_id, mcrow.tableno)
        into patentact
        from dual;
      select XMLConcat(owners, patentact) into owners from dual;
    
    end loop;
    close maincr;
    ---  bilo return(patentact);
    return(owners);
end;

$function$
; DROP FUNCTION xmlstructure.xmlpatentact1(numeric, character varying); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpatentact1(ippatent_id numeric, vtableno character varying)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
    --s  varchar(32000);
    xmlt xml;
    actname varchar(20);
  begin
    xmlt := null;
    actname :='patentactivity' || vTableNo;
   -- COMMENT EXECUTE of SELECT ... INTO is not implemented !!!!
     select xmlelement( name "ACTNAME" ,
                    --  xmlattributes(pa.patentactivity_id  as "PAC"),
                      xmlforest((select pr.tableno || ' ' ||
                                        pr.activity_fullname
                                   from patentactivityreg pr
                                  where pr.patentactivityreg_id =
                                        pa.patentactivityreg_id)  as "PATENTACTIVITYREG",
                                DECODE(isworkalone, 1.0, '��','��')  as "ISWORKALONE",
                                DECODE(ispersonalwork, 1.0, '��', '��')  as "ISPERSONALWORK",
                               -- (select pr.tableno
                               --    from patentactivityreg pr
                               --   where pr.patentactivityreg_id =
                               --         pa.patentactivityreg_id)  as "TABLENO",
                                DECODE(isapprenticereg, 1.0, '��', '��')  as "ISAPPRENTICEREG",
                                taxvalue_decl  as "STAXVALUE_DECL",
                                taxvalue_calc  as "STAXVALUE_CALC",
                                isfalse_taxvalue  as "ISFALSE_TAXVALUE",
                                xmlstructure.xmlpatentobj(pa.patentactivity_id)  as "PATENTOBJ")) into xmlt 
      from patentactivity pa 
     where pa.patent_id = ippatent_id 
        and exists
     (select pr.tableno
              from patentactivityreg pr
             where pr.patentactivityreg_id = pa.patentactivityreg_id
               and pr.tableno =  vtableno);
    --s := translate(s,Chr(13),' ');
    --Execute s;            
    return xmlt; --select vale_xmlstructure.xmlpatentact1(367, '04') from dual
end;
$function$
; DROP FUNCTION xmlstructure.xmlsubject(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlsubject(iptaxsubject_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  subject xml;
begin
select xmlforest(
taxsubjectno as "TAXSUBJECTNO", 
-- (select m.name from municipality m where m.municipality_id = ts.municipality_id) as "MUNICIPALITY", 
(select d.value from decode d where UPPER(d.columnname) = 'ISPERSON' and d.code::integer = isperson::integer)  as "ISPERSON",
(select d.value from decode d where upper(d.columnname) = 'KIND_IDN' and d.code::integer = kind_idn::integer) as "KIND_IDN",
xmlstructure.xmladdress(present_clientaddr_id) as "PRESENT_CLIENTADDR", 
to_char(present_addrdate,'dd.mm.yyyy') as "PRESENT_ADDRDATE", 
idn as "IDN",tsaccount::integer as "TSACCOUNT", taxno as "TAXNO", 
permanent_addres_exist::integer as "PERMANENT_ADDRES_EXIST", 
xmlstructure.xmladdress(permanent_clientaddr_id) as "PERMANENT_CLIENTADDR",
name as "SUBJECTNAME", 
xmlstructure.xmladdress(post_clientaddr_id) as "POST_CLIENTADDR_ID", 
to_char(post_addrdate,'dd.mm.yyyy') as "POST_ADDRDATE", 
-- user_date, 
-- user_id, 
to_char(permanent_addrdate,'dd.mm.yyyy') as "PERMANENT_ADDRDATE", 
e_mail as "E_MAIL",telefon as "TELEFON",fax as "FAX", 
note as "NOTE",postaddr_input_code::integer as "POSTADDR_INPUT_CODE", 
permaddr_input_code::integer as "PERMADDR_INPUT_CODE")
into subject
from taxsubject ts
where ts.taxsubject_id = iptaxsubject_id
;
return(subject);
end;
$function$
; DROP FUNCTION xmlstructure.xmlpatentobj(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpatentobj(ippatentactivity_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
crpo cursor is  
select  xmlelement(name "PATENTACTIVITYOBJ",xmlattributes(objno  as "POB"), xmlforest(
(select max(pz.zone)  from patentzone pz where pz.patentzone_id = o.patentzone_id)  as "PATENTZONE", 
---  vajno - bilo - da se proveri !!! (select pz.zone  from patentzone pz where pz.patentzone_id = patentzone_id)  as "PATENTZONE", 
objno  as "OBJNO", objname  as "OBJNAME", 
objmore  as "OBJMORE",
----   objaddress  as "OBJADDRESS", 
xmlstructure.addrstr2(address_id)  as "OBJADDRESS",
xmlstructure.xmladdress(address_id)  as "ADDRESS", 
category  as "CATEGORY",
DECODE(reg.tableno,'17',(decode(o.quantity1,1.0,'��','��')),CAST(quantity1 as VARCHAR))  as "QUANTITY1", 
DECODE(reg.tableno,'17',(decode(o.quantity2,1.0,'��','��')),CAST(quantity2 as VARCHAR))  as "QUANTITY2", 
 note  as "NOTE", 
taxvalue_decl  as "TAXVALUE_DECL", 
(select pr.tableno || pr.activityno ||' '|| pr.activity_fullname from patentactivityreg pr where o.patentactivityreg_id = pr.patentactivityreg_id)  as "PATENTACTIVITYREG",  
taxvalue_calc  as "TAXVALUE_CALC", 
isfalse_taxvalue  as "ISFALSE_TAXVALUE", 
to_char(begindate,'dd.mm.yyyy')  as "BEGINDATE", 
to_char(enddate,'dd.mm.yyyy')  as "ENDDATE", 
freetaxval  as "FREETAXVAL"
))
from patentactivityobj o, patentactivityreg reg
where o.patentactivity_id = ippatentactivity_id
and   o.patentactivityreg_id = reg.patentactivityreg_id
;
patentobj xml;
pobject  xml;
begin
open crpo;
loop
fetch crpo into patentobj;
exit when not FOUND;
select  XMLConcat(pobject ,patentobj) into pobject  from dual;
end loop;
close crpo;
  return(pobject);
 
end;
$function$
; DROP FUNCTION xmlstructure.xmlpatentobjend(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpatentobjend(ippatent_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
crpoe cursor is  
select  xmlelement(name "PATENTOBJEND",xmlattributes(objno  as "POBE"), xmlforest(
row_number() OVER (ORDER BY 0)  as "OBJNO",-- COMMENT rownum   as "OBJNO",
objmore  as "OBJMORE",
----   objaddress  as "OBJADDRESS", 
xmlstructure.addrstr2(address_id)  as "OBJADDRESS",
(select  pr.activity_fullname from patentactivityreg pr where o.patentactivityreg_id = pr.patentactivityreg_id)  as "PATENTACTIVITYREG",  
to_char(enddate,'dd.mm.yyyy')  as "ENDDATE"
))
from patentactivityobj o, patentactivity pa 
where o.patentactivity_id = pa.patentactivity_id
  and o.enddate is not null and pa.patent_id = ippatent_id
  order by o.patentactivityobj_id
;

patentobjend xml;
pobjectend  xml;
begin
open crpoe;
loop
fetch crpoe into patentobjend;
exit when not FOUND;
select  XMLConcat(pobjectend ,patentobjend) into pobjectend  from dual;
end loop;
close crpoe;
  return(pobjectend);
 
end;
$function$
; DROP FUNCTION xmlstructure.xmlpatentother(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlpatentother(ippatent_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
crpao cursor is  
select  xmlelement(name "PATENTOTHERACT",xmlattributes(row_number() OVER (ORDER BY 0)  as "POTH"), xmlforest( -- COMMENT xmlattributes(rownum  as "POTH"), xmlforest(
row_number() OVER (ORDER BY 0)  as "OBJNO",--COMMENT rownum   as "OBJNO",
(select  m.name  from municipality m where m.municipality_id = pot.municipality_id )  as "MUNICAPILITY",
pot.activityname  as "ACTIVITYNAME",
pot.objaddress    as "OBJADDRESS"
))
from patentother pot
where pot.patent_id = ippatent_id
order by pot.patentother_id
;

patentother xml;
pobjectend  xml;
begin
open crpao;
loop
fetch crpao into patentother;
exit when not FOUND;
select  XMLConcat(pobjectend ,patentother) into pobjectend  from dual;
end loop;
close crpao;
  return(pobjectend);
 
end;
$function$
; DROP FUNCTION xmlstructure.xmlproperty(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlproperty(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
properties xml;

begin
select  xmlforest(
(select m.fullname from municipality m where decode(p.location_municipality_id,0.0,1193.0,p.location_municipality_id) = m.municipality_id)  as "LOCATION_MUNICIPALITY", 
seqnoproperty  as "SEQNOPROPERTY", 
taxunit2  as "TAXUNIT2", 
xmlstructure.xmladdress(property_address_id)  as "PROPERTY_ADDRESS", 
onesender  as "ONESENDER", propertyno  as "PROPERTYNO", 
to_char(propdocdate,'dd.mm.yyyy')  as "PROPDOCDATE", 
propertynodoc  as "PROPERTYNODOC", 
(select d.value from decode d where UPPER(d.columnname) = 'KINDPROPERTY' and d.code = CAST(kindproperty as VARCHAR))  as "KINDPROPERTY", 
propemission  as "PROPEMISSION",
decode(oneowner,1.0,'��','��')  as "ONEOWNER", 
decode(oneuser,1.0,'��','��')   as "ONEUSER",
 propertynote  as "PROPERTYNOTE", 
(select d.value from decode d where d.columnname = 'KindLand' and d.code = kindland)  as "KINDLAND", 
other_incdoc  as "OTHER_INCDOC", 
DECODE(iselectro,1.0,'��� � �����',2.0,'���� � �����,�� ��� �����',3.0,'���� � ����� � ����� ����','???')  as "ISELECTRO", 
decode(iswater,1.0,'��� � �����',2.0,'���� � �����,�� ��� �����',3.0,'���� � ����� � ����� ����','???')   as "ISWATER", 
kadastrno  as "KADASTRNO", 
kadastr_year  as "KADASTR_YEAR", 
decode(issewer,1.0,'��� � �����',2.0,'���� � �����,�� ��� �����',3.0,'���� � ����� � ����� ����','???')  as "ISSEWER", 
decode(istec,1.0,'��� � �����',2.0,'���� � �����,�� ��� �����',3.0,'���� � ����� � ����� ����','???')   as "ISTEC", 
DECODE(isroad,1.0,'������� � ����� �����',0.0,'�� �������','???')  as "ISROAD",
decode(category_city,1.0,'��','��')  as "CATEGORY_CITY", 
DECODE(isnationalresort,1.0,'��','��')   as "ISNATIONALRESORT",
DECODE(islocalresort,1.0,'��','��')      as "ISLOCALRESORT", 
DECODE(isseezone,1.0,'��','��')          as "ISSEEZONE",
DECODE(isnationalroadnet,1.0,'��','��')  as "ISNATIONALROADNET", 
DECODE(isisolatedzone,1.0,'��','��')     as "ISISOLATEDZONE",
decode(city_category1,1.0,'��','��')     as "CITY_CATEGORY1", 
decode(city_category2,1.0,'��','��')     as "CITY_CATEGORY2",
decode(NVL(builder_zone,0.0),0.0,0.0,builder_zone)  as "BUILDER_ZONE", -- COMMENT decode(NVL(builder_zone,0.0),0.0,'��',builder_zone)  as "BUILDER_ZONE"
zrpno_district  as "ZRPNO_DISTRICT", zrpno_parcel  as "ZRPNO_PARCEL", 
to_char(zrp_date,'yyyy')  as "ZRP_DATE", 
decode(NVL(seezone_cat,0.0),0.0,0.0,seezone_cat)  as "SEEZONE_CAT", -- COMMENT decode(NVL(seezone_cat,0.0),0.0,'��',seezone_cat)  as "SEEZONE_CAT"
note  as "NOTE",
(select d.value from decode d where UPPER(d.columnname) = 'CONSTRUCTIONBOUND' and d.code = constructionbound)  as "CONSTRUCTIONBOUND",
(select d.value from decode d where UPPER(d.columnname) = 'STRUCTUREZONE' and d.code = structurezone)  as "STRUCTUREZONE",
repl_user_name  as "REPL_USER_NAME", 
earnway  as "EARNWAY", propertydoc  as "PROPERTYDOC", 
----   status  as "STATUS", 
(select d.value from decode d where UPPER(d.columnname) = 'STATUS' and d.code = status)  as "STATUS", 
usesright  as "USESRIGHT", errordata  as "ERRORDATA", 
--user_id, 
(select d.value from decode d where UPPER(d.columnname) = 'CODETBO' and d.code = codetbo)   as "CODETBO",
(select d.value from propgrouptbo pg, grouptbo g , decode d
 where pg.taxdoc_id = p.taxdoc_id 
 and pg.grouptbo_id = g.grouptbo_id
 and UPPER(d.columnname) = 'CODETBO' and d.code = to_char(g.tbo_code))  as "PROPGROUPTBO",
promil  as "PROMIL", 
dublproperty  as "DUBLPROPERTY", 
--user_date
xmlstructure.xmlbuilding(p.property_id)  as "EDIFICE",
xmlstructure.xmlland(p.property_id)  as "LAND",
xmlstructure.xmlpartproperty(p.property_id)  as "PARTPROPERTY"
)
into properties
from property p
where p.taxdoc_id = iptaxdoc_id
;
return(properties);
end;
$function$
; DROP FUNCTION xmlstructure.xmlrelief(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmlrelief(iprelief_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
reliefs xml;

begin
select xmlforest(
(select distinct ts.name from taxsubject ts where ts.taxsubject_id = r.taxsubject_id) as "SUBJECTNAME", 
(select distinct ts.idn from taxsubject ts where ts.taxsubject_id = r.taxsubject_id) as "SUBJECTIDN", 
decode(isretired,1.0,'��','��') as "ISRETIRED", 
to_char(retired_begindate,'dd.mm.yyyy') as "RETIRED_BEGINDATE", 
to_char(retired_enddate,'dd.mm.yyyy') as "RETIRED_ENDDATE", 
to_char(telk_decisiondate,'dd.mm.yyyy') as "TELK_DECISIONDATE", 
telk_decisionno as "TELK_DECISIONNO", 
to_char(telk_begindate,'dd.mm.yyyy') as "TELK_BEGINDATE", 
to_char(telk_enddate,'dd.mm.yyyy') as "TELK_ENDDATE", 
(case telk_enddate when null then '��' else '��' end) as "PERMRELIEF",
--decode(telk_enddate,null,'��','��') as "PERMRELIEF",
note as "NOTE"  
--, user_date, user_id
)
into reliefs
from relief r
where r.relief_id = iprelief_id
;
return(reliefs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltabinheritance7(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltabinheritance7(ipinheritance_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is 
select    xmlelement(name "TABINHROW",xmlattributes(pa.tabinheritance_id::integer as "PPN"), 
     xmlforest((select pr.tableno || ' ' || pr.tablename
          from tabinhreg pr where pr.tabinhreg_id =  pa.tabinhreg_id) as "TABINHREG",
                pa.rowno::integer as "ROWNO", pa.reasonfree::integer as "REASONFREE",
            pa.Col1value as "COL1VALUE", pa.Col2value as "COL2VALUE", pa.Col3value as "COL3VALUE",
               pa.Col4value as "COL4VALUE", pa.Col5value as "COL5VALUE", to_char(pa.Col6value,'dd.mm.yyyy') as "COL6VALUE"                   
)) from tabinheritance pa, tabinhreg treg
 where pa.inheritance_id =  ipinheritance_id
   and pa.tabinhreg_id   = treg.tabinhreg_id 
   and treg.tableno      = '7' order by pa.rowno
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmltabinheritance1(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltabinheritance1(ipinheritance_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is 
select    xmlelement(name "TABINHROW",xmlattributes(pa.tabinheritance_id::integer as "PPN"), 
     xmlforest((select pr.tableno || ' ' || pr.tablename
          from tabinhreg pr where pr.tabinhreg_id =  pa.tabinhreg_id) as "TABINHREG",
               pa.rowno::integer as "ROWNO", pa.reasonfree::integer as "REASONFREE",
               pa.Col1value as "COL1VALUE",
                xmlstructure.addrstr2(pa.Col2value::numeric) as "COL2VALUE", pa.Col3value as "COL3VALUE",
               pa.Col4value as "COL4VALUE", pa.Col5value as "COL5VALUE", to_char(pa.Col6value,'dd.mm.yyyy') as "COL6VALUE"                   
)) from tabinheritance pa, tabinhreg treg
 where pa.inheritance_id =  ipinheritance_id
   and pa.tabinhreg_id   = treg.tabinhreg_id 
   and treg.tableno      = '1'  order by pa.rowno
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmltabinheritance2(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltabinheritance2(ipinheritance_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is 
select  xmlelement(name "TABINHROW" ,xmlattributes(pa.tabinheritance_id::integer as "PPN"),  xmlforest((select pr.tableno || ' ' || pr.tablename
          from tabinhreg pr where pr.tabinhreg_id =  pa.tabinhreg_id) as "TABINHREG",
                pa.rowno::integer as "ROWNO",pa.reasonfree::integer as "REASONFREE",
              pa.Col1value as "COL1VALUE", pa.Col2value as "COL2VALUE", pa.Col3value as "COL3VALUE",
               pa.Col4value as "COL4VALUE", pa.Col5value as "COL5VALUE", to_char(pa.Col6value,'dd.mm.yyyy') as "COL6VALUE"                   
))  from tabinheritance pa, tabinhreg treg
 where pa.inheritance_id =  ipinheritance_id
   and pa.tabinhreg_id   = treg.tabinhreg_id 
   and treg.tableno      = '2' order by pa.rowno
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmltabinheritance3(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltabinheritance3(ipinheritance_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is 
select    xmlelement(name tabinhRow,xmlattributes(pa.tabinheritance_id::integer as ppn), 
     xmlforest((select pr.tableno || ' ' || pr.tablename
          from tabinhreg pr where pr.tabinhreg_id =  pa.tabinhreg_id) as  tabinhreg,
                pa.rowno::integer as rowno, pa.reasonfree::integer as reasonfree,
---     pa.Col1value as Col1value,
(select trm.name from transpmeansreg trm
  where trm.transpmeansreg_id = to_number(substr(pa.Col1value,1,instr(pa.Col1value,':',1,1)-1))
    and trm.code = trim(substr(pa.Col1value,instr(pa.Col1value,':',1,1)+1,10)) )  as Col1value,
---      pa.Col2value as Col2value,
(select cm.mark_name from  transpmeansreg  trm, carmark  cm, carmodel m, carreg cr
  where trm.transpmeansreg_id = to_number(substr(pa.Col1value,1,instr(pa.Col1value,':',1,1)-1))
    and trm.code = trim(substr(pa.Col1value,instr(pa.Col1value,':',1,1)+1,10))
 and trm.transpmeansreg_id = cm.transpmeansreg_id   and cm.carmark_id::integer = pa.col2value::integer

and  cm.carmark_id = m.carmark_id  and m.carmodel_id::integer = pa.col3value::integer
and  m.carmodel_id = cr.carmodel_id)  as col2value,
---   pa.Col3value as Col3value,
(select m.model_name from  transpmeansreg  trm, carmark  cm, carmodel m, carreg cr
  where trm.transpmeansreg_id = to_number(substr(pa.Col1value,1,instr(pa.Col1value,':',1,1)-1))
    and trm.code = trim(substr(pa.Col1value,instr(pa.Col1value,':',1,1)+1,10))
 and trm.transpmeansreg_id = cm.transpmeansreg_id   and cm.carmark_id::integer = pa.col2value::integer

and  cm.carmark_id = m.carmark_id  and m.carmodel_id::integer = pa.col3value::integer
and  m.carmodel_id = cr.carmodel_id)  as col3value,
--              
               pa.Col4value as Col4value, pa.Col5value as Col5value, to_char(pa.Col6value,'dd.mm.yyyy') as Col6value                   
)) from tabinheritance pa, tabinhreg treg
 where pa.inheritance_id =  ipinheritance_id
   and pa.tabinhreg_id   = treg.tabinhreg_id 
   and treg.tableno      = '3' order by pa.rowno
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmltabinheritance4(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltabinheritance4(ipinheritance_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is 
select    xmlelement(name "TABINHROW",xmlattributes(pa.tabinheritance_id::integer as "PPN"), 
     xmlforest((select pr.tableno || ' ' || pr.tablename
          from tabinhreg pr where pr.tabinhreg_id =  pa.tabinhreg_id) as "TABINHREG",
                pa.rowno::integer as "ROWNO", pa.reasonfree::integer as "REASONFREE",
              pa.Col1value as "COL1VALUE", pa.Col2value as "COL2VALUE", pa.Col3value as "COL3VALUE",
               pa.Col4value as "COL4VALUE", pa.Col5value as "COL5VALUE", to_char(pa.Col6value,'dd.mm.yyyy') as "COL6VALUE"                   
)) from tabinheritance pa, tabinhreg treg
 where pa.inheritance_id =  ipinheritance_id
   and pa.tabinhreg_id   = treg.tabinhreg_id 
   and treg.tableno      = '4' order by pa.rowno
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmltabinheritance5(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltabinheritance5(ipinheritance_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is 
select  xmlelement(name "TABINHROW" ,xmlattributes(pa.tabinheritance_id::integer as "PPN"),  xmlforest((select pr.tableno || ' ' || pr.tablename
          from tabinhreg pr where pr.tabinhreg_id =  pa.tabinhreg_id) as "TABINHREG",
                pa.rowno::integer as "ROWNO", pa.reasonfree::integer as "REASONFREE",
              pa.Col1value as "COL1VALUE", pa.Col2value as "COL2VALUE", pa.Col3value as "COL3VALUE",
               pa.Col4value as "COL4VALUE", pa.Col5value as "COL5VALUE", to_char(pa.Col6value,'dd.mm.yyyy') as "COL6VALUE"                   
))  from tabinheritance pa, tabinhreg treg
 where pa.inheritance_id =  ipinheritance_id
   and pa.tabinhreg_id   = treg.tabinhreg_id 
   and treg.tableno      = '5' order by pa.rowno
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmltabinheritance6(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltabinheritance6(ipinheritance_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is 
select    xmlelement(name "TABINHROW",xmlattributes(pa.tabinheritance_id::integer as "PPN"), 
     xmlforest((select pr.tableno || ' ' || pr.tablename
          from tabinhreg pr where pr.tabinhreg_id =  pa.tabinhreg_id) as "TABINHREG",
                pa.rowno::integer as "ROWNO", pa.reasonfree::integer as "REASONFREE",
              pa.Col1value as "COL1VALUE", pa.Col2value as "COL2VALUE", pa.Col3value as "COL3VALUE",
               pa.Col4value as "COL4VALUE", pa.Col5value as "COL5VALUE", to_char(pa.Col6value,'dd.mm.yyyy') as "COL6VALUE"                   
)) from tabinheritance pa, tabinhreg treg
 where pa.inheritance_id =  ipinheritance_id
   and pa.tabinhreg_id   = treg.tabinhreg_id 
   and treg.tableno      = '6' order by pa.rowno
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmltabinheritance8(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltabinheritance8(ipinheritance_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is 
select  xmlelement(name "TABINHROW" ,xmlattributes(pa.tabinheritance_id::integer as "PPN"),  xmlforest((select pr.tableno || ' ' || pr.tablename
          from tabinhreg pr where pr.tabinhreg_id =  pa.tabinhreg_id) as "TABINHREG",
                pa.rowno::integer as "ROWNO", pa.reasonfree::integer as "REASONFREE",
             pa.Col1value as "COL1VALUE", pa.Col2value as "COL2VALUE", pa.Col3value as "COL3VALUE",
               pa.Col4value as "COL4VALUE", pa.Col5value as "COL5VALUE", to_char(pa.Col6value,'dd.mm.yyyy') as "COL6VALUE"                   
))  from tabinheritance pa, tabinhreg treg
 where pa.inheritance_id =  ipinheritance_id
   and pa.tabinhreg_id   = treg.tabinhreg_id 
   and treg.tableno      = '8' order by pa.rowno
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmltabinheritance9(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltabinheritance9(ipinheritance_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
cr cursor is 
select    xmlelement(name "TABINHROW" ,xmlattributes(pa.tabinheritance_id::integer as "PPN"), 
     xmlforest((select pr.tableno || ' ' || pr.tablename
          from tabinhreg pr where pr.tabinhreg_id =  pa.tabinhreg_id) as "TABINHREG",
                pa.rowno::integer as "ROWNO", pa.reasonfree::integer as "REASONFREE",
             pa.Col1value as "COL1VALUE", 
       ---      xmlstructure.addrstr2(pa.Col2value) as "COL2VALUE",
              pa.Col2value as "COL2VALUE",
              pa.Col3value as "COL3VALUE",
               pa.Col4value as "COL4VALUE", pa.Col5value as "COL5VALUE", to_char(pa.Col6value,'dd.mm.yyyy') as "COL6VALUE"                   
)) from tabinheritance pa, tabinhreg treg
 where pa.inheritance_id =  ipinheritance_id
   and pa.tabinhreg_id   = treg.tabinhreg_id 
   and treg.tableno      = '9' order by pa.rowno
;
partinheritance1 xml;
inheritors  xml;
begin
open cr;
loop
fetch cr into partinheritance1;
exit when not FOUND;
select  XMLConcat(inheritors ,partinheritance1) into inheritors  from dual;
end loop;
close cr;
return(inheritors);
end;
$function$
; DROP FUNCTION xmlstructure.xmltaxdoc117(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltaxdoc117(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare

  taxdocs xml;
   vemprdvr character varying(50);
  vdeclrdvr character varying(50);
  vnum numeric;

begin
    begin
    select to_number(td.emp_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vemprdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.emp_rdvr into vemprdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
    begin
    select to_number(td.decl_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vdeclrdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.decl_rdvr into vdeclrdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;

  select xmlelement(name "TAXDOC",
                     xmlforest((select m.fullname
                                 from   municipality m
                                 where  m.municipality_id = td.municipality_id) as "MUNICIPALITY",
                                xmlstructure.xmlobject14(td.taxobject_id) as "OBJECT",
                                --
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.taxsubject_id) as "DECL_IDN", decl_name as "DECL_NAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.taxsubject_id) as "DECL_IDENTDOC_KIND",
                                decl_identdocno as "DECL_IDENTDOCNO",
                                decl_emission_date as "DECL_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  to_char(r.rdvr_id) = td.decl_rdvr) as "DECL_RDVR", */
                                  vdeclrdvr as "DECL_RDVR", 
                                xmlstructure.xmladdrnew(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                --
                                xmlstructure.xmladdrnew(td.decl_post_addr) as "DECL_POST_ADDR",
                                (select d.value
                                  from   decode d
                                  where  d.columnname = 'TypeDeclar'
                                  and    d.code = td.kinddecl) as "KINDDECL",
                                --basedoc_taxdoc_id, 
                                taxobjno as "TAXOBJNO", partidano as "PARTIDANO",
                                old_partidano as "OLD_PARTIDANO",
                                (select dt.doccode
                                  from   documenttype dt
                                  where  dt.documenttype_id = td.documenttype_id) as "DOCUMENTTYPE",
                                to_char(taxdocdate, 'dd.mm.yyyy') as "TAXDOCDATE",
                                docno as "DOCNO", docextno as "DOCEXTNO",
                                to_char(doc_date, 'dd.mm.yyyy') as "DOC_DATE",
                                to_char(docext_date, 'dd.mm.yyyy') as "DOCEXT_DATE",
                                to_char(td.earn_date, 'dd.mm.yyyy') as "EARN_DATE",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = emp_taxsubject_id) as "EMP_IDN", td.emp_name as "EMP_NAME",
                                xmlstructure.xmladdrnew(td.emp_post_addr) as "EMP_POST_ADDR",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.emp_taxsubject_id) as "EMP_IDENTDOC_KIND",
                                td.emp_identdocno as "EMP_IDENTDOCNO", empno as "EMPNO",
                                to_char(emp_emissiondate, 'dd.mm.yyyy') as "EMP_EMISSIONDATE", emp_certify as "EMP_CERTIFY",
                                to_char(EMP_IDENT_EMISSION_DATE, 'dd.mm.yyyy') as "EMP_IDENT_EMISSION_DATE",
                               /* (select r.name
                                  from   rdvr r
                                  where  r.rdvr_id = td.emp_rdvr::numeric) as "EMP_RDVR", */
                                  vemprdvr as "EMP_RDVR",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = give_reasonreg_id) as "GIVE_REASONREG",
                                xmlstructure.xmlrelief(td.relief_id) as "RELIEF",
                                --user_id, 
                                to_char(docwork_finaldate, 'dd.mm.yyyy') as "DOCWORK_FINALDATE",
                                to_char(receiver_date, 'dd.mm.yyyy') as "RECEIVER_DATE", receiver_note as "RECEIVER_NOTE",
                                to_char(docinput_date, 'dd.mm.yyyy') as "DOCINPUT_DATE", note as "NOTE",
                                (select s.name
                                  from   company c, taxsubject s
                                  where  c.company_id = td.company_id
                                  and    c.taxsubject_id = s.taxsubject_id) as "COMPANY",
                                (select d.value
                                  from   decode d
                                  where  UPPER(d.columnname) = 'DOCSTATUS'
                                  and    d.Code = docstatus) as "DOCSTATUS",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = close__reasonreg_id) as "CLOSE__REASONREG",
                                to_char(close_date, 'dd.mm.yyyy') as "CLOSE_DATE",
                                close_taxdoc_id as "CLOSE_TAXDOC_ID",
                                DECODE(isinheritance, to_number('1'), '��', '��') as "ISINHERITANCE",
                                 --to_char(wait_date,'dd.mm.yyyy') as "WAIT_DATE", 
                                to_user_id as "TO_USER_ID",
                                location_doc as "LOCATION_DOC",
                                to_char(user_date, 'dd.mm.yyyy') as "USER_DATE",
                                user_name ||
                                 (select ' ' || min(u.fullname)
                                  from   users u
                                  where  u.user_id = td.user_id) as "USER_NAME",
                                to_char(begintaxdate, 'dd.mm.yyyy') as "BEGINTAXDATE",
                                to_char(endtaxdate, 'dd.mm.yyyy') as "ENDTAXDATE",
                                isinvalid as "ISINVALID",
                                 --message_code as "MESSAGE_CODE", 
                                --message_date as "MESSAGE_DATE", 
                                receiver_user_id as "RECEIVER_USER_ID",
                                receiver_user_name as "RECEIVER_USER_NAME",
                                g.breed as "BREED",
                                to_char(g.earn_date, 'dd.mm.yyyy') as "EARNDATE",
                                decode(substr(g.reasonfree, 1, 1), '1', '��', '��') as "R1",
                                decode(substr(g.reasonfree, 2, 1), '1', '��', '��') as "R2",
                                decode(substr(g.reasonfree, 3, 1), '1', '��', '��') as "R3",
                                decode(substr(g.reasonfree, 4, 1), '1', '��', '��') as "R4",
                                decode(substr(g.reasonfree, 5, 1), '1', '��', '��') as "R5",
                                decode(substr(g.reasonfree, 6, 1), '1', '��', '��') as "R6"))
  into   taxdocs
  from   taxdoc td, dog g
  where  td.taxdoc_id = iptaxdoc_id
  and    td.taxdoc_id = g.taxdoc_id
  
  ;
  return(taxdocs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltaxdoc14(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltaxdoc14(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare

  taxdocs xml;
  vemprdvr character varying(50);
  vdeclrdvr character varying(50);
  vnum numeric;

begin
    begin
    select to_number(td.emp_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vemprdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.emp_rdvr into vemprdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
    begin
    select to_number(td.decl_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vdeclrdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.decl_rdvr into vdeclrdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;

  select xmlelement(name "TAXDOC",
                     xmlforest((select m.fullname
                                 from   municipality m
                                 where  m.municipality_id = td.municipality_id) as "MUNICIPALITY",
                                xmlstructure.xmlobject14(td.taxobject_id) as "OBJECT",
                                --xmlstructure.xmlsubject(td.taxsubject_id) as "TAXSUBJECT", 
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.taxsubject_id) as "DECL_IDN", decl_name as "DECL_NAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.taxsubject_id) as "DECL_IDENTDOC_KIND",
                                decl_identdocno as "DECL_IDENTDOCNO",
                                decl_emission_date as "DECL_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  to_char(r.rdvr_id) = td.decl_rdvr) as "DECL_RDVR",*/
                                  vdeclrdvr as "DECL_RDVR",
                                xmlstructure.xmladdrnew(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                -- xmlstructure.addrstr(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                -- td.decl_perm_addr as "DECL_PERM_ADDR",
                                xmlstructure.xmladdrnew(td.decl_post_addr) as "DECL_POST_ADDR",
                                -- xmlstructure.addrstr(td.decl_post_addr) as "DECL_POST_ADDR",
                                --td.decl_post_addr as "DECL_POST_ADDR", 
                                (select d.value
                                  from   decode d
                                  where  d.columnname = 'TypeDeclar'
                                  and    d.code = td.kinddecl) as "KINDDECL",
                                --basedoc_taxdoc_id, 
                                taxobjno as "TAXOBJNO", partidano as "PARTIDANO",
                                old_partidano as "OLD_PARTIDANO",
                                (select dt.doccode
                                  from   documenttype dt
                                  where  dt.documenttype_id = td.documenttype_id) as "DOCUMENTTYPE",
                                to_char(taxdocdate, 'dd.mm.yyyy') as "TAXDOCDATE",
                                docno as "DOCNO", docextno as "DOCEXTNO",
                                to_char(doc_date, 'dd.mm.yyyy') as "DOC_DATE",
                                to_char(docext_date, 'dd.mm.yyyy') as "DOCEXT_DATE",
                                to_char(earn_date, 'dd.mm.yyyy') as "EARN_DATE",
                                to_char(change_date, 'dd.mm.yyyy') as "CHANGE_DATE",
                                -- act_id as , 
                                -- xmlstructure.xmlsubject(td.emp_taxsubject_id) as "EMP_TAXSUBJECT",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = emp_taxsubject_id) as "EMP_IDN", td.emp_name as "EMP_NAME",
                                xmlstructure.xmladdrnew(td.emp_post_addr) as "EMP_POST_ADDR",
                                --xmlstructure.addrstr(td.emp_post_addr) as "EMP_POST_ADDR",
                                --td.emp_post_addr as "EMP_POST_ADDR",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.emp_taxsubject_id) as "EMP_IDENTDOC_KIND",
                                td.emp_identdocno as "EMP_IDENTDOCNO", empno as "EMPNO",
                                to_char(emp_emissiondate, 'dd.mm.yyyy') as "EMP_EMISSIONDATE", emp_certify as "EMP_CERTIFY",
                                to_char(EMP_IDENT_EMISSION_DATE, 'dd.mm.yyyy') as "EMP_IDENT_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  r.rdvr_id = td.emp_rdvr::numeric) as "EMP_RDVR",*/
                                 vemprdvr as "EMP_RDVR",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = give_reasonreg_id) as "GIVE_REASONREG",
                                xmlstructure.xmlrelief(td.relief_id) as "RELIEF",
                                --user_id, 
                                to_char(docwork_finaldate, 'dd.mm.yyyy') as "DOCWORK_FINALDATE",
                                to_char(receiver_date, 'dd.mm.yyyy') as "RECEIVER_DATE", receiver_note as "RECEIVER_NOTE",
                                to_char(docinput_date, 'dd.mm.yyyy') as "DOCINPUT_DATE", note as "NOTE",
                                (select s.name
                                  from   company c, taxsubject s
                                  where  c.company_id = td.company_id
                                  and    c.taxsubject_id = s.taxsubject_id) as "COMPANY",
                                (select d.value
                                  from   decode d
                                  where  UPPER(d.columnname) = 'DOCSTATUS'
                                  and    d.Code = docstatus) as "DOCSTATUS",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = close__reasonreg_id) as "CLOSE__REASONREG",
                                to_char(close_date, 'dd.mm.yyyy') as "CLOSE_DATE",
                                close_taxdoc_id as "CLOSE_TAXDOC_ID",
                                DECODE(isinheritance, to_number('1'), '��', '��') as "ISINHERITANCE",
                                 --to_char(wait_date,'dd.mm.yyyy') as "WAIT_DATE", 
                                to_user_id as "TO_USER_ID",
                                location_doc as "LOCATION_DOC",
                                to_char(user_date, 'dd.mm.yyyy') as "USER_DATE",
                                user_name ||
                                 (select ' ' || min(u.fullname)
                                  from   users u
                                  where  u.user_id = td.user_id) as "USER_NAME",
                                to_char(begintaxdate, 'dd.mm.yyyy') as "BEGINTAXDATE",
                                to_char(endtaxdate, 'dd.mm.yyyy') as "ENDTAXDATE",
                                isinvalid as "ISINVALID",
                                 --message_code as "MESSAGE_CODE", 
                                --message_date as "MESSAGE_DATE", 
                                receiver_user_id as "RECEIVER_USER_ID",
                                receiver_user_name as "RECEIVER_USER_NAME",
                                xmlstructure.xmlproperty(td.taxdoc_id) as "PROPERTY"))
  into   taxdocs
  from   taxdoc td
  where  td.taxdoc_id = iptaxdoc_id;
  return(taxdocs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltaxdoc17(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltaxdoc17(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare

  taxdocs xml;
    vemprdvr character varying(50);
    vdeclrdvr character varying(50);
    vnum numeric;
begin
    begin
    select to_number(td.emp_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vemprdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.emp_rdvr into vemprdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
    begin
    select to_number(td.decl_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vdeclrdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.decl_rdvr into vdeclrdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
  select xmlelement(name "TAXDOC",
                     xmlforest((select m.fullname
                                 from   municipality m
                                 where  m.municipality_id = td.municipality_id) as "MUNICIPALITY",
                                xmlstructure.xmlobject14(td.taxobject_id) as "OBJECT",
                                --xmlstructure.xmlsubject(td.taxsubject_id) as "TAXSUBJECT", 
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.taxsubject_id) as "DECL_IDN", decl_name as "DECL_NAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.taxsubject_id) as "DECL_IDENTDOC_KIND",
                                decl_identdocno as "DECL_IDENTDOCNO",
                                decl_emission_date as "DECL_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  to_char(r.rdvr_id) = td.decl_rdvr) as "DECL_RDVR",*/
                                   vdeclrdvr as "DECL_RDVR",
                                xmlstructure.xmladdrnew(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                --xmlstructure.addrstr(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                --td.decl_perm_addr as "DECL_PERM_ADDR",
                                xmlstructure.xmladdrnew(td.decl_post_addr) as "DECL_POST_ADDR",
                                --xmlstructure.addrstr(td.decl_post_addr) as "DECL_POST_ADDR",
                                --td.decl_post_addr as "DECL_POST_ADDR", 
                                (select d.value
                                  from   decode d
                                  where  d.columnname = 'TypeDeclar'
                                  and    d.code = td.kinddecl) as "KINDDECL",
                                --basedoc_taxdoc_id, 
                                taxobjno as "TAXOBJNO", partidano as "PARTIDANO",
                                old_partidano as "OLD_PARTIDANO",
                                (select dt.doccode
                                  from   documenttype dt
                                  where  dt.documenttype_id = td.documenttype_id) as "DOCUMENTTYPE",
                                to_char(taxdocdate, 'dd.mm.yyyy') as "TAXDOCDATE",
                                docno as "DOCNO", docextno as "DOCEXTNO",
                                to_char(doc_date, 'dd.mm.yyyy') as "DOC_DATE",
                                to_char(docext_date, 'dd.mm.yyyy') as "DOCEXT_DATE",
                                to_char(earn_date, 'dd.mm.yyyy') as "EARN_DATE",
                                to_char(change_date, 'dd.mm.yyyy') as "CHANGE_DATE",
                                -- act_id as , 
                                -- xmlstructure.xmlsubject(td.emp_taxsubject_id) as "EMP_TAXSUBJECT",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = emp_taxsubject_id) as "EMP_IDN", td.emp_name as "EMP_NAME",
                                xmlstructure.xmladdrnew(td.emp_post_addr) as "EMP_POST_ADDR",
                                --xmlstructure.addrstr(td.emp_post_addr) as "EMP_POST_ADDR",
                                --td.emp_post_addr as "EMP_POST_ADDR",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.emp_taxsubject_id) as "EMP_IDENTDOC_KIND",
                                
                                td.emp_identdocno as "EMP_IDENTDOCNO", empno as "EMPNO",
                                to_char(emp_emissiondate, 'dd.mmm.yyyy') as "EMP_EMISSIONDATE", emp_certify as "EMP_CERTIFY",
                                EMP_IDENT_EMISSION_DATE as "EMP_IDENT_EMISSION_DATE",
                               /* (select r.name
                                  from   rdvr r
                                  where  r.rdvr_id = td.emp_rdvr::numeric) as "EMP_RDVR",*/
                                  vemprdvr as "EMP_RDVR",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = give_reasonreg_id) as "GIVE_REASONREG",
                                --xmlstructure.xmlrelief(td.relief_id) as "RELIEF", 
                                user_id as "USER_ID",
                                to_char(docwork_finaldate, 'dd.mm.yyyy') as "DOCWORK_FINALDATE",
                                to_char(receiver_date, 'dd.mm.yyyy') as "RECEIVER_DATE", receiver_note as "RECEIVER_NOTE",
                                to_char(docinput_date, 'dd.mm.yyyy') as "DOCINPUT_DATE", note as "NOTE",
                                (select to_char(sum(NVL(o.accvalue, 0.0)),
                                                  '99999999.99')
                                  from   firmpropobj o, firmproperty fp
                                  where  fp.taxdoc_id = td.taxdoc_id
                                  and    fp.firmprop_id = o.firmproperty_id and o.taxenddate is null) as "ACCVALUE",
                                (select s.name
                                  from   company c, taxsubject s
                                  where  c.company_id = td.company_id
                                  and    c.taxsubject_id = s.taxsubject_id) as "COMPANY",
                                (select d.value
                                  from   decode d
                                  where  UPPER(d.columnname) = 'DOCSTATUS'
                                  and    d.Code = docstatus) as "DOCSTATUS",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = close__reasonreg_id) as "CLOSE__REASONREG",
                                to_char(close_date, 'dd.mm.yyyy') as "CLOSE_DATE",
                                close_taxdoc_id as "CLOSE_TAXDOC_ID",
                                DECODE(isinheritance, to_number('1'), '��', '��') as "ISINHERITANCE",
                                 --to_char(wait_date,'dd.mm.yyyy') as "WAIT_DATE", 
                                to_user_id as "TO_USER_ID",
                                location_doc as "LOCATION_DOC",
                                to_char(user_date, 'dd.mm.yyyy') as "USER_DATE",
                                user_name ||
                                 (select ' ' || min(u.fullname)
                                  from   users u
                                  where  u.user_id = td.user_id) as "USER_NAME",
                                to_char(begintaxdate, 'dd.mm.yyyy') as "BEGINTAXDATE",
                                to_char(endtaxdate, 'dd.mm.yyyy') as "ENDTAXDATE",
                                isinvalid as "ISINVALID",
                                 --message_code as "MESSAGE_CODE", 
                                --message_date as "MESSAGE_DATE", 
                                receiver_user_id as "RECEIVER_USER_ID",
                                receiver_user_name as "RECEIVER_USER_NAME",
                                xmlstructure.xmlfirmproperty(td.taxdoc_id) as "PROPERTY"))
  into   taxdocs
  from   taxdoc td
  where  td.taxdoc_id = iptaxdoc_id;
  return(taxdocs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltaxdoc19(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltaxdoc19(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare

  taxdocs xml;
  vemprdvr character varying(50);
    vdeclrdvr character varying(50);
    vnum numeric;
begin
begin
    select to_number(td.emp_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vemprdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.emp_rdvr into vemprdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
    begin
    select to_number(td.decl_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vdeclrdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.decl_rdvr into vdeclrdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
      select xmlelement(name "TAXDOC",
                     xmlforest((select m.fullname
                                 from   municipality m
                                 where  m.municipality_id = td.municipality_id) as "MUNICIPALITY",
                                xmlstructure.xmlobject14(td.taxobject_id) as "OBJECT",
                                --
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.taxsubject_id) as "DECL_IDN", decl_name as "DECL_NAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.taxsubject_id) as "DECL_IDENTDOC_KIND",
                                decl_identdocno as "DECL_IDENTDOCNO",
                                decl_emission_date as "DECL_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  to_char(r.rdvr_id) = td.decl_rdvr) as "DECL_RDVR",*/
                                 vdeclrdvr  as "DECL_RDVR",
                                xmlstructure.xmladdrnew(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                --
                                xmlstructure.xmladdrnew(td.decl_post_addr) as "DECL_POST_ADDR",
                                (select d.value
                                  from   decode d
                                  where  d.columnname = 'TypeDeclar'
                                  and    d.code = td.kinddecl) as "KINDDECL",
                                --basedoc_taxdoc_id, 
                                taxobjno as "TAXOBJNO", partidano as "PARTIDANO",
                                old_partidano as "OLD_PARTIDANO",
                                (select dt.doccode
                                  from   documenttype dt
                                  where  dt.documenttype_id = td.documenttype_id) as "DOCUMENTTYPE",
                                to_char(taxdocdate, 'dd.mm.yyyy') as "TAXDOCDATE",
                                docno as "DOCNO", docextno as "DOCEXTNO",
                                to_char(doc_date, 'dd.mm.yyyy') as "DOC_DATE",
                                to_char(docext_date, 'dd.mm.yyyy') as "DOCEXT_DATE",
                                to_char(earn_date, 'dd.mm.yyyy') as "EARN_DATE",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = emp_taxsubject_id) as "EMP_IDN", td.emp_name as "EMP_NAME",
                                xmlstructure.xmladdrnew(td.emp_post_addr) as "EMP_POST_ADDR",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.emp_taxsubject_id) as "EMP_IDENTDOC_KIND",
                                td.emp_identdocno as "EMP_IDENTDOCNO", empno as "EMPNO",
                                to_char(emp_emissiondate, 'dd.mm.yyyy') as "EMP_EMISSIONDATE", emp_certify as "EMP_CERTIFY",
                                to_char(EMP_IDENT_EMISSION_DATE, 'dd.mm.yyyy') as "EMP_IDENT_EMISSION_DATE",
                               /* (select r.name
                                  from   rdvr r
                                  where  r.rdvr_id = td.emp_rdvr::numeric) as "EMP_RDVR",*/
                                vemprdvr   as "EMP_RDVR",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = give_reasonreg_id) as "GIVE_REASONREG",
                                xmlstructure.xmlrelief(td.relief_id) as "RELIEF",
                                --user_id, 
                                to_char(docwork_finaldate, 'dd.mm.yyyy') as "DOCWORK_FINALDATE",
                                to_char(receiver_date, 'dd.mm.yyyy') as "RECEIVER_DATE", receiver_note as "RECEIVER_NOTE",
                                to_char(docinput_date, 'dd.mm.yyyy') as "DOCINPUT_DATE", note as "NOTE",
                                (select s.name
                                  from   company c, taxsubject s
                                  where  c.company_id = td.company_id
                                  and    c.taxsubject_id = s.taxsubject_id) as "COMPANY",
                                (select d.value
                                  from   decode d
                                  where  UPPER(d.columnname) = 'DOCSTATUS'
                                  and    d.Code = docstatus) as "DOCSTATUS",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = close__reasonreg_id) as "CLOSE__REASONREG",
                                to_char(close_date, 'dd.mm.yyyy') as "CLOSE_DATE",
                                close_taxdoc_id as "CLOSE_TAXDOC_ID",
                                DECODE(isinheritance, to_number('1'), '��', '��') as "ISINHERITANCE",
                                 --to_char(wait_date,'dd.mm.yyyy') as "WAIT_DATE", 
                                to_user_id as "TO_USER_ID",
                                location_doc as "LOCATION_DOC",
                                to_char(user_date, 'dd.mm.yyyy') as "USER_DATE",
                                user_name ||
                                 (select ' ' || min(u.fullname)
                                  from   users u
                                  where  u.user_id = td.user_id) as "USER_NAME",
                                to_char(begintaxdate, 'dd.mm.yyyy') as "BEGINTAXDATE",
                                to_char(endtaxdate, 'dd.mm.yyyy') as "ENDTAXDATE",
                                isinvalid as "ISINVALID",
                                 --message_code as "MESSAGE_CODE", 
                                --message_date as "MESSAGE_DATE", 
                                receiver_user_id as "RECEIVER_USER_ID",
                                receiver_user_name as "RECEIVER_USER_NAME",
                                xmlstructure.xmlgarbtax(td.taxdoc_id) as "GARBTAX"))
  into   taxdocs
  from   taxdoc td
  where  td.taxdoc_id = iptaxdoc_id;
  return(taxdocs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltaxdoc32(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltaxdoc32(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare
  taxdocs xml;
     vemprdvr character varying(50);
  vdeclrdvr character varying(50);
  vnum numeric;

begin
    begin
    select to_number(td.emp_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vemprdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.emp_rdvr into vemprdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
    begin
    select to_number(td.decl_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vdeclrdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.decl_rdvr into vdeclrdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;

  select xmlelement(name "TAXDOC",
                     xmlforest((select m.fullname
                                 from   municipality m
                                 where  m.municipality_id = td.municipality_id) as "MUNICIPALITY",
                                xmlstructure.xmlobject14(td.taxobject_id) as "OBJECT",
                                --xmlstructure.xmlsubject(td.taxsubject_id) as "TAXSUBJECT", 
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.taxsubject_id) as "DECL_IDN", decl_name as "DECL_NAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.taxsubject_id) as "DECL_IDENTDOC_KIND",
                                decl_identdocno as "DECL_IDENTDOCNO",
                                decl_emission_date as "DECL_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  to_char(r.rdvr_id) = td.decl_rdvr) as "DECL_RDVR",*/
                                  vdeclrdvr as "DECL_RDVR",
                                xmlstructure.xmladdrnew(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                -- xmlstructure.addrstr(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                -- td.decl_perm_addr as "DECL_PERM_ADDR",
                                xmlstructure.xmladdrnew(td.decl_post_addr) as "DECL_POST_ADDR",
                                -- xmlstructure.addrstr(td.decl_post_addr) as "DECL_POST_ADDR",
                                --td.decl_post_addr as "DECL_POST_ADDR", 
                                (select d.value
                                  from   decode d
                                  where  d.columnname = 'TypeDeclar'
                                  and    d.code = td.kinddecl) as "KINDDECL",
                                --basedoc_taxdoc_id, 
                                taxobjno as "TAXOBJNO", partidano as "PARTIDANO",
                                old_partidano as "OLD_PARTIDANO",
                                (select dt.doccode
                                  from   documenttype dt
                                  where  dt.documenttype_id = td.documenttype_id) as "DOCUMENTTYPE",
                                to_char(taxdocdate, 'dd.mm.yyyy') as "TAXDOCDATE",
                                docno as "DOCNO", docextno as "DOCEXTNO",
                                to_char(doc_date, 'dd.mm.yyyy') as "DOC_DATE",
                                to_char(docext_date, 'dd.mm.yyyy') as "DOCEXT_DATE",
                                to_char(earn_date, 'dd.mm.yyyy') as "EARN_DATE",
                                -- act_id as , 
                                -- xmlstructure.xmlsubject(td.emp_taxsubject_id) as "EMP_TAXSUBJECT",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = emp_taxsubject_id) as "EMP_IDN", td.emp_name as "EMP_NAME",
                                xmlstructure.xmladdrnew(td.emp_post_addr) as "EMP_POST_ADDR",
                                --xmlstructure.addrstr(td.emp_post_addr) as "EMP_POST_ADDR",
                                --td.emp_post_addr as "EMP_POST_ADDR",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.emp_taxsubject_id) as "EMP_IDENTDOC_KIND",
                                td.emp_identdocno as "EMP_IDENTDOCNO", empno as "EMPNO",
                                to_char(emp_emissiondate, 'dd.mm.yyyy') as "EMP_EMISSIONDATE", emp_certify as "EMP_CERTIFY",
                                to_char(EMP_IDENT_EMISSION_DATE, 'dd.mm.yyyy') as "EMP_IDENT_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  r.rdvr_id = td.emp_rdvr::numeric) as "EMP_RDVR", */
                                  vemprdvr as "EMP_RDVR", 
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = give_reasonreg_id) as "GIVE_REASONREG",
                                xmlstructure.xmlrelief(td.relief_id) as "RELIEF",
                                --user_id, 
                                to_char(docwork_finaldate, 'dd.mm.yyyy') as "DOCWORK_FINALDATE",
                                to_char(receiver_date, 'dd.mm.yyyy') as "RECEIVER_DATE", receiver_note as "RECEIVER_NOTE",
                                to_char(docinput_date, 'dd.mm.yyyy') as "DOCINPUT_DATE", note as "NOTE",
                                (select s.name
                                  from   company c, taxsubject s
                                  where  c.company_id = td.company_id
                                  and    c.taxsubject_id = s.taxsubject_id) as "COMPANY",
                                (select d.value
                                  from   decode d
                                  where  UPPER(d.columnname) = 'DOCSTATUS'
                                  and    d.Code = docstatus) as "DOCSTATUS",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = close__reasonreg_id) as "CLOSE__REASONREG",
                                to_char(close_date, 'dd.mm.yyyy') as "CLOSE_DATE",
                                close_taxdoc_id as "CLOSE_TAXDOC_ID",
                                DECODE(isinheritance, to_number('1'), '��', '��') as "ISINHERITANCE",
                                 --to_char(wait_date,'dd.mm.yyyy') as "WAIT_DATE", 
                                td.to_user_id as "TO_USER_ID",
                                location_doc as "LOCATION_DOC",
                                to_char(td.user_date, 'dd.mm.yyyy') as "USER_DATE",
                                user_name ||
                                 (select ' ' || min(u.fullname)
                                  from   users u
                                  where  u.user_id = td.user_id) as "USER_NAME",
                                to_char(begintaxdate, 'dd.mm.yyyy') as "BEGINTAXDATE",
                                to_char(endtaxdate, 'dd.mm.yyyy') as "ENDTAXDATE",
                                isinvalid as "ISINVALID",
                                 --message_code as "MESSAGE_CODE", 
                                --message_date as "MESSAGE_DATE", 
                                receiver_user_id as "RECEIVER_USER_ID",
                                receiver_user_name as "RECEIVER_USER_NAME",
                                --------xmlstructure.xmlproperty(td.taxdoc_id)  as "PROPERTY"
                                --  Dotuk e obshtata chast !!!!!!
                                xmlstructure.xmlinheritance(td.taxdoc_id) as "INHERITANCE"))
  into   taxdocs
  from   taxdoc td
  where  td.taxdoc_id = iptaxdoc_id
  
  ;
  return(taxdocs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltaxdoc49(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltaxdoc49(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare

  taxdocs xml;
   vemprdvr character varying(50);
  vdeclrdvr character varying(50);
  vnum numeric;

begin
    begin
    select to_number(td.emp_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vemprdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.emp_rdvr into vemprdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
    begin
    select to_number(td.decl_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vdeclrdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.decl_rdvr into vdeclrdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;

  
  select xmlelement(name "TAXDOC",
                     xmlforest((select m.fullname
                                 from   municipality m
                                 where  m.municipality_id = td.municipality_id) as "MUNICIPALITY",
                                xmlstructure.xmlobject14(td.taxobject_id) as "OBJECT",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.taxsubject_id) as "DECL_IDN", decl_name as "DECL_NAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.taxsubject_id) as "DECL_IDENTDOC_KIND",
                                decl_identdocno as "DECL_IDENTDOCNO",
                                decl_emission_date as "DECL_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  to_char(r.rdvr_id) = td.decl_rdvr) as "DECL_RDVR", */
                                  vdeclrdvr as "DECL_RDVR", 
                                xmlstructure.xmladdrnew(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                xmlstructure.xmladdrnew(td.decl_post_addr) as "DECL_POST_ADDR",
                                (select d.value
                                  from   decode d
                                  where  d.columnname = 'TypeDeclar'
                                  and    d.code = td.kinddecl) as "KINDDECL",
                                taxobjno as "TAXOBJNO", partidano as "PARTIDANO",
                                old_partidano as "OLD_PARTIDANO",
                                (select dt.doccode
                                  from   documenttype dt
                                  where  dt.documenttype_id = td.documenttype_id) as "DOCUMENTTYPE",
                                to_char(taxdocdate, 'dd.mm.yyyy') as "TAXDOCDATE",
                                docno as "DOCNO", docextno as "DOCEXTNO",
                                to_char(doc_date, 'dd.mm.yyyy') as "DOC_DATE",
                                to_char(docext_date, 'dd.mm.yyyy') as "DOCEXT_DATE",
                                to_char(td.earn_date, 'dd.mm.yyyy') as "EARN_DATE",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = emp_taxsubject_id) as "EMP_IDN", td.emp_name as "EMP_NAME",
                                xmlstructure.xmladdrnew(td.emp_post_addr) as "EMP_POST_ADDR",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.emp_taxsubject_id) as "EMP_IDENTDOC_KIND",
                                td.emp_identdocno as "EMP_IDENTDOCNO", empno as "EMPNO",
                                to_char(emp_emissiondate, 'dd.mm.yyyy') as "EMP_EMISSIONDATE", emp_certify as "EMP_CERTIFY",
                                to_char(EMP_IDENT_EMISSION_DATE, 'dd.mm.yyyy') as "EMP_IDENT_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  r.rdvr_id = td.emp_rdvr::numeric) as "EMP_RDVR", */
                                  vemprdvr as "EMP_RDVR", 
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = give_reasonreg_id) as "GIVE_REASONREG",
                                xmlstructure.xmlrelief(td.relief_id) as "RELIEF",
                                to_char(docwork_finaldate, 'dd.mm.yyyy') as "DOCWORK_FINALDATE",
                                to_char(receiver_date, 'dd.mm.yyyy') as "RECEIVER_DATE", receiver_note as "RECEIVER_NOTE",
                                to_char(td.docinput_date, 'dd.mm.yyyy') as "DOCINPUT_DATE", td.note as "NOTE",
                                (select s.name
                                  from   company c, taxsubject s
                                  where  c.company_id = td.company_id
                                  and    c.taxsubject_id = s.taxsubject_id) as "COMPANY",
                                (select d.value
                                  from   decode d
                                  where  UPPER(d.columnname) = 'DOCSTATUS'
                                  and    d.Code = docstatus) as "DOCSTATUS",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = close__reasonreg_id) as "CLOSE__REASONREG",
                                to_char(close_date, 'dd.mm.yyyy') as "CLOSE_DATE",
                                close_taxdoc_id as "CLOSE_TAXDOC_ID",
                                DECODE(isinheritance, to_number('1'), '��', '��') as "ISINHERITANCE", to_user_id as "TO_USER_ID",
                                td.location_doc as "LOCATION_DOC",
                                to_char(td.user_date, 'dd.mm.yyyy') as "USER_DATE",
                                user_name ||
                                 (select ' ' || min(u.fullname)
                                  from   users u
                                  where  u.user_id = td.user_id) as "USER_NAME",
                                to_char(begintaxdate, 'dd.mm.yyyy') as "BEGINTAXDATE",
                                to_char(endtaxdate, 'dd.mm.yyyy') as "ENDTAXDATE",
                                isinvalid as "ISINVALID",
                                receiver_user_id as "RECEIVER_USER_ID",
                                receiver_user_name as "RECEIVER_USER_NAME",
                                --//   do tuk e obshtata chast
                                (select rg.reason_text
                                  from   reasonreg rg
                                  where  rg.reasonreg_id = td.give_reasonreg_id
                                  and    rg.documenttype_id = 25
                                  and    rg.municipality_id = td.municipality_id) as "REASONREGNAME",
                                to_char(td.earn_date, 'dd.mm.yyyy') as "EARNDATE",
                                --    
                                decode(g.isexchange, 1.0, '��', '��') as "ISEXCHANGE",
                                decode(g.isexchange, 1.0,
                                        (select max(e.code)
                                          from   exchange_reg e
                                          where  e.exchange_id = g.paper_exchange_id),
                                        null) as "PAPER_KIND",
                                numbertrim(g.exchange_number) as "EXCHANGE_NUMBER",
                                to_char(g.exchange_value, '999999.99') as "EXCHANGE_VALUE",
                                --
                                decode(g.ispaper, 1.0, '��', '��') as "ISPAPER",
                                decode(g.ispaper, 1.0,
                                        (select max(e.fullname)
                                          from   exchange_reg e
                                          where  e.exchange_id = g.exchange_id), null) as "EXCHANGE_KIND", g.paper_number as "PAPER_NUMBER",
                                to_char(g.paper_value, '999999.99') as "PAPER_VALUE",
                                g.paper_emission as "PAPER_EMISSION",
                                ---
                                decode(g.isotherproperty, 1.0, '��', '��') as "ISOTHERPROPERTY", g.otherproperty as "OTHERPROPERTY",
                                g.otherproperty_number as "OTHERPROPERTY_NUMBER",
                                to_char(g.otherproperty_value, '999999.99') as "OTHERPROPERTY_VALUE",
                                --
                                decode(g.iscondone, 1.0, '��', '��') as "ISCONDONE",
                                to_char(g.condone_value, '999999.99') as "CONDONE_VALUE", g.Note as "NOTE",
                                --
                                decode(g.contrkins, 1.0, '��', '��') as "ISBROTHER",
                                decode(g.contrkins, 2.0, '��', '��') as "ISNOTBROTHER",
                                --
                                decode(g.isfull, 1.0, '��', '��') as "ISFULL",
                                decode(g.isfull, 0.0, '��', '��') as "ISNOTFULL",
                                decode(g.isfull, 1.0, '100',
                                        
                                        (select max(pgp.part)
                                          from   partgetproperty pgp, getproperty g
                                          where  g.taxdoc_id = td.taxdoc_id
                                          and    g.getproperty_id = pgp.getproperty_id
                                          and    pgp.taxsubject_id =
                                                 (select x.taxsubject_id
                                                   from   taxdoc x
                                                   where  x.taxdoc_id = td.taxdoc_id))) as "MYPERCENT",
                                
                                decode(substr(g.reasonfree, 1, 1), '1', '��', '��') as "R1",
                                decode(substr(g.reasonfree, 2, 1), '1', '��', '��') as "R2",
                                decode(substr(g.reasonfree, 3, 1), '1', '��', '��') as "R3",
                                decode(substr(g.reasonfree, 4, 1), '1', '��', '��') as "R4",
                                decode(substr(g.reasonfree, 5, 1), '1', '��', '��') as "R5",
                                decode(substr(g.reasonfree, 6, 1), '1', '��', '��') as "R6",
                                decode(substr(g.reasonfree, 7, 1), '1', '��', '��') as "R7",
                                decode(substr(g.reasonfree, 8, 1), '1', '��', '��') as "R8",
                                decode(substr(g.reasonfree, 9, 1), '1', '��', '��') as "R9",
                                decode(substr(g.reasonfree, 10, 1), '1', '��', '��') as "R10",
                                decode(substr(g.reasonfree, 11, 1), '1', '��', '��') as "R11",
                                decode(substr(g.reasonfree, 12, 1), '1', '��', '��') as "R12",
                                xmlstructure.xmlpartgetproperty(iptaxdoc_id) as "PARTGETPROPERTY"))
  into   taxdocs
  from   taxdoc td, getproperty g
  where  td.taxdoc_id = iptaxdoc_id
  and    td.taxdoc_id = g.taxdoc_id;
  return(taxdocs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltaxdoc54(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltaxdoc54(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare

  taxdocs xml;
    vemprdvr character varying(50);
    vdeclrdvr character varying(50);
    vnum numeric;
begin
begin
    select to_number(td.emp_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vemprdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.emp_rdvr into vemprdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
    begin
    select to_number(td.decl_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vdeclrdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.decl_rdvr into vdeclrdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;

  select xmlelement(name "TAXDOC",
                     xmlforest((select m.fullname
                                 from   municipality m
                                 where  m.municipality_id = td.municipality_id) as "MUNICIPALITY",
                                xmlstructure.xmlobject54(td.taxobject_id) as "OBJECT",
                                --xmlstructure.xmlsubject(td.taxsubject_id) as "TAXSUBJECT", 
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.taxsubject_id) as "DECL_IDN", decl_name as "DECL_NAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.taxsubject_id) as "DECL_IDENTDOC_KIND",
                                decl_identdocno as "DECL_IDENTDOCNO",
                                decl_emission_date as "DECL_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  to_char(r.rdvr_id) = td.decl_rdvr) as "DECL_RDVR",*/
                                 vdeclrdvr  as "DECL_RDVR",
                                xmlstructure.xmladdrnew(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                --xmlstructure.addrstr(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                --td.decl_perm_addr as "DECL_PERM_ADDR",
                                xmlstructure.xmladdrnew(td.decl_post_addr) as "DECL_POST_ADDR",
                                --xmlstructure.addrstr(td.decl_post_addr) as "DECL_POST_ADDR",
                                --td.decl_post_addr as "DECL_POST_ADDR", 
                                (select d.value
                                  from   decode d
                                  where  d.columnname = 'TypeDeclar'
                                  and    d.code = td.kinddecl) as "KINDDECL",
                                --basedoc_taxdoc_id, 
                                taxobjno as "TAXOBJNO", partidano as "PARTIDANO",
                                old_partidano as "OLD_PARTIDANO",
                                (select dt.doccode
                                  from   documenttype dt
                                  where  dt.documenttype_id = td.documenttype_id) as "DOCUMENTTYPE",
                                to_char(taxdocdate, 'dd.mm.yyyy') as "TAXDOCDATE",
                                docno as "DOCNO", docextno as "DOCEXTNO",
                                to_char(doc_date, 'dd.mm.yyyy') as "DOC_DATE",
                                to_char(docext_date, 'dd.mm.yyyy') as "DOCEXT_DATE",
                                to_char(earn_date, 'dd.mm.yyyy') as "EARN_DATE",
                                to_char(change_date, 'dd.mm.yyyy') as "CHANGE_DATE",
                                -- act_id as , 
                                -- xmlstructure.xmlsubject(td.emp_taxsubject_id) as "EMP_TAXSUBJECT",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = emp_taxsubject_id) as "EMP_IDN", td.emp_name as "EMP_NAME",
                                xmlstructure.xmladdrnew(td.emp_post_addr) as "EMP_POST_ADDR",
                                --xmlstructure.addrstr(td.emp_post_addr) as "EMP_POST_ADDR",
                                --td.emp_post_addr as "EMP_POST_ADDR",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.emp_taxsubject_id) as "EMP_IDENTDOC_KIND",
                                td.emp_identdocno as "EMP_IDENTDOCNO", empno as "EMPNO",
                                to_char(emp_emissiondate, 'dd.mm.yyyy') as "EMP_EMISSIONDATE", emp_certify as "EMP_CERTIFY",
                                to_char(EMP_IDENT_EMISSION_DATE, 'dd.mm.yyyy') as "EMP_IDENT_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  r.rdvr_id = td.emp_rdvr::numeric) as "EMP_RDVR",*/
                                 vemprdvr  as "EMP_RDVR",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = give_reasonreg_id) as "GIVE_REASONREG",
                                xmlstructure.xmlrelief(td.relief_id) as "RELIEF",
                                user_id as "USER_ID",
                                to_char(docwork_finaldate, 'dd.mm.yyyy') as "DOCWORK_FINALDATE",
                                to_char(receiver_date, 'dd.mm.yyyy') as "RECEIVER_DATE", receiver_note as "RECEIVER_NOTE",
                                to_char(docinput_date, 'dd.mm.yyyy') as "DOCINPUT_DATE", note as "NOTE",
                                (select s.name
                                  from   company c, taxsubject s
                                  where  c.company_id = td.company_id
                                  and    c.taxsubject_id = s.taxsubject_id) as "COMPANY",
                                (select d.value
                                  from   decode d
                                  where  UPPER(d.columnname) = 'DOCSTATUS'
                                  and    d.Code = docstatus) as "DOCSTATUS",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = close__reasonreg_id) as "CLOSE__REASONREG",
                                to_char(close_date, 'dd.mm.yyyy') as "CLOSE_DATE",
                                close_taxdoc_id as "CLOSE_TAXDOC_ID",
                                DECODE(isinheritance, to_number('1'), '��', '��') as "ISINHERITANCE",
                                 --to_char(wait_date,'dd.mm.yyyy') as "WAIT_DATE", 
                                to_user_id as "TO_USER_ID",
                                location_doc as "LOCATION_DOC",
                                to_char(user_date, 'dd.mm.yyyy') as "USER_DATE",
                                user_name ||
                                 (select ' ' || min(u.fullname)
                                  from   users u
                                  where  u.user_id = td.user_id) as "USER_NAME",
                                to_char(begintaxdate, 'dd.mm.yyyy') as "BEGINTAXDATE",
                                to_char(endtaxdate, 'dd.mm.yyyy') as "ENDTAXDATE",
                                isinvalid as "ISINVALID",
                                 --message_code as "MESSAGE_CODE", 
                                --message_date as "MESSAGE_DATE", 
                                receiver_user_id as "RECEIVER_USER_ID",
                                receiver_user_name as "RECEIVER_USER_NAME",
                                xmlstructure.xmltransport(td.taxdoc_id) as "TRANSPORT"))
  into   taxdocs
  from   taxdoc td
  where  td.taxdoc_id = iptaxdoc_id;
  return(taxdocs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltaxdoc61(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltaxdoc61(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare

  taxdocs xml;
    vemprdvr character varying(50);
    vdeclrdvr character varying(50);
    vnum numeric;
begin
begin
    select to_number(td.emp_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vemprdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.emp_rdvr into vemprdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
    begin
    select to_number(td.decl_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vdeclrdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.decl_rdvr into vdeclrdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
  select xmlelement(name "TAXDOC",
                     xmlforest((select m.fullname
                                 from   municipality m
                                 where  m.municipality_id = td.municipality_id) as "MUNICIPALITY",
                                ------
                                ----xmlstructure.xmlobject54(td.taxobject_id) as "OBJECT", 
                                ---------
                                --xmlstructure.xmlsubject(td.taxsubject_id) as "TAXSUBJECT", 
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.taxsubject_id) as "DECL_IDN", decl_name as "DECL_NAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.taxsubject_id) as "DECL_IDENTDOC_KIND",
                                decl_identdocno as "DECL_IDENTDOCNO",
                                decl_emission_date as "DECL_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  to_char(r.rdvr_id) = td.decl_rdvr) as "DECL_RDVR",*/
                                 vdeclrdvr as "DECL_RDVR",
                                xmlstructure.xmladdrnew(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                --xmlstructure.addrstr(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                --td.decl_perm_addr as "DECL_PERM_ADDR",
                                xmlstructure.xmladdrnew(td.decl_post_addr) as "DECL_POST_ADDR",
                                --xmlstructure.addrstr(td.decl_post_addr) as "DECL_POST_ADDR",
                                --td.decl_post_addr as "DECL_POST_ADDR", 
                                (select d.value
                                  from   decode d
                                  where  d.columnname = 'TypeDeclar'
                                  and    d.code = td.kinddecl) as "KINDDECL",
                                --basedoc_taxdoc_id, 
                                taxobjno as "TAXOBJNO", partidano as "PARTIDANO",
                                old_partidano as "OLD_PARTIDANO",
                                (select dt.doccode
                                  from   documenttype dt
                                  where  dt.documenttype_id = td.documenttype_id) as "DOCUMENTTYPE",
                                to_char(taxdocdate, 'dd.mm.yyyy') as "TAXDOCDATE",
                                docno as "DOCNO", docextno as "DOCEXTNO",
                                to_char(doc_date, 'dd.mm.yyyy') as "DOC_DATE",
                                to_char(docext_date, 'dd.mm.yyyy') as "DOCEXT_DATE",
                                to_char(earn_date, 'dd.mm.yyyy') as "EARN_DATE",
                                to_char(change_date, 'dd.mm.yyyy') as "CHANGE_DATE",
                                -- act_id as , 
                                -- xmlstructure.xmlsubject(td.emp_taxsubject_id) as "EMP_TAXSUBJECT",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = emp_taxsubject_id) as "EMP_IDN", td.emp_name as "EMP_NAME",
                                xmlstructure.xmladdrnew(td.emp_post_addr) as "EMP_POST_ADDR",
                                --xmlstructure.addrstr(td.emp_post_addr) as "EMP_POST_ADDR",
                                --td.emp_post_addr as "EMP_POST_ADDR",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.ettaxsubject_id) as "ETTAXUBJECTIDN",
                                (select ts.name
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.ettaxsubject_id) as "ETTAXUBJECTNAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.emp_taxsubject_id) as "EMP_IDENTDOC_KIND",
                                td.emp_identdocno as "EMP_IDENTDOCNO", empno as "EMPNO",
                                to_char(emp_emissiondate, 'dd.mm.yyyy') as "EMP_EMISSIONDATE", emp_certify as "EMP_CERTIFY",
                                to_char(EMP_IDENT_EMISSION_DATE, 'dd.mm.yyyy') as "EMP_IDENT_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  r.rdvr_id = td.emp_rdvr::numeric) as "EMP_RDVR", */
                                 vemprdvr as "EMP_RDVR",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = give_reasonreg_id) as "GIVE_REASONREG",
                                xmlstructure.xmlrelief(td.relief_id) as "RELIEF",
                                user_id as "USER_ID",
                                to_char(docwork_finaldate, 'dd.mm.yyyy') as "DOCWORK_FINALDATE",
                                to_char(receiver_date, 'dd.mm.yyyy') as "RECEIVER_DATE", receiver_note as "RECEIVER_NOTE",
                                to_char(docinput_date, 'dd.mm.yyyy') as "DOCINPUT_DATE", note as "NOTE",
                                (select s.name
                                  from   company c, taxsubject s
                                  where  c.company_id = td.company_id
                                  and    c.taxsubject_id = s.taxsubject_id) as "COMPANY",
                                (select d.value
                                  from   decode d
                                  where  UPPER(d.columnname) = 'DOCSTATUS'
                                  and    d.Code = docstatus) as "DOCSTATUS",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = close__reasonreg_id) as "CLOSE__REASONREG",
                                to_char(close_date, 'dd.mm.yyyy') as "CLOSE_DATE",
                                close_taxdoc_id as "CLOSE_TAXDOC_ID",
                                DECODE(isinheritance, to_number('1'), '��', '��') as "ISINHERITANCE",
                                 --to_char(wait_date,'dd.mm.yyyy') as "WAIT_DATE", 
                                to_user_id as "TO_USER_ID",
                                location_doc as "LOCATION_DOC",
                                to_char(user_date, 'dd.mm.yyyy') as "USER_DATE",
                                user_name ||
                                 (select ' ' || min(u.fullname)
                                  from   users u
                                  where  u.user_id = td.user_id) as "USER_NAME",
                                to_char(begintaxdate, 'dd.mm.yyyy') as "BEGINTAXDATE",
                                to_char(endtaxdate, 'dd.mm.yyyy') as "ENDTAXDATE",
                                isinvalid as "ISINVALID",
                                 --message_code as "MESSAGE_CODE", 
                                --message_date as "MESSAGE_DATE", 
                                receiver_user_id as "RECEIVER_USER_ID",
                                receiver_user_name as "RECEIVER_USER_NAME",
                                xmlstructure.xmlpatent(td.taxdoc_id) as "PATENT"))
  into   taxdocs
  from   taxdoc td
  where  td.taxdoc_id = iptaxdoc_id;
  return(taxdocs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltaxdoc71(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltaxdoc71(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare

  taxdocs xml;
  
  vemprdvr character varying(50);
  vdeclrdvr character varying(50);
  vnum numeric;

begin
    begin
    select to_number(td.emp_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vemprdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.emp_rdvr into vemprdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;
    begin
    select to_number(td.decl_rdvr) into vnum
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
     select min(r.name) into vdeclrdvr
       from rdvr r
       where r.rdvr_id = vnum;
     exception
      when invalid_text_representation then
     select td.decl_rdvr into vdeclrdvr
     from taxdoc td
     where td.taxdoc_id = iptaxdoc_id;
    end;

  select xmlelement(name "TAXDOC",
                     xmlforest((select m.fullname
                                 from   municipality m
                                 where  m.municipality_id = td.municipality_id) as "MUNICIPALITY",
                                xmlstructure.xmlobject14(td.taxobject_id) as "OBJECT",
                                --
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = td.taxsubject_id) as "DECL_IDN", decl_name as "DECL_NAME",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.taxsubject_id) as "DECL_IDENTDOC_KIND",
                                decl_identdocno as "DECL_IDENTDOCNO",
                                decl_emission_date as "DECL_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  to_char(r.rdvr_id) = td.decl_rdvr) as "DECL_RDVR", */
                                  vdeclrdvr as "DECL_RDVR", 
                                xmlstructure.xmladdrnew(td.decl_perm_addr) as "DECL_PERM_ADDR",
                                --
                                xmlstructure.xmladdrnew(td.decl_post_addr) as "DECL_POST_ADDR",
                                (select d.value
                                  from   decode d
                                  where  d.columnname = 'TypeDeclar'
                                  and    d.code = td.kinddecl) as "KINDDECL",
                                --basedoc_taxdoc_id, 
                                taxobjno as "TAXOBJNO", partidano as "PARTIDANO",
                                old_partidano as "OLD_PARTIDANO",
                                (select dt.doccode
                                  from   documenttype dt
                                  where  dt.documenttype_id = td.documenttype_id) as "DOCUMENTTYPE",
                                to_char(taxdocdate, 'dd.mm.yyyy') as "TAXDOCDATE",
                                docno as "DOCNO", docextno as "DOCEXTNO",
                                to_char(doc_date, 'dd.mm.yyyy') as "DOC_DATE",
                                to_char(docext_date, 'dd.mm.yyyy') as "DOCEXT_DATE",
                                to_char(earn_date, 'dd.mm.yyyy') as "EARN_DATE",
                                (select ts.idn
                                  from   taxsubject ts
                                  where  ts.taxsubject_id = emp_taxsubject_id) as "EMP_IDN", td.emp_name as "EMP_NAME",
                                xmlstructure.xmladdrnew(td.emp_post_addr) as "EMP_POST_ADDR",
                                (select d.value
                                  from   decode d, person p
                                  where  UPPER(d.columnname) = 'IDENTDOC_KIND'
                                  and    d.code = p.identdoc_kind
                                  and    p.taxsubject_id = td.emp_taxsubject_id) as "EMP_IDENTDOC_KIND",
                                td.emp_identdocno as "EMP_IDENTDOCNO", empno as "EMPNO",
                                to_char(emp_emissiondate, 'dd.mm.yyyy') as "EMP_EMISSIONDATE", emp_certify as "EMP_CERTIFY",
                                to_char(EMP_IDENT_EMISSION_DATE, 'dd.mm.yyyy') as "EMP_IDENT_EMISSION_DATE",
                                /*(select r.name
                                  from   rdvr r
                                  where  r.rdvr_id = td.emp_rdvr::numeric) as "EMP_RDVR", */
                                 vemprdvr  as "EMP_RDVR",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = give_reasonreg_id) as "GIVE_REASONREG",
                                xmlstructure.xmlrelief(td.relief_id) as "RELIEF",
                                --user_id, 
                                to_char(docwork_finaldate, 'dd.mm.yyyy') as "DOCWORK_FINALDATE",
                                to_char(receiver_date, 'dd.mm.yyyy') as "RECEIVER_DATE", receiver_note as "RECEIVER_NOTE",
                                to_char(docinput_date, 'dd.mm.yyyy') as "DOCINPUT_DATE", note as "NOTE",
                                (select s.name
                                  from   company c, taxsubject s
                                  where  c.company_id = td.company_id
                                  and    c.taxsubject_id = s.taxsubject_id) as "COMPANY",
                                (select d.value
                                  from   decode d
                                  where  UPPER(d.columnname) = 'DOCSTATUS'
                                  and    d.Code = docstatus) as "DOCSTATUS",
                                (select rr.reason_text
                                  from   reasonreg rr
                                  where  rr.reasonreg_id = close__reasonreg_id) as "CLOSE__REASONREG",
                                to_char(close_date, 'dd.mm.yyyy') as "CLOSE_DATE",
                                close_taxdoc_id as "CLOSE_TAXDOC_ID",
                                DECODE(isinheritance, to_number('1'), '��', '��') as "ISINHERITANCE",
                                 --to_char(wait_date,'dd.mm.yyyy') as "WAIT_DATE", 
                                to_user_id as "TO_USER_ID",
                                location_doc as "LOCATION_DOC",
                                to_char(user_date, 'dd.mm.yyyy') as "USER_DATE",
                                user_name ||
                                 (select ' ' || min(u.fullname)
                                  from   users u
                                  where  u.user_id = td.user_id) as "USER_NAME",
                                to_char(begintaxdate, 'dd.mm.yyyy') as "BEGINTAXDATE",
                                to_char(endtaxdate, 'dd.mm.yyyy') as "ENDTAXDATE",
                                td.isinvalid as "ISINVALID",
                                 --message_code as "MESSAGE_CODE", 
                                --message_date as "MESSAGE_DATE", 
                                receiver_user_id as "RECEIVER_USER_ID",
                                receiver_user_name as "RECEIVER_USER_NAME",
                                decode(g.sw_missing, 0.0, '��', '��') as "SW_MISSING",
                                decode(g.clean_missing, 0.0, '��', '��') as "CLEAN_MISSING",
                                decode(g.depot_missing, 0.0, '��', '��') as "DEPOT_MISSING"))
  into   taxdocs
  from   taxdoc td, garbtax g
  where  td.taxdoc_id = iptaxdoc_id
  and    td.taxdoc_id = g.taxdoc_id
  
  ;
  return(taxdocs);
end;
$function$
; DROP FUNCTION xmlstructure.xmltransport(numeric); 
CREATE OR REPLACE FUNCTION xmlstructure.xmltransport(iptaxdoc_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
DECLARE
  
transp xml;

begin
select xmlforest(
transportno as "TRANSPORTNO", regno as "REGNO", regno_old as "REGNO_OLD", 
xmlstructure.xmlcarreg(carreg_id) as "CARREG", 
(select mr.code || ' ' || mr.name from transpmeansreg mr where mr.transpmeansreg_id = tr.transpmeansreg_id) as "TRANSPMEANSREG", 
--reduce_reasonreg_id as "REDUCE_REASONREG", 
--(select  from reasonreg r where r.municipality_id =  free_reasonreg_id) as "FREE_REASONREG", 
 xmlstructure.xmlsubject(from_taxsubject_id) as "FROM_TAXSUBJECT", 
acquire_from as "ACQUIRE_FROM", acquiredoc as "ACQUIREDOC", 
acquirenote as "ACQUIRENOTE", 
to_char(motion_begindate,'dd.mm.yyyy') as "MOTION_BEGINDATE",
to_char(motion_enddate,'dd.mm.yyyy')   as "MOTION_ENDDATE",
(select d.value from decode d where UPPER(d.columnname) = 'CARSTATUS' and d.code = carstatus) as "CARSTATUS",
 firstreg_year as "FIRSTREG_YEAR", 
(select c.name from city c where c.city_id = city_rdvr_id) as "CITY_RDVR", 
(select min(c.name) from  city c where  city_rdvr_id = c.city_id) as "CITY_RDVR",
--mark_code as "MARK_CODE", model_code as "MODEL_CODE", 
tmodify as "TMODIFY", gate_number as "GATE_NUMBER", 
axes_number as "AXES_NUMBER", 
(select d.value from decode d where upper(d.columnname) = 'KIND_FUEL' and d.code = kind_fuel) as "KIND_FUEL",
 motor_capacity as "MOTOR_CAPACITY", 
power_kw as "POWER_KW", 
horsepower as "HORSEPOWER", produce_year as "PRODUCE_YEAR", ramano as "RAMANO", 
motorno as "MOTORNO", loading_capacity as "LOADING_CAPACITY", tonnage as "TONNAGE", 
(select d.value from decode d where UPPER(d.columnname) = 'KINDHANGING' and d.code = kindhanging) as "KINDHANGING",
max_mass as "MAX_MASS", max_mass_comp as "MAX_MASS_COMP", 
brutto_ton as "BRUTTO_TON", air_weight as "AIR_WEIGHT", custhentryno as "CUSTHENTRYNO", 
to_char(custhentry_date,'dd.mm.yyyy') as "CUSTHENTRY_DATE", 
decode(katalizator,1.0,'��','��') as "KATALIZATOR", 
to_char(katalizator_date,'dd.mm.yyyy') as "KATALIZATOR_DATE",
DECODE(eco_motor,1.0,'��','��') as "ECO_MOTOR",
DECODE(amb_car,1.0,'��','��') as "AMB_CAR", 
DECODE(budget,1.0,'��','��') as "BUDGET", 
DECODE(diplomat,1.0,'��','��') as "DIPLOMAT",
DECODE(bck,1.0,'��','��') as "BCK",
DECODE(isdefect,1.0,'��','��') as "ISDEFECT",  
DECODE(public_transport,1.0,'��','��') as "PUBLIC_TRANSPORT", 
--user_id, user_date, 
errordata as "ERRORDATA", --mark_name as "MARK_NAME", 
--model_name as "MODEL_NAME", 
seat_number as "SEAT_NUMBER", weigth_total as "WEIGTH_TOTAL", 
to_char(gain_date,'dd.mm.yyyy') as "GAIN_DATE", 
DECODE(isdefect,1.0,'��','��') as "ISDEFECT", stealdocno as "STEALDOCNO", 
to_char(stealdocdate,'dd.mm.yyyy') as "STEALDOCDATE", 
to_char(paidpodate,'dd.mm.yyyy')  as "PAIDPODATE",
maxpossible_mass as "MAXPOSSIBLE_MASS",
xmlstructure.xmlparttr(transport_id) as "PARTTR"
)
into transp
from transport tr
where tr.taxdoc_id = iptaxdoc_id
;
return(transp);
end;
$function$
;
