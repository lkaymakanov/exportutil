DROP FUNCTION advance_pkg.chisla(character varying); 
CREATE OR REPLACE FUNCTION advance_pkg.chisla(s character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
    result varchar(400);
  begin
  case s 
	when '1' then return '����';
	when '2' then return '���';
	when '3' then return '���';
	when '4' then return '������';
	when '5' then return '���';
	when '6' then return '����';
	when '7' then return '�����';
	when '8' then return '����';
	when '9' then return '�����';
	else return '';	
  end case;
end;
$function$
; DROP FUNCTION advance_pkg.ret05000_slovom(character varying, character varying, boolean); 
CREATE OR REPLACE FUNCTION advance_pkg.ret05000_slovom(INOUT suma_ character varying, INOUT words character varying, start_ boolean)
 RETURNS record
 LANGUAGE plpgsql
AS $function$ 
  begin
    if SUBSTR(Suma_, 2, 1) = '0'
    then
      if not Start_
      then
        if (SUBSTR(Suma_, 1, 1) = '0')
        then
          Words := Words;
        elsif (SUBSTR(Suma_, 1, 1) = '1')
        then
          Words := Words || ' � ����� ';
        elsif (SUBSTR(Suma_, 1, 1) = '2')
        then
          Words := Words || ' � ��������';
        else
          Words := Words || ' � ' || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '����� ';
        end if;
      else
        if (SUBSTR(Suma_, 1, 1) = '0')
        then
          Words := Words;
        elsif (SUBSTR(Suma_, 1, 1) = '1')
        then
          Words := Words || '����� ';
        elsif (SUBSTR(Suma_, 1, 1) = '2')
        then
          Words := Words || '��������';
        else
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '����� ';
        end if;
      end if;
    else
      if (SUBSTR(Suma_, 1, 1) = '0')
      then
        if SUBSTR(Suma_, 2, 1) = '2'
        then
          Words := Words || ' � ���';
        elsif SUBSTR(Suma_, 2, 1) = '1'
        then
          Words := Words || ' � ����';
        else
          Words := Words || ' � ' || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1));
        end if;
      elsif ( SUBSTR(Suma_, 1, 1) = '1')
      then
        if not Start_
        then
          if SUBSTR(Suma_, 2, 1) = '1'
          then
            Words := Words || ' � ' || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1)) || '������';
          else
            if SUBSTR(Suma_, 2, 1) = '2'
            then
              Words := Words || ' � ����������';
            else
              Words := Words || ' � ' || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1)) ||
                       '�������';
            end if;
          end if;
        else
          if SUBSTR(Suma_, 2, 1) = '1'
          then
            Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1)) || '������';
          else
            if SUBSTR(Suma_, 2, 1) = '2'
            then
              Words := Words || '����������';
            else
              Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1)) || '�������';
            end if;
          end if;
        end if;
      elsif ( SUBSTR(Suma_, 1, 1) = '2')
      then
        if SUBSTR(Suma_, 2, 1) = '2'
        then
          Words := Words || '�������� � ���';
        elsif SUBSTR(Suma_, 2, 1) = '1'
        then
          Words := Words || '�������� � ����';
        else
          Words := Words || '�������� � ' || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1));
        end if;
      else
        if SUBSTR(Suma_, 2, 1) = '2'
        then
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '����� � ' || '���';
        else
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '����� � ' ||
                   advance_pkg.Chisla(SUBSTR(Suma_, 2, 1));
        end if;
      end if;
    end if;
end;

$function$
; DROP FUNCTION advance_pkg.ret05_slovom(character varying, character varying, boolean); 
CREATE OR REPLACE FUNCTION advance_pkg.ret05_slovom(INOUT suma_ character varying, INOUT words character varying, start_ boolean)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
  begin
    if SUBSTR(Suma_, 2, 1) = '0'
    then
      if not Start_
      then
        if (SUBSTR(Suma_, 1, 1) = '0')
        then
          Words := Words;
        elsif (SUBSTR(Suma_, 1, 1) = '1')
        then
          Words := Words || ' � ����� ';
        elsif (SUBSTR(Suma_, 1, 1) = '2')
        then
          Words := Words || ' � ��������';
        else
          Words := Words || ' � ' || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '����� ';
        end if;
      else
        if (SUBSTR(Suma_, 1, 1) = '0')
        then
          Words := Words;
        elsif (SUBSTR(Suma_, 1, 1) = '1')
        then
          Words := Words || '����� ';
        elsif (SUBSTR(Suma_, 1, 1) = '2')
        then
          Words := Words || '��������';
        else
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '����� ';
        end if;
      end if;
    else
      if (SUBSTR(Suma_, 1, 1) = '0')
      then
        if SUBSTR(Suma_, 2, 1) <> '2'
        then
          Words := Words || ' � ' || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1));
        else
          Words := Words || ' � ���';
        end if;
      elsif (SUBSTR(Suma_, 1, 1) = '1')
      then
        if not Start_
        then
          if SUBSTR(Suma_, 2, 1) = '1'
          then
            Words := Words || ' � ' || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1)) || '������';
          else
            if SUBSTR(Suma_, 2, 1) = '2'
            then
              Words := Words || ' � ����������';
            else
              Words := Words || ' � ' || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1)) ||
                       '�������';
            end if;
          end if;
        else
          if SUBSTR(Suma_, 2, 1) = '1'
          then
            Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1)) || '������';
          else
            if SUBSTR(Suma_, 2, 1) = '2'
            then
              Words := Words || '����������';
            else
              Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1)) || '�������';
            end if;
          end if;
        end if;
      elsif (SUBSTR(Suma_, 1, 1) = '2')
      then
        if SUBSTR(Suma_, 2, 1) = '2'
        then
          Words := Words || '�������� � ���';
        else
          Words := Words || '�������� � ' || advance_pkg.Chisla(SUBSTR(Suma_, 2, 1));
        end if;
      else
        if SUBSTR(Suma_, 2, 1) = '2'
        then
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '����� � ' || '���';
        else
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '����� � ' ||
                   advance_pkg.Chisla(SUBSTR(Suma_, 2, 1));
        end if;
      end if;
    end if;
end;

$function$
; DROP FUNCTION advance_pkg.ret06_slovom(character varying, character varying, boolean); 
CREATE OR REPLACE FUNCTION advance_pkg.ret06_slovom(INOUT suma_ character varying, INOUT words character varying, start_ boolean)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
  begin
    if ((SUBSTR(Suma_, 2, 1) <> '0') or (SUBSTR(Suma_, 3, 1) <> '0'))
    then
      if (SUBSTR(Suma_, 1, 1) = '0')
      then
        Words := Words;
      elsif (SUBSTR(Suma_, 1, 1) = '1')
      then
        Words := Words || '��� ';
      elsif (SUBSTR(Suma_, 1, 1) = '2')
      then
        Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '��A ';
      elsif (SUBSTR(Suma_, 1, 1) = '3')
      then
        Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '��A ';
      else
        Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '������ ';
      end if;
    else
      if (SUBSTR(Suma_, 1, 1) = '0')
      then
        Words := Words;
      elsif (SUBSTR(Suma_, 1, 1) = '1')
      then
        Words := Words || ' ��� '; ---' � ��� ';
      elsif (SUBSTR(Suma_, 1, 1) = '2')
      then
        Words := Words || 
                 advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '��� ';
      elsif (SUBSTR(Suma_, 1, 1) = '3')
      then
        Words := Words || 
                 advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '��� ';
      else
        Words := Words || 
                 advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '������ ';
      end if;
    end if;
end;

$function$
; DROP FUNCTION advance_pkg.slovom(character varying); 
CREATE OR REPLACE FUNCTION advance_pkg.slovom(suma__ character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
    i      integer;
    Words  varchar(200);
    Start_ boolean;
    Suma_  varchar(100);
    r record;
  begin
    Start_ := false;
    Words  := '';
    Suma_  := Suma__;
    
    for i in reverse  Length(Suma_) .. 4
    loop
      if (Length(Suma_) = 5) or (Length(Suma_) = 8) or (Length(Suma_) = 11) or
         (Length(Suma_) = 14)
      then
        Start_ := true;
      end if;
      if Length(Suma_) = 16
      then
        if SUBSTR(Suma_, 1, 1) = '1'
        then
          Words := Words || ' ������� ';
        elsif  SUBSTR(Suma_, 1, 1) = '2'
        then
          Words := Words || '��� �������� ';
        else
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || ' �������� ';
        end if;
        Suma_ := Substr(Suma_, 2, 15);
      end if;
      if Length(Suma_) = 15
      then
         r :=  advance_pkg.ret06_slovom(Suma_, Words, Start_);
        Suma_ := Substr(r.Suma_, 2, 14);
        Words := r.Words;

      end if;
      if Length(Suma_) = 14
      then
        r :=  advance_pkg.ret05_Slovom(Suma_, Words, Start_);
        Suma_ := Substr(r.Suma_, 3, 12);
        Words := r.Words || ' �������� ';
      end if;
      if Length(Suma_) = 13
      then
        if  SUBSTR(Suma_, 1, 1) = '1'
        then
          Words := Words || ' ������� ';
        elsif  SUBSTR(Suma_, 1, 1) = '2'
        then
          Words := Words || '��� �������� ';
        else
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || ' �������� ';
        end if;
        Suma_ := Substr(Suma_, 2, 12);
      end if;
      if Length(Suma_) = 12
      then
        r :=  advance_pkg.ret06_Slovom(Suma_, Words, Start_);
        Suma_ := Substr(r.Suma_, 2, 11);
        Words := r.Words;
      end if;
      if Length(Suma_) = 11
      then
        r :=  advance_pkg.ret05_Slovom(Suma_, Words, Start_);
        Suma_ := Substr(r.Suma_, 3, 9);
        Words := r.Words || ' ������� ';
      end if;
      if Length(Suma_) = 10
      then
        if SUBSTR(Suma_, 1, 1) = '1'
        then
          Words := Words || ' ������ ';
        elsif SUBSTR(Suma_, 1, 1) = '2'
        then
          Words := Words || '��� ������� ';
        else
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || ' ������� ';
        end if;
        Suma_ := Substr(Suma_, 2, 9);
      end if;
      if Length(Suma_) = 9
      then
        r :=  advance_pkg.ret06_Slovom(Suma_, Words, Start_);
        Words := r.Words;
        Suma_ := Substr(r.Suma_, 2, 8);
      end if;

      if Length(Suma_) = 8
      then
        r := advance_pkg.ret05000_Slovom(Suma_, Words, Start_);
        Suma_ := Substr(r.Suma_, 3, 6);
        Words := r.Words || ' ������ ';
      end if;
      if Length(Suma_) = 7
      then
        if SUBSTR(Suma_, 1, 1) = '1'
        then
          Words := Words || '������ ';
        else
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || ' ������ ';
        end if;
        Suma_ := Substr(Suma_, 2, 6);
      end if;
     if Length(Suma_) = 6
      then
        if ((SUBSTR(Suma_, 2, 1) <> '0') or (SUBSTR(Suma_, 3, 1) <> '0'))
        then
          if ( SUBSTR(Suma_, 1, 1) = '0')
          then
            Words := Words;
          elsif ( SUBSTR(Suma_, 1, 1) = '1')
          then
            Words := Words || '��� ';
          elsif (SUBSTR(Suma_, 1, 1) = '2')
          then
            Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '��A ';
          elsif (SUBSTR(Suma_, 1, 1) = '3')
          then
            Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '��A ';
          else
            Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '������ ';
          end if;
        else
          if (SUBSTR(Suma_, 1, 1) = '0')
          then
            Words := Words;
          elsif (SUBSTR(Suma_, 1, 1) = '1')
          then
            Words := Words || ' ��� '; -- ' � ��� ';
          elsif (SUBSTR(Suma_, 1, 1) = '2')
          then
            Words := Words || 
                     advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '��� ';
          elsif (SUBSTR(Suma_, 1, 1) = '3')
          then
            Words := Words || 
                     advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '��� ';
          else
            Words := Words || 
                     advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || '������ ';
          end if;
        end if;
        Suma_ := SubStr(Suma_, 2, 5);
      end if;
      if Length(Suma_) = 5
      then
        r := advance_pkg.ret05_Slovom(Suma_, Words, Start_);
        Suma_ := r.Suma_;
        Words := r.Words;
        Words := Words || ' ��. � ' || Substr(Suma_, 4, 2) || ' ��.';
        return(Words);
        exit;
      end if;
      if Length(Suma_) = 4
      then
        if (SUBSTR(Suma_, 1, 1) = '0')
        then
          Words := Words || Substr(Suma_, 3, 2) || ' ��.';
        elsif (SUBSTR(Suma_, 1, 1) = '2')
        then
          Words := Words || '��� ��. � ' || Substr(Suma_, 3, 2) || '��.';
        else
          Words := Words || advance_pkg.Chisla(SUBSTR(Suma_, 1, 1)) || ' ��. � ' ||
                   Substr(Suma_, 3, 2) || ' ��.';
        end if;
      end if;
    end loop;
    return(Words);
end;

$function$
; DROP FUNCTION advance_pkg.slovom_str(character varying); 
CREATE OR REPLACE FUNCTION advance_pkg.slovom_str(sumastr character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  
    vstr varchar(400);
  begin
    if instr(sumastr, '.') = 0
    then
      vstr := sumastr || '.00';
    else
      vstr := substr(sumastr, 1, instr(sumastr, '.') - 1);
      vstr := vstr || rpad(substr(sumastr, instr(sumastr, '.'), 3), 3, '0');
    end if;
    vstr := advance_pkg.Slovom(vstr);
    return(vstr);
  end ;

$function$
; DROP FUNCTION advance_pkg.slovombyparam(character varying); 
CREATE OR REPLACE FUNCTION advance_pkg.slovombyparam(OUT return_val character varying, suma__ character varying, OUT sslovom character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                          
    ErrMsg varchar(200);
  begin
    sSlovom    := advance_pkg.Slovom(Suma__);
    return_val := 'Ok';
    return;
  exception
    when others then
      perform NOM_PKG.ErrManage(ErrMsg);
      --rollback;
      return_val := ErrMsg;
      return;
end;

$function$
;
