DROP FUNCTION plvdate.unuse_easter(); 
CREATE OR REPLACE FUNCTION plvdate.unuse_easter()
 RETURNS boolean
 LANGUAGE sql
 STRICT
AS $function$SELECT plvdate.use_easter(false); SELECT NULL::boolean;$function$
; DROP FUNCTION plvdate.use_easter(); 
CREATE OR REPLACE FUNCTION plvdate.use_easter()
 RETURNS boolean
 LANGUAGE sql
 STRICT
AS $function$SELECT plvdate.use_easter(true); SELECT NULL::boolean;$function$
; DROP FUNCTION plvdate.use_easter(boolean); 
CREATE OR REPLACE FUNCTION plvdate.use_easter(boolean)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_use_easter$function$
; DROP FUNCTION plvdate.using_easter(); 
CREATE OR REPLACE FUNCTION plvdate.using_easter()
 RETURNS boolean
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_using_easter$function$
; DROP FUNCTION plvdate.version(); 
CREATE OR REPLACE FUNCTION plvdate.version()
 RETURNS cstring
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_version$function$
; DROP FUNCTION plvdate.add_bizdays(date, integer); 
CREATE OR REPLACE FUNCTION plvdate.add_bizdays(date, integer)
 RETURNS date
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvdate_add_bizdays$function$
; DROP FUNCTION plvdate.bizdays_between(date, date); 
CREATE OR REPLACE FUNCTION plvdate.bizdays_between(date, date)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvdate_bizdays_between$function$
; DROP FUNCTION plvdate.days_inmonth(date); 
CREATE OR REPLACE FUNCTION plvdate.days_inmonth(date)
 RETURNS integer
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_days_inmonth$function$
; DROP FUNCTION plvdate.default_holidays(text); 
CREATE OR REPLACE FUNCTION plvdate.default_holidays(text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_default_holidays$function$
; DROP FUNCTION plvdate.include_start(); 
CREATE OR REPLACE FUNCTION plvdate.include_start()
 RETURNS boolean
 LANGUAGE sql
 STRICT
AS $function$SELECT plvdate.include_start(true); SELECT NULL::boolean;$function$
; DROP FUNCTION plvdate.include_start(boolean); 
CREATE OR REPLACE FUNCTION plvdate.include_start(boolean)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_include_start$function$
; DROP FUNCTION plvdate.including_start(); 
CREATE OR REPLACE FUNCTION plvdate.including_start()
 RETURNS boolean
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_including_start$function$
; DROP FUNCTION plvdate.isbizday(date); 
CREATE OR REPLACE FUNCTION plvdate.isbizday(date)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvdate_isbizday$function$
; DROP FUNCTION plvdate.isleapyear(date); 
CREATE OR REPLACE FUNCTION plvdate.isleapyear(date)
 RETURNS boolean
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_isleapyear$function$
; DROP FUNCTION plvdate.nearest_bizday(date); 
CREATE OR REPLACE FUNCTION plvdate.nearest_bizday(date)
 RETURNS date
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvdate_nearest_bizday$function$
; DROP FUNCTION plvdate.next_bizday(date); 
CREATE OR REPLACE FUNCTION plvdate.next_bizday(date)
 RETURNS date
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvdate_next_bizday$function$
; DROP FUNCTION plvdate.noinclude_start(); 
CREATE OR REPLACE FUNCTION plvdate.noinclude_start()
 RETURNS boolean
 LANGUAGE sql
 STRICT
AS $function$SELECT plvdate.include_start(false); SELECT NULL::boolean;$function$
; DROP FUNCTION plvdate.prev_bizday(date); 
CREATE OR REPLACE FUNCTION plvdate.prev_bizday(date)
 RETURNS date
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvdate_prev_bizday$function$
; DROP FUNCTION plvdate.set_nonbizday(text); 
CREATE OR REPLACE FUNCTION plvdate.set_nonbizday(text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_set_nonbizday_dow$function$
; DROP FUNCTION plvdate.set_nonbizday(date); 
CREATE OR REPLACE FUNCTION plvdate.set_nonbizday(date)
 RETURNS boolean
 LANGUAGE sql
 STRICT
AS $function$SELECT plvdate.set_nonbizday($1, false); SELECT NULL::boolean;$function$
; DROP FUNCTION plvdate.set_nonbizday(date, boolean); 
CREATE OR REPLACE FUNCTION plvdate.set_nonbizday(date, boolean)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_set_nonbizday_day$function$
; DROP FUNCTION plvdate.unset_nonbizday(text); 
CREATE OR REPLACE FUNCTION plvdate.unset_nonbizday(text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_unset_nonbizday_dow$function$
; DROP FUNCTION plvdate.unset_nonbizday(date); 
CREATE OR REPLACE FUNCTION plvdate.unset_nonbizday(date)
 RETURNS boolean
 LANGUAGE sql
 STRICT
AS $function$SELECT plvdate.unset_nonbizday($1, false); SELECT NULL::boolean;$function$
; DROP FUNCTION plvdate.unset_nonbizday(date, boolean); 
CREATE OR REPLACE FUNCTION plvdate.unset_nonbizday(date, boolean)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvdate_unset_nonbizday_day$function$
;
