DROP FUNCTION plvlex.tokens(text, boolean, boolean); 
CREATE OR REPLACE FUNCTION plvlex.tokens(str text, skip_spaces boolean, qualified_names boolean, OUT pos integer, OUT token text, OUT code integer, OUT class text, OUT separator text, OUT mod text)
 RETURNS SETOF record
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvlex_tokens$function$
;
