DROP FUNCTION plvsubst.setsubst(); 
CREATE OR REPLACE FUNCTION plvsubst.setsubst()
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvsubst_setsubst_default$function$
; DROP FUNCTION plvsubst.setsubst(text); 
CREATE OR REPLACE FUNCTION plvsubst.setsubst(str text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvsubst_setsubst$function$
; DROP FUNCTION plvsubst.string(text, text[]); 
CREATE OR REPLACE FUNCTION plvsubst.string(template_in text, values_in text[])
 RETURNS text
 LANGUAGE sql
 STRICT
AS $function$SELECT plvsubst.string($1,$2, NULL);$function$
; DROP FUNCTION plvsubst.string(text, text); 
CREATE OR REPLACE FUNCTION plvsubst.string(template_in text, vals_in text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plvsubst_string_string$function$
; DROP FUNCTION plvsubst.string(text, text[], text); 
CREATE OR REPLACE FUNCTION plvsubst.string(template_in text, values_in text[], subst text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plvsubst_string_array$function$
; DROP FUNCTION plvsubst.string(text, text, text); 
CREATE OR REPLACE FUNCTION plvsubst.string(template_in text, vals_in text, delim_in text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plvsubst_string_string$function$
; DROP FUNCTION plvsubst.string(text, text, text, text); 
CREATE OR REPLACE FUNCTION plvsubst.string(template_in text, vals_in text, delim_in text, subst_in text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plvsubst_string_string$function$
; DROP FUNCTION plvsubst.subst(); 
CREATE OR REPLACE FUNCTION plvsubst.subst()
 RETURNS text
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$plvsubst_subst$function$
;
