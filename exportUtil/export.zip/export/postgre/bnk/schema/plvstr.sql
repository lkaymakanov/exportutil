DROP FUNCTION plvstr.betwn(text, integer, integer); 
CREATE OR REPLACE FUNCTION plvstr.betwn(str text, start integer, _end integer)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.betwn($1,$2,$3,true);$function$
; DROP FUNCTION plvstr.betwn(text, text, text); 
CREATE OR REPLACE FUNCTION plvstr.betwn(str text, start text, _end text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$ SELECT plvstr.betwn($1,$2,$3,1,1,true,false);$function$
; DROP FUNCTION plvstr.betwn(text, integer, integer, boolean); 
CREATE OR REPLACE FUNCTION plvstr.betwn(str text, start integer, _end integer, inclusive boolean)
 RETURNS text
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_betwn_i$function$
; DROP FUNCTION plvstr.betwn(text, text, text, integer, integer); 
CREATE OR REPLACE FUNCTION plvstr.betwn(str text, start text, _end text, startnth integer, endnth integer)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$ SELECT plvstr.betwn($1,$2,$3,$4,$5,true,false);$function$
; DROP FUNCTION plvstr.betwn(text, text, text, integer, integer, boolean, boolean); 
CREATE OR REPLACE FUNCTION plvstr.betwn(str text, start text, _end text, startnth integer, endnth integer, inclusive boolean, gotoend boolean)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plvstr_betwn_c$function$
; DROP FUNCTION plvstr.instr(text, text); 
CREATE OR REPLACE FUNCTION plvstr.instr(str text, patt text)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_instr2$function$
; DROP FUNCTION plvstr.instr(text, text, integer); 
CREATE OR REPLACE FUNCTION plvstr.instr(str text, patt text, start integer)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_instr3$function$
; DROP FUNCTION plvstr.instr(text, text, integer, integer); 
CREATE OR REPLACE FUNCTION plvstr.instr(str text, patt text, start integer, nth integer)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_instr4$function$
; DROP FUNCTION plvstr.is_prefix(text, text); 
CREATE OR REPLACE FUNCTION plvstr.is_prefix(str text, prefix text)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.is_prefix($1,$2,true);$function$
; DROP FUNCTION plvstr.is_prefix(integer, integer); 
CREATE OR REPLACE FUNCTION plvstr.is_prefix(str integer, prefix integer)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_is_prefix_int$function$
; DROP FUNCTION plvstr.is_prefix(bigint, bigint); 
CREATE OR REPLACE FUNCTION plvstr.is_prefix(str bigint, prefix bigint)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_is_prefix_int64$function$
; DROP FUNCTION plvstr.is_prefix(text, text, boolean); 
CREATE OR REPLACE FUNCTION plvstr.is_prefix(str text, prefix text, cs boolean)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_is_prefix_text$function$
; DROP FUNCTION plvstr.left(text, integer); 
CREATE OR REPLACE FUNCTION plvstr."left"(str text, n integer)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_left$function$
; DROP FUNCTION plvstr.lpart(text, text); 
CREATE OR REPLACE FUNCTION plvstr.lpart(str text, div text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.lpart($1,$2, 1, 1, false); $function$
; DROP FUNCTION plvstr.lpart(text, text, integer); 
CREATE OR REPLACE FUNCTION plvstr.lpart(str text, div text, start integer)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.lpart($1,$2, $3, 1, false); $function$
; DROP FUNCTION plvstr.lpart(text, text, integer, integer); 
CREATE OR REPLACE FUNCTION plvstr.lpart(str text, div text, start integer, nth integer)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.lpart($1,$2, $3, $4, false); $function$
; DROP FUNCTION plvstr.lpart(text, text, integer, integer, boolean); 
CREATE OR REPLACE FUNCTION plvstr.lpart(str text, div text, start integer, nth integer, all_if_notfound boolean)
 RETURNS text
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_lpart$function$
; DROP FUNCTION plvstr.lstrip(text, text); 
CREATE OR REPLACE FUNCTION plvstr.lstrip(str text, substr text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.lstrip($1, $2, 1); $function$
; DROP FUNCTION plvstr.lstrip(text, text, integer); 
CREATE OR REPLACE FUNCTION plvstr.lstrip(str text, substr text, num integer)
 RETURNS text
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_lstrip$function$
; DROP FUNCTION plvstr.normalize(text); 
CREATE OR REPLACE FUNCTION plvstr.normalize(str text)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_normalize$function$
; DROP FUNCTION plvstr.right(text, integer); 
CREATE OR REPLACE FUNCTION plvstr."right"(str text, n integer)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_right$function$
; DROP FUNCTION plvstr.rpart(text, text); 
CREATE OR REPLACE FUNCTION plvstr.rpart(str text, div text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.rpart($1,$2, 1, 1, false); $function$
; DROP FUNCTION plvstr.rpart(text, text, integer); 
CREATE OR REPLACE FUNCTION plvstr.rpart(str text, div text, start integer)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.rpart($1,$2, $3, 1, false); $function$
; DROP FUNCTION plvstr.rpart(text, text, integer, integer); 
CREATE OR REPLACE FUNCTION plvstr.rpart(str text, div text, start integer, nth integer)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.rpart($1,$2, $3, $4, false); $function$
; DROP FUNCTION plvstr.rpart(text, text, integer, integer, boolean); 
CREATE OR REPLACE FUNCTION plvstr.rpart(str text, div text, start integer, nth integer, all_if_notfound boolean)
 RETURNS text
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_rpart$function$
; DROP FUNCTION plvstr.rstrip(text, text); 
CREATE OR REPLACE FUNCTION plvstr.rstrip(str text, substr text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.rstrip($1, $2, 1); $function$
; DROP FUNCTION plvstr.rstrip(text, text, integer); 
CREATE OR REPLACE FUNCTION plvstr.rstrip(str text, substr text, num integer)
 RETURNS text
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_rstrip$function$
; DROP FUNCTION plvstr.rvrs(text); 
CREATE OR REPLACE FUNCTION plvstr.rvrs(str text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.rvrs($1,1,NULL);$function$
; DROP FUNCTION plvstr.rvrs(text, integer); 
CREATE OR REPLACE FUNCTION plvstr.rvrs(str text, start integer)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.rvrs($1,$2,NULL);$function$
; DROP FUNCTION plvstr.rvrs(text, integer, integer); 
CREATE OR REPLACE FUNCTION plvstr.rvrs(str text, start integer, _end integer)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plvstr_rvrs$function$
; DROP FUNCTION plvstr.substr(text, integer); 
CREATE OR REPLACE FUNCTION plvstr.substr(str text, start integer)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_substr2$function$
; DROP FUNCTION plvstr.substr(text, integer, integer); 
CREATE OR REPLACE FUNCTION plvstr.substr(str text, start integer, len integer)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$plvstr_substr3$function$
; DROP FUNCTION plvstr.swap(text, text); 
CREATE OR REPLACE FUNCTION plvstr.swap(str text, replace text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT plvstr.swap($1,$2,1, NULL);$function$
; DROP FUNCTION plvstr.swap(text, text, integer, integer); 
CREATE OR REPLACE FUNCTION plvstr.swap(str text, replace text, start integer, length integer)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plvstr_swap$function$
;
