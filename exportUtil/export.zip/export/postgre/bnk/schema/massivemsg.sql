DROP FUNCTION massivemsg.massmsgdbf(numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION massivemsg.massmsgdbf(OUT return_val character varying, itaxsubject_id numeric, itaxdoc_id numeric, itaxperiod_id numeric, iuser_id numeric, OUT vlines character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare 
    ErrMsg varchar(300);
    -- message
    subjects cursor (vGroupActionID numeric, vFromSeqNom varchar, vTotalSeqNom varchar, vKindIDN varchar) is
      select a.seqnom,
             a.taxsubject_id,
             a.taxdoc_id,
             ts.idn,
             ts.name ime,
             getaddress(ts.present_clientaddr_id) address,
             td.partidano parno
        from action a
        inner join taxsubject ts on a.taxsubject_id = ts.taxsubject_id
        inner join taxdoc td on a.taxdoc_id = td.taxdoc_id
       where a.groupaction_id = 0 --iGroupAction_id
         and a.seqnom >= vFromSeqNom
         and a.seqnom <= (vTotalSeqNom + vFromSeqNom - 1)
         and ts.taxsubject_id != (select c.configvalue from config c where upper(c.name) = 'TAXSUBJECT_ID')
         and ts.kind_idn = vKindIDN
         --and td.documenttype_id = 22 -- Decl 14
      --and (select count(distinct x.taxdoc_id) from action x where x.taxsubject_id = a.taxsubject_id) > 2
      --group by a.taxsubject_id
       order by seqnom, ime;
    message cursor (vtaxsubject_id numeric, vtaxdoc_id numeric, vtaxperiod_id numeric) is
      select distinct rpadc(ts.idn, 10) EGN,
                      decode(ts.kind_idn,
                             '10',
                             '1',
                             '21',
                             '2',
                             '11',
                             '',
                             '1') FEGN,
                      rpadc(' ', 7) NOP,
                      rpadc(td.docno ||'/'|| to_char(td.doc_date, 'dd.mm.yyyy'), 27) VHN_D,
                      rpadc(td.partidano, 13) PARNOM,
                      --rpadc(m.old_code, 4) DSKOD,
                      rpadc((select mu.fullname
                              from municipality mu 
                             where mu.municipality_id = tobj.municipality_id), 20) DSIMOT,
                      rpadc(replace(ts.name, chr(9)), 60) IME1,
                      rpadc(' ', 20) IME2,
                      rpadc((select d.value
                              from decode d
                             where upper(d.columnname) = 'KINDPROPERTY'
                               and d.code = tobj.kindproperty), 13) VIM,
                      rpadc(replace((select decode(city.kind_city,
                                          '1',
                                          '��.',
                                          '2',
                                          '�.',
                                          '3',
                                          '����.',
                                          '??') || city.name 
                              from city inner join address a on city.city_id = a.city_id
                             where a.address_id = tobj.address_id),'@',' '), 25) NASMI,
                      rpadc((select mu.fullname
                              from municipality mu
                             where mu.municipality_id = tobj.municipality_id), 25) OBSIME,
                      rpadc((select c.ekatte
                              from City c, address a
                             where c.city_id = a.city_id
                               and a.address_id = tobj.address_id), 5) KN_I,
                      rpadc(replace(REGEXP_REPLACE(getaddress(tobj.address_id),'(�){1,}','N:'),'@',' ') , 46) ULIME,
                      rpadc(' ', 4) DSLICE,
                      -- ?
                      rpadc((select c.name
                              from City c, address a
                             where c.city_id = a.city_id
                               and a.address_id = ts.post_clientaddr_id), 25) NASML,
                      rpadc((select m.fullname
                              from municipality m inner join address a on m.municipality_id = a.municipality_id
                             where a.address_id = ts.post_clientaddr_id), 25) OBSLIME,
                      rpadc((select c.ekatte
                              from City c inner join address a on c.city_id = a.city_id
                             where a.address_id = ts.post_clientaddr_id), 5) KN_L,
                      rpadc('9', 4) PKODL,
                      rpadc(replace(REGEXP_REPLACE(GetAddress(ts.post_clientaddr_id),'(�){1,}', 'N:'),'@',' '), 46) ULIMEL,
                      rpadc((select p.name
                              from province p 
                              inner join municipality m on p.province_id = m.province_id
                             where m.municipality_id = tobj.municipality_id), 25) AOBL,
                      rpadc(' ', 8) DATSAOB,
                      rpadc(td.location_doc, 9) KASH,
                      td.taxdoc_id, ds.doccode
        from Taxdoc td
        join Debtsubject ds on td.taxdoc_id = ds.document_id
        join Taxobject tobj on td.taxobject_id = tobj.taxobject_id
        join Documenttype dt on td.documenttype_id = dt.documenttype_id
        left join Taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
        left join Municipality m on td.municipality_id = m.municipality_id
        left join Province p on m.province_id = p.province_id
       where /*td.docno = ds.docno
         and td.doc_date = ds.doc_date*/
             td.taxdoc_id = vtaxdoc_id
         --and td.docstatus = '30'
         and ts.taxsubject_id = vtaxsubject_id
         and ds.taxperiod_id = vtaxperiod_id
       order by parnom;
    -- installments
    installments cursor(vTaxDoc_id numeric, vTaxSubject_id numeric, vTaxPeriod_id numeric, vIsSofia int) is
      select to_char((select sum(nvl(dpp.sumval,0))
                           from debtpartproperty dpp  
                          where dpp.debtsubject_id = (select max(xds.debtsubject_id)
                                                        from debtsubject xds
                                                       where xds.document_id = ds.document_id
                                                         and xds.taxsubject_id = ds.taxsubject_id
                                                         and xds.taxperiod_id = ds.taxperiod_id
                                                         and xds.kinddebtreg_id = 2
                                                         and nvl(xds.typecorr,0) != 2)) 
                         , '99999999990.99') DOC,
             (select max(xds.debtsubject_id)
                from debtsubject xds
               where xds.document_id = ds.document_id
                 and xds.taxsubject_id = ds.taxsubject_id
                 and xds.taxperiod_id = ds.taxperiod_id
                 and xds.kinddebtreg_id = 5) PROM_debtsubject_id,
             (select sum(nvl(xds.totaltax,0))
                from debtsubject xds
               where xds.document_id = ds.document_id
                 and xds.taxsubject_id = ds.taxsubject_id
                 and xds.taxperiod_id = ds.taxperiod_id
                 and xds.kinddebtreg_id = 2) DAN1,
             (select sum(nvl(xds.totaltax,0))
                from debtsubject xds
               where xds.document_id = ds.document_id
                 and xds.taxsubject_id = ds.taxsubject_id
                 and xds.taxperiod_id = ds.taxperiod_id
                 and xds.kinddebtreg_id = 5) SMET,
             case when (ds.kinddebtreg_id = 5) and (vIsSofia = 1) then sum(ds.totaltax)
                  else                      
                   sum(nvl(ds.totaltax,0)) -
                   (sanction_pkg.tempdiscount((select di.debtinstalment_id
                                                from debtinstalment di
                                               where di.debtsubject_id = (select max(xds.debtsubject_id)   
                                                                            from debtsubject xds
                                                                           where xds.document_id = ds.document_id
                                                                             and xds.taxsubject_id = ds.taxsubject_id
                                                                             and xds.taxperiod_id = ds.taxperiod_id
                                                                             /*and xds.kinddebtreg_id = 5*/)

                                                 and di.instno = '2'),
                                              trunc(sysdate)))
             end DDAN_SSMET5,
             (select sum(nvl(di.instsum,0))
                from debtinstalment di
               where di.debtsubject_id in (select xds.debtsubject_id   
                                            from debtsubject xds
                                           where xds.document_id = ds.document_id
                                             and xds.taxsubject_id = ds.taxsubject_id
                                             and xds.taxperiod_id = ds.taxperiod_id
                                             and xds.kinddebtreg_id = ds.kinddebtreg_id
                                          )
                 and di.instno = '1') DDAN_SSMET25,
             case when (ds.kinddebtreg_id = 5) and (vIsSofia = 1) then 
                   (select sum(nvl(di.instsum,0))
                      from debtinstalment di
                     where di.debtsubject_id in (select xds.debtsubject_id   
                                                  from debtsubject xds
                                                 where xds.document_id = ds.document_id
                                                   and xds.taxsubject_id = ds.taxsubject_id
                                                   and xds.taxperiod_id = ds.taxperiod_id
                                                   and xds.kinddebtreg_id = ds.kinddebtreg_id
                                                )
                       and di.instno = '4')
                  else 
                   (select sum(nvl(di.instsum,0))
                      from debtinstalment di
                     where di.debtsubject_id in (select xds.debtsubject_id
                                                  from debtsubject xds
                                                 where xds.document_id = ds.document_id
                                                   and xds.taxsubject_id = ds.taxsubject_id
                                                   and xds.taxperiod_id = ds.taxperiod_id
                                                   and xds.kinddebtreg_id = ds.kinddebtreg_id
                                                )
                       and di.instno = '2') 
             end DDAN_SSMET25_4,
             max(ds.debtsubject_id) debtsubject_id
        from TaxDoc td
        inner join Debtsubject ds on td.taxdoc_id = ds.document_id 
                                 and nvl(ds.typecorr,0) != 2
                                 --and ds.docno = td.docno
                                 --and ds.doc_date = td.doc_date
        inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
       where td.taxdoc_id = vTaxDoc_id
         and ds.taxsubject_id = vTaxSubject_id
         and ds.taxperiod_id = vtaxperiod_id
         and ds.prtdate is null
       group by ds.kinddebtreg_id, ds.document_id, ds.taxsubject_id, ds.taxperiod_id
       order by ds.kinddebtreg_id;
    bank cursor(vMunicipality_id numeric) is
      select replace(b.name,'@',' ') banka, REGEXP_REPLACE(trim(a.iban),'( ){1,}','') bsm, b.bic bkod
        from baccount a, bank b
       where b.bank_id = a.bank_id
         and a.isactive = 1
         and a.isbase = 1
         and a.municipality_id = vMunicipality_id;
    promtbo cursor(vdebtsubj_id numeric) is
      select p.debtsubject_id,
             p.taxperiod_id,
             decode(sign(h.kindhomeobjreg_id - 6), -1, 0, 1) kod,
             to_char(min(p.promiltbo),'90.99') promil
        from debtpartproperty p inner join homeobj h on h.homeobj_id = p.homeobj_id
       where p.debtsubject_id = vdebtsubj_id
       group by p.debtsubject_id,
                p.taxperiod_id,
                decode(sign(h.kindhomeobjreg_id - 6), -1, 0, 1)
       order by p.debtsubject_id,
                decode(sign(h.kindhomeobjreg_id - 6), -1, 0, 1);
    i                numeric;
    vPromil          varchar(100);
    vProm0           varchar(50);
    vProm1           varchar(50);
    vSuma5           numeric(9, 2);
    vSuma25          numeric(9, 2);
    vSuma25_4        numeric(9, 2);
    vLine            varchar(1024);
    vMunicipality_ID numeric;
    visSofia         int;
    vDSKOD           varchar(4); 
  begin
    vPromil   := '';
    vLine     := '';
    vSuma5    := 0;
    vSuma25   := 0;
    vSuma25_4 := 0;
    visSofia  := 0;
    vDSKOD    := ''; 

    --  v_file := UTL_FILE.FOPEN('','SAOB.csv','W');
    --  DBMS_OUTPUT.put_line('');
      i := 1; -- �����

      select m.municipality_id, case when m1.municipality_id is not null then 1 else 0 end, rpadc(m.old_code,4) 
        into vMunicipality_ID, visSofia, vDSKOD 
        from users u 
        inner join municipality m on m.municipality_id = u.municipality_id
        left outer join municipality m1 on m.parentmunicipality_id = m1.municipality_id         
       where u.user_id = iUser_id;
   
    /*vLines(i) := 'EGN,C,10' || '@' || 'FEGN,C,1' || '@' || 'NOP,N,7,0' || '@' ||
                   'VHN_D,C,27' || '@' || 'PARNOM,C,15' || '@' ||
                   'DSKOD,C,4' || '@' || 'DSIMOT,C,20' || '@' ||
                   'IME1,C,30' || '@' || 'IME2,C,20' || '@' || 'VIM,C,13' || '@' ||
                   'NASMI,C,25' || '@' || 'OBSIME,C,25' || '@' ||
                   'KN_I,C,5' || '@' || 'ULIME,C,46' || '@' || 'DSLICE,C,4' || '@' ||
                   'NASML,C,25' || '@' || 'OBSLIME,C,25' || '@' ||
                   'KN_L,C,5' || '@' || 'PKODL,C,4' || '@' || 'ULIMEL,C,46' || '@' ||
                   'DOC,N,12,2' || '@' || 'PROMSM,C,32' || '@' ||
                   'DAN1,N,9,2' || '@' || 'SMET,N,9,2' || '@' ||
                   'DDAN5,N,9,2' || '@' || 'DDAN25,N,9,2' || '@' ||
                   'DDAN25_4,N,9,2' || '@' || 'SSMET5,N,9,2' || '@' ||
                   'SSMET25,N,9,2' || '@' || 'SSMET254,N,9,2' || '@' ||
                   'SUMA5,N,9,2' || '@' || 'SUMA25,N,9,2' || '@' ||
                   'SUMA25_4,N,9,2' || '@' || 'IMENASM,C,25' || '@' ||
                   'BANKA,C,30' || '@' || 'BSM,C,22' || '@' || 'ADRES,C,40' || '@' ||
                   'BKOD,C,10' || '@' || 'AOBL,C,25' || '@' ||
                   'DATSAOB,D,8' || '@' || 'PECHAT,C,1' || '@' ||
                   'KASH,C,9' || '@' || 'OSNJ,C,1' || '@' || 'EGN_N,C,10'; */

    --  for rec in subjects(iGroupAction_id, iFromSeqNom, iTotalSeqNom, iKindIDN ) loop
        for mes in message(iTaxSubject_id, itaxdoc_id, iTaxperiod_id) loop
          vPromil := '';
          vSuma5 := 0;
          vSuma25 := 0;
          vSuma25_4 := 0;
          vLines  := vLines || mes.egn || '@' || mes.fegn || '@' || mes.nop || '@' ||
                               mes.vhn_d || '@' || mes.parnom || '@' || vDSKOD/*mes.dskod*/ || '@' ||
                               mes.dsimot || '@' || mes.ime1 || '@' || mes.ime2 || '@' ||
                               mes.vim || '@' || mes.nasmi || '@' || mes.obsime || '@' ||
                               mes.kn_i || '@' || mes.ulime || '@' || mes.dslice || '@' ||
                               mes.nasml || '@' || mes.obslime || '@' || mes.kn_l || '@' ||
                               mes.pkodl || '@' || mes.ulimel || '@'; -- delimiter = 20
          for ins in installments(mes.taxdoc_id,itaxsubject_id,iTaxperiod_id, visSofia) loop
            vLine := '';
            if installments%rowcount < 2 then
              vLine := nvl(ins.doc,0) || '@'; -- delimiter = 21

              for prom in promtbo(ins.prom_debtsubject_id) loop
              /*  if nvl(promtbo_rec.promil, 0) > 0 then
                  case promtbo_rec.kod
                    when 0 then  -- �������
                      if (vProm0 is null) then
                        vProm0 := nvl(promtbo_rec.promil, 0);
                      else
                        vProm0 := vProm0 || ', ' || nvl(promtbo_rec.promil, 0); -- �������
                      end if;
                    when 1 then -- ���������
                      if (vProm1 is null) then
                        vProm1 := nvl(promtbo_rec.promil, 0);
                      else
                        vProm1 := vProm1 || ', ' || nvl(promtbo_rec.promil, 0); -- ���������
                      end if;
                  end case;
                end if;
                
                if (vProm0 is not null) or (vProm1 is not null) then
                  vPDPrt(i) := ' ������� �� ��� : ';
                  if (trim(per_rec.doccode) = '17') then
                    case
                      when (vProm1 is null) and (vProm0 is null) then
                        vPDPrt(i) := vPDPrt(i);
                      else
                        vPDPrt(i) := vPDPrt(i) || ' ' || ' ��������� ����� ' || vProm0 || vProm1;
                    end case;
                  else
                    case
                      when (vProm0 is null) then
                        vPDPrt(i) := vPDPrt(i);
                      else
                        vPDPrt(i) := vPDPrt(i) || ' ������� ����� ' || vProm0;
                    end case;
                    case
                      when (vProm1 is null) then
                        vPDPrt(i) := vPDPrt(i);
                      else
                        vPDPrt(i) := vPDPrt(i) || ' ' || ' ��������� ����� ' || vProm1;
                    end case;
                  end if;
                  i := i + 1;
                end if; */

                --if nvl(prom.promil,0) > 0 then
                --vPromil := rpadc(case prom.kod when 0 then '���.' else '�����.' end || nvl(prom.promil,0),32)||'@';
                if (mes.doccode = '17') then 
                  vPromil := rpadc('�����.' || nvl(prom.promil, 0) || '%o', 32) || '@'; -- delimiter = 22
                else 
                  vPromil := rpadc('���.' || nvl(prom.promil, 0) || '%o, ' ||
                                   ' �����.' || nvl(prom.promil, 0) || '%o', 32) || '@'; -- delimiter = 22                  
                end if;  
                --end if;
              end loop;
              if length(vPromil) > 0 then
                vLine := vLine || vPromil;
              else
                vLine := vLine || rpadc(' ', 32) || '@'; -- delimiter = 22
              end if;

              vLine := vLine || to_char(nvl(ins.dan1,0), '9999990.99') || '@' ||
                       to_char(nvl(ins.smet,0), '9999990.99') || '@'; -- delimiter = 24
            end if;

            vLine := vLine || to_char(nvl(ins.ddan_ssmet5,0), '999990.99') || '@' ||
                     to_char(nvl(ins.ddan_ssmet25,0), '999990.99') || '@' ||
                     to_char(nvl(ins.ddan_ssmet25_4,0), '999990.99') || '@'; -- delimiter = 27

            vSuma5    := vSuma5 + nvl(ins.ddan_ssmet5,0);
            vSuma25   := vSuma25 + nvl(ins.ddan_ssmet25,0);
            vSuma25_4 := vSuma25_4 + nvl(ins.ddan_ssmet25_4,0);

            vLines := vLines || vLine;

          end loop;

          vLines := vLines || to_char(vSuma5, '999990.99') || '@' ||
                              to_char(vSuma25, '999990.99') || '@' ||
                              to_char(vSuma25_4, '999990.99') || '@'; -- delimiter = 30
          
          begin -- IMENASM �������� ����� �� ����� �����
            select vLines || rpadc(nvl(o.note, ' '), 25) || '@' -- delimiter = 31
              into vLines
              from Users u inner join Office o on o.office_id = u.office_id
             where o.isactive = 1
               and u.user_id = iUser_id;
          exception
          when NO_DATA_FOUND then
            begin
              vLines := vLines || rpadc(' ', 25) || '@';  -- delimiter = 31
            end;
          end;  
          
          for b in bank(vMunicipality_ID) loop
            
            vLines := vLines || b.banka || '@' || rpadc(b.bsm,22) || '@'; -- delimiter = 33

            begin -- Adres �� ����� �����
              select vLines || rpadc(nvl(o.address, ' '), 40) || '@' -- delimiter = 34
                into vLines
                from Users u inner join Office o on o.office_id = u.office_id
               where o.isactive = 1
                 and u.user_id = iUser_id;
            exception
              when NO_DATA_FOUND then
                begin
                  vLines := vLines || rpadc(' ', 40) || '@'; -- delimiter = 34
                end;

            end;

            vLines := vLines || rpadc(b.bkod,8) || '@';  -- delimiter = 35

          end loop;

          vLines := vLines || mes.aobl || '@' || mes.datsaob || '@'; -- delimiter = 37
          -- pechat
          --if trim(mes.doccode) = '17' then
          select case (select count(*)
                     from firm_1417 f
                    where f.taxdoc_id_17 = mes.taxdoc_id
                      and f.no_active is null)
                   when 0 then
                    vLines || '0'
                   else
                    vLines || '1'
                 end || '@'  -- delimiter = 38
            into vLines
            from dual;
           --else
            -- vLines := vLines || '0';
           --end if; 
          -- kashon
          vLines := vLines || mes.kash || '@'; -- delimiter = 39

          -- isbasehome
          select case (select count(*)
                     from debtsubject ds inner join debtpartproperty dpp on ds.debtsubject_id = dpp.debtsubject_id
                    where ds.document_id = mes.taxdoc_id
                      and ds.kinddebtreg_id = 2
                      and dpp.isbasehome > 0)
                   when 0 then
                    vLines || '0'
                   else
                    vLines || '1'
                 end 
            into vLines
            from dual;

          vLines := vLines || '@' || rpadc(' ',10); -- EGN_N  delimiter = 40

          i := i + 1;
        end loop;

       /* if mod(i,100) = 0 then
          commit;
        end if;  */
     -- end loop;
      
    commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        rollback;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := errmsg;
        return;

      end;

end;
$function$
; DROP FUNCTION massivemsg.massmsgxmld14(numeric, numeric, character varying, integer, numeric); 
CREATE OR REPLACE FUNCTION massivemsg.massmsgxmld14(itaxsubject_id numeric, itaxperiod_id numeric, imsgnum character varying, irecap integer, iuser_id numeric)
 RETURNS xml
 LANGUAGE plpgsql
AS $function$
declare
  -- municipality logo
  title cursor(vUser_id numeric) is
    select xmlelement(name header,
                       xmlforest(m.ebk_code, m.fullname,
                                  getaddress(ts.present_clientaddr_id) as addr,
                                  m.municipality_id)) as header
    from   municipality m, config c, taxsubject ts, users u
    where  u.user_id = vUser_id
    and    u.municipality_id = m.municipality_id
    and    m.municipality_id = c.municipality_id
    and    upper(c.name) = 'TAXSUBJECT_ID'
    and    c.configvalue ::integer = ts.taxsubject_id ::integer;


  -- message
  message cursor(vtaxsubject_id numeric, vtaxperiod_id numeric) is
    select
    
     xmlelement(name docid, max(ds.document_id)) docid,
     xmlelement(name subheader,
                 xmlforest(max((select d.value
                                from   decode d
                                where  upper(d.columnname) = 'KIND_IDN'
                                and    d.code = ts.kind_idn)) as kind_idn,
                            max(ts.idn) as idn, max(td.partidano) as partidano,
                            32 as msgnum)) subheader,
     -- TaxSubject
     xmlelement(name subject,
                 xmlforest(max(ts.name) as name,
                            max(GetAddress(ts.present_clientaddr_id)) as tsaddr,
                            max((select m.fullname
                                 from   municipality mu, Address adr
                                 where  mu.municipality_id = adr.municipality_id
                                 and    adr.address_id = ts.present_clientaddr_id)) as
                             tsmunicipality)) subject,
     -- TaxObject     
     xmlelement(name object,
                 xmlforest(max((select d.value
                                from   decode d
                                where  upper(d.columnname) = 'KINDPROPERTY'
                                and    d.code = tobj.kindproperty)) as kindprop,
                            max((td.docno || '/' ||
                                 to_char(td.doc_date, 'dd.mm.yyyy') || ' �.')) as
                             docno, max(getaddress(tobj.address_id)) as objaddr,
                            max((select mu.fullname
                                 from   municipality mu
                                 where  mu.municipality_id = tobj.municipality_id)) as
                             objmunicipality)) as object
    from   Taxdoc td
    inner  join Debtsubject ds
    on     td.taxdoc_id = ds.document_id
    inner  join Taxobject tobj
    on     td.taxobject_id = tobj.taxobject_id
    inner  join Documenttype dt
    on     td.documenttype_id = dt.documenttype_id
    left   join Municipality m
    on     td.municipality_id = m.municipality_id
    left   join Taxsubject ts
    on     ds.taxsubject_id = ts.taxsubject_id
    where  td.documenttype_id = 21
    and    ts.taxsubject_id = vtaxsubject_id
    and    ds.taxperiod_id = vtaxperiod_id
    group  by ds.document_id;

  periods cursor(vTaxDoc_id numeric, vTaxSubject_id numeric) is
    select xmlelement(name title,
                       xmlforest(to_char(max(ds.tax_begidate), 'yyyy') as
                                  taxperiod,
                                  to_char(nvl(max(ds.totalval), 0.0), '999990.99') as
                                   totalval, ds.taxperiod_id,
                                  max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                                       from   debtinstalment di
                                       where  di.debtsubject_id = ds.debtsubject_id
                                       and    di.instno = '1')) as period,
                                  max(nvl(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                                                     from   debtinstalment di
                                                                     where  di.debtsubject_id =
                                                                            ds.debtsubject_id
                                                                     and    di.instno = '4'),
                                                                     trunc(current_date)),
                                           0.0)) as dis,
                                  max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                                       from   debtinstalment di
                                       where  di.debtsubject_id = ds.debtsubject_id
                                       and    di.instno = '1')) as tdate1,
                                  max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                                       from   debtinstalment di
                                       where  di.debtsubject_id = ds.debtsubject_id
                                       and    di.instno = '2')) as tdate2,
                                  max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                                       from   debtinstalment di
                                       where  di.debtsubject_id = ds.debtsubject_id
                                       and    di.instno = '3')) as tdate3,
                                  max((select to_char(di.termpay_date, 'dd.mm.yyyy')
                                       from   debtinstalment di
                                       where  di.debtsubject_id = ds.debtsubject_id
                                       and    di.instno = '4')) as tdate4,
                                  max(ds.debtsubject_id) as debtsubject_id)) title
    from   TaxDoc td, Debtsubject ds, taxsubject ts, kinddebtreg dr
    where  td.taxdoc_id = vTaxDoc_id
    and    ds.taxsubject_id = vTaxSubject_id
    and    ds.prtdate is null
    and    td.taxdoc_id = ds.document_id
    and    nvl(ds.docno, '*') = nvl(td.docno, '*')
    and    nvl(ds.doc_date, current_date) = nvl(td.doc_date, current_date)
    and    ds.taxsubject_id = ts.taxsubject_id
    and    ds.kinddebtreg_id = dr.kinddebtreg_id
    and    ds.taxperiod_id = itaxperiod_id
    group  by ts.taxsubject_id, ds.taxperiod_id;

  -- installments   
  inst    cursor(vTaxDoc_id numeric, vTaxSubject_id numeric, vTaxPeriod_id numeric) is
    select xmlforest(decode(trim(dr.code), '2400', '���', dr.name) as kinddebt,
                      to_char(ds.totaltax, '99999990.99') as sumall,
                      to_char(ds.tax_begidate, 'yyyy') as taxperiod,
                      (select to_char(di.termpay_date, 'dd.mm.yyyy')
                        from   debtinstalment di
                        where  di.debtsubject_id = ds.debtsubject_id
                        and    di.instno = '1') as period,
                      nvl(sanction_pkg.tempdiscount((select di.debtinstalment_id
                                                     from   debtinstalment di
                                                     where  di.debtsubject_id =
                                                            ds.debtsubject_id
                                                     and    di.instno = '4'),
                                                     trunc(current_date)), 0.0) as dis,
                      to_char(nvl((select di.instsum
                                   from   debtinstalment di
                                   where  di.debtsubject_id = ds.debtsubject_id
                                   and    di.instno = '1'), 0.0), '9999990.99') as v1,
                      to_char(nvl((select di.instsum
                                   from   debtinstalment di
                                   where  di.debtsubject_id = ds.debtsubject_id
                                   and    di.instno = '2'), 0.0), '9999990.99') as v2,
                      to_char(nvl((select di.instsum
                                   from   debtinstalment di
                                   where  di.debtsubject_id = ds.debtsubject_id
                                   and    di.instno = '3'), 0.0), '9999990.99') as v3,
                      to_char(nvl((select di.instsum
                                   from   debtinstalment di
                                   where  di.debtsubject_id = ds.debtsubject_id
                                   and    di.instno = '4'), 0.0), '9999990.99') as v4,
                      (select to_char(di.termpay_date, 'dd.mm.yyyy')
                        from   debtinstalment di
                        where  di.debtsubject_id = ds.debtsubject_id
                        and    di.instno = '4') as tdate2,
                      to_char((select nvl(b.interestsum, 0.0) +
                                       sanction_pkg.tempint(di.debtinstalment_id,
                                                            trunc(current_date))
                               from   debtinstalment di, baldebtinst b
                               where  di.debtsubject_id = ds.debtsubject_id
                               and    di.instno = '1'
                               and    b.debtinstalment_id = di.debtinstalment_id),
                               '999990.99') as lixv1,
                      to_char((select nvl(b.interestsum, 0.0) +
                                       sanction_pkg.tempint(di.debtinstalment_id,
                                                            trunc(current_date))
                               from   debtinstalment di, baldebtinst b
                               where  di.debtsubject_id = ds.debtsubject_id
                               and    di.instno = '2'
                               and    b.debtinstalment_id = di.debtinstalment_id),
                               '999990.99') as lixv2,
                      to_char((select nvl(b.interestsum, 0.0) +
                                       sanction_pkg.tempint(di.debtinstalment_id,
                                                            trunc(current_date))
                               from   debtinstalment di, baldebtinst b
                               where  di.debtsubject_id = ds.debtsubject_id
                               and    di.instno = '3'
                               and    b.debtinstalment_id = di.debtinstalment_id),
                               '999990.99') as lixv3,
                      to_char((select nvl(b.interestsum, 0.0) +
                                       sanction_pkg.tempint(di.debtinstalment_id,
                                                            trunc(current_date))
                               from   debtinstalment di, baldebtinst b
                               where  di.debtsubject_id = ds.debtsubject_id
                               and    di.instno = '4'
                               and    b.debtinstalment_id = di.debtinstalment_id),
                               '999990.99') as lixv4,
                      ds.debtsubject_id as debtsubject_id) as installments
    from   TaxDoc td, Debtsubject ds, taxsubject ts, kinddebtreg dr
    where  td.taxdoc_id = vTaxDoc_id
    and    ds.taxsubject_id = vTaxSubject_id
    and    ds.taxperiod_id = vtaxperiod_id
    and    ds.prtdate is null
    and    td.taxdoc_id = ds.document_id
    and    ds.docno = td.docno
    and    ds.doc_date = td.doc_date
    and    ds.taxsubject_id = ts.taxsubject_id
    and    ds.kinddebtreg_id = dr.kinddebtreg_id
    order  by ds.tax_begidate, ds.kinddebtreg_id;

  offices cursor(vMunicipality_id numeric) is
    select xmlelement(name office,
                       xmlforest(o.fullname as name, nvl(o.address, '') as addr)) office
    from   Users u, Office o
    where  o.isactive = 1
    and    o.office_id = u.office_id
    and    u.user_id = iUser_id;

  bank    cursor(vMunicipality_id numeric) is
    select xmlelement(name bank, xmlforest(b.name, a.iban, b.bic)) bank
    from   baccount a, bank b
    where  b.bank_id = a.bank_id
    and    a.isactive = 1
    and    a.isbase = 1
    and    a.municipality_id = vMunicipality_id;

  --��� ��������� ������ ������������ �� �� ��������:

  promtbo        cursor(vdebtsubj_id numeric) is
    select p.taxperiod_id,
           decode(sign(h.kindhomeobjreg_id - 6) ::integer, -1, 0, 1) kod,
           min(nvl(p.promiltbo, 0.0)) promiltbo
    from   debtpartproperty p, homeobj h
    where  h.homeobj_id = p.homeobj_id
    and    p.debtsubject_id = vdebtsubj_id
    group  by p.debtsubject_id, p.taxperiod_id,
              decode(sign(h.kindhomeobjreg_id - 6) ::integer, -1, 0, 1)
    order  by p.debtsubject_id,
              decode(sign(h.kindhomeobjreg_id - 6) ::integer, -1, 0, 1);

  xmlmess14      xml;
  xmldebtrows    xml;
  xmlpartmessage xml;

  vPromil          varchar(35);
  vMunicipality_id numeric;
  vSumDis          numeric(18, 2);
  vSumv1           numeric(18, 2);
  vSumv2           numeric(18, 2);
  vSumv3           numeric(18, 2);
  vSumv4           numeric(18, 2);
  vSumAll          numeric(18, 2);
  vSumLix          numeric(18, 2);
  vOperator        varchar(200);
  rowcount         integer;
  x                xml;
  d                varchar;
begin
  vSumDis := 0;
  vSumv1  := 0;
  vSumv2  := 0;
  vSumv3  := 0;
  vSumv4  := 0;
  vSumAll := 0;
  if (iTaxSubject_id = 0)
  then
    return(null);
  end if;

  select u.username || '/' || u.fullname
  into   voperator
  from   users u
  where  u.user_id = iuser_id;
  for tit in title(iUser_id)
  loop
    d                := getStringVal(xpath('//municipality_id/text()',
                                           tit.header));
    vMunicipality_id := d ::numeric;
    xmlmess14        := tit.header;
  end loop;
  rowcount := 1;
  for msg in message(iTaxSubject_id, iTaxPeriod_id)
  loop
    if rowcount > 1
    then
      xmlpartmessage := null;
      xmldebtrows    := null;
      --if i > 60 then
      --vPDPrt[i]  := chr(12);
    end if;
    rowcount := 2;
    select xmlconcat(xmlpartmessage, msg.docid, msg.subheader, msg.subject,
                      msg.object)
    into   xmlpartmessage
    from   dual;
    for per in periods(getStringVal(xpath('/docid/text()', msg.docid)),
                       itaxsubject_id)
    loop
      vSumDis := 0;
      vSumv1  := 0;
      vSumv2  := 0;
      vSumv3  := 0;
      vSumv4  := 0;
      vSumAll := 0;
      vSumLix := 0;
      select xmlconcat(xmlpartmessage, per.title)
      into   xmlpartmessage
      from   dual;
      for rec in promtbo(getStringVal(xpath('//debtsubject_id/text()', per.title)))
      loop
        if rec.PROMILTBO > 0
        then
          vPromil := case rec.kod
                       when 0 then
                        '������� ����� '
                       else
                        '��������� ����� '
                     end || to_char(rec.promiltbo, '99990.99');
          select xmlconcat(xmlpartmessage, xmlelement(name Promil, vPromil))
          into   xmlpartmessage
          from   dual;
        end if;
      end loop;
      -- Installments    
    
      for rec in inst(getStringVal(xpath('/docid/text()', msg.docid)),
                      itaxsubject_id, itaxperiod_id)
      loop
        x := rec.installments;
        if existsnode('/lixv1', rec.installments)
        then
          vSumLix := nvl(getStringVal(xpath('//lixv1/text()', rec.installments)),
                         0) +
                     nvl(getStringVal(xpath('//lixv2/text()', rec.installments)),
                         0) +
                     nvl(getStringVal(xpath('//lixv3/text()', rec.installments)),
                         0) +
                     nvl(getStringVal(xpath('//lixv4/text()', rec.installments)),
                         0);
          vSumAll := vSumAll +
                     getStringVal(xpath('/sumall/text()', rec.installments)) +
                     vSumLix;
          vSumDis := vSumDis +
                     nvl(getStringVal(xpath('/dis/text()', rec.installments)), 0);
          vSumv1  := vSumv1 +
                     nvl(getStringVal(xpath('/v1/text()', rec.installments)), 0) +
                     nvl(getStringVal(xpath('/lixv1/text()', rec.installments)),
                         0);
          vSumv2  := vSumv2 +
                     nvl(getStringVal(xpath('/v2/text()', rec.installments)), 0) +
                     nvl(getStringVal(xpath('/lixv2/text()', rec.installments)),
                         0);
          vSumv3  := vSumv3 +
                     nvl(getStringVal(xpath('/v3/text()', rec.installments)), 0) +
                     nvl(getStringVal(xpath('/lixv3/text()', rec.installments)),
                         0);
          vSumv4  := vSumv4 +
                     nvl(getStringVal(xpath('/v4/text()', rec.installments)), 0) +
                     nvl(getStringVal(xpath('/lixv4/text()', rec.installments)),
                         0);
        end if;
        x := xmlelement(name debtrow,
                        xmlattributes(extractvalue(rec.installments,
                                                    '/debtsubject_id') as
                                       debtsubject_id), rec.installments);
        select xmlconcat(xmldebtrows,
                          xmlelement(name debtrow,
                                      xmlattributes(extractvalue(rec.installments,
                                                                  '/debtsubject_id') as
                                                     debtsubject_id),
                                      rec.installments))
        into   xmldebtrows
        from   dual;
      
      end loop;
    
      select xmlconcat(xmlpartmessage, xmlelement(name debtrows, xmldebtrows))
      into   xmlpartmessage
      from   dual;
    
      select xmlconcat(xmlpartmessage,
                        xmlelement(name allsumrow,
                                    xmlforest(to_char(vSumAll, '9999990.99') as
                                               vsumall,
                                               to_char(vSumDis, '9999990.99') as
                                                vsumdis,
                                               to_char(vSumv1, '9999990.99') as
                                                vsumv1,
                                               to_char(vSumv2, '9999990.99') as
                                                vsumv2,
                                               to_char(vSumv3, '9999990.99') as
                                                vsumv3,
                                               to_char(vSumv4, '9999990.99') as
                                                vsumv4)))
      into   xmlpartmessage
      from   dual;
    
    end loop;
  
    for rec in offices(vMunicipality_id)
    loop
      select xmlconcat(xmlpartmessage, rec.office)
      into   xmlpartmessage
      from   dual;
    end loop;
    for rec in bank(vMunicipality_id)
    loop
      select xmlconcat(xmlpartmessage, rec.bank)
      into   xmlpartmessage
      from   dual;
    end loop;
  
    select xmlconcat(xmlmess14,
                      xmlelement(name "partmessage",
                                  xmlattributes(getStringVal(xpath('/docid/text()',
                                                                    msg.docid)) as
                                                 DOCUMENT_ID), xmlpartmessage))
    into   xmlmess14
    from   dual;
  
  end loop;

  select xmlelement(name "MESSAGES", xmlmess14)
  into   xmlmess14
  from   dual;

  return(xmlmess14);

end;
$function$
;
