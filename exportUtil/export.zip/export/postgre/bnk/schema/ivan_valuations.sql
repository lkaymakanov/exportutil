DROP FUNCTION ivan_valuations.dogforyear(numeric); 
CREATE OR REPLACE FUNCTION ivan_valuations.dogforyear(ipuser_id numeric, OUT opstatus character varying, OUT errn numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
    cr cursor is
      select *
      from   taxdoc td
      where  td.documenttype_id = 32
      and    td.docstatus = '30';
    rdog          record;
    vCurYear      varchar(10);
    vTaxPeriod_Id numeric;
    vdebtsubj_id  numeric;
  
  begin
    select min(c.ConfigValue)
    into   vCurYear -- YYYY
    from   Config c
    where  name = 'TAXYEAR';
  
    select min(tp.TaxPeriod_Id)
    into   vTaxPeriod_Id
    from   TaxPeriod tp
    where  tp.TaxPerKind = '0'
    and    to_char(tp.Begin_Date, 'yyyy') = vCurYear;
    if vTaxPeriod_Id is null
    then
      opStatus := '������ ������';
      return;
    end if;
    errn := 0;
    open cr;
    loop
      fetch cr
        into rdog;
      exit when not found;
      select min(ds.debtsubject_id)
      into   vdebtsubj_id
      from   debtsubject ds
      where  ds.document_id = rdog.taxdoc_id
      and    ds.taxperiod_id = vTaxPeriod_Id;
      if vdebtsubj_id is null
      then
        perform ivan_valuations.DogValuation(rdog.taxdoc_id, ipuser_id, opStatus);
        if opStatus <> 'OK'
        then
          errn := errn + 1;
        end if;
      end if;
    end loop;
     --zatvarya cursora na 20.09.2011
    close cr;
    opStatus := 'OK';
  exception
    when others then
      opStatus := sqlerrm;
end;
$function$
; DROP FUNCTION ivan_valuations.dogvaluation(numeric, numeric); 
CREATE OR REPLACE FUNCTION ivan_valuations.dogvaluation(iptaxdoc_id numeric, ipuser_id numeric, OUT opstatus character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  cr cursor is
    select di.debtinstalment_id, di.termpay_date,
           nvl(bi.interestsum, 0.0) interestsum, bi.instSum, ds.kinddebtreg_id,
           ds.debtsubject_id, ds.kindparreg_id
    from   debtinstalment di
    join   debtsubject ds
    on     di.debtsubject_id = ds.debtsubject_id
    left   outer join baldebtinst bi
    on     di.debtinstalment_Id = bi.debtinstalment_Id
    where  ds.document_id = ipTaxDoc_Id
    and    nvl(bi.instSum, 0.0) > 0.0 -- samo za neplateni otataci prispada po vnoski
    order  by di.termpay_date;

  r  record;

  ErrTxt             varchar(255);
  i                  integer;
  vCurYear           varchar(128);
  vTaxYear           numeric;
  vBeginTaxDate      TaxDoc.BeginTaxDate%type;
  vTaxPeriod_Id      TaxPeriod.TaxPeriod_Id%type;
  vMunicipality_Id   TaxDoc.Municipality_Id%type;
  vParReg            numeric;
  vChargeValue       ChargePrice.ChargeValue%type;
  vChargeValueMonth  ChargePrice.ChargeValue%type;
  vTDateBegin        date;
  vTDateEnd          date;
  vPer               numeric;
  vDebtSubject_Id    DebtSubject.DebtSubject_Id%type;
  vDebtInstalment_Id DebtInstalment.DebtInstalment_Id%type;
  vFreeSum_Obj       DebtSubject.FreeSum_Obj%type;
  vFreeSum_Subj      DebtSubject.FreeSum_Subj%type;
  vReasonFree        Dog.ReasonFree%type;
  vpartno            varchar(40);
  vtaxsubj_id        numeric;
  vcity_id           numeric;
  vclose_date        date;
  vdocstatus         varchar(10);
  voldsaldo          numeric;
  vOperation_Id      numeric;
  voversubject_Id    numeric;
  vtaxsubject_id     numeric;
  vearndate          date;
  vtermdate          date;
  vchipdate          date;
begin
  ErrTxt   := 'Start_';
  opStatus := '';
  select count(*), max(d.ReasonFree), max(td.BeginTaxDate),
         max(td.Municipality_Id), max(td.taxsubject_id), max(td.close_date),
         max(td.partidano), max(td.docstatus), max(td.taxsubject_id),
         max(td.earn_date),max(d.chipdate)
  into   i, vReasonFree, vBeginTaxDate, vMunicipality_Id, vtaxsubj_id,
         vclose_date, vpartno, vdocstatus, vtaxsubject_id, vearndate,  vchipdate
  from   TaxDoc td, Dog d
  where  td.TaxDoc_Id = ipTaxDoc_Id
  and    td.TaxDoc_Id = d.TaxDoc_Id;
  if i <> 1
  then
    opStatus := '���������� ����� � Dog';
    return;
  end if;

  select c.ConfigValue
  into   vCurYear -- YYYY
  from   Config c
  where  name = 'TAXYEAR';
  if Length(vCurYear) = 4
  then
    null;
  else
    opStatus := '������ ����� ������� ������ � Config';
    return;
  end if;

  select count(*), min(tp.TaxPeriod_Id)
  into   i, vTaxPeriod_Id
  from   TaxPeriod tp
  where  tp.TaxPerKind = '0'
  and    tp.Begin_Date::date <= To_Date('01.01.' || vCurYear, 'dd.mm.yyyy')
  and    tp.End_Date::date >= To_Date('31.12.' || vCurYear, 'dd.mm.yyyy');
  if i <> 1
  then
    opStatus := '������ ����� ������� ������ � TaxPeriod';
    return;
  end if;
  if vpartno is null
  then
   -- perform getpartidano(vMunicipality_Id, cast(32 as numeric), vpartno);
     vpartno := public.getpartidano(vMunicipality_Id, cast(32 as numeric));
    update taxdoc 
    set    partidano = vpartno
    where  taxdoc_id = ipTaxDoc_Id
    and    partidano is null;
  end if;
  vcity_id := null;
  if vtaxsubj_id is not null
  then
    select max(a.city_id)
    into   vcity_id
    from   taxsubject ts, address a
    where  ts.taxsubject_id = vtaxsubj_id
    and    ts.permanent_clientaddr_id = a.address_id;
  end if;
  if vclose_date is null
  then
    select count(*)
    into   i
    from   DebtSubject ds
    where  ds.Document_Id = ipTaxDoc_Id
    and    ds.TaxPeriod_Id = vTaxPeriod_Id
    and    ds.Municipality_Id = vMunicipality_Id
    and    ds.KindDebtReg_Id = 37;
    if i > 0
    then
      opStatus := 'OK';
      return;
    end if;
    vTaxYear := To_Number(To_Char(vBeginTaxDate::date, 'yyyy'));
    while vTaxYear <= To_Number(vCurYear)
    loop
      select max(tp.TaxPeriod_Id)
      into   vTaxPeriod_Id
      from   TaxPeriod tp
      where  tp.TaxPerKind = '0'
      and    tp.Begin_Date::date <= To_Date('01.01.' || vTaxYear, 'dd.mm.yyyy')
      and    tp.End_Date::date >= To_Date('31.12.' || vTaxYear, 'dd.mm.yyyy');
      select count(*)
      into   i
      from   DebtSubject ds
      where  ds.Document_Id = ipTaxDoc_Id
      and    ds.TaxPeriod_Id = vTaxPeriod_Id
      and    ds.Municipality_Id = vMunicipality_Id
      and    ds.KindDebtReg_Id = 37;
    
      if (i = 0) and (vTaxPeriod_Id is not null)
      then
        -- ����������
        select count(*), max(cp.ChargeValue)
        into   i, vChargeValue
        from   ChargeReg cr, ChargePrice cp
        where  cr.DocumentType_Id = 32
              --and nvl(cp.city_id,nvl(vcity_id,1)) = nvl(vcity_id,1)
        and    nvl(cp.city_id, -1.0) in (case
                                         when (select count(cp1.city_id)
                                               from   ChargePrice cp1
                                               where  cp1.TaxPeriod_Id = vTaxPeriod_Id
                                               and    nvl(cp1.city_id, -1.0) = nvl(vcity_id, -1.0)) = 1 then
                                          vcity_id
                                         else
                                          -1
                                       end)
        and    cr.ChargeReg_Id = cp.ChargeReg_Id
        and    cp.TaxPeriod_Id = vTaxPeriod_Id;
        if i = 1
        then
          -- ��� ���� ChargePrice
          if vTaxYear < To_Number(vCurYear)
          then
            vParReg := 3;
          else
            vParReg := 2;
          end if;
          if vTaxYear = To_Number(To_Char(vBeginTaxDate::date, 'yyyy'))
          then
            vTDateBegin := To_Date('01.' || To_Char(vBeginTaxDate::date, 'mm.yyyy'),
                                   'dd.mm.yyyy');
          else
            vTDateBegin := To_Date('01.01.' || to_char(vTaxYear), 'dd.mm.yyyy');
          end if;
          vTDateEnd         := To_Date('31.12.' || To_Char(vTaxYear),
                                       'dd.mm.yyyy');
          vChargeValueMonth := vChargeValue / 12;
          vPer              := Round(Months_Between(vTDateEnd, vTDateBegin));
          -- ����� �� �������
          ErrTxt := 'Insert_';
          if InStr(vReasonFree, '1') > 0 and InStr(vReasonFree, '1') < 7 
          then
            vFreeSum_Obj  := 0.0;
            vFreeSum_Subj := Round((vChargeValueMonth * vPer), 2);
          else
            vFreeSum_Obj  := 0.0;
            vFreeSum_Subj := 0.0;
            if vchipdate is not null then
 --            if vchipdate < vTDateBegin then
 --             vFreeSum_Obj  := vChargeValueMonth * vPer;
 --            else
              if vchipdate < vTDateEnd then
                vFreeSum_Obj  := vChargeValueMonth *
                                 Round(Months_Between(vTDateEnd, last_day(vchipdate)));
              end if;
--             end if;
            end if;
          end if;
          select nextval('s_DebtSubject')
          into   vDebtSubject_Id;
          insert into DebtSubject
            (DebtSubject_Id, TaxSubject_Id, Document_Id, KindDoc,
             KindDebtReg_id, TaxPeriod_Id, DocCode, Tax_BegiDate, Tax_EndDate,
             TotalVal, TotalTax, CalcDate, FreeSum_Obj, PrtDate, Inst_Number,
             FreeSum_Subj, Corr_InstNumber, CodeTBO, Corr_SumTotal, UserDate,
             User_Id, TaxObject_Id, PartidaNo, Municipality_Id, KindParReg_Id,
             PayDiscSum, DocNo, Doc_Date, Parent_DebtSubject_Id)
            select vDebtSubject_Id, td.TaxSubject_Id, td.TaxDoc_Id, 1, 37,
                   vTaxPeriod_Id, '117', vTDateBegin, vTDateEnd,
                   Round((vChargeValueMonth * vPer), 2),
                    (Round((vChargeValueMonth * vPer) - vFreeSum_Subj - vFreeSum_Obj, 2)), 
                    current_date, ROUND(vFreeSum_Obj,2), null, 1,
                   Round(vFreeSum_Subj,2), null, null, null, current_date, ipUser_Id,
                   td.TaxObject_Id, vpartno, td.Municipality_Id, vParReg, null,
                   td.DocNo, td.Doc_Date, null
            from   TaxDoc td
            where  td.TaxDoc_Id = ipTaxDoc_Id;
        
          select nextval('s_DebtInstalment')
          into   vDebtInstalment_Id;
          if coalesce(vearndate, vBeginTaxDate::date) >=
             To_Date('01.04.' || vTaxYear, 'dd.mm.yyyy')
          then
            vtermdate := add_months(coalesce(vearndate, vBeginTaxDate::date), 1);
          else
            vtermdate := To_Date('31.03.' || vTaxYear, 'dd.mm.yyyy');
          end if;
          insert into DebtInstalment
            (DebtInstalment_Id, DebtSubject_Id, InstNo, TermPay_Date, InstSum,
             IntBeginDate)
          values
            (vDebtInstalment_Id, vDebtSubject_Id, 1, vtermdate,
              -- ??? getWorkingDay(vtermpaydate,1),
             (Round((vChargeValueMonth * vPer), 2) - vFreeSum_Subj -
              vFreeSum_Obj), vtermdate + 1); -- ??? getWorkingDay(vtermpaydate,1)+1,
        
          insert into BalDebtInst
            (DebtInstalment_Id, InstSum, InterestSum, DiscSum)
          values
            (vDebtInstalment_Id,
             (Round((vChargeValueMonth * vPer), 2) - vFreeSum_Subj -
              vFreeSum_Obj), 0, 0);
          else
            opStatus := '�����a ������� ������ �� ��������';
            return;
        end if; -- ��� ���� ChargePrice
      end if; -- ����������
      vTaxYear := vTaxYear + 1;
    end loop; -- vTaxYear <=  To_Number(To_Char(vCurYear,'yyyy'))
   --zatvarya cursora na 20.09.2011
  -- close cr;
    opStatus := 'OK';
    update taxdoc
    set    docstatus = '30'
    where  taxdoc_id = ipTaxDoc_Id;
  
    ----commit;
  else
    if vdocstatus = '90'
    then
      opStatus := 'OK';
      return;
    end if;
    vclose_date := to_date('01.' ||
                           to_char(add_months(vclose_date, 1), 'mm.yyyy'),
                           'dd.mm.yyyy');
    vTaxYear    := To_Number(To_Char(vclose_date, 'yyyy'));
    while vTaxYear <= To_Number(vCurYear)
    loop
      select max(tp.TaxPeriod_Id)
      into   vTaxPeriod_Id
      from   TaxPeriod tp
      where  tp.TaxPerKind = '0'
      and    tp.Begin_Date <= To_Date('01.01.' || vTaxYear, 'dd.mm.yyyy')
      and    tp.End_Date >= To_Date('31.12.' || vTaxYear, 'dd.mm.yyyy');
      ---------------------------
      select count(*), max(cp.ChargeValue)
      into   i, vChargeValue
      from   ChargeReg cr, ChargePrice cp
      where  cr.DocumentType_Id = 32
            --and nvl(cp.city_id,nvl(vcity_id,1)) = nvl(vcity_id,1)
      and    nvl(cp.city_id, -1.0) in
             (case when (select count(cp1.city_id)
                from   ChargePrice cp1
                where  cp1.TaxPeriod_Id = vTaxPeriod_Id
                and    nvl(cp1.city_id, -1.0) = nvl(vcity_id, -1.0)) = 1 then
               vcity_id else - 1 end)
      and    cr.ChargeReg_Id = cp.ChargeReg_Id
      and    cp.TaxPeriod_Id = vTaxPeriod_Id;
      if i = 1
      then
        -- ��� ���� ChargePrice
        if vTaxYear < To_Number(vCurYear)
        then
          vParReg := 3;
        else
          vParReg := 2;
        end if;
        select sum(b.instsum)
        into   voldsaldo
        from   DebtSubject ds, debtinstalment s, baldebtinst b
        where  ds.Document_Id = ipTaxDoc_Id
        and    ds.TaxPeriod_Id = vTaxPeriod_Id
        and    ds.Municipality_Id = vMunicipality_Id
        and    s.debtsubject_id = ds.debtsubject_id
        and    b.debtinstalment_id = s.debtinstalment_id;
      
        if vTaxYear = To_Number(To_Char(vClose_Date, 'yyyy'))
        then
          vTDateBegin := To_Date('01.' || To_Char(vClose_Date, 'mm.yyyy'),
                                 'dd.mm.yyyy');
        else
          vTDateBegin := To_Date('01.01.' || to_char(vTaxYear), 'dd.mm.yyyy');
        end if;
        vTDateEnd         := To_Date('31.12.' || To_Char(vTaxYear), 'dd.mm.yyyy');
        vChargeValueMonth := vChargeValue / 12;
        vPer              := Round(Months_Between(vTDateEnd, vTDateBegin));
        -- ����� �� �������
        --            ErrTxt := 'Insert_';
        if InStr(vReasonFree, '1') > 0
        then
          vFreeSum_Obj  := 0.0;
          vFreeSum_Subj := Round((vChargeValueMonth * vPer), 2);
        else
          vFreeSum_Obj  := 0.0;
          vFreeSum_Subj := 0.0;
           if vchipdate is not null then
             if vchipdate < vTDateBegin then
              vFreeSum_Obj  := vChargeValueMonth * vPer;
             else
              if vchipdate < vTDateEnd then
                vFreeSum_Obj  := vChargeValueMonth *
                                 Round(Months_Between(vTDateEnd, last_day(vchipdate)));
              end if;
             end if;
            end if;
        end if;
        select nextval('s_DebtSubject')
        into   vDebtSubject_Id;
        insert into DebtSubject
          (DebtSubject_Id, TaxSubject_Id, Document_Id, KindDoc, KindDebtReg_id,
           TaxPeriod_Id, DocCode, Tax_BegiDate, Tax_EndDate, TotalVal, TotalTax,
           CalcDate, FreeSum_Obj, PrtDate, Inst_Number, FreeSum_Subj,
           Corr_InstNumber, CodeTBO, Corr_SumTotal, UserDate, User_Id,
           TaxObject_Id, PartidaNo, Municipality_Id, KindParReg_Id, PayDiscSum,
           DocNo, Doc_Date, Parent_DebtSubject_Id)
          select vDebtSubject_Id, td.TaxSubject_Id, td.TaxDoc_Id, 1, 37,
                 vTaxPeriod_Id, '117', vTDateBegin, vTDateEnd,
                 -Round((vChargeValueMonth * vPer), 2),
                 - (Round((vChargeValueMonth * vPer), 2) - vFreeSum_Subj -
                   vFreeSum_Obj), current_date, -vFreeSum_Obj, null, 1,
                 -vFreeSum_Subj, null, null, null, current_date, ipUser_Id,
                 td.TaxObject_Id, vpartno, td.Municipality_Id, vParReg, null,
                 td.DocNo, td.Doc_Date, null
          from   TaxDoc td
          where  td.TaxDoc_Id = ipTaxDoc_Id;
      
        select nextval('s_DebtInstalment')
        into   vDebtInstalment_Id;
	insert into DebtInstalment
          (DebtInstalment_Id, DebtSubject_Id, InstNo, TermPay_Date, InstSum,
           IntBeginDate)
        values
          (vDebtInstalment_Id, vDebtSubject_Id, 1,
           To_Date('31.03.' || vTaxYear, 'dd.mm.yyyy'),
            -- ??? getWorkingDay(vtermpaydate,1),
           - (Round((vChargeValueMonth * vPer), 2) - vFreeSum_Subj -
              vFreeSum_Obj), To_Date('31.03.' || vTaxYear, 'dd.mm.yyyy') + 1); -- ??? getWorkingDay(vtermpaydate,1)+1,
        --          voldsaldo := voldsaldo - (Round((vChargeValueMonth*vPer),2)-vFreeSum_Subj-vFreeSum_Obj);
        voldsaldo := (Round((vChargeValueMonth * vPer), 2) - vFreeSum_Subj -
                     vFreeSum_Obj);
        --         if voldsaldo >= 0 then
        select nextval('s_operation')
        into   vOperation_Id;
        insert into operation
          (operation_id, oper_date, operdocno, opercode, opersum, user_date,
           user_id, user_name, baloversum, resolution_id, paytransaction_id,
           oversubject_id, municipality_id)
        values
          (voperation_id, vclose_date, voperation_id, '15', -voldsaldo,
           trunc(current_date), ipuser_Id,
           (select u.fullname
             from   users u
             where  u.user_id = ipuser_Id), null, null, null, null,
           vmunicipality_Id);
      
        open cr;
        loop
          fetch cr
            into r;
          exit when not found;
          if r.instsum < voldsaldo
          then
            update baldebtinst 
            set    instsum = 0
            where  debtinstalment_id = r.debtinstalment_id;
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, r.kinddebtreg_Id,
               r.debtinstalment_Id, -r.instsum, null, null, r.kindparreg_Id,
               null, null);
            voldsaldo := voldsaldo - r.instsum;
          else
            update baldebtinst 
            set    instsum = instsum - voldsaldo
            where  debtinstalment_id = r.debtinstalment_id;
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, r.kinddebtreg_Id,
               r.debtinstalment_Id, -voldsaldo, null, null, r.kindparreg_Id,
               null, null);
            voldsaldo := 0;
          end if;
         
        end loop;
         close cr;
        -- insert into -- nadvzeta  
        if voldsaldo > 0
        then
          select nextval('s_oversubject')
          into   voversubject_Id;
          insert into oversubject
            (oversubject_id, kinddebtreg_id, taxsubject_id, overpaysum,
             overinterestsum, overcorsum, partidano, municipality_id,
             debtsubject_id)
          values
            (voversubject_Id, 37, vtaxsubject_id, null, null, voldsaldo,
             vpartno, vmunicipality_Id, vDebtSubject_Id);
          insert into baloverinst
            (oversubject_id, oversum)
          values
            (voversubject_Id, voldsaldo);
          update operation 
          set    oversubject_id = voversubject_Id, baloversum = voldsaldo
          where  operation_id = vOperation_Id;
        
          -----------------------
        end if;
      end if;
      ---------------------------
      vTaxYear := vTaxYear + 1;
    end loop;
  
    update taxdoc
    set    docstatus = '90'
    where  taxdoc_id = ipTaxDoc_Id;
  
    opStatus := 'OK';
  
  end if;
  insert into taxdocarx
    (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno, arxdate,
     docdata, taxobject_id, location_doc, taxobjno, documenttype_id, taxdocdate,
     docextno, doc_date, docext_date, earn_date, act_id, emp_taxsubject_id,
     empno, emp_certify, give_reasonreg_id, relief_id, user_id,
     docwork_finaldate, receiver_date, receiver_note, docinput_date, note,
     company_id, docstatus, close__reasonreg_id, close_date, close_taxdoc_id,
     isinheritance, to_user_id, user_date, user_name, begintaxdate, closenote,
     endtaxdate, isinvalid, receiver_user_id, receiver_user_name,
     last_message_id, change_date, telephone, ettaxsubject_id, kinddecl) 
     
    select nextval('s_taxdocarx'), rowdoc.taxdoc_id, rowdoc.taxsubject_id,
           rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
           xmlstructure.xmltaxdoc117(iptaxdoc_id), rowdoc.taxobject_id,
           rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
           rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date,
           rowdoc.docext_date, rowdoc.earn_date, rowdoc.act_id,
           rowdoc.emp_taxsubject_id, rowdoc.empno, rowdoc.emp_certify,
           rowdoc.give_reasonreg_id, rowdoc.relief_id, rowdoc.user_id,
           rowdoc.docwork_finaldate, rowdoc.receiver_date, rowdoc.receiver_note,
           rowdoc.docinput_date, rowdoc.note, rowdoc.company_id,
           rowdoc.docstatus, rowdoc.close__reasonreg_id, rowdoc.close_date,
           rowdoc.close_taxdoc_id, rowdoc.isinheritance, rowdoc.to_user_id,
           rowdoc.user_date, rowdoc.user_name, rowdoc.begintaxdate,
           rowdoc.closenote, rowdoc.endtaxdate, rowdoc.isinvalid,
           rowdoc.receiver_user_id, rowdoc.receiver_user_name,
           rowdoc.last_message_id, rowdoc.change_date, rowdoc.telephone,
           rowdoc.ettaxsubject_id, rowdoc.kinddecl
    from   taxdoc rowdoc
    where  rowdoc.taxdoc_id = ipTaxDoc_Id;
  update debtsubject 
  set    taxdocarx_id = currval('s_taxdocarx')
  where  document_id = ipTaxDoc_Id
  and    taxdocarx_id is null;

--close cr;
  ----commit;
exception
  when others then
    opStatus := ErrTxt || sqlerrm;
    ----rollback;
end;
$function$
; DROP FUNCTION ivan_valuations.getproptax(numeric, numeric); 
CREATE OR REPLACE FUNCTION ivan_valuations.getproptax(iptaxdoc_id numeric, ipuser_id numeric, OUT opstatus character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  
    cr cursor(ipgetpr_id numeric) is
      select *
      from   partgetproperty gp
      where  gp.getproperty_id = ipgetpr_id;
    r record;
  
    rtaxdoc            taxdoc%rowtype;
    rgetpr             getproperty%rowtype;
    vpartno            varchar(40);
    vtaxval            numeric;
    vfreeval           numeric;
    i                  integer;
    fl                 integer;
    vtotaltax          numeric;
    vtaxvals           numeric;
    vtaxperiod_id      numeric;
    vChargeValue       numeric;
    vDebtSubject_Id    numeric;
    vDebtInstalment_Id numeric;
    vtermdate          date;
    ErrTxt             varchar(200);
  
  begin
    select *
    into   rtaxdoc
    from   taxdoc td
    where  td.taxdoc_id = ipTaxDoc_Id;

    select * into vpartno from getpartidano(rtaxdoc.municipality_id, 25);
    
    update taxdoc 
    set    partidano = vpartno
    where  taxdoc_id = ipTaxDoc_Id
    and    partidano is null;
    select tp.taxperiod_id
    into   vtaxperiod_id
    from   taxperiod tp
    where  tp.taxperkind = '0'
    and    To_Char(tp.begin_date, 'yyyy') =
           to_char(nvl(rtaxdoc.begintaxdate, rtaxdoc.doc_date), 'yyyy');
    select *
    into   rgetpr
    from   getproperty gp
    where  gp.taxdoc_id = ipTaxDoc_Id;
    vtaxval := nvl(rgetpr.exchange_value, 0.0) + nvl(rgetpr.paper_value, 0.0) +
               nvl(rgetpr.otherproperty_value, 0.0) +
               nvl(rgetpr.condone_value, 0.0);
    for i in 1 .. 12
    loop
      if substr(rgetpr.reasonfree, i, 1) = '1'
      then
        fl := 1;
      end if;
    end loop;
    if fl = 1
    then
      vtotaltax := 0;
    else
      if rgetpr.contrkins = '1'
      then
        select nvl(max(cp.ChargeValue), 0.0)
        into   vChargeValue
        from   ChargeReg crg, ChargePrice cp
        where  crg.DocumentType_Id = 25
        and    crg.ChargeReg_Id = cp.ChargeReg_Id
        and    cp.TaxPeriod_Id = vTaxPeriod_Id
        and    crg.name = 'nearheir';
      else
        select nvl(max(cp.ChargeValue), 0.0)
        into   vChargeValue
        from   ChargeReg crg, ChargePrice cp
        where  crg.DocumentType_Id = 25
        and    crg.ChargeReg_Id = cp.ChargeReg_Id
        and    cp.TaxPeriod_Id = vTaxPeriod_Id
        and    crg.name = 'otherheir';
      end if;
    
      vtotaltax := round(vtaxval * vChargeValue / 100, 2);
      open cr(rgetpr.getproperty_id);
      loop
        fetch cr
          into r;
        exit when not found;
        vtaxvals := round(vtotaltax * r.part / 100, 2);
        select nextval('s_DebtSubject') into   vDebtSubject_Id ;
        insert into DebtSubject
          (DebtSubject_Id, TaxSubject_Id, Document_Id, KindDoc, KindDebtReg_id,
           TaxPeriod_Id, DocCode, Tax_BegiDate, Tax_EndDate, TotalVal, TotalTax,
           CalcDate, FreeSum_Obj, PrtDate, Inst_Number, FreeSum_Subj,
           Corr_InstNumber, CodeTBO, Corr_SumTotal, UserDate, User_Id,
           TaxObject_Id, PartidaNo, Municipality_Id, KindParReg_Id, PayDiscSum,
           DocNo, Doc_Date, Parent_DebtSubject_Id)
        values
          (vDebtSubject_Id, r.TaxSubject_Id, rtaxdoc.TaxDoc_Id, 1, 6,
           vTaxPeriod_Id, '49', rtaxdoc.begintaxdate, rtaxdoc.begintaxdate,
           round(vtaxval * r.part / 100, 2), vtaxvals, Trunc(current_date), null,
           null, 1, null, null, null, null, current_date, ipUser_Id, null, vpartno,
           rtaxdoc.Municipality_Id, 2, null, rtaxdoc.DocNo, rtaxdoc.Doc_Date,
           null);
 --       if rgetpr.isotherproperty = 1 then
         vtermdate := add_months(nvl(rtaxdoc.begintaxdate, rtaxdoc.doc_date),2);
 --       else
 --        vtermdate := nvl(rtaxdoc.begintaxdate, rtaxdoc.doc_date) + cast('7 day' as interval);
 --       end if;
        
        select nextval('s_DebtInstalment') into   vDebtInstalment_Id;
        insert into DebtInstalment
          (DebtInstalment_Id, DebtSubject_Id, InstNo, TermPay_Date, InstSum,
           IntBeginDate)
        values
          (vDebtInstalment_Id, vDebtSubject_Id, null,
          vtermdate, vtaxvals,
            vtermdate +  cast('1 day' as interval));
        if vtaxvals > 0
        then
          insert into BalDebtInst
            (DebtInstalment_Id, InstSum, InterestSum, DiscSum)
          values
            (vDebtInstalment_Id, vtaxvals, 0, 0);
        
        end if;
      
      end loop;
     close cr;
    end if;
    
    opStatus := 'OK';
    update taxdoc 
    set    docstatus = '30'
    where  taxdoc_id = ipTaxDoc_Id;
  
    insert into taxdocarx
      (taxdocarx_id,
       taxdoc_id,
       taxsubject_id,
       partidano,
       docdate,
       docno,
       arxdate,
       docdata,
       taxobject_id,
       location_doc,
       taxobjno,
       documenttype_id,
       taxdocdate,
       docextno,
       doc_date,
       docext_date,
       earn_date,
       act_id,
       emp_taxsubject_id,
       empno,
       emp_certify,
       give_reasonreg_id,
       relief_id,
       user_id,
       docwork_finaldate,
       receiver_date,
       receiver_note,
       docinput_date,
       note,
       company_id,
       docstatus,
       close__reasonreg_id,
       close_date,
       close_taxdoc_id,
       isinheritance,
       to_user_id,
       user_date,
       user_name,
       begintaxdate,
       closenote,
       endtaxdate,
       isinvalid,
       receiver_user_id,
       receiver_user_name,
       last_message_id,
       change_date,
       telephone,
       ettaxsubject_id,
       kinddecl)
      select nextval('s_taxdocarx'),
             rowdoc.taxdoc_id,
             rowdoc.taxsubject_id,
             rowdoc.partidano,
             rowdoc.doc_date,
             rowdoc.docno,
             current_date,
             xmlstructure.xmltaxdoc49(iptaxdoc_id),
             rowdoc.taxobject_id,
             rowdoc.location_doc,
             rowdoc.taxobjno,
             rowdoc.documenttype_id,
             rowdoc.taxdocdate,
             rowdoc.docextno,
             rowdoc.doc_date,
             rowdoc.docext_date,
             rowdoc.earn_date,
             rowdoc.act_id,
             rowdoc.emp_taxsubject_id,
             rowdoc.empno,
             rowdoc.emp_certify,
             rowdoc.give_reasonreg_id,
             rowdoc.relief_id,
             rowdoc.user_id,
             rowdoc.docwork_finaldate,
             rowdoc.receiver_date,
             rowdoc.receiver_note,
             rowdoc.docinput_date,
             rowdoc.note,
             rowdoc.company_id,
             rowdoc.docstatus,
             rowdoc.close__reasonreg_id,
             rowdoc.close_date,
             rowdoc.close_taxdoc_id,
             rowdoc.isinheritance,
             rowdoc.to_user_id,
             rowdoc.user_date,
             rowdoc.user_name,
             rowdoc.begintaxdate,
             rowdoc.closenote,
             rowdoc.endtaxdate,
             rowdoc.isinvalid,
             rowdoc.receiver_user_id,
             rowdoc.receiver_user_name,
             rowdoc.last_message_id,
             rowdoc.change_date,
             rowdoc.telephone,
             rowdoc.ettaxsubject_id,
             rowdoc.kinddecl
        from taxdoc rowdoc
       where rowdoc.taxdoc_id = ipTaxDoc_Id;
  
    update debtsubject 
       set taxdocarx_id = currval('s_taxdocarx')
     where document_id = ipTaxDoc_Id
       and taxdocarx_id is null;
    ----commit;
  
  exception
    when others then
      opStatus := ErrTxt || sqlerrm;
      ----rollback;
    
end;
$function$
; DROP FUNCTION ivan_valuations.inheritvalue(numeric, numeric); 
CREATE OR REPLACE FUNCTION ivan_valuations.inheritvalue(iptaxdoc_id numeric, ipuser_id numeric, OUT opstatus character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE                        
    cr cursor(tabid numeric) is
      select *
      from   partinheritance pih
      where  pih.inheritance_id = tabid
      and    pih.kindinherit = '1';
  
    r                  record;
    rtaxdoc            taxdoc%rowtype;
    rinh               inheritance%rowtype;
    vtaxval            numeric;
    vtb1val            numeric;
    vfreeval           numeric;
    vfunval            numeric;
    vdate              date;
    vdead_date         date;
    vmes               integer;
    vtaxvals           numeric;
    vTaxPeriod_Id      numeric;
    vChargeValue       numeric;
    vlimit             numeric;
    vDebtSubject_Id    numeric;
    vDebtinstalment_Id numeric;
    vtotaltax          numeric;
    vpartno            varchar(20);
    ErrTxt             varchar(200);
    taxdocs xml;
  
  begin
    vlimit  := 250000;
    vfunval := 1000;
    select *
    into   rtaxdoc
    from   taxdoc td
    where  td.taxdoc_id = ipTaxDoc_Id;

    select * into vpartno from getpartidano(rtaxdoc.municipality_id, 24);

    update taxdoc 
    set    partidano = vpartno
    where  taxdoc_id = ipTaxDoc_Id
    and    partidano is null;
    select tp.taxperiod_id
    into   vtaxperiod_id
    from   taxperiod tp
    where  tp.taxperkind = '0'
    and    to_char(tp.begin_date, 'yyyy') =
           to_char(cast(rtaxdoc.begintaxdate as date), 'yyyy');
    select *
    into   rinh
    from   inheritance i
    where  i.taxdoc_id = ipTaxDoc_Id;
    if rinh.reasonfreesubj = 1
    then
      --- taxval = 0 za vsichki
      null;
    else
      select sum(valtab1), sum(val), sum(valfree)
      into   vtb1val, vtaxval, vfreeval
      from   (select case tir.tableno 
                           when '1' then nvl(tih.col5value, '0')
                             else '0'
                     end::numeric valtab1,    
                      case tir.tableno 
                             when '2' then nvl(tih.col4value, '0')
                              when '3' then nvl(tih.col5value, '0')
                               when '4' then nvl(tih.col4value, '0')
                                when '5' then '-' || nvl(tih.col4value, '0')
                                 when '6' then '-' || nvl(tih.col2value, '0')
                                  when '7' then nvl(tih.col3value, '0')
                                   when '8' then nvl(tih.col2value, '0')
                              else '0'
                       end::numeric val,
                      0 valfree
               from   tabinheritance tih, tabinhreg tir
               where  tih.tabinhreg_id = tir.tabinhreg_id
               and    nvl(tih.reasonfree, 0.0) = 0.0
               and    tih.inheritance_id = rinh.inheritance_id
               union
               select 0, 0,
                      case tir.tableno 
                            when '1' then nvl(tih.col5value, '0')
                              when '2' then nvl(tih.col4value, '0')
                               when '3' then nvl(tih.col5value, '0')
                                when '4' then nvl(tih.col4value, '0')
                                 when '5' then '-' || nvl(tih.col4value, '0')
                                  when '6' then '-' || nvl(tih.col2value, '0')
                                   when '7' then nvl(tih.col3value, '0')
                                    when '8' then nvl(tih.col2value, '0')
                            else '0'
                      end::numeric val
               from   tabinheritance tih, tabinhreg tir
               where  tih.tabinhreg_id = tir.tabinhreg_id
               and    nvl(tih.reasonfree, 0.0) <> 0.0
               and    tih.inheritance_id = rinh.inheritance_id) sub;
      vtaxval := vtaxval - vfunval;
      select min(tih.col6value)
      into   vdate
      from   tabinheritance tih, tabinhreg tir
      where  tih.tabinhreg_id = tir.tabinhreg_id
      and    tir.tableno = '1';
      select min(p.dead_date)
      into   vdead_date
      from   person p
      where  p.taxsubject_id = rtaxdoc.taxsubject_id;
      if (vdate is not null) and (vdead_date is not null)
      then
        vmes := round(months_between(vdead_date, vdate));
        if vmes <= 12
        then
          vtb1val := vtb1val * 0.4;
        elsif vmes <= 24
        then
          vtb1val := vtb1val * 0.5;
        elsif vmes <= 36
        then
          vtb1val := vtb1val * 0.6;
        end if;
      end if;
    end if;
    vtaxval := vtaxval + vtb1val;
  
    open cr(rinh.inheritance_id);
    loop
      fetch cr
        into r;
      exit when not found;
      if r.divisor > 0
      then
        vtaxvals := vtaxval * r.divident / r.divisor;
      else
        vtaxvals := 0;
      end if;
      vtotaltax := 0;
      if (vtaxvals >= vlimit) and (r.relation = '2')
      then
        select nvl(max(cp.ChargeValue), 0.0)
        into   vChargeValue
        from   ChargeReg crg, ChargePrice cp
        where  crg.DocumentType_Id = 24
        and    crg.ChargeReg_Id = cp.ChargeReg_Id
        and    cp.TaxPeriod_Id = vTaxPeriod_Id
        and    crg.name = 'grant_heir';
      
        vtotaltax := round(vtaxvals * vChargeValue / 100, 2);
      elsif (vtaxvals >= vlimit)
      then
        select nvl(max(cp.ChargeValue), 0.0)
        into   vChargeValue
        from   ChargeReg crg, ChargePrice cp
        where  crg.DocumentType_Id = 24
        and    crg.ChargeReg_Id = cp.ChargeReg_Id
        and    cp.TaxPeriod_Id = vTaxPeriod_Id
        and    crg.name = 'grant_other';
      
        vtotaltax := round(vtaxvals * vChargeValue / 100, 2);
      end if;
    
      select nextval('s_DebtSubject') into vDebtSubject_Id;
      insert into DebtSubject
        (DebtSubject_Id, TaxSubject_Id, Document_Id, KindDoc, KindDebtReg_id,
         TaxPeriod_Id, DocCode, Tax_BegiDate, Tax_EndDate, TotalVal, TotalTax,
         CalcDate, FreeSum_Obj, PrtDate, Inst_Number, FreeSum_Subj,
         Corr_InstNumber, CodeTBO, Corr_SumTotal, UserDate, User_Id,
         TaxObject_Id, PartidaNo, Municipality_Id, KindParReg_Id, PayDiscSum,
         DocNo, Doc_Date, Parent_DebtSubject_Id)
      values
        (vDebtSubject_Id, r.TaxSubject_Id, rtaxdoc.TaxDoc_Id, 1, 3,
         vTaxPeriod_Id, '32', rtaxdoc.begintaxdate, rtaxdoc.begintaxdate,
         vtaxvals, vtotaltax, current_date, null, null, 1, null, null, null,
         null, current_date, ipUser_Id, null, vpartno, rtaxdoc.Municipality_Id, 2,
         null, rtaxdoc.DocNo, rtaxdoc.Doc_Date, null);
    
      select nextval('s_DebtInstalment') into   vDebtInstalment_Id ;
      insert into DebtInstalment
        (DebtInstalment_Id, DebtSubject_Id, InstNo, TermPay_Date, InstSum,
         IntBeginDate)
      values
        (vDebtInstalment_Id, vDebtSubject_Id, null, rtaxdoc.begintaxdate + interval '7 days',
         vtotaltax, rtaxdoc.begintaxdate + interval '8 days');
      if vtotaltax > 0
      then
        insert into BalDebtInst
          (DebtInstalment_Id, InstSum, InterestSum, DiscSum)
        values
          (vDebtInstalment_Id, vtotaltax, 0, 0);
      
      end if;
    
    end loop;
    close cr;
    opStatus := 'OK';
    update taxdoc 
    set    docstatus = '30'
    where  taxdoc_id = ipTaxDoc_Id;
  
    select * into taxdocs from xmlstructure.xmltaxdoc32(iptaxdoc_id);

    insert into taxdocarx 
      (taxdocarx_id, taxdoc_id, taxsubject_id, partidano, docdate, docno,
       arxdate, docdata, taxobject_id, location_doc, taxobjno, documenttype_id,
       taxdocdate, docextno, doc_date, docext_date, earn_date, act_id,
       emp_taxsubject_id, empno, emp_certify, give_reasonreg_id, relief_id,
       user_id, docwork_finaldate, receiver_date, receiver_note, docinput_date,
       note, company_id, docstatus, close__reasonreg_id, close_date,
       close_taxdoc_id, isinheritance, to_user_id, user_date, user_name,
       begintaxdate, closenote, endtaxdate, isinvalid, receiver_user_id,
       receiver_user_name, last_message_id, change_date, telephone,
       ettaxsubject_id, kinddecl)
      select nextval('s_taxdocarx'), rowdoc.taxdoc_id, rowdoc.taxsubject_id,
             rowdoc.partidano, rowdoc.doc_date, rowdoc.docno, current_date,
             taxdocs, rowdoc.taxobject_id,
             rowdoc.location_doc, rowdoc.taxobjno, rowdoc.documenttype_id,
             rowdoc.taxdocdate, rowdoc.docextno, rowdoc.doc_date,
             rowdoc.docext_date, rowdoc.earn_date, rowdoc.act_id,
             rowdoc.emp_taxsubject_id, rowdoc.empno, rowdoc.emp_certify,
             rowdoc.give_reasonreg_id, rowdoc.relief_id, rowdoc.user_id,
             rowdoc.docwork_finaldate, rowdoc.receiver_date,
             rowdoc.receiver_note, rowdoc.docinput_date, rowdoc.note,
             rowdoc.company_id, rowdoc.docstatus, rowdoc.close__reasonreg_id,
             rowdoc.close_date, rowdoc.close_taxdoc_id, rowdoc.isinheritance,
             rowdoc.to_user_id, rowdoc.user_date, rowdoc.user_name,
             rowdoc.begintaxdate, rowdoc.closenote, rowdoc.endtaxdate,
             rowdoc.isinvalid, rowdoc.receiver_user_id,
             rowdoc.receiver_user_name, rowdoc.last_message_id,
             rowdoc.change_date, rowdoc.telephone, rowdoc.ettaxsubject_id,
             rowdoc.kinddecl
      from   taxdoc rowdoc
      where  rowdoc.taxdoc_id = ipTaxDoc_Id;
 
     update debtsubject 
       set taxdocarx_id = currval('s_taxdocarx')
     where document_id = ipTaxDoc_Id
       and taxdocarx_id is null;
    ----commit;
  
  exception
    when others then
      opStatus := ErrTxt || sqlerrm;
      ----rollback;
end;
$function$
;
