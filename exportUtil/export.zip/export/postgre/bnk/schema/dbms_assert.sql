DROP FUNCTION dbms_assert.enquote_literal(character varying); 
CREATE OR REPLACE FUNCTION dbms_assert.enquote_literal(str character varying)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$dbms_assert_enquote_literal$function$
; DROP FUNCTION dbms_assert.enquote_name(character varying); 
CREATE OR REPLACE FUNCTION dbms_assert.enquote_name(str character varying)
 RETURNS character varying
 LANGUAGE sql
 IMMUTABLE
AS $function$SELECT dbms_assert.enquote_name($1, true)$function$
; DROP FUNCTION dbms_assert.enquote_name(character varying, boolean); 
CREATE OR REPLACE FUNCTION dbms_assert.enquote_name(str character varying, loweralize boolean)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$dbms_assert_enquote_name$function$
; DROP FUNCTION dbms_assert.noop(character varying); 
CREATE OR REPLACE FUNCTION dbms_assert.noop(str character varying)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$dbms_assert_noop$function$
; DROP FUNCTION dbms_assert.object_name(character varying); 
CREATE OR REPLACE FUNCTION dbms_assert.object_name(str character varying)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$dbms_assert_object_name$function$
; DROP FUNCTION dbms_assert.qualified_sql_name(character varying); 
CREATE OR REPLACE FUNCTION dbms_assert.qualified_sql_name(str character varying)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$dbms_assert_qualified_sql_name$function$
; DROP FUNCTION dbms_assert.schema_name(character varying); 
CREATE OR REPLACE FUNCTION dbms_assert.schema_name(str character varying)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$dbms_assert_schema_name$function$
; DROP FUNCTION dbms_assert.simple_sql_name(character varying); 
CREATE OR REPLACE FUNCTION dbms_assert.simple_sql_name(str character varying)
 RETURNS character varying
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$dbms_assert_simple_sql_name$function$
;
