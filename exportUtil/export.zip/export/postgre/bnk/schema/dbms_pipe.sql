DROP FUNCTION dbms_pipe.__list_pipes(); 
CREATE OR REPLACE FUNCTION dbms_pipe.__list_pipes()
 RETURNS SETOF record
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_list_pipes$function$
; DROP FUNCTION dbms_pipe.create_pipe(text); 
CREATE OR REPLACE FUNCTION dbms_pipe.create_pipe(text)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_pipe_create_pipe_1$function$
; DROP FUNCTION dbms_pipe.create_pipe(text, integer); 
CREATE OR REPLACE FUNCTION dbms_pipe.create_pipe(text, integer)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_pipe_create_pipe_2$function$
; DROP FUNCTION dbms_pipe.create_pipe(text, integer, boolean); 
CREATE OR REPLACE FUNCTION dbms_pipe.create_pipe(text, integer, boolean)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_pipe_create_pipe$function$
; DROP FUNCTION dbms_pipe.next_item_type(); 
CREATE OR REPLACE FUNCTION dbms_pipe.next_item_type()
 RETURNS integer
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_next_item_type$function$
; DROP FUNCTION dbms_pipe.pack_message(text); 
CREATE OR REPLACE FUNCTION dbms_pipe.pack_message(text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_pack_message_text$function$
; DROP FUNCTION dbms_pipe.pack_message(date); 
CREATE OR REPLACE FUNCTION dbms_pipe.pack_message(date)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_pack_message_date$function$
; DROP FUNCTION dbms_pipe.pack_message(timestamp with time zone); 
CREATE OR REPLACE FUNCTION dbms_pipe.pack_message(timestamp with time zone)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_pack_message_timestamp$function$
; DROP FUNCTION dbms_pipe.pack_message(numeric); 
CREATE OR REPLACE FUNCTION dbms_pipe.pack_message(numeric)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_pack_message_number$function$
; DROP FUNCTION dbms_pipe.pack_message(integer); 
CREATE OR REPLACE FUNCTION dbms_pipe.pack_message(integer)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_pack_message_integer$function$
; DROP FUNCTION dbms_pipe.pack_message(bigint); 
CREATE OR REPLACE FUNCTION dbms_pipe.pack_message(bigint)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_pack_message_bigint$function$
; DROP FUNCTION dbms_pipe.pack_message(bytea); 
CREATE OR REPLACE FUNCTION dbms_pipe.pack_message(bytea)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_pack_message_bytea$function$
; DROP FUNCTION dbms_pipe.pack_message(record); 
CREATE OR REPLACE FUNCTION dbms_pipe.pack_message(record)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_pack_message_record$function$
; DROP FUNCTION dbms_pipe.purge(text); 
CREATE OR REPLACE FUNCTION dbms_pipe.purge(text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_purge$function$
; DROP FUNCTION dbms_pipe.receive_message(text); 
CREATE OR REPLACE FUNCTION dbms_pipe.receive_message(text)
 RETURNS integer
 LANGUAGE sql
AS $function$SELECT dbms_pipe.receive_message($1,NULL::int);$function$
; DROP FUNCTION dbms_pipe.receive_message(text, integer); 
CREATE OR REPLACE FUNCTION dbms_pipe.receive_message(text, integer)
 RETURNS integer
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_pipe_receive_message$function$
; DROP FUNCTION dbms_pipe.remove_pipe(text); 
CREATE OR REPLACE FUNCTION dbms_pipe.remove_pipe(text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_remove_pipe$function$
; DROP FUNCTION dbms_pipe.reset_buffer(); 
CREATE OR REPLACE FUNCTION dbms_pipe.reset_buffer()
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_pipe_reset_buffer$function$
; DROP FUNCTION dbms_pipe.send_message(text); 
CREATE OR REPLACE FUNCTION dbms_pipe.send_message(text)
 RETURNS integer
 LANGUAGE sql
AS $function$SELECT dbms_pipe.send_message($1,NULL,NULL);$function$
; DROP FUNCTION dbms_pipe.send_message(text, integer); 
CREATE OR REPLACE FUNCTION dbms_pipe.send_message(text, integer)
 RETURNS integer
 LANGUAGE sql
AS $function$SELECT dbms_pipe.send_message($1,$2,NULL);$function$
; DROP FUNCTION dbms_pipe.send_message(text, integer, integer); 
CREATE OR REPLACE FUNCTION dbms_pipe.send_message(text, integer, integer)
 RETURNS integer
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_pipe_send_message$function$
; DROP FUNCTION dbms_pipe.unique_session_name(); 
CREATE OR REPLACE FUNCTION dbms_pipe.unique_session_name()
 RETURNS character varying
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_unique_session_name$function$
; DROP FUNCTION dbms_pipe.unpack_message_bytea(); 
CREATE OR REPLACE FUNCTION dbms_pipe.unpack_message_bytea()
 RETURNS bytea
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_unpack_message_bytea$function$
; DROP FUNCTION dbms_pipe.unpack_message_date(); 
CREATE OR REPLACE FUNCTION dbms_pipe.unpack_message_date()
 RETURNS date
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_unpack_message_date$function$
; DROP FUNCTION dbms_pipe.unpack_message_number(); 
CREATE OR REPLACE FUNCTION dbms_pipe.unpack_message_number()
 RETURNS numeric
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_unpack_message_number$function$
; DROP FUNCTION dbms_pipe.unpack_message_record(); 
CREATE OR REPLACE FUNCTION dbms_pipe.unpack_message_record()
 RETURNS record
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_unpack_message_record$function$
; DROP FUNCTION dbms_pipe.unpack_message_text(); 
CREATE OR REPLACE FUNCTION dbms_pipe.unpack_message_text()
 RETURNS text
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_pipe_unpack_message_text$function$
; DROP FUNCTION dbms_pipe.unpack_message_timestamp(); 
CREATE OR REPLACE FUNCTION dbms_pipe.unpack_message_timestamp()
 RETURNS timestamp with time zone
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_pipe_unpack_message_timestamp$function$
;
