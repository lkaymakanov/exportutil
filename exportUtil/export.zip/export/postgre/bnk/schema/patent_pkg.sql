DROP FUNCTION patent_pkg.patentactivityupdate(numeric, numeric, numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION patent_pkg.patentactivityupdate(ippatent_id numeric, ippatentactivityreg_id numeric, ipisworkalone numeric, ipispersonalwork numeric, ipisapprenticereg numeric, iptaxvalue_decl numeric, OUT opresult integer)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
declare
  actscount   numeric(12) := 0;
  actscntHelp numeric(12) := 0;
  patactId    numeric(12) := -1;
begin
  select count(*)
  into   actscount
  from   patentactivity t
  where  t.patent_id = ipPatent_id
  and    t.patentactivityreg_id = ipPatentactivityreg_id;
  if actscount > 1
  then
    begin
      patactId := -1;
    end;
  elsif actscount = 0
  then
    begin
      select nextval('s_patentactivity')
      into   patactId;
      begin
        insert into patentactivity
          (patentactivity_id, patent_id, patentactivityreg_id, isworkalone,
           ispersonalwork, isapprenticereg, taxvalue_decl)
        values
          (patactId, ipPatent_id, ipPatentactivityreg_id, ipIsworkalone,
           ipIspersonalwork, ipIsapprenticereg, ipTaxvalue_decl);
      
        select count(*)
        into   actscntHelp
        from   patentactivity t
        where  t.patent_id = ipPatent_id
        and    t.patentactivityreg_id = ipPatentactivityreg_id;
        if actscount <> actscntHelp - 1
        then
          patactId := -1;
          raise exception 'Rollback';
        end if;
      exception
        when others then
          null;
      end;
    end;
  else
    begin
      select t.patentactivity_id
      into   patactId
      from   patentactivity t
      where  t.patent_id = ipPatent_id
      and    t.patentactivityreg_id = ipPatentactivityreg_id;
    
      begin
        update patentactivity
        set    patent_id = ipPatent_id,
               patentactivityreg_id = ipPatentactivityreg_id,
               isworkalone = ipIsworkalone, ispersonalwork = ipIspersonalwork,
               isapprenticereg = ipIsapprenticereg,
               taxvalue_decl = ipTaxvalue_decl
        where  patentactivity_id = patactId;
      
        select count(*)
        into   actscntHelp
        from   patentactivity t
        where  t.patent_id = ipPatent_id
        and    t.patentactivityreg_id = ipPatentactivityreg_id;
        if actscount <> actscntHelp
        then
          patactId := -1;
          raise exception 'Rollback';
        end if;
      exception
        when others then
          null;
      end;
    end;
  end if;
  opResult := cast(patactId as integer);
end;
$function$
; DROP FUNCTION patent_pkg.patenttaxpricetransfer(); 
CREATE OR REPLACE FUNCTION patent_pkg.patenttaxpricetransfer(OUT opresult character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  zonesCnt              numeric;
  pricesCnt             numeric;
  futureZonePresenceCnt numeric;
  zoneFutureId          numeric;
  activePeriodId        numeric;
  prevPeriodId          numeric;
  patenttaxprice_id     numeric;
  stcityZoneFutureId    numeric;
  activeYear            numeric;
  prevYear              numeric;
  zoneNumber            numeric;
  municipality_id       numeric;
  zonesPrevPeriodCr     cursor(aPrevPer numeric) is
    select *
    from   patentzone t
    where  t.taxperiod_id = aPrevPer
    and    t.city_id is null
    and    t.street_id is null;

  zonesPrices           cursor(aPzoneId numeric) is
    select *
    from   patenttaxprice t
    where  t.patentzone_id = aPzoneId;

  zoneFuturePeriod cursor (aZoneNum numeric, aFuterePer numeric, munid numeric) is
      select *
        from patentzone t
       where t.taxperiod_id = aFuterePer
         and t.city_id is null
         and t.street_id is null
         and t.municipality_id = munid
         and t.zone = aZoneNum;

  citiesstreetsInzone   cursor(aZoneId numeric) is
    select *
    from   patentzone t
    where  t.isallcity = aZoneId
	and    t.taxperiod_id = prevPeriodId
    and    (t.street_id is not null or t.city_id is not null);    

begin
  zonesCnt              := 0;
  pricesCnt             := 0;
  futureZonePresenceCnt := 0;
  zoneFutureId          := -1;
  activePeriodId        := -1;
  prevPeriodId          := -1;
  patenttaxprice_id     := -1;
  stcityZoneFutureId    := -1;
  activeYear            := -1;
  zoneNumber            := -1;
  municipality_id       := -1;
  opResult              := 'OK';
 
    --get only TAXYEAR
  select c.configvalue
  into   activeYear
  from   config c
  where  c.name = 'TAXYEAR';
  --and    c.configvalue = (select to_char(current_date, 'yyyy'));
  prevYear := activeYear - 1;
  select t.taxperiod_id
  into   activePeriodId
  from   taxperiod t
  where  t.begin_date = to_date('01.01.' || activeYear, 'dd.mm.yyyy')
  and    t.taxperkind = '0';
  select t.taxperiod_id
  into   prevPeriodId
  from   taxperiod t
  where  t.begin_date = to_date('01.01.' || prevYear, 'dd.mm.yyyy')
  and    t.taxperkind = '0';
  if (activePeriodId <= prevPeriodId)
  then
    opResult := 'Future period Id less than Previous Period Id...';
    return;
  end if;
  for zones in zonesPrevPeriodCr(prevPeriodId)
  loop
    zoneFutureId          := -1;
    futureZonePresenceCnt := 0;
    if( zoneNumber = zones.zone and municipality_id = zones.municipality_id )
    then
      opResult := 'More than one zone with same numeric for previous period...';
      return;
    end if;
    zoneNumber := zones.zone;
    municipality_id := zones.municipality_id;
    for zoneFuture in zoneFuturePeriod(zones.Zone, activePeriodId, municipality_id) 
    loop
      zoneFutureId          := zoneFuture.patentzone_id;
      futureZonePresenceCnt := futureZonePresenceCnt + 1;
      if futureZonePresenceCnt > 1
      then
        opResult := 'More than one zone with same numeric for future period...';
        return;
      end if;
    end loop;
    delete from patenttaxprice t
    where  t.patentzone_id = zoneFutureId;
    if (zoneFutureId <= -1)
    then
      begin
        select nexval('s_patentzone')
        into   zoneFutureId;
        insert into patentzone
          (patentzone_id, municipality_id, taxperiod_id, city_id, street_id,
           zone, isallcity, admregion_id, note)
        values
          (zoneFutureId, zones.municipality_id, activePeriodId, zones.city_id,
           zones.street_id, zones.zone,zoneFutureId, /*zones.isallcity,*/ zones.admregion_id,
           zones.note);
      end;
    end if;
    delete from patentzone t
    where  t.isallcity = zoneFutureId
    and    (t.city_id is null and t.street_id is not null);
    delete from patentzone t
    where  t.isallcity = zoneFutureId
    and    (t.city_id is not null and t.street_id is not null);
    for stcity in citiesstreetsInzone(zones.patentzone_id)
    loop
      select nextval('s_patentzone')
      into   stcityZoneFutureId;
      insert into patentzone
        (patentzone_id, municipality_id, taxperiod_id, city_id, street_id, zone,
         isallcity, admregion_id, note)
      values
        (stcityZoneFutureId, stcity.municipality_id, activePeriodId,
         stcity.city_id, stcity.street_id, stcity.zone, zoneFutureId,
         stcity.admregion_id, stcity.note);
    end loop;
    pricesCnt := 0;
    for prices in zonesPrices(zones.patentzone_id)
    loop
      select nextval('s_patenttaxprice')
      into   patenttaxprice_id;
      insert into patenttaxprice
        (patenttaxprice_id, municipality_id, taxperiod_id, city_id,
         patentactivityreg_id, patentzone_id, taxprice)
      values
        (patenttaxprice_id, prices.municipality_id, activePeriodId,
         prices.city_id, prices.patentactivityreg_id, zoneFutureId,
         prices.taxprice);
      pricesCnt := pricesCnt + 1;
    end loop;
    zonesCnt := zonesCnt + 1;
  end loop;
 
exception
  when TOO_MANY_ROWS then
    opResult := 'Too many activeYears !';
  when NO_DATA_FOUND then
    opResult := 'No activeYears !';
  when others then
    opResult := 'Error'||SQLERRM;
    --rollback;
end;
$function$
; DROP FUNCTION patent_pkg.patentupdate(numeric, numeric, numeric, numeric, numeric, numeric, numeric, date, date, date, numeric, numeric, numeric, numeric, date, date, date); 
CREATE OR REPLACE FUNCTION patent_pkg.patentupdate(iptaxdoc_id numeric, iptaxperiod_id numeric, iptaxsubject_id numeric, ipisactivityapp14 numeric, ipisturnover numeric, ipisdds numeric, ipispersonalwork numeric, ipbegindate date, ipchangedate date, ipuser_date date, ipuser_id numeric, ipcircumstance1 numeric, ipcircumstance2 numeric, ipcircumstance3 numeric, ipcircumstance1_date date, ipcircumstance2_date date, ipcircumstance3_date date, OUT opresult integer)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
declare

  patentscount   numeric(12) := 0;
  patentscntHelp numeric(12) := 0;
  patentId       numeric(12) := -1;

begin
  select count(*)
  into   patentscount
  from   patent t
  where  t.taxdoc_id = ipTaxdoc_id;
  if patentscount > 1
  then
    begin
      patentId := -1;
    end;
  elsif patentscount = 0
  then
    begin
      select count(*)
      into   patentId
      from   patent t
      where  t.taxdoc_id = ipTaxdoc_id;
    
      select nextval('s_patent')
      into   patentId;
    
      insert into patent
        (patent_id, taxperiod_id, taxsubject_id, taxdoc_id, isactivityappl4,
         isturnover, isdds, ispersonalwork, begindate, changedate, user_date,
         user_id)
      values
        (patentId, ipTaxperiod_id, ipTaxsubject_id, ipTaxdoc_id,
         ipIsactivityapp14, ipIsturnover, ipIsdds, ipIspersonalwork, ipBegindate,
         ipChangedate, ipUser_date, ipUser_id);
    
      select count(*)
      into   patentscntHelp
      from   patent t
      where  t.taxdoc_id = ipTaxdoc_id;
    
      if patentscount <> patentscntHelp - 1
      then
        patentId := -1;
        raise exception 'Rollback';
      end if;
    exception
      when others then
        null;
    end;
  else
    begin
      select t.patent_id
      into   patentId
      from   patent t
      where  t.taxdoc_id = ipTaxdoc_id;
    
      update patent
      set    taxperiod_id = ipTaxperiod_id, taxsubject_id = ipTaxsubject_id,
             taxdoc_id = ipTaxdoc_id, isactivityappl4 = ipIsactivityapp14,
             isturnover = ipIsturnover, isdds = ipIsdds,
             ispersonalwork = ipIspersonalwork, changedate = ipChangedate,
             user_date = ipUser_date, user_id = ipUser_id,
             circumstance1 = ipCircumstance1, circumstance2 = ipCircumstance2,
             circumstance3 = ipCircumstance3,
             circumstance1_date = ipCircumstance1_date,
             circumstance2_date = ipCircumstance2_date,
             circumstance3_date = ipCircumstance3_date,
             begindate = decode(ipBegindate, null, patent.begindate, ipBegindate)
      where  patent.patent_id = patentId;
    
      select count(*)
      into   patentscntHelp
      from   patent t
      where  t.taxdoc_id = ipTaxdoc_id;
    
      if patentscount <> patentscntHelp
      then
        patentId := -1;
        raise exception 'Rollback';
      end if;
    exception
      when others then
        null;
    end;
  end if;
  opResult := cast(patentId as integer);
end;
$function$
; DROP FUNCTION patent_pkg.patentzoneselect(numeric, numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION patent_pkg.patentzoneselect(ipmunicipality_id numeric, iptaxobject_id numeric, ipcity_id numeric, ipstreet_id numeric, ipadmregion_id numeric, OUT oppd_lob text)
 RETURNS text
 LANGUAGE plpgsql
AS $function$
declare
  tbl1 varchar [ ];
  tbl2 varchar [ ];
  tbl3 varchar [ ];
  tbl4 varchar [ ];
  indx integer;
  i    integer := 0;
  competentmunicipality_id integer:= -1;



  c1    cursor is
    select cast(t.isallcity as int), cast(t.zone as int)
    from   patentzone t
    where  t.taxperiod_id =
           (select p.taxperiod_id
            from   taxobject p
            where  p.taxobject_id = ipTaxobject_id)
    and t.municipality_id = competentmunicipality_id
    and    nvl(t.admregion_id, 0.0) = nvl(ipAdmRegion_id, 0.0)
    and    t.city_id = ipCity_id
    and    t.street_id = ipStreet_id
    order  by t.zone;

  c1row record;

  c2    cursor is
    select cast(t.patentzone_id as int), cast(t.zone as int)
    from   patentzone t
    where  t.taxperiod_id =
           (select p.taxperiod_id
            from   taxobject p
            where  p.taxobject_id = ipTaxobject_id)
    and t.municipality_id = competentmunicipality_id
    and    nvl(t.admregion_id, 0.0) = nvl(ipAdmRegion_id, 0.0)
    and    t.city_id = ipCity_id
    and    t.street_id is null
    order  by t.zone;

  c2row record;

  c3    cursor is
    select cast(t.isallcity as int), cast(t.zone as int)
    from   patentzone t
    where  t.taxperiod_id =
           (select p.taxperiod_id
            from   taxobject p
            where  p.taxobject_id = ipTaxobject_id)
    and    t.municipality_id = competentmunicipality_id
    and    nvl(t.admregion_id, 0.0) = nvl(ipAdmRegion_id, 0.0)
    and    t.city_id is null
    and    t.street_id = ipCity_id
    order  by t.zone;

  c3row record;

  c4    cursor is
    select cast(t.patentzone_id as int), cast(t.zone as int)
    from   patentzone t
    where  t.taxperiod_id =
           (select p.taxperiod_id
            from   taxobject p
            where  p.taxobject_id = ipTaxobject_id)
    and    t.municipality_id = competentmunicipality_id
    and    nvl(t.admregion_id, 0.0) = nvl(ipAdmRegion_id, 0.0)
    and    t.city_id is null
    and    t.street_id is null
    order  by t.zone;

  c4row record;




begin
  
  select coalesce(t.parentmunicipality_id, t.municipality_id)   into competentmunicipality_id
  from municipality t where t.municipality_id = ipMunicipality_id;

  opPD_lob := '';
  open c1;
  loop
    fetch c1
      into c1row;
    exit when not found;
    tbl1 [ i ] := c1row.isallcity || ',' || c1row.zone || ':';
    i := i + 1;
  end loop;
  close c1;
  i := 0;
  open c2;
  loop
    fetch c2
      into c2row;
    exit when not found;
    tbl2 [ i ] := c2row.patentzone_id || ',' || c2row.zone || ':';
    i := i + 1;
  end loop;
  close c2;
  i := 0;
  open c3;
  loop
    fetch c3
      into c3row;
    exit when not found;
    tbl3 [ i ] := c3row.isallcity || ',' || c3row.zone || ':';
    i := i + 1;
  end loop;
  close c3;

  i := 0;
  open c4;
  loop
    fetch c4
      into c4row;
    exit when not found;
    tbl4 [ i ] := c4row.patentzone_id || ',' || c4row.zone || ':';
    i := i + 1;
  end loop;
  close c4;

  if (array_length(tbl1, 1) > 0)
  then
    for indx in 0 .. array_length(tbl1, 1) - 1
    loop
      opPD_lob := opPD_lob || tbl1 [ indx ];
    end loop;
  else
    if (array_length(tbl2, 1) > 0)
    then
      for indx in 0 .. array_length(tbl2, 1) - 1
      loop
        opPD_lob := opPD_lob || tbl2 [ indx ];
      end loop;
    else
      if (array_length(tbl3, 1) > 0)
      then
        for indx in 0 .. array_length(tbl3, 1) - 1
        loop
          opPD_lob := opPD_lob || tbl3 [ indx ];
        end loop;
      else
        for indx in 0 .. array_length(tbl4, 1) - 1
        loop
          opPD_lob := opPD_lob || tbl4 [ indx ];
        end loop;
      end if;
    end if;
  end if;
  --  ? := vPD_lob;
end;
$function$
; DROP FUNCTION patent_pkg.patentzoneupdate(numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, character varying, numeric, numeric); 
CREATE OR REPLACE FUNCTION patent_pkg.patentzoneupdate(ippatentzone_id numeric, ipcity_id numeric, ipmunicipality_id numeric, iptaxperiod_id numeric, ipzone numeric, ipstreet_id numeric, ipallcity numeric, ipadmregion_id numeric, ipnote character varying, ippatentzonestreet_id numeric, ipcityzones numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  cnt            integer;
  patentrefId    numeric := ipPatentzonestreet_id;
  vPatentzone_id numeric := ipPatentzone_id;
begin
  if ipCityzones = 1.0
  then
    select count(t.patentzone_id)
    into   cnt
    from   patentzone t
    where  t.municipality_id = ipMunicipality_id
    and    t.taxperiod_id = ipTaxperiod_id
    and    t.zone = ipZone
    and    t.street_id is null
    and    nvl(t.admregion_id, 0.0) = nvl(ipAdmRegion_id, 0.0)
    and    t.city_id = ipCity_id;
  else
    select count(t.patentzone_id)
    into   cnt
    from   patentzone t
    where  t.municipality_id = ipMunicipality_id
    and    t.taxperiod_id = ipTaxperiod_id
    and    t.zone = ipZone
    and    t.street_id is null
    and    nvl(t.admregion_id, 0.0) = nvl(ipAdmRegion_id, 0.0)
    and    t.city_id is null;
  end if;

  if cnt = 0 and ipStreet_id is null
  then
    begin
      insert into patentzone
        (patentzone_id, municipality_id, taxperiod_id, city_id, street_id, zone,
         isallcity, admregion_id, note)
      values
        (nextval('s_patentzone'), ipMunicipality_id, ipTaxperiod_id, ipCity_id,
         ipStreet_id, ipZone, ipAllcity, ipAdmRegion_id, ipNote);
      --commit;
    end;
  end if;

  if ((ipCity_id is not null and ipCity_id > 0.0) and (ipCityzones = 0.0))
  then
    select count(t.patentzone_id)
    into   cnt
    from   patentzone t
    where  cast(t.isallcity as int) = cast(vPatentzone_id as int)
    and    cast(t.street_id as int) = cast(ipCity_id as int);
    if cnt = 0
    then
      if ((patentrefId is null) or (patentrefId = -1.0))
      then
        select nextval('s_patentzone')
        into   patentrefId;
      end if;
      insert into patentzone
        (patentzone_id, municipality_id, taxperiod_id, street_id, zone,
         isallcity, admregion_id, note)
      values
        (patentrefId, ipMunicipality_id, ipTaxperiod_id, ipCity_id, ipZone,
         vPatentzone_id, ipAdmRegion_id, ipNote);
      --commit;
    end if;
    if cnt = 1
    then
      select t.patentzone_id
      into   vPatentzone_id
      from   patentzone t
      where  cast(t.isallcity as int) = cast(vPatentzone_id as int)
      and    cast(t.street_id as int) = cast(ipCity_id as int);
      update patentzone
      set    note = ipNote
      where  patentzone_id = vPatentzone_id;
      --commit;
    else
      --rollback;
    end if;
  else
    if cnt = 1
    then
      if ipCityzones = 1.0
      then
        select t.patentzone_id
        into   vPatentzone_id
        from   patentzone t
        where  t.municipality_id = ipMunicipality_id
        and    t.taxperiod_id = ipTaxperiod_id
        and    t.zone = ipZone
        and    t.street_id is null
        and    nvl(t.admregion_id, 0.0) = nvl(ipAdmRegion_id, 0.0)
        and    t.city_id = ipCity_id;
      
      else
        select t.patentzone_id
        into   vPatentzone_id
        from   patentzone t
        where  t.municipality_id = ipMunicipality_id
        and    t.taxperiod_id = ipTaxperiod_id
        and    t.zone = ipZone
        and    t.street_id is null
        and    nvl(t.admregion_id, 0.0) = nvl(ipAdmRegion_id, 0.0)
        and    t.city_id is null;
      
      end if;
      if ipStreet_id is null
      then
        update patentzone
        set    municipality_id = ipMunicipality_id,
               taxperiod_id = ipTaxperiod_id, city_id = ipCity_id,
               street_id = ipStreet_id, zone = ipZone, isallcity = ipAllcity,
               admregion_id = ipAdmRegion_id, note = ipNote
        where  patentzone_id = vPatentzone_id;
      else
        select count(t.patentzone_id)
        into   cnt
        from   patentzone t
        where  t.isallcity = vPatentzone_id
        and    t.street_id = ipStreet_id;
        if cnt = 1
        then
          select t.patentzone_id
          into   patentrefId
          from   patentzone t
          where  t.isallcity = vPatentzone_id
          and    t.street_id = ipStreet_id;
          update patentzone
          set    municipality_id = ipMunicipality_id,
                 taxperiod_id = ipTaxperiod_id, city_id = ipCity_id,
                 street_id = ipStreet_id, zone = ipZone, isallcity = ipAllcity,
                 admregion_id = ipAdmRegion_id, note = ipNote
          where  patentzone_id = patentrefId;
        else
          if ((patentrefId is null) or (patentrefId = -1.0))
          then
            select nextval('s_patentzone')
            into   patentrefId;
          end if;
          insert into patentzone
            (patentzone_id, municipality_id, taxperiod_id, city_id, street_id,
             zone, isallcity, admregion_id, note)
          values
            (patentrefId, ipMunicipality_id, ipTaxperiod_id, ipCity_id,
             ipStreet_id, ipZone, vPatentzone_id, ipAdmRegion_id, ipNote);
          update patentzone t
          set    isallcity = 0
          where  t.patentzone_id = vPatentzone_id;
        end if;
      end if;
      --commit;
    else
      --rollback;
    end if;
  end if;
  return 'OK';
end;
$function$
;
