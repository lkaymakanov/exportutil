DROP FUNCTION utl_file.fclose_all(); 
CREATE OR REPLACE FUNCTION utl_file.fclose_all()
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$utl_file_fclose_all$function$
; DROP FUNCTION utl_file.fcopy(text, text, text, text); 
CREATE OR REPLACE FUNCTION utl_file.fcopy(src_location text, src_filename text, dest_location text, dest_filename text)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$utl_file_fcopy$function$
; DROP FUNCTION utl_file.fcopy(text, text, text, text, integer); 
CREATE OR REPLACE FUNCTION utl_file.fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$utl_file_fcopy$function$
; DROP FUNCTION utl_file.fcopy(text, text, text, text, integer, integer); 
CREATE OR REPLACE FUNCTION utl_file.fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer, end_line integer)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$utl_file_fcopy$function$
; DROP FUNCTION utl_file.fgetattr(text, text); 
CREATE OR REPLACE FUNCTION utl_file.fgetattr(location text, filename text, OUT fexists boolean, OUT file_length bigint, OUT blocksize integer)
 RETURNS record
 LANGUAGE c
AS '$libdir/orafunc', $function$utl_file_fgetattr$function$
; DROP FUNCTION utl_file.fopen(text, text, text, integer); 
CREATE OR REPLACE FUNCTION utl_file.fopen(location text, filename text, open_mode text, max_linesize integer)
 RETURNS utl_file.file_type
 LANGUAGE c
 SECURITY DEFINER
AS '$libdir/orafunc', $function$utl_file_fopen$function$
; DROP FUNCTION utl_file.fopen(text, text, text, integer, name); 
CREATE OR REPLACE FUNCTION utl_file.fopen(location text, filename text, open_mode text, max_linesize integer, encoding name)
 RETURNS utl_file.file_type
 LANGUAGE c
 SECURITY DEFINER
AS '$libdir/orafunc', $function$utl_file_fopen$function$
; DROP FUNCTION utl_file.fremove(text, text); 
CREATE OR REPLACE FUNCTION utl_file.fremove(location text, filename text)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$utl_file_fremove$function$
; DROP FUNCTION utl_file.frename(text, text, text, text); 
CREATE OR REPLACE FUNCTION utl_file.frename(location text, filename text, dest_dir text, dest_file text)
 RETURNS void
 LANGUAGE sql
AS $function$SELECT utl_file.frename($1, $2, $3, $4, false);$function$
; DROP FUNCTION utl_file.frename(text, text, text, text, boolean); 
CREATE OR REPLACE FUNCTION utl_file.frename(location text, filename text, dest_dir text, dest_file text, overwrite boolean)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$utl_file_frename$function$
; DROP FUNCTION utl_file.tmpdir(); 
CREATE OR REPLACE FUNCTION utl_file.tmpdir()
 RETURNS text
 LANGUAGE c
AS '$libdir/orafunc', $function$utl_file_tmpdir$function$
;
