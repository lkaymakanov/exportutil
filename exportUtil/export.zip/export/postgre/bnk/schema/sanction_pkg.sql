DROP FUNCTION sanction_pkg.calcdiscount(numeric, numeric, date, character varying, numeric); 
CREATE OR REPLACE FUNCTION sanction_pkg.calcdiscount(iptaxsubject_id numeric, iptaxobject_id numeric, ippaydate date, OUT opstat character varying, ippartno character varying, ipkinddebtreg_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
 cr cursor is
    select min(t.debtsubject_id) debtsubject_id, min(t.document_id) document_id,
           min(t.taxperiod_id) taxperiod_id, min(t.totaltax) totaltax
    from   debtinstalment di
    inner  join debtsubject dd
    on     dd.debtsubject_id = di.debtsubject_id
    left   outer join baldebtinst bd
    on     di.debtinstalment_id = bd.debtinstalment_id
    inner  join (select min(nvl(ds.parent_debtsubject_id, ds.debtsubject_id)) debtsubject_id,
                        ds.document_id, ds.taxperiod_id, ds.taxsubject_id,
                        sum(ds.totaltax) totaltax
                 from   debtsubject ds
                 where  ds.taxsubject_id = ipTaxSubject_id
			and ds.taxperiod_id = (select p.taxperiod_id from config c , taxperiod p 
						where c.name = 'TAXYEAR'
						and p.begin_date = to_date('01.01.' || c.configvalue,'dd.mm.yyyy'))
			and ds.partidano = (case when ippartno=null then ds.partidano
						 when ippartno=0 then ds.partidano
						 else ippartno end)
			and ds.kinddebtreg_id = (case when ipkinddebtreg_id=null then ds.kinddebtreg_id
						      when ipkinddebtreg_id=0 then ds.kinddebtreg_id
						      else ipkinddebtreg_id end)				
			--and ds.partidano = decode(ippartno, null,ds.partidano, 0 , ds.partidano,ippartno)
			--and ds.kinddebtreg_id = decode(ipkinddebtreg_id,null,ds.kinddebtreg_id,0,ds.kinddebtreg_id,ipkinddebtreg_id)
                 group  by ds.document_id, ds.taxperiod_id, ds.taxsubject_id,
                           ds.kinddebtreg_id) t
    on     nvl(dd.parent_debtsubject_id, dd.debtsubject_id) = t.debtsubject_id
    group  by dd.document_id, dd.taxperiod_id, dd.taxsubject_id,
              dd.kinddebtreg_id
    having sum(nvl(bd.instsum, 0.0)) > 0;


  rdebt       record;
  vPaydate    date;
  vtermdisc   date;
  vpercent    numeric;
  vinstnumber numeric;
  vper_id     numeric;
  vdoctype_id numeric;
  vearndate   date;
  vtotaltax   numeric;
  maxdate timestamp;
  vpaydiscount numeric;
begin
  vPaydate := ipPayDate;
  open cr;
  loop
    fetch cr
      into rdebt;
    exit when not found;
    vtermdisc := null;
    begin
      select d.termdisc, d.percent, ty.instnumber, tp.taxperiod_id,
             ty.documenttype_id
      into   vtermdisc, vpercent, vinstnumber, vper_id, vdoctype_id
      from   taxdoc td, discount d, taxperiod tp, documenttype ty
      where  td.taxdoc_id = rdebt.document_id
      and    d.documenttype_id = td.documenttype_id
      and    d.taxperiod_id = tp.taxperiod_id
      and    tp.taxperkind = '0'
      and    to_char(tp.begin_date, 'yyyy') =
             (select c.configvalue
               from   config c
               where  c.name = 'TAXYEAR' || substr(ty.doccode, 1, 2)
               and    c.municipality_id = td.municipality_id)
      and    ty.documenttype_id = td.documenttype_id
      --   and td.municipality_id = ty.municipality_id
      ;
      select count(tp.taxperiodpay_id)
      into   vinstnumber
      from   taxperiodpay tp
      where  tp.taxperiod_id = vper_id
      and    tp.documenttype_id = vdoctype_id;
    exception
      when no_data_found then
        null;
    end;
    if vtermdisc is not null and (ipPayDate <= vtermdisc)
    then
      update baldebtinst
      set    discsum = 0
      where  debtinstalment_id in
             (select di.debtinstalment_id
              from   debtinstalment di, debtsubject ds
              where  di.debtsubject_id = ds.debtsubject_id
              and  ((ds.parent_debtsubject_id = rdebt.debtsubject_id) or (ds.debtsubject_id = rdebt.debtsubject_id)));
      select min(td.earn_date)
      into   vearndate
      from   taxdoc td, debtsubject ds
      where  ds.debtsubject_id = rdebt.debtsubject_id
      and    td.taxdoc_id = ds.document_id
      and    td.documenttype_id in (26, 27, 28, 29);
      select sum(i.instsum)
      into   vtotaltax
      from   debtsubject ds, debtinstalment i
      where  ds.debtsubject_id = i.debtsubject_id
      and    nvl(ds.parent_debtsubject_id, ds.debtsubject_id) =
             rdebt.debtsubject_id;
      select max(do1.paydate), sum(pd.paydiscsum) into maxdate, vpaydiscount
	from paydocument do1, paydebt pd, debtsubject ds, debtinstalment i
	where do1.paydocument_id = pd.paydocument_id
		and pd.debtinstalment_id = i.debtinstalment_id
		and  i.debtsubject_id = ds.debtsubject_id
		and ((ds.parent_debtsubject_id = rdebt.debtsubject_id) or (ds.debtsubject_id = rdebt.debtsubject_id))
		and do1.null_date is null;
      if to_char(nvl(vearndate, to_date('19000101', 'yyyymmdd')), 'yyyy') <>
         to_char(vPaydate, 'yyyy')
      then
        --    
        if (vPaydate <= vtermdisc) and (nvl(maxdate,to_date('19000101','yyyymmdd')) <= vtermdisc)
		and (vper_id = rdebt.taxperiod_id)
        then
          update baldebtinst
          set    discsum = round((vpercent * vtotaltax / 100) - nvl(vpaydiscount,0.0),2)
          --set    discsum = round(vpercent * vtotaltax / 100, 2)
          where  debtinstalment_id in
                 (select min(di.debtinstalment_id)
                  from   debtinstalment di, debtsubject ds, baldebtinst b
                  where  di.debtsubject_id = ds.debtsubject_id
                  and    b.debtinstalment_id = di.debtinstalment_id
                  and    nvl(ds.parent_debtsubject_id, ds.debtsubject_id) =
                         rdebt.debtsubject_id
                  and    b.instsum =
                         (select max(bb.instsum)
                           from   debtsubject dd, debtinstalment ii,
                                  baldebtinst bb
                           where  nvl(dd.parent_debtsubject_id, dd.debtsubject_id) =
                                  rdebt.debtsubject_id
                           and    ii.debtsubject_id = dd.debtsubject_id
                           and    bb.debtinstalment_id = ii.debtinstalment_id
                           and    ii.instno = vinstnumber)
                  and    di.instno = vinstnumber);
          -- else
        end if;
      end if;
    end if;
  end loop;
  ----commit ;
  opStat := 'OK';
  close cr;
exception
  when no_data_found then
    ----rollback;
    opStat := '��� ��������';
   -- close cr;
  when others then
    ----rollback;
    opStat := 'errOrclDB'; --'??????'; 
   -- close cr;
end;
$function$
; DROP FUNCTION sanction_pkg.calculateint(numeric, date, numeric); 
CREATE OR REPLACE FUNCTION sanction_pkg.calculateint(ipdebtinstalment numeric, ipto date, ipuser_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  crintper cursor(vtodate date) is
    select *
    from   interestpct ip
    where  ip.begin_date between
           (select max(ib.begin_date)
            from   interestpct ib
            where  ib.begin_date <= vtodate) and
           (select max(ie.begin_date)
            from   interestpct ie
            where  ie.begin_date <= ipto)
    order  by ip.begin_date;


  rintper          record;
  vBDate           date;
  vEDate           date;
  crPCT            numeric;
  vIntSum          numeric;
  vinterestoper_id numeric;
  vpersum          numeric;
  vtodate          date;
  basesum          numeric;
  vintdebt_id      numeric;
  ipto1            date;
begin
  ipto1 := ipto;
  select max(di.debtinstalment_id), max(di.todate)
  into   vintdebt_id, vtodate
  from   interestdebt di
  where  di.debtinstalment_id = ipdebtinstalment;
  if vintdebt_id is null
  then
  
    select di.intbegindate
    into   vtodate
    from   debtinstalment di
    where  di.debtinstalment_id = ipdebtinstalment;
    --   select s_interestdebt.nextval into vintdebt_id from dual;  
  else
    vtodate := vtodate + integer '1';
  end if;
  if vtodate <= ipto1
  then
    select min(bd.instsum)
    into   basesum
    from   baldebtinst bd
    where  bd.debtinstalment_id = ipdebtinstalment;
  
    basesum := coalesce(basesum, 0);
    if basesum <> 0.0
    then
      vIntSum := 0.0;
      open crintper(vtodate);
      fetch crintper
        into rintper;
      if not found
      then
        vIntSum := 0.0;
        return('OK');
      end if;
      vBDate := vtodate;
      crPCT  := rintper.interestpct + coalesce(rintper.interestpctadd,0);
      loop
        fetch crintper
          into rintper;
        exit when not found;
        vEdate  := rintper.begin_date::date - integer '1';
        vpersum := round(((vEdate - vBDate) + integer '1') * crPCT * BaseSum / 36000.0, 5);
        vIntSum := vIntSum + vpersum;
        select nextval('s_interestoper')
        into   vinterestoper_id;
        insert into interestoper
          (interestoper_id, DEBTINSTALMENT_ID, kindoper, oper_date, begin_date,
           end_date, instsum, intpct, interestsum, user_date, user_id)
        values
          (vinterestoper_id, ipdebtinstalment, '10', ipto1, vBDate, vEdate,
           basesum, crPCT, vpersum, current_date, ipuser_id);
        crPCT  := rintper.interestpct + coalesce(rintper.interestpctadd, 0);
        vBDate := rintper.begin_date;
      end loop;
      close crintper;
      vpersum := round((ipto1 - vBDate + integer '1') * crPCT * BaseSum / 36000.0, 5);
      vIntSum := vIntSum + vpersum;
      if vIntSum <> 0.0
      then
        if vintdebt_id is null
        then
          insert into interestdebt
            (intdebtsum, debtinstalment_id, user_date, todate)
          values
            (0, ipdebtinstalment, current_date, ipto1);
        end if;
        select nextval('s_interestoper')
        into   vinterestoper_id;
        insert into interestoper
          (interestoper_id, DEBTINSTALMENT_ID, kindoper, oper_date, begin_date,
           end_date, instsum, intpct, interestsum, user_date, user_id)
        values
          (vinterestoper_id, ipdebtinstalment, '10', ipto1, vBDate, ipto1,
           basesum, crPCT, vpersum, current_date, ipuser_id);
      
        update baldebtinst
        set    interestsum = COALESCE(interestsum, 0) + round(vIntSum, 5)
        where  debtinstalment_id = ipdebtinstalment;
      end if;
    end if;
    update interestdebt
    set    intdebtsum = intdebtsum + vIntSum, todate = ipto1
    where  debtinstalment_id = ipdebtinstalment;
    ----commit;  
  end if;
  return('OK');
exception
  when others then
    ----rollback; 
    return('errOrclDB' || sqlerrm);
end;
$function$
; DROP FUNCTION sanction_pkg.debtint(numeric, date, numeric, character varying, numeric); 
CREATE OR REPLACE FUNCTION sanction_pkg.debtint(iptaxsubject_id numeric, ipdate date, ipuser_id numeric, ippartno character varying, ipkinddebtreg_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  cr          cursor is
    select di.debtinstalment_id
    from   debtsubject ds, baldebtinst bd, debtinstalment di
    where  ds.taxsubject_id = iptaxsubject_id
    and    ds.debtsubject_id = di.debtsubject_id
    and    di.debtinstalment_id = bd.debtinstalment_id
    and nvl(ds.partidano,'*') = (case when ippartno=null then nvl(ds.partidano,'*')
			    when ippartno=0 then nvl(ds.partidano,'*')
			    else ippartno end)
    and ds.kinddebtreg_id = (case when ipkinddebtreg_id=null then ds.kinddebtreg_id
			    when ipkinddebtreg_id=0 then ds.kinddebtreg_id
			    else ipkinddebtreg_id end)				
    and    nvl(bd.instsum, 0.0) > 0.0;

  err         varchar(200);
  vintdebt_id numeric;
begin
  open cr;  
  loop
    fetch cr
      into vintdebt_id;
    exit when not found;
    err := sanction_pkg.CalculateInt(vintdebt_id, ipdate, ipuser_id);
    if err <> 'OK'
    then
      RAISE EXCEPTION 'ROLLBACK';
    end if;
  end loop;
  /*transaction PG-style
  if err = 'OK'
  then
    ----commit; 
  else
    ----rollback;  
  end if;*/
  return(err);
  exception when others then
   return(err);
   null;

end;
$function$
; DROP FUNCTION sanction_pkg.intcalculator(date, date, numeric); 
CREATE OR REPLACE FUNCTION sanction_pkg.intcalculator(ipfrom date, ipto date, ipsum numeric)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare
  crintper cursor(vtodate date) is
    select *
    from   interestpct ip
    where  ip.begin_date between
           (select max(ib.begin_date)
            from   interestpct ib
            where  ib.begin_date::date <= vtodate) and
           (select max(ie.begin_date)
            from   interestpct ie
            where  ie.begin_date::date <= trunc(ipto))
    order  by ip.begin_date;

  rintper  record;
  vBDate   date;
  vEDate   date;
  crPCT    numeric;
  vIntSum  numeric;
  vpersum  numeric;
  vtodate  date;
  opintsum numeric;

begin
  vtodate := ipfrom;

  open crintper(vtodate);
  fetch crintper
    into rintper;
  if not found
  then
    vIntSum := 0.0;
    return(vIntSum);
  end if;
  vIntSum := 0.0;
  vBDate  := vtodate;
  crPCT   := rintper.interestpct + nvl(rintper.interestpctadd, 0.0);
  loop
    fetch crintper
      into rintper;
    exit when not found;
    vEdate  := rintper.begin_date - interval '1 day';
    vpersum := (vEdate - vBDate + 1) * crPCT * IpSum / 36000.0;
    vIntSum := vIntSum + vpersum;
    crPCT   := rintper.interestpct + nvl(rintper.interestpctadd, 0.0);
    vBDate  := rintper.begin_date::date;
  end loop;
  vpersum := (trunc(ipto) - vBDate) * crPCT * ipSum / 36000.0;
  vIntSum := vIntSum + vpersum;
  return(round(vIntSum, 2));
end;
$function$
; DROP FUNCTION sanction_pkg.monthcalc(date, numeric); 
CREATE OR REPLACE FUNCTION sanction_pkg.monthcalc(ipintdate date, ipuser_id numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  cr cursor is
    select di.debtinstalment_id
    from   debtinstalment di, baldebtinst b
    where  di.debtinstalment_id = b.debtinstalment_id
    and    b.instsum > 0.0
    and    di.termpay_date < ipIntDate;

  r  record;
begin
  open cr;
  loop
    fetch cr
      into r;
    exit when not found;
  
    begin
      opStat := sanction_pkg.CalculateInt(r.debtinstalment_id, ipintdate,
                                          ipuser_id);
      if opStat <> 'OK'
      then
        raise exception 'ROLLBACK';
      end if;
    exception
      when others then
        exit;
    end;
  end loop;
  ----commit;
end;
$function$
; DROP FUNCTION sanction_pkg.tempdiscount(numeric, date); 
CREATE OR REPLACE FUNCTION sanction_pkg.tempdiscount(ipdebtinstalment numeric, ipto date)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare
  vdisc       numeric;
  vtotaltax   numeric;
  vpercent    numeric;
  vinstno     numeric;
  vtermdisc   date;
  vinstnumber numeric;
  vper_id     numeric;
  vdoctype_id numeric;
  vparend_id  numeric;
begin
  select d.termdisc, d.percent, ty.instnumber,
         (select sum(dd.totaltax)
           from   debtsubject dd
           where  dd.document_id = td.taxdoc_id
           and    dd.taxperiod_id = ds.taxperiod_id
           and    dd.taxsubject_id = ds.taxsubject_id
           and    dd.kinddebtreg_id = ds.kinddebtreg_id), di.instno,
         td.documenttype_id, ds.taxperiod_id, ds.parent_debtsubject_id
  into   vtermdisc, vpercent, vinstnumber, vtotaltax, vinstno, vdoctype_id,
         vper_id, vparend_id
  from   taxdoc td, discount d, debtinstalment di, debtsubject ds,
         documenttype ty -- taxperiod tp,
  where  d.documenttype_id = td.documenttype_id
  and    d.taxperiod_id = ds.taxperiod_id --tp.taxperiod_id
        
  and    ty.documenttype_id = td.documenttype_id
        --  and td.municipality_id = ty.municipality_id
  and    di.debtsubject_id = ds.debtsubject_id
  and    ds.document_id = td.taxdoc_id
  and    di.debtinstalment_id = ipdebtinstalment;
  select count(tp.taxperiodpay_id)
  into   vinstnumber
  from   taxperiodpay tp
  where  tp.taxperiod_id = vper_id
  and    tp.documenttype_id = vdoctype_id;

  if (ipto <= vtermdisc) and (vinstno = vinstnumber) and (vparend_id is null)
  then
    vdisc := round(vpercent * vtotaltax / 100, 2);
  else
    vdisc := 0;
  end if;
  return(vdisc);
end;
$function$
; DROP FUNCTION sanction_pkg.tempint(numeric, date); 
CREATE OR REPLACE FUNCTION sanction_pkg.tempint(ipdebtinstalment numeric, ipto date)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare
  crintper    cursor(vtodate date) is
    select *
    from   interestpct ip
    where  ip.begin_date between
           (select max(ib.begin_date)
            from   interestpct ib
            where  ib.begin_date <= vtodate) and
           (select max(ie.begin_date)
            from   interestpct ie
            where  ie.begin_date <= ipto)
    order  by ip.begin_date;

  rintper     record;
  vBDate      date;
  vEDate      date;
  crPCT       numeric;
  vIntSum     numeric;
  vpersum     numeric;
  vtodate     date;
  basesum     numeric;
  vintdebt_id numeric;
  ipto1       date;
begin
  ipto1 := ipto;
  select max(di.debtinstalment_id), max(di.todate)
  into   vintdebt_id, vtodate
  from   interestdebt di
  where  di.debtinstalment_id = ipdebtinstalment;
  if vintdebt_id is null
  then
    select di.intbegindate
    into   vtodate
    from   debtinstalment di
    where  di.debtinstalment_id = ipdebtinstalment;
  else
    vtodate := vtodate + integer '1';
  end if;
  vIntSum := 0.0;
  if vtodate < ipto1
  then
    select min(bd.instsum), sum(bd.interestsum)
    into   basesum, vIntSum
    from   baldebtinst bd
    where  bd.debtinstalment_id = ipdebtinstalment;
    vIntSum := 0.0;
    basesum := nvl(basesum, 0.0);
    if basesum <> 0.0
    then
      open crintper(vtodate);
      fetch crintper
        into rintper;
    
      if not found
      then
        close crintper;
        return(vIntSum);
      end if;
      vBDate := vtodate;
      crPCT  := rintper.interestpct + nvl(rintper.interestpctadd, 0.0);
      loop
        fetch crintper
          into rintper;
        exit when not found;
        vEdate  := rintper.begin_date::date - integer '1';
        vpersum := round((vEdate - vBDate + integer '1') * crPCT * BaseSum / 36000.0, 5);
        vIntSum := vIntSum + vpersum;
        crPCT   := rintper.interestpct + nvl(rintper.interestpctadd, 0.0);
        vBDate  := rintper.begin_date::date;
      end loop;
      vpersum := round((ipto1 - vBDate + integer '1') * crPCT * BaseSum / 36000.0, 5);
      vIntSum := vIntSum + vpersum;
      close crintper;
    end if;
  
  end if;
  return(round(vIntSum, 5));
end;
$function$
;
