DROP FUNCTION oracle.substr(text, integer); 
CREATE OR REPLACE FUNCTION oracle.substr(str text, start integer)
 RETURNS text
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$oracle_substr2$function$
; DROP FUNCTION oracle.substr(text, integer, integer); 
CREATE OR REPLACE FUNCTION oracle.substr(str text, start integer, len integer)
 RETURNS text
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$oracle_substr3$function$
;
