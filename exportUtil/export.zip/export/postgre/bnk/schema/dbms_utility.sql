DROP FUNCTION dbms_utility.format_call_stack(); 
CREATE OR REPLACE FUNCTION dbms_utility.format_call_stack()
 RETURNS text
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_utility_format_call_stack0$function$
; DROP FUNCTION dbms_utility.format_call_stack(text); 
CREATE OR REPLACE FUNCTION dbms_utility.format_call_stack(text)
 RETURNS text
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_utility_format_call_stack1$function$
;
