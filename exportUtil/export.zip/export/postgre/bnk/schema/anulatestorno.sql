DROP FUNCTION anulatestorno.cashpaymentanulate(character varying, date, numeric, numeric); 
CREATE OR REPLACE FUNCTION anulatestorno.cashpaymentanulate(ipkindpaydoc character varying, ipdatestor date, ipuser_id numeric, ippaydocument_id numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
begin
    if (ipKindpaydoc = '600')
    then
      declare
        cr cursor is
          select pdt.kinddebtreg_id kdrid, dis.debtsubject_id dsid,
                 sum(nvl(pdt.payinstsum, 0.0) + nvl(pdt.payinterestsum, 0.0)) sumOv                 
          from   paydebt pdt, debtinstalment dis
          where  pdt.debtinstalment_id = dis.debtinstalment_id
          and    pdt.paydocument_id = ipPayDocument_id
          group  by pdt.kinddebtreg_id, dis.debtsubject_id;
      
        r        record;
        tsid     numeric;
        partno   varchar(50);
        munid    numeric;
        vosid    numeric;
        vsb      numeric;
      begin
      
        select pd.taxsubject_id, pd.partidano, ptr.municipality_id
        into   tsid, partno, munid
        from   paydocument pd, paytransaction ptr
        where  pd.paytransaction_id = ptr.paytransaction_id
        and    pd.paydocument_id = ipPayDocument_id;
        open cr;
        loop
          fetch cr
            into r;
          exit when not found;
          select max(os.oversubject_id)
          into   vosid
          from   oversubject os
          where  os.kinddebtreg_id = r.kdrid
          and    os.taxsubject_id = tsid
          and    os.debtsubject_id = r.dsid;
        
          if vosid is not null
          then
          
            update OverSubject osup
            set    overpaysum =
                    (nvl(overpaysum, 0.0) + r.SumOv)
            where  osup.oversubject_id = vosid;
          
            select max(bi.oversubject_id)
            into   vsb
            from   baloverinst bi
            where  bi.oversubject_Id = vosid;
          
            if vsb is null
            then
              insert into Baloverinst
                (OverSubject_Id, oversum)
              values
                (vosid, r.SumOv);
            
            else
              update baloverinst boip
              set    oversum = nvl(oversum, 0.0) + r.SumOv
              where  boip.oversubject_id = vosid;
            
            end if;
          
          else
            select nextval('s_oversubject')
            into   vosid;
          
            insert into Oversubject
              (oversubject_id, kinddebtreg_id, taxsubject_id, overpaysum,
               overinterestsum, overcorsum, partidano, municipality_id,
               debtsubject_id)
            values
              (vosid, r.kdrid, tsid, r.sumOV, null, null, partno, munid, r.dsid);
          
            insert into Baloverinst
              (OverSubject_Id, oversum)
            values
              (vosid, r.SumOv);
          end if;
        
          insert into operation
            (operation_id, oper_date, operdocno, opercode, opersum, user_date,
             user_id, user_name, paytransaction_id, oversubject_id,
             municipality_id, cancel_Paydocument_Id)
          values
            (nextval('s_Operation'), ipDatestor, currval('s_Operation'), '17', r.SumOv,
             current_date, ipUser_id,
             (select us.fullname
               from   users us
               where  us.user_Id = ipUser_id), null, vosid, munid,
             ipPayDocument_id);
        
        end loop;
        --zatvarya cursora na 20.09.2011
        close cr;
      end;
    end if;
end;
$function$
; DROP FUNCTION anulatestorno.cashpaymentstorno(character varying, numeric, date, numeric, numeric); 
CREATE OR REPLACE FUNCTION anulatestorno.cashpaymentstorno(ipkindpaydoc character varying, ipfinishday_id numeric, ipdatestor date, ipuser_id numeric, ippaydocument_id numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
begin
  if (ipFinishday_id is not null)
  then
    if (ipKindpaydoc = '600')
    then
      declare
        cr cursor is
          select pdt.kinddebtreg_id kdrid, dis.debtsubject_id dsid,
                 sum(nvl(pdt.payinstsum, 0.0) + nvl(pdt.payinterestsum, 0.0)) sumOv,
                 max(pdt.kindparreg_id) kprid
          from   paydebt pdt, debtinstalment dis
          where  pdt.debtinstalment_id = dis.debtinstalment_id
          and    pdt.paydocument_id = ipPayDocument_id
          group  by pdt.kinddebtreg_id, dis.debtsubject_id;
      
      
        r        record;
        tsid     numeric;
        partno   varchar(50);
        munid    numeric;
        vosid    numeric;
        vsb      numeric;
        opid     numeric;
        vopersum numeric;
      
      begin
      
        select pd.taxsubject_id, pd.partidano, ptr.municipality_id
        into   tsid, partno, munid
        from   paydocument pd, paytransaction ptr
        where  pd.paytransaction_id = ptr.paytransaction_id
        and    pd.paydocument_id = ipPayDocument_id;
      
        select pd.docsum
        into   vopersum
        from   Paydocument pd
        where  pd.paydocument_id = ipPayDocument_id;
      
        open cr;
        loop
          fetch cr
            into r;
          exit when not found;
          select max(os.oversubject_id)
          into   vosid
          from   oversubject os
          where  os.kinddebtreg_id = r.kdrid
          and    os.taxsubject_id = tsid
          and    os.debtsubject_id = r.dsid;
        
          if vosid is not null
          then
            update OverSubject osup
            set    overpaysum =
                    (nvl(osup.overpaysum, 0.0) + r.SumOv)
            where  osup.oversubject_id = vosid;
          
            select max(bi.oversubject_id)
            into   vsb
            from   baloverinst bi
            where  bi.oversubject_Id = vosid;
          
            if vsb is null
            then
              insert into Baloverinst
                (OverSubject_Id, oversum)
              values
                (vosid, r.SumOv);
            
            else
              update baloverinst boip
              set    oversum = nvl(boip.oversum, 0.0) + r.SumOv
              where  boip.oversubject_id = vosid;
            
            end if;
          
          else
            select nextval('s_oversubject')
            into   vosid;
          
            insert into Oversubject
              (oversubject_id, kinddebtreg_id, taxsubject_id, overpaysum,
               overinterestsum, overcorsum, partidano, municipality_id,
               debtsubject_id)
            values
              (vosid, r.kdrid, tsid, r.sumOV, null, null, partno, munid, r.dsid);
          
            insert into Baloverinst
              (OverSubject_Id, oversum)
            values
              (vosid, r.SumOv);
          
          end if;
        
          select nextval('s_Operation')
          into   opid;
        
          insert into operation
            (operation_id, oper_date, operdocno, opercode, opersum, user_date,
             user_id, user_name, paytransaction_id, oversubject_id,
             municipality_id, cancel_Paydocument_Id)
          values
            (opid, ipDatestor, currval('s_Operation'), '17', r.SumOv,
             current_date, ipUser_id,
             (select us.fullname
               from   users us
               where  us.user_Id = ipUser_id), null, vosid, munid,
             ipPayDocument_id);
        
          insert into operdebt
            (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
             operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
             balinstsum)
          values
            (nextval('s_operdebt'), opid, r.kdrid, null, r.sumOV, null, null,
             r.kprid, null, null);
        
        end loop;
        --dobaveno zatvaryane na cursora 20092011
        close cr;
      end;
    end if;
  end if;
end;
$function$
; DROP FUNCTION anulatestorno.eachcatchstorno(numeric, numeric, date, numeric, character varying, numeric); 
CREATE OR REPLACE FUNCTION anulatestorno.eachcatchstorno(ipoperation_id numeric, ipuser_id numeric, ipdatestor date, ipmunicipality_id numeric, iposnovanie character varying, ipoversubject_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  vpaytr       numeric;
  vsumstortr   numeric;
  vtransaction numeric;
  vbaccount_id numeric;
  vbanksmetka  varchar(50);
  vbic         varchar(50);
  bidi         numeric;
  vregDocno    varchar(50);
  vseries      varchar(50);
  vbank_id     numeric;
  rec          record;

  cr cursor(mypaytr numeric) is
    select *
    from   paydocument pd
    where  pd.paytransaction_id = mypaytr;





  crd cursor(myvoper_id numeric) is
    select *
    from   operdebt od
    where  od.operation_Id = myvoper_id;




begin
  begin
    select op.paytransaction_id, ptr.trsuma
    into   vpaytr, vsumstortr
    from   operation op, paytransaction ptr
    where  op.operation_Id = ipOperation_id
    and    op.paytransaction_Id = ptr.paytransaction_Id;
  exception
    when others then
      return '';
  end;

  select nextval('s_paytransaction')
  into   vtransaction;

  insert into paytransaction
    (paytransaction_id, transactionno, trdate, trsuma, trtype, user_date,
     user_id, municipality_ID)
  values
    (vtransaction, nextval('s_paytransaction'), ipDatestor, vsumstortr, '3',
     current_date, ipUser_id, ipMunicipality_id);

  select b.baccount_id, b.iban, bk.bic, bk.bank_id
  into   vbaccount_id, vbanksmetka, vbic, vbank_id
  from   baccount b, bank bk
  where  b.municipality_id = ipMunicipality_id
  and    b.isbase = 1
  and    b.isactive = 1
  and    b.bank_id = bk.bank_id;

  for cr_r in cr(vpaytr)
  loop
  
    select into rec *
    from   getdocnumber(ipMunicipality_id, '630', '1');
    vregDocno := rec.opdocnumber;
    vseries   := rec.opseries;
    --perform getdocnumber(ipMunicipality_id, '630', '1', vregDocno, vseries);
  
    insert into PayDocument
      (paydocument_id, baccount_id, taxsubject_id, kindpaydoc, regdocno,
       documentno, series, documentdate, paydate, payTime, docsum, user_date,
       user_id, user_name, reason1, reason2, note, tsaccount, docpay,
       docfromdate, doctodate, paytransaction_id, partidano, taxobject_id,
       overPaySum, OverSubject_Id, over_kinddebtreg_id, From_kinddebtreg_id,
       tsbic, rcbic, rcaccount, rcbank_id)
    values
      (nextval('s_paydocument'), vbaccount_id, cr_r.taxsubject_id,
       cr_r.kindpaydoc, null, vregDocno, vseries, current_date, ipDatestor,
       current_date, cr_r.docsum, current_date, ipUser_id,
       (select us.fullname
         from   users us
         where  us.user_Id = ipUser_id), '������ ����������e', ipOsnovanie,
       cr_r.note, vbanksmetka, cr_r.docpay, cr_r.docfromdate, cr_r.doctodate,
       vtransaction, cr_r.partidano, cr_r.taxobject_id, cr_r.overPaySum,
       cr_r.OverSubject_Id, cr_r.From_kinddebtreg_id, cr_r.over_kinddebtreg_id,
       vbic, vbic, vbanksmetka, vbank_id);
  
  end loop;
   --zatvarya cursora na 20.09.2011
close cr;
  update operation 
  set    null_Date = ipDatestor, null_userDate = current_date,
         null_User_Id = ipUser_id,
         null_user_name =
          (select us.fullname
           from   users us
           where  us.user_Id = ipUser_id),
         null_PayTransaction_Id = vtransaction, null_reason = ipOsnovanie
  where  operation_Id = ipOperation_id;

  for cr_rd in crd(ipOperation_id)
  loop
  
    select max(bi.debtinstalment_Id)
    into   bidi
    from   baldebtinst bi
    where  bi.debtinstalment_Id = cr_rd.debtinstalment_Id;
    if bidi is null
    then
      insert into baldebtinst
        (debtinstalment_Id, InstSum, interestSum)
      values
        (cr_rd.debtinstalment_Id, cr_rd.operoversum, cr_rd.operintsum);
    else
      update baldebtinst 
      set    instsum =
              (nvl(instsum, 0.0) + nvl(cr_rd.operoversum, 0.0) +
              nvl(cr_rd.discsum, 0.0)),
             interestSum =
              (nvl(interestSum, 0.0) + nvl(cr_rd.operintsum, 0.0))
      where  debtinstalment_Id = cr_rd.debtinstalment_Id;
    end if;
    if nvl(cr_rd.discsum, 0.0) > 0
    then
      update debtsubject 
      set    paydiscsum = null
      where  dsup.debtsubject_id =
             (select di.debtsubject_id
              from   debtinstalment di
              where  di.debtinstalment_id = cr_rd.debtinstalment_Id);
    end if;
  
  end loop;
   --zatvarya cursora na 20.09.2011
close crd;
  select max(bis.oversubject_Id)
  into   bidi
  from   baloverinst bis
  where  bis.oversubject_id = ipOversubject_id;

  if bidi is null
  then
    insert into baloverinst
      (oversubject_Id, oversum)
    values
      (ipOversubject_id, vsumstortr);
  else
    update baloverinst 
    set    overSum = nvl(oversum, 0.0) + vsumstortr
    where  oversubject_Id = ipOversubject_id;
  end if;
exception
  when others then
    return '';
end;
$function$
; DROP FUNCTION anulatestorno.eachliquidateanulate(numeric, numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION anulatestorno.eachliquidateanulate(ipdebtinstalment_id numeric, ippayinstsum numeric, ippayinterestsum numeric, ippaydiscsum numeric, ipdebtsubject_id numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
declare

  bdi       numeric;
  visactive numeric;
begin
  select kd.isactive
  into   visactive
  from   kinddebtreg kd, debtsubject ds
  where  kd.kinddebtreg_id = ds.kinddebtreg_id
  and    ds.debtsubject_id = ipDebtsubject_id;
  if visactive <> 2
  then
    select max(bd.debtinstalment_id)
    into   bdi
    from   Baldebtinst bd
    where  bd.debtinstalment_id = ipDebtinstalment_id;
    if (bdi is null)
    then
    
      insert into BalDebtInst
        (debtinstalment_id, instsum, interestsum, discsum)
      values
        (ipDebtinstalment_id, (ipPayinstsum + ipPaydiscsum), ipPayinterestsum,
         null);
    
    else
      update Baldebtinst 
      set    instsum =
              (nvl(instsum, 0.0) + ipPayinstsum + ipPaydiscsum),
             interestsum =
              (nvl(interestsum, 0.0) + ipPayinterestsum), discsum = null
      where  debtinstalment_id = ipDebtinstalment_id;
    end if;
    if (ipPaydiscsum <> 0.0)
    then
      update debtsubject 
      set    paydiscsum = null
      where  debtsubject_id = ipDebtsubject_id;
    end if;
  end if;
  if visactive = 2
  then
    delete from baldebtinst 
    where  debtinstalment_id = ipDebtinstalment_id;
    update debtsubject 
    set    totaltax = 0, totalval = 0, note = '���������� �������'
    where  debtsubject_id =
           (select di.debtsubject_id
            from   debtinstalment di
            where  di.debtinstalment_id = ipDebtinstalment_id);
  
    update debtinstalment 
    set    instsum = 0
    where  debtinstalment_id = ipDebtinstalment_id;
  
  end if;
end;
$function$
; DROP FUNCTION anulatestorno.eachliquidatepayment(numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION anulatestorno.eachliquidatepayment(ipdebtinstalment_id numeric, ippayinstsum numeric, ippayinterestsum numeric, ippaydiscsum numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
declare                               
  bdi numeric;
begin

  select max(bd.debtinstalment_id)
    into bdi
    from Baldebtinst bd
   where bd.debtinstalment_id = ipDebtinstalment_id;
  if (bdi is null) then
  
    insert into BalDebtInst
      (debtinstalment_id, instsum, interestsum, discsum)
    values
      (ipDebtinstalment_id,
       (ipPayinstsum + ipPaydiscsum),
       ipPayinterestsum,
       null);
  
  else
    update Baldebtinst 
       set instsum     = (nvl(instsum, 0.0) + ipPayinstsum +
                              ipPaydiscsum),
           interestsum = (nvl(interestsum, 0.0) + ipPayinterestsum),
           discsum     = null
     where debtinstalment_id = ipDebtinstalment_id;
  end if;
  if (ipPaydiscsum > 0.0) then
  
    update debtsubject 
       set paydiscsum = 0.0
     where debtsubject_id =
           (select di.debtsubject_id
              from debtinstalment di
             where di.debtinstalment_id = ipDebtinstalment_id);
  end if;
end;
$function$
; DROP FUNCTION anulatestorno.eachliquidatestorno(numeric, numeric, date, numeric, numeric, character varying, numeric, numeric, numeric, date, character varying, character varying, numeric); 
CREATE OR REPLACE FUNCTION anulatestorno.eachliquidatestorno(ipoversubject_id numeric, ipdocsum numeric, ipdatestor date, ipuser_id numeric, ippaydocument_id numeric, ipkindpaydoc character varying, ipfinishday_id numeric, ipmunicipality_id numeric, ipdocnum numeric, ipuserdate date, ipidn character varying, ipname character varying, ipoverkinddebtreg_id numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
declare
  vptr         numeric;
  vbaccount_id numeric;
  vbanksmetka  varchar(100);
  vbic         varchar(100);
  vTSObstina   varchar(100);
  vbank_id     numeric;
  opdocnumber  varchar(50);
  opseries     varchar(50);
  rec          record;

begin
  select into rec *
  from   getdocnumber(ipMunicipality_id, '613', '6');
  opdocnumber := rec.opdocnumber;
  opseries    := rec.opseries;
  --perform getdocnumber(ipMunicipality_id, '613', '6', opdocnumber, opseries);
  if (ipFinishday_id is not null)
  then
    if (ipKindpaydoc = '621')
    then
      select nextval('s_Paytransaction')
      into   vptr;
      select b.baccount_id, b.iban, bk.bic, bk.bank_id
      into   vbaccount_id, vbanksmetka, vbic, vbank_id
      from   baccount b, bank bk
      where  b.municipality_id = ipMunicipality_id
      and    b.isbase = 1
      and    b.isactive = 1
      and    b.bank_id = bk.bank_id;
      select c.configvalue
      into   vTSObstina
      from   config c
      where  c.name = 'TAXSUBJECT_ID';
    
      insert into paydocument
        (paydocument_id, baccount_id, taxsubject_id, kindpaydoc, regdocno,
         documentno, series, documentdate, paydate, docsum, bin, user_date,
         user_id, user_name, reason1, note, tsaccount, paytransaction_id,
         partidano, reason2, oversubject_id, overpaysum, over_kinddebtreg_id,
         from_kinddebtreg_id, tsbic, rcbic, rcaccount, receive_taxsubject_id,
         company_id, rcbank_id)
      values
        (nextval('s_Paydocument'), vbaccount_id, vTSObstina ::numeric, '613',
         null, opdocnumber, opseries, ipDatestor, ipDatestor, ipDocsum, null,
         current_date, ipUser_id,
         (select us.fullname
           from   users us
           where  us.user_Id = ipUser_id),
         '������ ��� �' || ipDocnum || '/' || to_char(ipUserdate, 'dd.MM.yyyy'),
         null, vbanksmetka, vptr, null,
         '�� ���/�������:' || ipIdn || '���:' || ipName, ipOversubject_id,
         ipDocsum, ipOverkinddebtreg_id, null, vbaccount_id, vbaccount_id,
         vbanksmetka, null, null, vbank_id);
    
      insert into paytransaction
        (paytransaction_id, transactionno, trdate, trsuma, trtype, user_date,
         user_id, municipality_id)
      values
        (vptr, vptr, ipDatestor, ipDocsum, '2', current_date, ipUser_id,
         ipMunicipality_id);

      insert into operation
        (operation_id, oper_date, operdocno, opercode, opersum, user_date,
         user_id, user_name, paytransaction_id, oversubject_id, municipality_id,
         cancel_Paydocument_Id)
      values
        (nextval('s_Operation'), ipDatestor, currval('s_Operation'), '17',
         ipDocsum, current_date, ipUser_id,
         (select us.fullname
           from   users us
           where  us.user_Id = ipUser_id), null, ipOversubject_id,
         ipMunicipality_id, ipPayDocument_id);
    
    end if;
  end if;
end;
$function$
; DROP FUNCTION anulatestorno.rkoanulate(character varying, date, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION anulatestorno.rkoanulate(ipkindpaydoc character varying, ipdatestor date, ipuser_id numeric, ippaydocument_id numeric, ipmunicipality_id numeric)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
declare
  opdocnumber varchar(50);
  opseries    varchar(50);
  vparent_id  numeric;
  vdocno      varchar(20);
  vpaydate    date;
  rec         record;
begin
  select into rec *
  from   getdocnumber(ipMunicipality_id, '613', '6');
  opdocnumber := rec.opdocnumber;
  opseries    := rec.opseries;
  --perform getdocnumber(ipMunicipality_id, '613', '6', opdocnumber, opseries);

  if (ipKindpaydoc = '621')
  then
  
    select pd.parent_paydocument_id, pd.documentno, pd.paydate
    into   vparent_id, vdocno, vpaydate
    from   paydocument pd
    where  pd.paydocument_id = ipPayDocument_id;
    update paydocument 
    set    null_date = ipDatestor, null_userdate = current_date,
           null_user_id = ipUser_id,
           null_user_name =
            (select u.fullname
             from   users u
             where  u.user_id = ipUser_id),
           nullreason = '���  �����' || vdocno || '/' || vpaydate
    where  paydocument_id = vparent_id;
  end if;
end;
$function$
;
