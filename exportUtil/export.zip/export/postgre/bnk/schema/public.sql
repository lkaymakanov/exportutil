DROP FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.pldbg_oid_debug(oid); 
CREATE OR REPLACE FUNCTION public.pldbg_oid_debug(functionoid oid)
 RETURNS integer
 LANGUAGE c
 STRICT
AS '$libdir/plugins/plugin_debugger', $function$pldbg_oid_debug$function$
; DROP FUNCTION public.plpgsql_oid_debug(oid); 
CREATE OR REPLACE FUNCTION public.plpgsql_oid_debug(functionoid oid)
 RETURNS integer
 LANGUAGE sql
 STRICT
AS $function$ SELECT pldbg_oid_debug($1) $function$
; DROP FUNCTION public.pldbg_get_target_info(text, "char"); 
CREATE OR REPLACE FUNCTION public.pldbg_get_target_info(signature text, targettype "char")
 RETURNS targetinfo
 LANGUAGE sql
AS $function$
  SELECT p.oid AS target,
         pronamespace AS schema,
         pronargs::int4 AS nargs,
         -- The returned argtypes column is of type oidvector, but unlike
         -- proargtypes, it's supposed to include OUT params. So we
         -- essentially have to return proallargtypes, converted to an
         -- oidvector. There is no oid[] -> oidvector cast, so we have to
         -- do it via text.
         CASE WHEN proallargtypes IS NOT NULL THEN
           translate(proallargtypes::text, ',{}', ' ')::oidvector
         ELSE
           proargtypes
         END AS argtypes,
         proname AS targetname,
         proargmodes AS argmodes,
         proargnames AS proargnames,
         prolang AS targetlang,
         quote_ident(nspname) || '.' || quote_ident(proname) AS fqname,
         proretset AS returnsset,
         prorettype AS returntype
  FROM pg_proc p, pg_namespace n
  WHERE p.pronamespace = n.oid
  AND p.oid = $1::oid
  -- We used to support querying by function name or trigger name/oid as well,
  -- but that was never used in the client, so the support for that has been
  -- removed. The targeType argument remains as a legacy of that. You're
  -- expected to pass 'o' as target type, but it doesn't do anything.
  AND $2 = 'o'
$function$
; DROP FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint)
 RETURNS bigint
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric)
 RETURNS numeric
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, date, anyelement, date, anyelement, date); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, date, anyelement, date, anyelement, date)
 RETURNS date
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone)
 RETURNS time without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone)
 RETURNS timestamp without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone)
 RETURNS timestamp with time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, text, anyelement, text, anyelement, text, text); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, text, anyelement, text, anyelement, text, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, character, anyelement, character, anyelement, character, character); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, character, anyelement, character, anyelement, character, character)
 RETURNS character
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer, integer); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer, integer)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint, bigint); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint, bigint)
 RETURNS bigint
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric, numeric); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric, numeric)
 RETURNS numeric
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, date, anyelement, date, anyelement, date, date); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, date, anyelement, date, anyelement, date, date)
 RETURNS date
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone, time without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone, time without time zone)
 RETURNS time without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone)
 RETURNS timestamp without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone)
 RETURNS timestamp with time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.dsaproc(numeric); 
CREATE OR REPLACE FUNCTION public.dsaproc(ipreq_id numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  DSAreq cursor is
    select l.idn, l.name
    from   dsalist l
    where  l.recnom = 0
    and    l.dsarequest_id = ipreq_id;

  cr_subj cursor (ipidn varchar) is
    select ts.taxsubject_id, ts.name
    from   taxsubject ts
    where  ts.idn = ipidn;
  vtaxsubjectId numeric;

  cr_prop cursor (tsId numeric) is
    select (select d.value
             from   decode d
             where  upper(d.columnname) = 'KINDPROPERTY'
             and    d.code = trim(p.kindproperty)) kindprop,
           getaddress(p.property_address_id) addr, p.property_id prop_id
    from   partproperty pp
    inner join property p on pp.property_id = p.property_id
    inner join  taxdoc t on t.taxdoc_id = p.taxdoc_id
    where  pp.taxsubject_id = tsId
    and    pp.typedeclar = 1
    and    t.docstatus <> '90'
    and    (exists
     (select *
            from parthomeobj ho
            inner join homeobj h on h.homeobj_id = ho.homeobj_id
            inner join building b on b.building_id = h.building_id
            where b.property_id = p.property_id
              and ho.taxsubject_id = pp.taxsubject_id
              and case when coalesce(ho.part, 0) = 0 then
                          (ho.divident / case when coalesce(ho.divisor, 0) = 0 then 1
                                              else coalesce(ho.divisor, 0) end)
                       else ho.part end > 0)      or 
             exists(select * from land l inner join partland pl on pl.land_id = l.land_id 
                     where l.property_id = p.property_id
                       and l.typedeclar = 1
                       and (case when coalesce(pl.partland, 0) = 0 then
                                   (pl.dividentland / case when coalesce(pl.divisorland, 0) = 0 then 1 else pl.divisorland end)
                                else pl.partland end) > 0));
                       
  cr_parts cursor (tsId numeric, propid numeric) is
    select r.fullname kindobj,
           (case when coalesce(ph.part, 0) = 0 then (ph.divident || '/' || ph.divisor) else to_char(ph.part) end) part
    from   parthomeobj ph
    inner join homeobj h on h.homeobj_id = ph.homeobj_id
    inner join building b on b.building_id = h.building_id
    inner join kindhomeobjreg r on r.kindhomeobjreg_id = h.kindhomeobjreg_id
    where ph.taxsubject_id = tsId
      and b.property_id = propid
      and (case when coalesce(ph.part, 0) = 0 then 
                    (ph.divident / case when coalesce(ph.divisor, 0) = 0 then 1 else ph.divisor end)
               else ph.part end) > 0
    union all
    select '����' kindobj,
           (case when coalesce(pl.partland, 0) = 0 then (pl.dividentland || '/' || pl.divisorland) else to_char(pl.partland) end) part
        from   partland pl 
        inner join land l on l.land_id = pl.land_id     
        where pl.taxsubject_id = tsId
          and pl.typedeclar = 1 
          and l.property_id = propid
          and (case when coalesce(pl.partland, 0) = 0 then
                         (pl.dividentland / case when coalesce(pl.divisorland, 0) = 0 then 1 else pl.divisorland end)
                    else pl.partland end) > 0;                  

  cr_trans cursor (taxsubj numeric) is
    select min(r.name) kindtr, count(t.transport_id) trnom
    from   transport t
    inner join taxdoc td on td.taxdoc_id = t.taxdoc_id
    inner join parttransport pt on pt.transport_id = t.transport_id
    inner join transpmeansreg r on r.transpmeansreg_id = t.transpmeansreg_id
    where  pt.taxsubject_id = taxsubj
    and    t.taxdoc_id = td.taxdoc_id
    and    td.docstatus <> '90'
    group  by t.transpmeansreg_id;

  io        integer;
  js        integer;
  vnote     varchar(100);
begin

  For dsa in DSAreq Loop

    delete from dsalist l
     where l.dsarequest_id = ipreq_id
       and l.idn = dsa.idn
          --and l.name = vname
       and l.recnom > 0;
       commit;

       js := 0;
       for subj in cr_subj(dsa.idn) loop
         io     := 0;
         vnote  := '';
         js     := js + 1;
        -- �������� �� ��� �� ������
         if (trim(subj.name) != trim(dsa.name)) then
           vnote := ''; --'������ ��� �� ������';
         elsif (trim(subj.name) = '') then
           vnote := '������ ��� �� ������';
         end if;
         -- subj properties
         for prop in cr_prop(subj.taxsubject_id) loop
           io := io + 1;
           insert into DSALIST
            (dsarequest_id, idn, name, recnom, kind, address, objpart,
             transportnom, note, taxsubject_id, property_id)
           values
            (ipreq_id, dsa.idn, case when io > 1 then ' ' else subj.name end, io, prop.kindprop, prop.addr, null, null,
             vnote, subj.taxsubject_id, prop.prop_id);
           vnote := '';
           -- real parts
           for pobj in cr_parts(subj.taxsubject_id, prop.prop_id) loop
            io := io + 1;
            insert into DSALIST
              (dsarequest_id, idn, name, recnom, kind, address, objpart,
               transportnom, note, taxsubject_id, property_id)
            values
              (ipreq_id, dsa.idn, ' ' /*subj.name*/, io, pobj.kindobj, null, pobj.part, 
               null, vnote, subj.taxsubject_id, prop.prop_id);

           end loop;
           
         end loop;

       -- MPC
         for trans in cr_trans(subj.taxsubject_id) loop
          io := io + 1;
          insert into DSALIST
            (dsarequest_id, idn, name, recnom, kind, address, objpart,
             transportnom, note, taxsubject_id, property_id)
          values
            (ipreq_id, dsa.idn, case when io > 1 then ' ' else subj.name end, io, trans.kindtr, null, null,
             trans.trnom, vnote, subj.taxsubject_id, null);

         end loop;

       end loop;

       if (js = 0) or (js = 1 and io = 0) then
        -- ��� �� ������ ���
        if (js = 0) and (length(dsa.idn) = 10) and not checkEGN(dsa.idn) then
          vnote := '������ ���';
        else
          vnote := '���� �����';
        end if;
        insert into DSALIST
          (dsarequest_id, idn, name, recnom, kind, address, objpart, transportnom,
           note, taxsubject_id, property_id)
        values
          (ipreq_id, dsa.idn, dsa.name, 1, null, null, null, null, vnote, null, null);
       end if;

       commit;

  End Loop;
--> Old way --->
/*
  open DSAreq;
  loop
    fetch dsareq
      into vidn, vname;
    exit when dsareq%notfound;
    delete from dsalist l
    where  l.dsarequest_id = ipreq_id
    and    l.idn = vidn
          --and l.name = vname
    and    l.recnom > 0;

    js := 0;
    open subj(vidn);
    io     := 0;
    vnote  := '';
    bsname := '';
    loop
      fetch subj
        into vtaxsubjectId;
      exit when subj%notfound;
      js := js + 1;
      select t.name
      into   bsname
      from   taxsubject t
      where  t.taxsubject_id = vtaxsubjectId;
      if (trim(bsname) <> trim(vname))
      then
        -- �������� �� ��� �� ������
        vnote := '������ ��� �� ������';
      elsif (trim(bsname) = '')
      then
        vnote := '������ ��� �� ������';
      end if;
      --- �����
      open prop(vtaxsubjectId);
      loop
        fetch prop
          into rprop;
        exit when prop%notfound;
        io := io + 1;
        insert into DSALIST
          (dsarequest_id, idn, name, recnom, kind, address, objpart,
           transportnom, note, taxsubject_id, property_id)
        values
          (ipreq_id, vidn, bsname, io, rprop.kindprop, rprop.addr, null, null,
           vnote, vtaxsubjectId, rprop.prop_id);
        vnote := '';

        open partobj(vtaxsubjectId, rprop.prop_id);
        loop
          fetch partobj
            into rpartobj;
          exit when partobj%notfound;
          io := io + 1;
          insert into DSALIST
            (dsarequest_id, idn, name, recnom, kind, address, objpart,
             transportnom, note, taxsubject_id, property_id)
          values
            (ipreq_id, vidn, ' ' , io, rpartobj.kindobj, null,
             rpartobj.part, null, vnote, vtaxsubjectId, rprop.prop_id);
        end loop; -- partobj
        close partobj;

        select min(decode(coalesce(pl.partland, 0), 0,
                           (pl.dividentland || '/' || pl.divisorland),
                           to_char(pl.partland)))
        into   vlandpart
        from   partland pl, land l
        where  pl.taxsubject_id = vtaxsubjectId
        and    pl.land_id = l.land_id
        and    l.property_id = rprop.prop_id
        and    decode(coalesce(pl.partland, 0), 0,
                      (pl.dividentland /
                       decode(coalesce(pl.divisorland, 0), 0, 1, pl.divisorland)),
                      pl.partland) > 0;
        if vlandpart is not null
        then
          io := io + 1;
          insert into DSALIST
            (dsarequest_id, idn, name, recnom, kind, address, objpart,
             transportnom, note, taxsubject_id, property_id)
          values
            (ipreq_id, vidn, ' ', io, '����', null, vlandpart, null,
             vnote, vtaxsubjectId, rprop.prop_id);
        end if;
      end loop; -- prop
      close prop;
      --- ���
      open trans(vtaxsubjectId);
      loop
        fetch trans
          into rtrans;
        exit when trans%notfound;
        io := io + 1;
        insert into DSALIST
          (dsarequest_id, idn, name, recnom, kind, address, objpart,
           transportnom, note, taxsubject_id, property_id)
        values
          (ipreq_id, vidn, ' ', io, rtrans.kindtr, null, null,
           rtrans.trnom, vnote, vtaxsubjectId, rprop.prop_id);
      end loop; --- trans
      close trans;

    end loop;
    close subj;

    if (js = 0) or (js = 1 and io = 0)
    then
      -- ��� �� ������ ���
      if (js = 0) and (length(vIDN) = 10) and not checkEGN(vIDN) then
        vnote := '������ ���';
      else
        vnote := '���� �����';
      end if;
      insert into DSALIST
        (dsarequest_id, idn, name, recnom, kind, address, objpart, transportnom,
         note, taxsubject_id, property_id)
      values
        (ipreq_id, vidn, vname, 1, null, null, null, null, vnote, null, null);
    end if;

  end loop; -- req
  commit;
  close DSAreq; */
end;
$function$
; DROP FUNCTION public.dump("any"); 
CREATE OR REPLACE FUNCTION public.dump("any")
 RETURNS character varying
 LANGUAGE c
AS '$libdir/orafunc', $function$orafce_dump$function$
; DROP FUNCTION public.dump(text); 
CREATE OR REPLACE FUNCTION public.dump(text)
 RETURNS character varying
 LANGUAGE c
AS '$libdir/orafunc', $function$orafce_dump$function$
; DROP FUNCTION public.dump("any", integer); 
CREATE OR REPLACE FUNCTION public.dump("any", integer)
 RETURNS character varying
 LANGUAGE c
AS '$libdir/orafunc', $function$orafce_dump$function$
; DROP FUNCTION public.dump(text, integer); 
CREATE OR REPLACE FUNCTION public.dump(text, integer)
 RETURNS character varying
 LANGUAGE c
AS '$libdir/orafunc', $function$orafce_dump$function$
; DROP FUNCTION public.existsnode(character varying, character varying); 
CREATE OR REPLACE FUNCTION public.existsnode(node character varying, doc character varying)
 RETURNS boolean
 LANGUAGE plpgsql
AS $function$
begin
 if array_length(xpath(rtrim(replace('/_root/' || node, '//','/'),'/'),xmlparse(content '<_root>'||doc||'</_root>')), 1) >= 1
 then return true;
 else return false;
 end if;
  
end;
$function$
; DROP FUNCTION public.existsnode(character varying, xml); 
CREATE OR REPLACE FUNCTION public.existsnode(node character varying, doc xml)
 RETURNS boolean
 LANGUAGE plpgsql
AS $function$
begin
 
 if array_length(xpath(rtrim(replace('/_root/' || node, '//','/'),'/'),xmlparse(content '<_root>'|| doc || '</_root>')), 1) >= 1
 then return true;
 else return false;
 end if;
  
end;
$function$
; DROP FUNCTION public.extractvalue(xml, character varying); 
CREATE OR REPLACE FUNCTION public.extractvalue(p_data xml, p_xpath character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
res varchar;
begin

 select (xpath(rtrim(replace('/_root/' || p_xpath, '//','/'),'/')||'/text()',xmlparse(content '<_root>'|| p_data || '</_root>')))[1]::text into res;
 return res;                         
end;
$function$
; DROP FUNCTION public.corrinterest(numeric, numeric, date, numeric, date, numeric, character varying, date, character varying); 
CREATE OR REPLACE FUNCTION public.corrinterest(ipuser_id numeric, ipdebtinstalment_id numeric, ipfromdate date, ipsuminterest_new numeric, ipdatecorr date, ipofficial_id numeric, OUT opstat character varying, ipprotocolnom character varying, ipprotdate date, ipreason_corr character varying, OUT javabundleresult integer)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                                         
   cr cursor is
    select *
    from   interestoper io
    where  io.kindoper <= 10
    and    io.debtinstalment_id = ipDebtinstalment_Id
    order  by io.begin_date;
  r                record;
  vBegin_Date      date;
  vEnd_date        date;
  vIntdebtsum_Old  numeric;
  vsumCorr         numeric; -- suma korekcia
  vsumLix          numeric; --suma lixva sled korekcia
  vDalzLix         numeric; -- dalzima lixva
  vDalzGl          numeric;
  Razlika          numeric;
  vOperation_Id    numeric;
  vkinddebtreg_id  numeric;
  vkindparreg_Id   numeric;
  vdebtsubject_id  numeric;
  vtaxsubject_id   numeric;
  vpartidano       varchar(40);
  vmunicipality_Id numeric;
  voversubject_Id  numeric;
  vinterestcorr_Id numeric;
  -- 
begin
  if ipdateCorr is null
  then
    opstat           := '���������� ���� ��������!';
    javaBundleResult := 1;
    return;
  end if;

  select max(nvl(idt.intdebtsum, 0.0)), max(idt.todate)
  into   vIntdebtsum_Old, vEnd_date
  from   interestdebt idt
  where  idt.debtinstalment_id = ipDebtinstalment_Id;
  if vIntdebtsum_Old = 0
  then
    opstat           := '������ ��������� �����!';
    javaBundleResult := 2;
    return;
  end if;
  ---storno lixa ot data 
  if ipFromDate is not null
  then
  
    select di.intbegindate::date
    into   vBegin_Date
    from   debtinstalment di
    where  di.debtinstalment_id = ipDebtinstalment_Id;
  
    if ipFromDate < vBegin_Date
    then
      opstat           := '���������� ���� �� ����� �� �� ������� �����!';
      javaBundleResult := 3;
      return;
    end if;
  
    if ipFromDate = vBegin_Date
    then
      --storno na cialta suma lixva
      vsumLix := 0;
    else
      open cr;
      loop
        fetch cr
          into r;
        exit when not FOUND;
        if r.end_date::date < ipfromdate
        then
          vsumLix := nvl(vsumlix, 0.0) + r.interestsum;
        else
          --  IntCalculator (ipfrom date,ipto date,ipsum numeric)
          vsumLix := nvl(vsumlix, 0.0) +
                     (r.instsum * r.intpct * (ipFromdate - r.begin_date) /
                      36000);
          exit;
        end if;
      
      end loop;
    end if;
    if vsumLix > vIntdebtsum_Old
    then
      vsumLix := vIntdebtsum_Old;
    end if;
  
  end if; -- opredeliane na suma lixva za storno po data
  ------
  if ipFromDate is null and nvl(ipSumInterest_New, 0.0) >= 0.0
  then
    vsumlix := ipSumInterest_New;
    if vsumLix > vIntdebtsum_Old
    then
      opstat           := '���������� ���� ����� - �����!';
      javaBundleResult := 4;
      return;
    end if;
  end if;
  --------------------------
  vsumLix  := round(vsumLix, 2);
  vsumCorr := vsumLix - vIntdebtsum_Old;
  if vsumCorr = 0
  then
    opstat           := '������ ����� �� ����������!';
    javaBundleResult := 5;
    return;
  end if;
  insert into interestoper
    (interestoper_id, debtinstalment_id, kindoper, oper_date, begin_date,
     end_date, instsum, intpct, interestsum, user_date, user_id)
  values
    (nextval('s_interestoper'), ipdebtinstalment_id, '20', ipdateCorr, ipfromdate,
     vEnd_date, null, null, vsumCorr, current_timestamp, ipuser_Id);

  update interestdebt
  set    intdebtsum = vSumLix,
         --  idup.todate = ipFromDate
         todate = ipdateCorr
  where  debtinstalment_id = ipDebtinstalment_Id;

  select round(nvl(bd.interestsum, 0.0), 2), nvl(bd.instsum, 0.0)
  into   vDalzLix, vdalzGl
  from   baldebtinst bd
  where  bd.debtinstalment_id = ipDebtinstalment_Id;
  ---------------------------------------       
  Razlika := vSumlix - (vIntdebtsum_Old - vDalzLix);
  razlika := Round(Razlika, 2);
  if (Razlika >= 0)
  then
    update baldebtinst
    set    interestsum = Razlika
    where  debtinstalment_id = ipDebtinstalment_Id;
  end if;

  if razlika < 0
  then
    select ds.debtsubject_id, ds.kinddebtreg_Id, ds.kindparreg_Id, ds.partidano,
           ds.municipality_id, ds.taxsubject_id
    into   vdebtsubject_id, vkinddebtreg_Id, vkindparreg_Id, vpartidano,
           vmunicipality_id, vtaxsubject_id
    from   debtinstalment di, debtsubject ds
    where  ds.debtsubject_id = di.debtsubject_id
    and    di.debtinstalment_id = ipDebtinstalment_Id;
  
    update baldebtinst
    set    interestsum = 0
    where  debtinstalment_id = ipDebtinstalment_Id;
  
  
  
    select nextval('s_operation')
    into   vOperation_Id
    from   dual;
  
    insert into operation
      (operation_id, oper_date, operdocno, opercode, opersum, user_date,
       user_id, user_name, baloversum, resolution_id, paytransaction_id,
       oversubject_id, municipality_id)
    values
      (voperation_id, ipDateCorr, voperation_id, '16', -Razlika, current_timestamp,
       ipuser_Id,
       (select u.fullname
         from   users u
         where  u.user_id = ipuser_Id), null, null, null, null, vmunicipality_Id);
    insert into operdebt
      (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
       operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
       balinstsum)
    values
      (nextval('s_operdebt'), vOperation_Id, vkinddebtreg_Id, ipdebtinstalment_Id,
       -Razlika, null, null, vkindparreg_Id, null, null);
  
    select nextval('s_oversubject')
    into   voversubject_Id
    from   dual;
  
    insert into oversubject
      (oversubject_id, kinddebtreg_id, taxsubject_id, overpaysum,
       overinterestsum, overcorsum, partidano, municipality_id, debtsubject_id)
    values
      (voversubject_Id, vkinddebtreg_id, vtaxsubject_id, null, -Razlika, null,
       vpartidano, vmunicipality_Id, vdebtsubject_id);
    insert into baloverinst
      (oversubject_id, oversum)
    values
      (voversubject_Id, -Razlika);
  end if;
  -- zapis v INTERESTCORR

  select nextval('s_interestcorr')
  into   vinterestcorr_Id
  from   dual;

  insert into interestcorr
    (interestcorr_id, official_id, debtinstalment_id, datecorr, interestsum_old,
     interestsum_new, oversum, user_id, user_date, protocolno, protocol_date,
     reason_corr, operation_Id)
  values
    (vinterestcorr_Id, ipOfficial_Id, ipDebtinstalment_Id, ipdatecorr,
     vIntdebtsum_Old, ipSumInterest_New, decode(sign(razlika), -1.0, -razlika, 0.0),
     ipUser_Id, current_timestamp, ipProtocolNom, ipprotdate, ipreason_corr, vOperation_Id);

  --commit;
  opStat           := 'OK';
  javaBundleResult := 0;
exception
  when others then
    --rollback;
    opStat           := '������';
    javaBundleResult := -1;
end;
$function$
; DROP FUNCTION public.fday(numeric, numeric, timestamp without time zone, timestamp without time zone, numeric); 
CREATE OR REPLACE FUNCTION public.fday(ipuser numeric, ipoffice numeric, ipdatprik timestamp without time zone, ippaydate timestamp without time zone, OUT opstat character varying, ipcashier_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  ptract cursor (vfinday numeric) is
    select pt.municipality_id
    from   paytransaction pt
    where  pt.finishday_id = vfinday
    group  by pt.municipality_id;
  pn cursor (vfinday numeric) is
  -- pri kasovo plastane ne se dopuska nadvnasiane na sumi!
    select ptr.municipality_Id mncp, pdt.kinddebtreg_Id kdr,
           sum(coalesce(pdt.payinstsum, 0)) + sum(coalesce(pdt.payinterestsum, 0)) suma
    from   paydocument pd
           inner join paytransaction ptr on ptr.paytransaction_id = pd.paytransaction_id
           inner join paydebt pdt on pdt.paydocument_id = pd.paydocument_id
           inner join kinddebtreg kdr on kdr.kinddebtreg_id = pdt.kinddebtreg_id
    where  pd.null_date is null
    and    ptr.finishday_id = vfinday
    and    ptr.trtype = '1'
    and    pd.kindpaydoc = '600'
    group  by ptr.municipality_Id, pdt.kinddebtreg_Id, kdr.code
    order by kdr.code;

  -- rpt record;
  --rpn record; --pn%rowtype;
  ---rrko rko%rowtype;
  r            record;
  vfinday      numeric;
  vptr         numeric;
  vusername    varchar(150);
  vbaccount_id numeric;
  vbanksmetka  varchar(150);
  vbic         varchar(150);
  vrgn         numeric;
  vregDocno    varchar(30);
  vseries      varchar(6);
  vtaxsubid    numeric;
  vNote        varchar(200);

begin
  select u.fullname
  into   vusername
  from   users u
  where  u.user_id = ipuser;
/*  select '��������� ���� - ���: ' || u.other || ' ���:' || u.fullname
  into   vnote
  from   users u
  where  u.user_id = ipCashier_Id; changed 04.11.2011 Fryday
*/
  if ipoffice < 0 then
    opStat := 'errOrclDB'; --'������';
    return;
  end if;
  select snextval('s_Finishday') into vfinday as dummy;

  -- Finishday
  insert into FinishDay
    (finishday_id, office_id, date_finish, user_id, to_date, username,
     from_date)
  -- (finishday_id, office_id, to_date, user_id, userdate, username)
  values
    (vfinday, ipoffice, trunc(ipdatPrik), ipuser, ipdatPrik, vusername,
     (select max(fi.To_date)
       from   finishday fi
       where  fi.office_id = ipoffice
       and    fi.to_date < ipdatPrik));
  --  + 1 sekunda !
  ---FinishCashier
  update paytransaction 
  set    finishday_id = vfinday
  where  office_id = ipoffice
  and    finishday_id is null
  and    trtype = '1'
  and    trunc(trdate) <= ipdatPrik ------!!!
  ;
  insert into FinishCashier
    (finishcashier_id, finishday_id, user_id, username, dt_sum, kt_sum)
    (select snextval('s_finishcashier'), vfinday, debit.usid,
            (select u.fullname
              from   users u
              where  u.user_id = debit.usid), debit.ss, kredit.ss
     from   (select pd1.user_id usid, sum(coalesce(pd1.docsum, 0)) ss
              from   paytransaction ptr1, paydocument pd1
              where  ptr1.finishday_id = vfinday
              and    pd1.paytransaction_id = ptr1.paytransaction_id
              and    ptr1.trtype = '1'
              and    pd1.null_date is null
              and    pd1.kindpaydoc = '600'
              -- and pd.paydate = to_Date('08.10.2008','dd.mm.yyyy')
              group  by pd1.user_id) debit
     left   outer join (select pd2.user_id usid, sum(coalesce(pd2.docsum, 0)) ss
                       from   paytransaction ptr2, paydocument pd2
                       where  ptr2.finishday_id = vfinday
                       and    pd2.paytransaction_id = ptr2.paytransaction_id
                       and    ptr2.trtype = '1'
                       and    pd2.null_date is null
                       and    pd2.kindpaydoc = '621'
                       -- and pd.paydate = to_Date('08.10.2008','dd.mm.yyyy')
                       group  by pd2.user_id) kredit
     on     debit.usid = kredit.usid);
  --Paytransaction --> Sazdavane na pl.dok za vsiaka obshtina
  for rpt in ptract(vfinday) loop
    --fetch ptract into rpt;
    --exit when ptract%notfound;
    select snextval('s_paytransaction') into vptr as dummy;
    insert into paytransaction
      (paytransaction_id, transactionno, trdate, trsuma, trtype, user_date,
       user_id, verified_user_id, verified_user_date, municipality_id,
       transactionreg_id, office_id, finishday_id)

      (select vptr, vptr, trunc(ipdatPrik),
              (select sum(coalesce(pd.docsum, 0))
                from   paydocument pd, paytransaction ptr
                where  pd.paytransaction_id = ptr.paytransaction_id
                and    pd.null_date is null
                and    ptr.finishday_Id = vfinday
                and    ptr.trtype = '1'
                and    ptr.municipality_id = rpt.municipality_id
                and    pd.kindpaydoc = '600'), '31', current_date, ipuser, null, null,
              rpt.municipality_id, null, ipoffice, vfinday
       from dual);
  end loop;
  -------- end Paytransaction
  -- prevodni narezdania za PK
  -- close ptract;
  for rpn in pn(vfinday) loop
    --fetch pn into rpn;
    --exit when pn%notfound;
    begin
      select b.baccount_id, b.iban, bk.bic
      into   vbaccount_id, vbanksmetka, vbic
      from   baccount b, bank bk
      where  b.municipality_id = rpn.mncp
      and    b.isbase = 1
      and    b.isactive = 1
      and    b.bank_id = bk.bank_id;
    exception
      when others then begin
       rollback; 
       opStat := 'errMissBank';
       return;
      end; 
    end;  

    r := getdocnumber(rpn.mncp, '613', '1');
    vregDocno := r.opdocnumber;
    vseries := r.opseries;
    if vregDocno = '-1' then
      exit;
    end if;

    select c.configvalue
    into   vtaxsubid
    from   config c
    where  c.name = 'TAXSUBJECT_ID'
    and    c.municipality_id = rpn.mncp;
    select '��������� ���� - ���: ' || ts.idn || ' ���: ' || ts.name /*changed 04.11.2011 Fryday*/
    into   vnote
    from   taxsubject ts
    where  ts.taxsubject_id = vtaxsubid;


    insert into paydocument
      (paydocument_id, baccount_id, taxsubject_id, kindpaydoc, regdocno,
       documentno, series, documentdate, paydate, docsum, bin, user_date,
       user_id, user_name, reason1, note, tsaccount, null_date, docpay,
       docfromdate, doctodate, paytime, paytransaction_id, partidano,
       taxobject_id, reason2, oversubject_id, overpaysum, over_kinddebtreg_id,
       from_kinddebtreg_id, tsbic, nullreason, rcbic, rcaccount,
       RECEIVE_TAXSUBJECT_ID)

      (select snextval('s_paydocument'), vbaccount_id, vtaxsubid, '613', null,
              vregDocno, null, trunc(ippaydate), trunc(ippaydate), rpn.suma,
              null, current_date, ipuser, vusername,
              '��.�����. �� ���� ' ||
               To_char(ipdatprik, 'dd.mm.yyyy hh24:mi:ss'), vnote, vbanksmetka,
              null, ipdatprik, ipdatprik, ipdatprik, ipdatprik, vptr, null, null,
              (select k.fullname
                from   kinddebtreg k
                where  k.kinddebtreg_id = rpn.kdr), null, null, rpn.kdr, null,
              vbic, null, vbic, vbanksmetka, vtaxsubid
       from   dual);
  end loop;
  --close pn;
  ----�� �������� �� �� ���
  update paytransaction 
  set    finishday_id = vfinday
  where  trtype = '32'
  and    finishday_id is null;
  --- iztrivane na nulevi ostataci
  delete from baldebtinst 
  where  coalesce(instsum, 0) = 0
  and    round(abs(coalesce(interestsum, 0)), 2) = 0.00;

  --commit;
  opStat := 'OK';
exception
  when no_data_found then      
    opStat := 'errMissDuty'; --'������� �����';
    opStat := sqlerrm;
  when others then
    opStat := 'errOrclDB'; --'������';
    opStat := sqlerrm;
end;
$function$
; DROP FUNCTION public.corroldds(numeric, numeric, numeric, numeric, numeric, date, date, numeric, date, character varying, date, numeric, character varying, character varying, date, date, numeric, date, numeric, numeric, character varying, character varying, character varying); 
CREATE OR REPLACE FUNCTION public.corroldds(ipdebtsubject_id numeric, iptotalval numeric, iptotaltax numeric, ipfreesumsubj numeric, ipfreesumobj numeric, iptax_begindate_new date, iptax_enddate_new date, ipuser_id numeric, ipdoc_date_new date, ipdocno_new character varying, ipdatecorr date, ipinspector_id numeric, ipreason_corr character varying, ipprotocolnom character varying, ipprotdate date, iptermpay_date date, ipdebtsubject_new numeric, ipinterestbegdate date, iptaxsubject_id numeric, ipkinddebtreg_id numeric, ippartidano character varying, ipkindcorr character varying, OUT opstat character varying, ipclosedoc character varying DEFAULT '0'::character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                                      
 cr cursor is
    select di.debtinstalment_id, di.termpay_date,
           nvl(bi.interestsum, 0.0) interestsum, di.instno, bi.instSum,
           ds.kinddebtreg_id, ds.debtsubject_id, ds.kindparreg_id
    from   debtsubject ds
    inner  join debtinstalment di
    on     ds.debtsubject_id = di.debtsubject_id
    left   outer join baldebtinst bi
    on     bi.debtinstalment_Id = di.debtinstalment_Id
    where  (ds.debtsubject_id = ipDebtsubject_Id or
           ds.parent_debtsubject_id = ipDebtsubject_Id)
    and    nvl(bi.instSum, 0.0) > 0 -- samo za neplateni otataci prispada po vnoski
    order  by di.termpay_date, bi.instsum;

   cr1 cursor is
    select di.debtinstalment_id, di.termpay_date,
           nvl(bi.interestsum, 0.0) interestsum, di.instno, bi.instSum,
           ds.kinddebtreg_id, ds.debtsubject_id, ds.kindparreg_id
    from   debtsubject ds
    inner  join debtinstalment di
    on     ds.debtsubject_id = di.debtsubject_id
    left   outer join baldebtinst bi
    on     bi.debtinstalment_Id = di.debtinstalment_Id
    where  (ds.debtsubject_id = ipDebtsubject_Id or
           ds.parent_debtsubject_id = ipDebtsubject_Id)
    and    nvl(bi.instSum, 0.0) > 0 -- samo za neplateni otataci prispada po vnoski
    order  by di.termpay_date desc;
  cr2 CURSOR(inv integer) is
   select b.debtinstalment_id, b.instsum
    from debtsubject ds left join debtinstalment ii on ds.debtsubject_id = ii.debtsubject_id
    left join baldebtinst b on ii.debtinstalment_id = b.debtinstalment_id
    where b.instsum > 0 and (ds.debtsubject_id = ipDebtsubject_Id or
           ds.parent_debtsubject_id = ipDebtsubject_Id)
    and ii.instno = inv;  
  --ind numeric;
  vdetsubject_ID_LastCorr numeric; -- �������� �������� ����� ����
  vTotalVal_Old           numeric;
  vtotaltax_Old           numeric;
  votstapka               numeric;
  vGlDalzima_Old          numeric;
  vKinddebtreg_Id         numeric;
  vtaxsubject_id          numeric;
  vpartidano              varchar(30);
  vmunicipality_Id        numeric;
  vdebtsubject_New        numeric;
  vdebtinstalment_Id      numeric;
  vdocument_Id            numeric;
  vkinddoc                numeric;
  vTaxperiod_Id           numeric;
  vdoccode                varchar(20);
  vtaxobject_id           numeric;
  vFreesumSubj_old        numeric;
  vFreeSumObj_old         numeric;
  Razlika                 numeric;
  Ost                     numeric;
  vOperation_Id           numeric;
  voversubject_Id         numeric;
  Voversum                numeric;
  vcorrno                 numeric;
  r                       record;
  vTAXYEAR                varchar(4);
  vKindparreg             numeric;
  vtax_begindate          date;
  vtax_enddate            date;
  i                       integer;
  vnoski                  integer;
  pom1                    numeric;
  pom2                    numeric;
  invsum                  numeric;
  sumzad                  numeric;
  nv                      numeric;
  fffl                    integer;
  vnorminst               numeric;
  vdiv                    numeric;
  vtermdate               date;
  vinstost                numeric;
begin
  if nvl(iptotaltax, 0.0) < 0
  then
    opStat := 'errNewDuty'; --'���������� ���� ���� ����������!';
    return;
  end if;
  if ipdebtsubject_id is null
  then
    --ako e null, t.j. novo zadalzenie, vsicki tezi danni trjabva da sa vavedeni ot forma za korekciata
    if ipTaxsubject_Id is null or ipKinddebtreg_Id is null
      --or ipPartidano is null
       or iptax_begindate_new is null
    then
      opStat := 'errMissDuty'; --'������� ����� �� ������������!';
      return;
    end if;
    vTotalVal_Old   := 0;
    votstapka       := 0;
    vKinddebtreg_Id := ipKinddebtreg_Id;
    vtaxsubject_id  := ipTaxsubject_Id;
    vpartidano      := ipPartidano;
    vtotaltax_Old   := 0;
    vGlDalzima_Old  := 0;
    select u.municipality_id
    into   vmunicipality_id
    from   users u
    where  u.user_id = ipuser_id;
    select t.taxperiod_id
    into   vtaxperiod_id
    from   taxperiod t
    where  t.taxperkind = 0
    and    To_Char(t.begin_date, 'yyyy') = To_char(iptax_begindate_new, 'yyyy');
    --end if;
  else
    
  
  
    select max(dss.debtsubject_id), nvl(max(dss.corrno), 0.0)
    into   vdetsubject_ID_LastCorr, vcorrno
    from   debtsubject dss
    where  nvl(dss.corrno, 0.0) =
           (select nvl(max(ds.corrno), 0.0)
            from   debtsubject ds
            where  ds.parent_debtsubject_id = ipdebtsubject_Id)
    and    dss.parent_debtsubject_id = ipdebtsubject_Id;
  
    if vdetsubject_ID_LastCorr is null
    then
      vdetsubject_ID_LastCorr := ipdebtsubject_id;
    end if;
  
    select c.configvalue
    into   vTAXYEAR
    from   config c
    where  upper(c.name) = 'TAXYEAR';
  
  
    -- opredelenie na sumi - staro
    select sum(nvl(ds.totalval, 0.0)), sum(nvl(ds.paydiscsum, 0.0)),
           max(ds.kinddebtreg_id), max(ds.taxsubject_id), max(ds.partidano),
           max(ds.municipality_id), sum(nvl(ds.totaltax, 0.0)),
           max(ds.document_id), max(ds.kinddoc), max(ds.taxperiod_id),
           max(ds.doccode), max(ds.taxobject_id), sum(ds.freesum_subj),
           sum(ds.freesum_obj)
    into   vTotalVal_Old, votstapka, vKinddebtreg_Id, vtaxsubject_id, vpartidano,
           vmunicipality_id, vtotaltax_Old, vdocument_Id, vkinddoc,
           vtaxperiod_id, vdoccode, vtaxobject_id, vfreesumsubj_Old,
           vfreesumobj_Old
    from   debtsubject ds
    where  ds.debtsubject_id in
           (select dsb.debtsubject_id
            from   debtsubject dsb
            where  dsb.debtsubject_id = ipDebtsubject_Id
            or     dsb.parent_debtsubject_id = ipDebtsubject_Id) --ipdebtsubject_Id
    ;
    select sum(nvl(bdi.instsum, 0.0)), count(*)
    into   vGlDalzima_Old, fffl
    from   baldebtinst bdi, debtinstalment di
    where  bdi.debtinstalment_id = di.debtinstalment_id
    and    di.debtsubject_id in
           (select dsb.debtsubject_id
             from   debtsubject dsb
             where  dsb.debtsubject_id = ipDebtsubject_Id
             or     dsb.parent_debtsubject_id = ipDebtsubject_Id)
        and bdi.instsum > 0   
    
    ;
  end if;

  Razlika := round(ipTotalTax - vTotaltax_Old,5);
  -- ako razlika <0 => votstapka := 0;   ?????
  if (ipclosedoc = '1') then 
    if (ipTotalTax <= vTotaltax_Old) then
      Razlika := - ipTotalTax;
    else    
      Razlika := -vTotaltax_Old;
    end if;
  end if;
  voversum    := null;
  vKindparreg := 3;
  if To_Char(iptax_begindate_new, 'yyyy') = vTAXYEAR
  then
    vKindparreg := 2;
  end if;
  if ipdebtsubject_New is null
  then
    select nextval('s_debtsubject')
    into   vdebtsubject_New
    from   dual;
    if vdetsubject_ID_LastCorr is null
    then
      vdetsubject_ID_LastCorr := vdebtsubject_New;
    end if;
  
  
  
    insert into debtsubject
      (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,
       taxperiod_id, doccode, TAX_BEGIDATE, tax_enddate, relief_id, totalval,
       totaltax, calcdate, freesum_subj, prtdate, inst_number, freesum_obj,
       corr_instnumber, codetbo, userdate, user_id, taxobject_id, partidano,
       municipality_id, kindparreg_id, doc_date, docno, paydiscsum,
       PARENT_DEBTSUBJECT_ID, corrno, typecorr)
    values
      (vdebtsubject_New, vtaxsubject_id, vdocument_id, vkinddoc,
       vkinddebtreg_id, vtaxperiod_id, vdoccode, iptax_begindate_new,
       iptax_enddate_new, null, (nvl(ipTotalval, 0.0) - nvl(vTotalval_Old, 0.0)),
       (nvl(ipTotaltax, 0.0) - nvl(vTotalTax_Old, 0.0)), ipDateCorr,
       nvl(ipFreesumSubj, 0.0) - nvl(vfreesumsubj_Old, 0.0), null, 1,
       nvl(ipFreesumobj, 0.0) - nvl(vfreesumobj_Old, 0.0), null, null, current_timestamp,
       ipuser_Id, vtaxobject_id, vpartidano, vmunicipality_id, vKindparreg,
       ipdoc_date_new, ipdocno_new, (0.0 - nvl(votstapka, 0.0)), ipdebtsubject_id,
       vcorrno + 1.0, ipKindCorr);
  else
    vdebtsubject_New := ipdebtsubject_New;
    if ipclosedoc = '1' then
    update debtsubject
    set    TAX_BEGIDATE = iptax_begindate_new,
           tax_enddate = iptax_enddate_new, inst_number = 1,
           totaltax = -nvl(ipTotaltax, 0.0),
           totalval = -nvl(ipTotalval, 0.0),
           doc_date = ipdoc_date_new, docno = ipdocno_new,
           paydiscsum =
            (0 - nvl(votstapka, 0.0)),
           PARENT_DEBTSUBJECT_ID = ipDebtsubject_Id,
           freesum_subj = nvl(ipFreesumsubj, 0.0) - nvl(vfreesumsubj_Old, 0.0),
           freesum_obj = nvl(ipFreesumobj, 0.0) - nvl(vfreesumobj_Old, 0.0),
           corrno = vcorrno + 1.0, typecorr = ipKindCorr,
           kindparreg_id = vKindparreg
    where  debtsubject_id = ipdebtsubject_New;
    else
    update debtsubject
    set    TAX_BEGIDATE = iptax_begindate_new,
           tax_enddate = iptax_enddate_new, inst_number = 1,
           totaltax = nvl(ipTotaltax, 0.0) - nvl(vTotaltax_Old, 0.0),
           totalval = nvl(ipTotalval, 0.0) - nvl(vTotalval_Old, 0.0),
           doc_date = ipdoc_date_new, docno = ipdocno_new,
           paydiscsum =
            (0 - nvl(votstapka, 0.0)),
           PARENT_DEBTSUBJECT_ID = ipDebtsubject_Id,
           freesum_subj = nvl(ipFreesumsubj, 0.0) - nvl(vfreesumsubj_Old, 0.0),
           freesum_obj = nvl(ipFreesumobj, 0.0) - nvl(vfreesumobj_Old, 0.0),
           corrno = vcorrno + 1.0, typecorr = ipKindCorr,
           kindparreg_id = vKindparreg
    where  debtsubject_id = ipdebtsubject_New;
    end if;
  end if;
  --------- 20.01.2010 pove4e vnoski
  -----------------------------------
  if ipdebtsubject_New is not null
  then
    select ds.doccode, ds.kinddebtreg_id, ds.tax_begidate, ds.tax_enddate,
           ds.taxperiod_id
    into   vdoccode, vkinddebtreg_id, vtax_begindate, vtax_enddate,
           vtaxperiod_id
    from   debtsubject ds
    where  ds.debtsubject_id = ipdebtsubject_New;
    if razlika <> 0.0
    then
      select nextval('s_operation')
      into   vOperation_Id
      from   dual;
      insert into operation
        (operation_id, oper_date, operdocno, opercode, opersum, user_date,
         user_id, user_name, baloversum, resolution_id, paytransaction_id,
         oversubject_id, municipality_id)
      values
        (voperation_id, ipDateCorr, voperation_id, '15', Razlika,
         trunc(current_date), ipuser_Id,
         (select u.fullname
           from   users u
           where  u.user_id = ipuser_Id), null, null, null, null,
         vmunicipality_Id);
    end if;
  
    if razlika > 0.0
    then
      if vdoccode in ('17', '14')
      then
        select count(*)
        into   vnorminst
        from   taxperiodpay p
        where  p.documenttype_id = decode(vdoccode, '17', 22, 21)
        and ((p.kinddebtreg_id = ipKinddebtreg_Id) or (p.kinddebtreg_id is null))
        and    p.taxperiod_id = vtaxperiod_id;
        if vnorminst = 0
        then
          vdiv      := 1;
          vnorminst := 2;
        else
          vdiv := round(12 / vnorminst);
        end if;
        pom1   := round(months_between(vtax_enddate, vtax_begindate) + 0.5);
        vnoski := round((pom1 / vdiv) + 0.4);
        if vnoski = 0
        then
          vnoski := 1;
        end if;
        i      := vnoski;
        invsum := 0;
        while i > 0
        loop
        
          nv := vnorminst - vnoski + i;
          i  := i - 1;
          if i = 0
          then
            sumzad := razlika - invsum;
          else
		    sumzad := round(razlika * vdiv / pom1, 2);
            --sumzad := round(razlika / vnoski, 2);
            invsum := invsum + sumzad;
          end if;
        
          select nextval('s_debtinstalment')
          into   vdebtinstalment_Id
          from   dual;
          insert into debtinstalment
            (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
             intbegindate)
            select vdebtinstalment_Id, vdebtsubject_New, tp.instalmentnumber,
                   getWorkingDay(tp.termpaydate::date, 1), sumzad,
                   getWorkingDay(tp.termpaydate::date, 1) + integer '1'
            from   taxperiodpay tp, documenttype dt
            where  tp.taxperiod_id = vtaxperiod_id
            and    tp.instalmentnumber = nv
            and    tp.documenttype_id = dt.documenttype_id
            and    ((tp.kinddebtreg_id = ipKinddebtreg_Id) or (tp.kinddebtreg_id is null))
            and    dt.doccode = vdoccode
            --    and dt.municipality_id = vmunicipality_id
            ;
          select count(*)
          into   pom2
          from   debtinstalment di
          where  di.debtinstalment_id = vdebtinstalment_Id;
          if pom2 > 0
          then
            insert into baldebtinst
              (debtinstalment_id, instsum, interestsum, discsum)
            values
              (vdebtinstalment_Id, sumzad, 0, 0);
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, vkinddebtreg_id,
               vdebtinstalment_Id, null, sumzad, null, vkindparreg, null,
               null);
          end if;
        end loop;
      
      elsif vdoccode = '61'
      then
         select count(*), getWorkingDay(max(td.doc_date::date) + 7, 1) into pom2,vtermdate
         from taxdoc td, debtsubject ds, reasonreg rr
         where td.taxdoc_id = ds.document_id
         and ds.debtsubject_id = ipDebtsubject_Id
         and rr.reasonreg_id = td.give_reasonreg_id
         and rr.reason_code in ('612', '611')
         and td.change_date > td.begintaxdate
         ; 

        i      := to_number(to_char(vtax_begindate, 'mm')) - 1;
        vnoski := (4 - (i - mod(i, 3)) / 3);
        sumzad := round(razlika / vnoski, 2);
        invsum := 0;
        i      := vnoski;
        while i > 0
        loop
          nv := 4 - vnoski + i;
          if i = 1
          then
            sumzad := razlika - invsum;
          else
            invsum := invsum + sumzad;
          end if;
          select nextval('s_debtinstalment')
          into   vdebtinstalment_Id
          from   dual;
          insert into debtinstalment
            (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
             intbegindate)
            select vdebtinstalment_Id, vdebtsubject_New, tp.instalmentnumber,
                   getWorkingDay(tp.termpaydate::date, 1), sumzad,
                   getWorkingDay(tp.termpaydate::date, 1) + integer '1'
            from   taxperiodpay tp, documenttype dt
            where  tp.taxperiod_id = vtaxperiod_id
            and    tp.instalmentnumber = nv
            and    tp.documenttype_id = dt.documenttype_id
            and ((tp.kinddebtreg_id = ipKinddebtreg_Id)  or (tp.kinddebtreg_id is null))
            and    dt.doccode = vdoccode
            --    and dt.municipality_id = vmunicipality_id
            ;
           if (nvl(pom2,0.0) > 0) then
            update debtinstalment 
              set termpay_date = vtermdate, intbegindate = vtermdate + integer '1'
             where debtinstalment_id = vdebtinstalment_Id
            ; 
           end if;

        select count(*)
          into   pom2
          from   debtinstalment di
          where  di.debtinstalment_id = vdebtinstalment_Id;
          if pom2 > 0
          then
            insert into baldebtinst
              (debtinstalment_id, instsum, interestsum, discsum)
            values
              (vdebtinstalment_Id, sumzad, 0, 0);
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, vkinddebtreg_id,
               vdebtinstalment_Id, null, sumzad, null, vkindparreg, null,
               null);
          end if;
          i := i - 1;
          pom2 := 0;
        end loop;
--      elsif vdoccode like '54%' then
       
      else
        select nextval('s_debtinstalment')
        into   vdebtinstalment_Id
        from   dual;
        insert into debtinstalment
          (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
           intbegindate)
        /*values*/
         /* (vdebtinstalment_Id, vdebtsubject_New, 1, iptermpay_date, Razlika,
           nvl(ipInterestBegdate, iptermpay_date + 1))
           */
           (select vdebtinstalment_Id, vdebtsubject_New, 2,
                 nvl(min(i.termpay_date), iptermpay_date), Razlika,
                 nvl(min(i.termpay_date), iptermpay_date) + integer '1'
          from   debtinstalment i
          where  i.debtsubject_id = ipDebtsubject_Id
          and    i.termpay_date >= iptax_begindate_new)
        --  iptermpay_date, (nvl(ipTotaltax,0) -nvl(vTotaltax_Old,0)+ nvl(votstapka,0)),ipInterestBegdate)
        ;
        select count(*)
        into   pom2
        from   debtinstalment di
        where  di.debtinstalment_id = vdebtinstalment_Id;
        if pom2 > 0
        then
          insert into baldebtinst
            (debtinstalment_id, instsum, interestsum, discsum)
          values
            (vdebtinstalment_Id, Razlika, 0.0, 0.0);
          insert into operdebt
            (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
             operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
             balinstsum)
          values
            (nextval('s_operdebt'), vOperation_Id, vkinddebtreg_id,
             vdebtinstalment_Id, null, Razlika, null, vkindparreg, null,
             null);
        end if;
      end if;
    else
      -- < 0 ???
      
      --      if fffl <> 1 and nvl(ost,0) > abs(Razlika) then
      if (fffl <> 1) and (nvl(vGlDalzima_Old, 0.0) > abs(Razlika)) and
         (ipclosedoc <> '1')
      then

        --------------------------------
     if vdoccode in ('17', '14')
      then            
        select count(*)
        into   vnorminst
        from   taxperiodpay p
        where  p.documenttype_id = decode(vdoccode, '17', 22, 21)
        and ((p.kinddebtreg_id = ipKinddebtreg_Id) or (p.kinddebtreg_id is null))
        and    p.taxperiod_id = vtaxperiod_id;
        if vnorminst = 0
        then
          vdiv      := 1;
          vnorminst := 2;
        else
          vdiv := round(12 / vnorminst);
        end if;
        pom1   := round(months_between(vtax_enddate, vtax_begindate) + 0.5);
        vnoski := round((pom1 / vdiv) + 0.4);
        if vnoski = 0
        then
          vnoski := 1;
        end if;
        pom2 := razlika;
        i      := 0; 
        invsum := 0;
        while i < vnoski
        loop
          i := i + 1;
          nv := vnorminst - vnoski + i;
          if i = vnoski
          then
            sumzad := razlika - invsum;
          else
           if i = 1 then
            sumzad := round(razlika * (1- ((vnoski - 1) * vdiv / pom1)), 2);
           else
            sumzad := round(razlika * (vdiv / pom1), 2);
           end if;
            invsum := invsum + sumzad;
          end if;
      select nextval('s_debtinstalment')
      into   vdebtinstalment_Id
      from   dual;
      insert into debtinstalment
        (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
         intbegindate)
      values
        (vdebtinstalment_Id, vdebtsubject_New, nv, iptermpay_date, sumzad,
         ipInterestBegdate)
      ;
       ost := -sumzad;
       open cr2(nv);
       loop
        fetch cr2 into vdebtinstalment_Id, vinstost ;
        exit when cr2%notfound;
         if ost < vinstost then
           update baldebtinst b
             set b.instsum = b.instsum - ost
           where b.debtinstalment_id = vdebtinstalment_Id
           ;
          if ost <> 0 then 
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, ipkinddebtreg_Id,
               vdebtinstalment_Id, -ost, null, null, vKindparreg, null, null);
          end if;
          pom2 := pom2 + ost;
          ost := 0; 
          fffl := fffl - 1;
         else
           ost := ost - vinstost;
           pom2 := pom2 + vinstost;
          update baldebtinst b
            set b.instsum = 0
          where b.debtinstalment_id = vdebtinstalment_Id
          ;
          if vinstost <> 0 then 
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, ipkinddebtreg_Id,
               vdebtinstalment_Id, -vinstost, null, null, vKindparreg, null, null);
          end if;
         end if;
       end loop;
       close cr2;        
      end loop;
      else   
        --------------------------------
        if vdoccode like '54%' then
         select   min(di.instno), count(*)
           into  i , vnoski   
           from debtinstalment di
           where di.debtsubject_id in
           (select ds.debtsubject_id
           from debtsubject ds
           where ds.debtsubject_id = di.debtsubject_id
           and (ds.debtsubject_id = ipDebtsubject_Id or ds.parent_debtsubject_id = ipDebtsubject_Id)
           and ds.typecorr is null
           );
          if vnoski > 1 then
          vdiv := round(12 / vnoski);
          pom1   := round(months_between(vtax_enddate, vtax_begindate) + 0.5);
        pom2 := razlika;
    --    i      := 0; 
        i := i - 1;
        invsum := 0;
        while i < vnoski
        loop
          i := i + 1;
          nv := i;
          if i = vnoski
          then
            sumzad := razlika - invsum;
          else
------------
           if i = 1 then
            sumzad := round(razlika * (1- ((vnoski - 1) * vdiv / pom1)), 2);
           else
            sumzad := round(razlika * (vdiv / pom1), 2);
           end if;
------------
            invsum := invsum + sumzad;
          end if;
          select nextval('s_debtinstalment')
          into   vdebtinstalment_Id
          from   dual;
          insert into debtinstalment
            (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
             intbegindate)
          values
            (vdebtinstalment_Id, vdebtsubject_New, nv, iptermpay_date, sumzad,
             ipInterestBegdate) ;
----  !!!!!!!!!!!!!
           ost := -sumzad;
           open cr2(nv);
           loop
            fetch cr2 into vdebtinstalment_Id, vinstost ;
            exit when cr2%notfound;
             if ost < vinstost then
               update baldebtinst b
                 set b.instsum = b.instsum - ost
               where b.debtinstalment_id = vdebtinstalment_Id
               ;
              if ost <> 0 then 
                insert into operdebt
                  (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
                   operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
                   balinstsum)
                values
                  (nextval('s_operdebt'), vOperation_Id, ipkinddebtreg_Id,
                   vdebtinstalment_Id, -ost, null, null, vKindparreg, null, null);
              end if;
              pom2 := pom2 + ost;
              ost := 0; 
              fffl := fffl - 1;
             else
               ost := ost - vinstost;
               pom2 := pom2 + vinstost;
              update baldebtinst b
                set b.instsum = 0
              where b.debtinstalment_id = vdebtinstalment_Id
              ;
              if vinstost <> 0 then 
                insert into operdebt
                  (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
                   operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
                   balinstsum)
                values
                  (nextval('s_operdebt'), vOperation_Id, ipkinddebtreg_Id,
                   vdebtinstalment_Id, -vinstost, null, null, vKindparreg, null, null);
              end if;
             end if;
           end loop;
           close cr2;        
          end loop;  
          else
        select nextval('s_debtinstalment')
        into   vdebtinstalment_Id
        from   dual;
        insert into debtinstalment
          (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
           intbegindate)
        values
          (vdebtinstalment_Id, vdebtsubject_New, i, iptermpay_date,
           Razlika, iptermpay_date + integer '1');
            pom2 := razlika;
          end if;        
        else                         
        select   max(di.instno)
           into  i
           from debtinstalment di
           where di.debtsubject_id in
           (select ds.debtsubject_id
           from debtsubject ds
           where ds.debtsubject_id = di.debtsubject_id
           and (ds.debtsubject_id = ipDebtsubject_Id or ds.parent_debtsubject_id = ipDebtsubject_Id)
           );
        select nextval('s_debtinstalment')
        into   vdebtinstalment_Id
        from   dual;
        insert into debtinstalment
          (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
           intbegindate)
        values
          (vdebtinstalment_Id, vdebtsubject_New, i, iptermpay_date,
           Razlika, iptermpay_date + 1);
        pom2 := razlika;
       end if; 
      end if;
 --       Ost  := -pom2;
        Razlika := pom2;
        if fffl > 0 then
        pom1 := round(-pom2 / fffl, 2);
        else 
          pom1 := -pom2;
        end if;
        ost  := 0;
        i    := 0;
        open cr;
        loop
          fetch cr
            into r;
          exit when not FOUND;
          i := i + 1;
          if i = fffl
          then
            pom1 := -Razlika - ((fffl - 1) * round(-Razlika / fffl, 2));
          end if;
          if r.instSum >= (pom1 + ost)
          then
            pom2 := pom1 + ost;
            ost  := 0;
          else
            pom2 := r.instSum;
            ost  := ost + pom1 - r.instsum;
          end if;
          --    ost := ost - r.instsum;
          if fffl <= 1 then pom1 := pom1 - pom2; ost := 0.0; end if;
          if pom2 <> 0 then		  
          insert into operdebt
            (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
             operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
             balinstsum)
          values
            (nextval('s_operdebt'), vOperation_Id, r.kinddebtreg_Id,
             r.debtinstalment_Id, -pom2, null, null, r.kindparreg_Id, null, null);
          update baldebtinst
          set    instsum = instsum - pom2
          where  debtinstalment_id = r.debtinstalment_Id;
		  end if;
        end loop;
        close cr;
        fffl := 0;
        -------------------------------
        --------------------------------
      else
        fffl := 1;
        delete from operation o
        where  o.operation_id = vOperation_Id;
      end if;
    end if;
  /*else
    select nextval('s_debtinstalment')
    into   vdebtinstalment_Id
    from   dual;
    insert into debtinstalment
      (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
       intbegindate)
    values
      (vdebtinstalment_Id, vdebtsubject_New, 1, iptermpay_date,
       (nvl(ipTotaltax, 0.0) - nvl(vTotaltax_Old, 0.0)), ipInterestBegdate)
    --  iptermpay_date, (nvl(ipTotaltax,0) -nvl(vTotaltax_Old,0)+ nvl(votstapka,0)),ipInterestBegdate)
    ;*/
  end if;
  if (ipdebtsubject_New is null) or ((fffl = 1) and (razlika < 0)) or (ipclosedoc = '1')
  then
    --- ??? Samo za novi !!!    
    if razlika <> 0.0
    then
/*      select nextval('s_operation')
      into   vOperation_Id
      from   dual;
      select nextval('s_debtinstalment')
      into   vdebtinstalment_Id
      from   dual;*/
      if (ipclosedoc = '1')
      then
        if substr(nvl(vdoccode, '00'), 1, 2) = '54'
        then
          vnoski := 2;
        elsif (substr(nvl(vdoccode, '00'), 1, 2) in ('14', '17')) and
              iptax_begindate_new >= to_date('01.01.2011', 'dd.mm.yyyy')
        then
          vnoski := 2;
        else
          vnoski := 4;
        end if;
      else
        vnoski := 1;
      end if;
	   -------------------- poveche vnoski proporcionalno
 --------------------
     if vdoccode in ('17', '14')
      then
        select count(*)
        into   vnorminst
        from   taxperiodpay p
        where  p.documenttype_id = decode(vdoccode, '17', 22, 21)
        and ((p.kinddebtreg_id = ipKinddebtreg_Id) or (p.kinddebtreg_id is null))
        and    p.taxperiod_id = vtaxperiod_id;
        if vnorminst = 0
        then
          vdiv      := 1;
          vnorminst := 2;
        else
          vdiv := round(12 / vnorminst);
        end if;
        pom1   := round(months_between(vtax_enddate, vtax_begindate) + 0.5);
        vnoski := round((pom1 / vdiv) + 0.4);
        if vnoski = 0
        then
          vnoski := 1;
        end if;
        i      := 0; 
        invsum := 0;
        while i < vnoski
        loop
          i := i + 1;
          nv := vnorminst - vnoski + i;
          if i = vnoski
          then
            sumzad := razlika - invsum;
          else
            sumzad := round(razlika * (1- (vdiv / pom1)), 2);
            invsum := invsum + sumzad;
          end if;
      select nextval('s_operation')
      into   vOperation_Id
      from   dual;
      select nextval('s_debtinstalment')
      into   vdebtinstalment_Id
      from   dual;
      insert into debtinstalment
        (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
         intbegindate)
      values
        (vdebtinstalment_Id, vdebtsubject_New, nv, iptermpay_date, sumzad,
         ipInterestBegdate)
      ;
      insert into operation
        (operation_id, oper_date, operdocno, opercode, opersum, user_date,
         user_id, user_name, baloversum, resolution_id, paytransaction_id,
         oversubject_id, municipality_id)
      values
        (voperation_id, ipDateCorr, voperation_id, '15', sumzad,
         current_timestamp, ipuser_Id,
         (select u.fullname
           from   users u
           where  u.user_id = ipuser_Id), null, null, null, null,
         vmunicipality_Id);
        end loop;
      else   
-------------------- poveche vnoski proporcionalno
      select nextval('s_operation')
      into   vOperation_Id
      from   dual;
      select nextval('s_debtinstalment')
      into   vdebtinstalment_Id
      from   dual;
      insert into debtinstalment
        (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
         intbegindate)
      values
        (vdebtinstalment_Id, vdebtsubject_New, vnoski, iptermpay_date, razlika,
         ipInterestBegdate)
      --  iptermpay_date, (nvl(ipTotaltax,0) -nvl(vTotaltax_Old,0)+ nvl(votstapka,0)),ipInterestBegdate)
      ;
      insert into operation
        (operation_id, oper_date, operdocno, opercode, opersum, user_date,
         user_id, user_name, baloversum, resolution_id, paytransaction_id,
         oversubject_id, municipality_id)
      values
        (voperation_id, ipDateCorr, voperation_id, '15', Razlika,
         current_timestamp, ipuser_Id,
         (select u.fullname
           from   users u
           where  u.user_id = ipuser_Id), null, null, null, null,
         vmunicipality_Id);
		       end if;
    end if;
    if (Razlika > 0.0)
    then
      -------  ?????????
      insert into operdebt
        (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
         operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
         balinstsum)
      values
        (nextval('s_operdebt'), vOperation_Id, vkinddebtreg_Id,
         vdebtinstalment_Id, (nvl(ipTotaltax, 0.0) - nvl(vTotaltax_Old, 0.0)), null,
         null, vkindparreg, null, null);
      insert into baldebtinst
        (debtinstalment_id, instsum, interestsum)
      values
        (vdebtinstalment_Id, (nvl(ipTotaltax, 0.0) - nvl(vTotaltax_Old, 0.0)), 0);
    end if;
  
  
    if (Razlika < 0.0)
    then
      Ost := -Razlika;
      ------- ?????????????
      if ipclosedoc = '1'
      then
        open cr1;
        loop
          fetch cr1
            into r;
          exit when not FOUND;
        
          ost := ost - r.instsum;
          if ost >= 0
          then
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, r.kinddebtreg_Id,
               r.debtinstalment_Id, -r.instsum, null, null, r.kindparreg_Id,
               null, null);
            update baldebtinst
            set    instsum = 0
            where  debtinstalment_id = r.debtinstalment_Id;
          end if;
        
          if ost < 0
          then
            --prispada samo razlika
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, r.kinddebtreg_Id,
               r.debtinstalment_Id, - (r.instsum + ost), null, null,
               r.kindparreg_Id, null, null);
            update baldebtinst
            set    instsum = -ost
            where  debtinstalment_id = r.debtinstalment_Id;
            exit; -- i izliza ot cikala
          end if;
        
        end loop;
        close cr1;
      else
        open cr;
        loop
          fetch cr
            into r;
          exit when not FOUND;
        
          ost := ost - r.instsum;
          if ost >= 0
          then
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, r.kinddebtreg_Id,
               r.debtinstalment_Id, -r.instsum, null, null, r.kindparreg_Id,
               null, null);
            update baldebtinst
            set    instsum = 0
            where  debtinstalment_id = r.debtinstalment_Id;
          end if;
        
          if ost < 0
          then
            --prispada samo razlika
            insert into operdebt
              (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
               operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
               balinstsum)
            values
              (nextval('s_operdebt'), vOperation_Id, r.kinddebtreg_Id,
               r.debtinstalment_Id, - (r.instsum + ost), null, null,
               r.kindparreg_Id, null, null);
            update baldebtinst
            set    instsum = -ost
            where  debtinstalment_id = r.debtinstalment_Id;
            exit; -- i izliza ot cikala
          end if;
        
        end loop;
        close cr;
      end if;
    
      ost := ost - nvl(votstapka, 0.0);
      if ost < 0
      then
        ost := 0;
      end if;
      if ost > 0
      then
        -- prehvarlia na nadvnesena suma
        Voversum := ost;
        select nextval('s_oversubject')
        into   voversubject_Id
        from   dual;
      
        insert into oversubject
          (oversubject_id, kinddebtreg_id, taxsubject_id, overpaysum,
           overinterestsum, overcorsum, partidano, municipality_id,
           debtsubject_id)
        values
          (voversubject_Id, vkinddebtreg_id, vtaxsubject_id, null, null,
           Voversum, vpartidano, vmunicipality_Id, vdebtsubject_New);
        insert into baloverinst
          (oversubject_id, oversum)
        values
          (voversubject_Id, Voversum);
      end if;
    
      -- nakraja zapis na gornoto nivo v operation
      update operation
      set    oversubject_id = voversubject_Id, baloversum = Voversum
      where  operation_id = vOperation_Id;
    end if;
  end if;
  --------
  insert into debtsubjectcorr
    (debtsubjectcorr_id, debtsubject_id, corr_date,
     -- telk_id_old, telk_id_new,
     totalval_old, totalval_new, totaltax_old, totaltax_new, paydiscsum_old,
     paydiscsum_new,
     -- part_old, part_new
     user_date, user_id, user_name, protocolno, protocol_date, reason_corr,
     inspector_user_id, Parent_debtsubject_id, freesumobj_old, freesumobj_new,
     freesumsubj_old, freesumsubj_new, KindCorr, oversum, operation_Id)

    select nextval('s_Debtsubjectcorr'), vdebtsubject_New, ipDateCorr,
           -- null,null,
           vTotalVal_Old, ipTotalval, vtotaltax_old, iptotaltax, votstapka, 0,
           Trunc(current_date), ipuser_Id,
           (select u.fullname
             from   users u
             where  u.user_id = ipuser_Id), ipProtocolNom, ipProtDate,
           ipreason_corr, ipinspector_Id, ipDebtsubject_Id, vfreesumobj_old,
           ipfreesumobj, vfreesumsubj_old, ipfreesumsubj, ipKindCorr,
           decode(sign(ost), 1.0, ost, 0.0), vOperation_Id
    
    from   debtsubject ds
    where  ds.debtsubject_id = vdetsubject_ID_LastCorr;

  --commit;
  opStat := 'OK';
exception
  when others then
    --rollback;
    opStat := 'errOrclDB'; --'������';
end;
$function$
; DROP FUNCTION public.freereason(character varying); 
CREATE OR REPLACE FUNCTION public.freereason(instr character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
 DECLARE
 i integer;
 vstr varchar(100);
 instr1 varchar(20);
 begin
  instr1 := rpad(instr, 15, '0');
  vstr   := null;
  for i in 1 .. 15
  loop
    if substr(instr1, i, 1) = '1'
    then
      vstr := vstr || '8.' || i || '; ';
    end if;
  end loop;
  if vstr is null
  then
    vstr := '��';
  end if;
  return vstr;
 end;
 $function$
; DROP FUNCTION public.getaddress(numeric); 
CREATE OR REPLACE FUNCTION public.getaddress(ipaddr_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  vCityName      varchar(128);
  vStreetName    varchar(128);
  vQuarterName   varchar(128);
  vAddrNo        varchar(128);
  vAddrBlock     varchar(128);
  vAddrEntry     varchar(128);
  vAddrFloor     varchar(128);
  vAddrApartment varchar(128);
begin
  select (DECODE(adr.street_id, null, adr.street_name,
                  case Str.Kind_Street
                    when '0' then ' '
                      when '1' then '��.'
                        when '2' then '���.'
                          when '3' then '��.'
                            when '4' then '�.�.'
                              when '5' then '�.�.'
                                when '6' then '�.��.'
                                  when '7' then '��.'
                                    else '---'
                   end || Str.Name)) StrName, 
        adr.nom, adr.block, adr.entry, adr.floor, adr.apartment,
        case Ci.Kind_City 
          when '0' then ' '
            when '1' then '��.'
              when '2' then '�.'
                when '3' then '�.'
                  when '4' then '��.'
                    else '---'
         end || Ci.Name X2
  into   vStreetName, vAddrNo, vAddrBlock, vAddrEntry, vAddrFloor,
         vAddrApartment, vCityName
  from   Address adr
  left   outer join City Ci
  on     adr.city_id = Ci.City_Id
  left   outer join Street Str
  on     adr.street_id = Str.Street_Id
  where  adr.address_id = ipAddr_id;
  if vAddrNo is not null
  then
    vStreetName := vStreetName || ' N: ' || vAddrNo;
  end if;
  if vAddrBlock is not null
  then
    vStreetName := vStreetName || ' ��.' || vAddrBlock;
  end if;
  if vAddrEntry is not null
  then
    vStreetName := vStreetName || ' ��.' || vAddrEntry;
  end if;
  if vAddrApartment is not null
  then
    vStreetName := vStreetName || ' ��.' || vAddrApartment;
  end if;
  if vAddrFloor is not null
  then
    vStreetName := vStreetName || ' ��.' || vAddrFloor;
  end if;
  --     IF vQuarterName is not NULL then vStreetName := '��. ' || vQuarterName || ' ' || vStreetName; END IF;
  vStreetName := ' ' || vStreetName;
  vCityName := vCityName ||  nvl(vStreetName,'');
  return(vCityName);
exception
  when others then
    begin
      return('');
    end;
end;

$function$
; DROP FUNCTION public.getclientcity(numeric); 
CREATE OR REPLACE FUNCTION public.getclientcity(iptaxsubject_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  vCityName varchar(128);
begin
  select case Ci.Kind_City 
          when '0' then ' '
            when '1' then '��.'
              when '2' then '�.'
                when '3' then '�.'
                  when '4' then '��.'
                    else '---'
         end || Ci.Name X2
  into   vCityName
  from   Taxsubject t
  inner  join Address addr
  on     t.present_clientaddr_id = addr.address_id
  left   outer join City Ci
  on     addr.city_id = ci.city_id
  where  t.taxsubject_id = ipTaxSubject_id;

  return(vCityName);
exception
  when others then
    begin
      return('');
    end;
end;

$function$
; DROP FUNCTION public.getdefaultgrouptbo(character varying, numeric, character varying); 
CREATE OR REPLACE FUNCTION public.getdefaultgrouptbo(ipyear character varying, ipaddress_id numeric, ipkind_property character varying, OUT tbocode numeric, OUT tbo character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                                               
  vcity_id      numeric;
  vtaxperiod_id numeric;
begin
  select tp.taxperiod_id
  into   vtaxperiod_id
  from   taxperiod tp
  where  to_char(tp.begin_date, 'yyyy') = ipyear
  and    tp.taxperkind = '0';
  
  select a.city_id
  into   vcity_id
  from   address a
  where  a.address_id = ipaddress_id;
  
  select pt.tbo_code, d.value
  into   tbocode, tbo
  from   promtbo pt, decode d
  where  d.columnname = 'CodeTBO'
  and    d.code::numeric = pt.tbo_code
  and    pt.city_id = vcity_id
  and    pt.taxperiod_id = vtaxperiod_id
  and    pt.calctype = '0'
  and    pt.code = '1'
  union
  select pt.tbo_code, d.value
  from   promtbo pt, decode d
  where  d.columnname = 'CodeTBO'
  and    d.code::numeric = pt.tbo_code
  and    pt.city_id = vcity_id
  and    pt.taxperiod_id = vtaxperiod_id
  and    pt.calctype = '1'
  and    pt.code = decode(ipkind_property, '1', '1', '2');
end;
$function$
; DROP FUNCTION public.getdocstatus(numeric); 
CREATE OR REPLACE FUNCTION public.getdocstatus(ipdoc_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare  
  vPayDate     date;
  vNullDate    date;
  vUser_id     numeric;
  vNullUser_id numeric;
  vStatus      varchar(20);
begin
  vStatus := '';
  select pdoc.paydate, pdoc.null_date, pdoc.user_id, pdoc.null_user_id
  into   vPayDate, vNullDate, vUser_id, vNullUser_id
  from   Paydocument pdoc
  where  pdoc.paydocument_id = ipDoc_id;
  if vNullDate is not null
  then
    if (vPayDate = vNullDate) and (vUser_id = vNullUser_id)
    then
      vStatus := '��������';
    else
      vStatus := '���������';
    end if;
  end if;
  return(vStatus);
exception
  when others then
    begin
      return('');
    end;
end;

$function$
; DROP FUNCTION public.getobjno(numeric, numeric); 
CREATE OR REPLACE FUNCTION public.getobjno(ipmun_id numeric, ipdoctype_id numeric, OUT opdocnumber character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                                    
  vdoccode varchar(20);
begin

  select d.doccode
  into   vdoccode
  from   documenttype d
  where  d.documenttype_id = ipdoctype_id;

  select c.configvalue
  into   opdocnumber
  from   config c
  where  c.municipality_id = ipmun_id
  and    upper(c.name) = 'TAXOBJNO';

  update config
  set    configvalue = to_char(to_number(opdocnumber) + 1)
  where  municipality_id = ipmun_id
  and    upper(name) = 'TAXOBJNO';
  --commit;
  -- select  trim(decode(substr(vdoccode,1,2),'14','H','17','F','54','T','61','P',' ')||opdocnumber)
  -- into opdocnumber from dual;
  --opstat := 'OK';
exception
  when others then
    --rollback;
    --opstat := 'OK';
    opdocnumber := '-1';
end;
$function$
; DROP FUNCTION public.taxyearnotified(numeric, character varying, character varying, numeric); 
CREATE OR REPLACE FUNCTION public.taxyearnotified(ipuser_id numeric, ipdocno character varying, ipdocdate character varying, ipfromtaxyaer numeric DEFAULT NULL::numeric, OUT ipstatus character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
groupParams CURSOR is
   select t1.h, t1.l from 
     (select 2 h, 10000 l ) t1  -- comment
   union all
   select t2.h , t2.l from 
     (select 0 h, 3 l ) t2
   order by 1 desc, 2 desc;
   
sidedSubjects CURSOR(vhigh bigint, vlow bigint) is
   select ds.taxsubject_id, count(distinct ds.document_id) docs,
          case when count(distinct ds.document_id) > 2 then '2' else '1' end actionstatus
     from debtsubject ds
     inner join taxdoc td on ds.document_id = td.taxdoc_id
                         and ds.doc_date = td.doc_date
                         and ds.docno = td.docno    
     inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
     inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
     inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
                             and ts.taxsubject_id != (select c.configvalue from config c where upper(c.name) = 'TAXSUBJECT_ID')
     left outer join Address adr on adr.address_id = ts.post_clientaddr_id                        
     left outer join Municipality m on m.municipality_id = adr.municipality_id                           
    where 
          -- ds.kinddebtreg_id in (2,5)
           td.documenttype_id in (21,22) -- Decl 14, 17    
       and td.docstatus = '30'
       and (coalesce(bdi.instsum,0) + coalesce(bdi.interestsum,0)) > 0
       and to_char(ds.tax_begidate, 'yyyy')::integer = 
	(case when (coalesce(ipfromtaxyear,0))==0 then 0 else ipfromtaxyaer END)
       --(CASE WHEN coalesce(ipfromtaxyaer=0) THEN 0 ELSE 1990,ipfromtaxyaer END)
       and not exists (Select * from actionItem ai
                                inner join action a on ai.action_id = a.action_id
                           where a.kindaction = '10'
                             and ai.debtinstalment_id = di.debtinstalment_id)
  group by m.ebk_code, ds.taxsubject_id
  having count(distinct ds.document_id) > vhigh and count(distinct ds.document_id) < vlow
  order by m.ebk_code;
  
 subjects cursor(vtaxsubjectId numeric) is
   select td.docno, td.doc_date, td.taxdoc_id, di.debtinstalment_id,
          nvl(bdi.instsum,0) instsum, 
         (nvl(bdi.interestsum,0)+sanction_pkg.tempint(di.debtinstalment_id,trunc(sysdate))) interestsum, 
          ds.taxsubject_id
       from debtsubject ds
       inner join taxdoc td on ds.document_id = td.taxdoc_id
                           and ds.doc_date = td.doc_date
                           and ds.docno = td.docno    
       inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
       inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
       inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
                               and ts.taxsubject_id != (select c.configvalue from config c where upper(c.name) = 'TAXSUBJECT_ID')
       left outer join Address adr on adr.address_id = ts.post_clientaddr_id                        
       left outer join Municipality m on m.municipality_id = adr.municipality_id                           
       where 
            -- ds.kinddebtreg_id in (2,5)
             td.documenttype_id in (21,22) -- Decl 14, 17    
         and td.docstatus = '30'
         and (nvl(bdi.instsum,0) + nvl(bdi.interestsum,0)) > 0
         and To_Number(To_char(ds.tax_begidate,'yyyy')) = decode(nvl(ipfromtaxyaer,0),0,1990,ipfromtaxyaer)
         and not exists (Select * from actionItem ai
                                  inner join action a on ai.action_id = a.action_id
                             where a.kindaction = '10'
                               and ai.debtinstalment_id = di.debtinstalment_id)
         and ds.taxsubject_id = vtaxsubjectId                      
   order by ts.idn, ds.debtsubject_id, di.instno;

 actions cursor is
  select a.*
    from action a
    inner join groupaction ga on a.groupaction_id = ga.groupaction_id
   where 
         ga.kindaction = '10'
     and ga.fromtaxyaer = ipfromtaxyaer
order by a.taxsubject_id;     
 gactions cursor is
  select ga.groupaction_id 
    from groupaction ga 
   where ga.kindaction = '10'
     and ga.fromtaxyaer = ipfromtaxyaer;
vgroupaction_Id numeric;
vtsId numeric;
vdocId numeric;
vaction_Id numeric;
vminsumdebt numeric;
vmaxsumdebt numeric;
vfromtermpaydate date;
vtotermpaydate date;
r record;
i numeric;
begin
   if (trim(opStat) = '1') then  
     for rec in actions loop
      delete from actionitem ai where ai.action_id = rec.action_id;
     end loop;
     for rec in gactions loop
       delete from action a where a.groupaction_id = rec.groupaction_id;
     end loop;
     delete from groupaction ga 
      where ga.kindaction = '10'
        and ga.fromtaxyaer = ipfromtaxyaer;
   end if;
-- olixviavane do current_date

  select min(di.termpay_date), max(di.termpay_date),
         min(bdi.instsum), max(bdi.instsum) 
    into vfromtermpaydate, vtotermpaydate,
         vminsumdebt, vmaxsumdebt       
    from debtsubject ds
    inner join taxdoc td on ds.document_id = td.taxdoc_id
                        and ds.doc_date = td.doc_date
                        and ds.docno = td.docno    
    inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
    inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id  
    inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
   where 
         td.documenttype_id in (21,22) -- Decl 14, 17    
     and td.docstatus = '30'     
     and (nvl(bdi.instsum,0) + nvl(bdi.interestsum,0)) > 0
     and To_Number(To_char(ds.tax_begidate,'yyyy')) = decode(nvl(ipfromtaxyaer,0),0,1990,ipfromtaxyaer)
     and not exists (Select * from actionItem ai
                              inner join action a on ai.action_id = a.action_id
                         where a.kindaction = '10'
                           and ai.debtinstalment_id = di.debtinstalment_id);

  select nextval('s_groupaction') into vgroupaction_Id from dual;

  insert into groupaction
         (groupaction_id, kindaction, dategroupaction, docno, docdate,
          fromtermpaydate, isperson, minsumdebt, maxsumdebt, kinddebtreg_id,
          fromtaxyaer, totaxyear, totermpaydate)
   values
         (vgroupaction_Id, '10', trunc(sysdate), ipdocno, to_date(ipDocDate,'dd.mm.yyyy'),
          trunc(vfromtermpaydate), 0, vminsumdebt, vmaxsumdebt, 1,
          ipfromtaxyaer, ipfromtaxyaer, trunc(vtotermpaydate)
          );

  vtsId := -1;
  vdocId := -1;
  i := 1;
for g in groupParams loop
   for r in sidedSubjects(g.h, g.l) loop
    for rec in subjects(r.taxsubject_id) loop    
      if (vtsId != rec.taxsubject_id) or (vdocId != rec.taxdoc_id) then
         select  nextval('s_action') into vaction_id ;
         insert into action
           (action_id, groupaction_id, taxdoc_id, taxsubject_id, kindaction, seqnom, 
            docno, doc_date, action_date, exec_date, actionstatus, exec_user_date, exec_user_id )
          -- actionstatus ( 1 = one-sided & 2 = two-sided print )
         values
           (vaction_id, vgroupaction_Id, rec.taxdoc_id, rec.taxsubject_id, '10', i, 
            rec.docno, rec.doc_date, date_trunc('day', LOCALTIMESTAMP), date_trunc('day', LOCALTIMESTAMP), r.actionstatus, date_trunc('day', LOCALTIMESTAMP), ipuser_id);

         vtsId := rec.taxsubject_id;
         vdocId := rec.taxdoc_id;
         i := i +1;
      end if;

      insert into actionitem
       (action_id, debtinstalment_id, instsum, interestsum)
      values
       (vaction_id, rec.debtinstalment_id, rec.instsum, rec.interestsum);

    end loop;
   end loop;
  end loop;

  --commit;
  ipStatus := 'OK';

exception
  when others then
    --rollback;
    --opstat := sqlerrm;	
    ipStatus := sqlerrm;
    perform NOM_PKG.ErrManage(sqlerrm);

end;
$function$
; DROP FUNCTION public.taxyearnotified(numeric, character varying, character varying, numeric, character varying); 
CREATE OR REPLACE FUNCTION public.taxyearnotified(ipuser_id numeric, ipdocno character varying, ipdocdate character varying, ipfromtaxyaer numeric DEFAULT NULL::numeric, INOUT opstat character varying DEFAULT 'OK'::character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
sidedSubjects cursor (vtaxsubjectId numeric) is
   select ds.taxsubject_id, ds.document_id taxdoc_id,
          --case when count(distinct ds.document_id) > 2 then '2' else '1' end actionstatus --original
          case when ts.isperson = 1 then '10' 
               when ts.isperson = 0 then '21' end actionstatus,
          max(ds.docno) docno, max(ds.doc_date) doc_date        -- for DBF 
     from debtsubject ds
     inner join taxdoc td on ds.document_id = td.taxdoc_id
                         and nvl(ds.typecorr,0) != 2 
     inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
     inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
     inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
                             and ts.taxsubject_id != (select c.configvalue from config c where upper(c.name) = 'TAXSUBJECT_ID')
     left outer join Address adr on adr.address_id = ts.post_clientaddr_id                        
     left outer join Municipality m on m.municipality_id = adr.municipality_id                           
    where 
          -- ds.kinddebtreg_id in (2,5)
           td.documenttype_id in (21,22) -- Decl 14, 17    
      -- and td.docstatus = '30' not needed
       and (nvl(bdi.instsum,0) + nvl(bdi.interestsum,0)) > 0
       and To_Number(To_char(ds.tax_begidate,'yyyy')) = decode(nvl(ipfromtaxyaer,0),0,1990,ipfromtaxyaer)
  /*     and not exists (Select * from actionItem ai
                                inner join action a on ai.action_id = a.action_id
                           where a.kindaction = '10'
                             and ai.debtinstalment_id = di.debtinstalment_id)
   group by m.ebk_code, ds.taxsubject_id originale */
        and ds.taxsubject_id > vtaxsubjectId   
   group by ts.isperson, ds.taxsubject_id, ds.document_id -- for DBF  
--  having count(distinct ds.document_id) > vhigh and count(distinct ds.document_id) < vlow
   order by ts.isperson desc; -- for DBF
   --order by m.ebk_code; original
   
subjects cursor (vtaxsubjectId numeric) is
   select td.docno, td.doc_date, td.taxdoc_id, 
          nvl(bdi.instsum,0) instsum, 
         (nvl(bdi.interestsum,0)+sanction_pkg.tempint(di.debtinstalment_id,trunc(sysdate))) interestsum, 
          ds.taxsubject_id
       from debtsubject ds
       inner join taxdoc td on ds.document_id = td.taxdoc_id
       inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
       inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
       inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
                               --and ts.taxsubject_id != (select c.configvalue from config c where upper(c.name) = 'TAXSUBJECT_ID')
       left outer join Address adr on adr.address_id = ts.post_clientaddr_id                        
       left outer join Municipality m on m.municipality_id = adr.municipality_id                           
       where 
            -- ds.kinddebtreg_id in (2,5)
             td.documenttype_id in (21,22) -- Decl 14, 17    
         and (nvl(bdi.instsum,0) + nvl(bdi.interestsum,0)) > 0
         and To_Number(To_char(ds.tax_begidate,'yyyy')) = decode(nvl(ipfromtaxyaer,0),0,1990,ipfromtaxyaer)
         /*and not exists (Select * from actionItem ai
                                  inner join action a on ai.action_id = a.action_id
                             where a.kindaction = '10'
                               and ai.debtinstalment_id = di.debtinstalment_id) */
         and ds.taxsubject_id = vtaxsubjectId
       order by ts.idn, ds.debtsubject_id, di.instno;         
partidi cursor (vtaxsubjectId numeric) is
   select max(td.docno) docno, max(td.doc_date) doc_date, ds.document_id taxdoc_id, 
          ds.taxsubject_id, max(ds.partidano) partidano
       from debtsubject ds
       inner join taxdoc td on ds.document_id = td.taxdoc_id
       inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
       inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
       inner join taxsubject ts on ts.taxsubject_id = ds.taxsubject_id
                               --and ts.taxsubject_id != (select c.configvalue from config c where upper(c.name) = 'TAXSUBJECT_ID')
       left outer join Address adr on adr.address_id = ts.post_clientaddr_id                        
       left outer join Municipality m on m.municipality_id = adr.municipality_id                           
       where 
            -- ds.kinddebtreg_id in (2,5)
             td.documenttype_id in (21,22) -- Decl 14, 17    
         and (nvl(bdi.instsum,0) + nvl(bdi.interestsum,0)) > 0
         and To_Number(To_char(ds.tax_begidate,'yyyy')) = decode(nvl(ipfromtaxyaer,0),0,1990,ipfromtaxyaer)
         /*and not exists (Select * from actionItem ai
                                  inner join action a on ai.action_id = a.action_id
                             where a.kindaction = '10'
                               and ai.debtinstalment_id = di.debtinstalment_id) */
         and ds.taxsubject_id = vtaxsubjectId
       group by ds.document_id, ds.taxsubject_id  
       order by partidano;         
       
actions cursor is
  select a.*
    from action a
    inner join groupaction ga on a.groupaction_id = ga.groupaction_id
   where 
         ga.kindaction = '10'
     and ga.fromtaxyaer = ipfromtaxyaer
order by a.taxsubject_id;     
gactions cursor is
  select ga.groupaction_id 
    from groupaction ga 
   where ga.kindaction = '10'
     and ga.fromtaxyaer = ipfromtaxyaer;
vgroupaction_Id numeric;
vtsId numeric;
vaction_Id numeric;
vminsumdebt numeric;
vmaxsumdebt numeric;
vfromtermpaydate date;
vtotermpaydate date;
vtaxperiod_id numeric;
vmessage varchar(4086);
verr varchar(300);
vseqnom numeric;
 i numeric;
begin
   
   if (trim(opStat) = '1') then  -- Potvyrjdenie na iztrivane 
     for rec in actions loop
      delete from actionitem ai where ai.action_id = rec.action_id;
     end loop;
     for rec in gactions loop
       delete from action a where a.groupaction_id = rec.groupaction_id;
     end loop;
     delete from groupaction ga 
      where ga.kindaction = '10'
        and ga.fromtaxyaer = ipfromtaxyaer;
     commit;   
   end if;
   
  select min(di.termpay_date), max(di.termpay_date),
         min(bdi.instsum), max(bdi.instsum) 
    into vfromtermpaydate, vtotermpaydate,
         vminsumdebt, vmaxsumdebt       
    from debtsubject ds
    inner join taxdoc td on ds.document_id = td.taxdoc_id
                        and nvl(ds.typecorr,0) != 2 
    inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
    inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id  
    inner join taxsubject ts on ds.taxsubject_id = ts.taxsubject_id
   where 
         td.documenttype_id in (21,22) -- Decl 14, 17    
     --and td.docstatus = '30'     
     and (nvl(bdi.instsum,0) + nvl(bdi.interestsum,0)) > 0
     and To_Number(To_char(ds.tax_begidate,'yyyy')) = decode(nvl(ipfromtaxyaer,0),0,1990,ipfromtaxyaer);

  select s_groupaction.nextval into vgroupaction_Id from dual;
  
  insert into groupaction
         (groupaction_id, kindaction, dategroupaction, docno, docdate,
          fromtermpaydate, isperson, minsumdebt, maxsumdebt, kinddebtreg_id,
          fromtaxyaer, totaxyear, totermpaydate)
   values
         (vgroupaction_Id, '10', trunc(sysdate), ipdocno, to_date(ipDocDate,'dd.mm.yyyy'),
          trunc(vfromtermpaydate), 0, vminsumdebt, vmaxsumdebt, 1,
          ipfromtaxyaer, ipfromtaxyaer, trunc(vtotermpaydate)
          );
   commit;       
          
   select tp.taxperiod_id  
     into vtaxperiod_id
     from taxperiod tp 
    where to_char(tp.begin_date,'yyyy') = (select c.configvalue from config c where c.name = 'TAXYEAR14')
      and tp.taxperkind = '0';
          

   vtsId := -1;
   i := 1;
  /* 
   begin     
     select a.groupaction_id, a.taxsubject_id, a.seqnom 
       into vgroupaction_Id, vtsId, vseqnom
       from action a      
      where a.seqnom = (select max(x.seqnom) from action x);
   exception
     when no_data_found then begin
       vtsId := -1;
       i := 1;    
     end;  
   end;    
   if (nvl(vseqnom,0) > 0) then 
     i := vseqnom + 1;
   end if;
   if vgroupaction_Id is null then 
      select s_groupaction.currval into vgroupaction_Id from dual;
   end if; */     
     
    
   for r in sidedSubjects(vtsId) loop -- only taxsubjects
    -- for rec in partidi(r.taxsubject_id) loop -- partidi by taxsubjects   
         vmessage := null;
         select  s_action.nextval into vaction_id from dual;
         
         begin
         perform massivemsg.MassMsgDBF(verr, r.taxsubject_id, r.taxdoc_id, vtaxperiod_id, ipuser_Id, vmessage); 
         exception
           when others then
             vmessage := verr;   
         end;
         
         insert into action
           (action_id, groupaction_id, taxdoc_id, taxsubject_id, kindaction, seqnom, 
            docno, doc_date, action_date, exec_date, actionstatus, exec_user_date, exec_user_id, 
            message )
         values
           (vaction_id, vgroupaction_Id, r.taxdoc_id, r.taxsubject_id, '10', i, 
            r.docno, r.doc_date, trunc(sysdate), trunc(sysdate), r.actionstatus, trunc(sysdate), ipuser_id,
            vmessage);

         i := i + 1;
         commit;

    -- end loop;
   end loop;
  
  commit;
  opStat := 'OK';

exception
  when others then begin
    rollback;
    perform NOM_PKG.ErrManage(opStat);
  end; 

end;
$function$
; DROP FUNCTION public.getdocnumber(numeric, character varying, character varying); 
CREATE OR REPLACE FUNCTION public.getdocnumber(ipmunicipality_id numeric, ipdoccode character varying, ipkinddoc character varying, OUT opdocnumber character varying, OUT opseries character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                                         
  inlast  numeric;
  in_to   numeric;
  outlast numeric;
  out_to  numeric;
  vreg_id numeric;
  opstat  varchar(100);

begin

  select r.incno_last, r.incno_to, r.outno_last, r.outno_to, r.regnumber_id,
         r.series
  into   inlast, in_to, outlast, out_to, vreg_id, opseries
  from   doctyperegnum t, regnumber r, documenttype dt
  where  dt.doccode = ipdoccode
  and    dt.documenttype_id = t.documettype_id
  and    t.regnumber_id = r.regnumber_id
  and    r.municipality_id = ipmunicipality_id;
  if ipkinddoc = '0' then
     if (coalesce(inlast, 0) + 1) <= coalesce(in_to, 0)
    then
     opdocnumber := to_char(Round(coalesce(inlast, 0),0) + 1);
      opstat      := 'OK';
      update regnumber
      set    incno_last = Round(coalesce(inlast, 0),0) + 1
      where  regnumber_id = vreg_id;
      --commit;
    else
      opdocnumber := '-1';
      opstat      := '�������� ��������';
    end if;
  end if;
  if ipkinddoc = '1' then
    if (coalesce(outlast, 0) + 1) <= coalesce(out_to, 0)
    then
      opdocnumber := to_char(Round(coalesce(outlast, 0),0) + 1);
      opstat      := 'OK';
      update regnumber
      set    outno_last = Round(coalesce(outlast, 0),0) + 1
      where  regnumber_id = vreg_id;
      --commit;
    else
      opdocnumber := '-1';
      opstat      := '�������� ��������';
    end if;
  end if;
exception
  when others then
    --rollback;
    opdocnumber := '-1';
    opstat      := '������';
end;
$function$
; DROP FUNCTION public.validitydate(numeric); 
CREATE OR REPLACE FUNCTION public.validitydate(tvtaxdocid numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE

  Result character varying(20);
  
  vdate character varying(20);
  taxper character varying(20);
  documenttypeid numeric;
  
  decl14to17 numeric;

  termpay_date1 character varying;
  suma1 numeric;
  termpay_date character varying;
  suma numeric;

BEGIN
  select td.decl14to17, td.documenttype_id
  into   decl14to17, documenttypeid
  from taxdoc td, tvtaxdoc tvd 
  where tvd.tvtaxdoc_id = tvTaxDocId --1534 
        and tvd.taxdoc_id = td.taxdoc_id;
 if documenttypeid = 21 AND coalesce(decl14to17,0) <> 1  then
        select max(c.configvalue)
        into taxper
        from config c
        where c.name = 'TAXYEAR14'
        and c.configvalue = to_char(CURRENT_DATE,'yyyy');

 else
        select max(c.configvalue)
        into taxper
        from config c
        where c.name = 'TAXYEAR17'
        and c.configvalue = to_char(CURRENT_DATE,'yyyy');
   end if;
        
  if  decl14to17 = 1 then    
  select min(di.termpay_date) termpay_date1, sum(bbi.instsum) suma1
  into termpay_date1, suma1
      from debtsubject ds
      join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      join tvtaxdoc d on /*d.taxdoc_id = ds.document_id and */d.taxsubject_id = ds.taxsubject_id
      left outer join baldebtinst bbi on di.debtinstalment_id = bbi.debtinstalment_id
      where ds.document_id  = (select f.taxdoc_id_17
                              from  tvtaxdoc tvd , firm_1417 f
                              where tvd.tvtaxdoc_id = tvTaxDocId
                              and tvd.taxdoc_id = f.taxdoc_id_14)
         and to_char(di.termpay_date, 'yyyy')= to_char(CURRENT_DATE,'yyyy');


  select min(di.termpay_date) termpay_date, sum(bi.instsum) suma
  into termpay_date, suma
      from baldebtinst bi, debtsubject ds, debtinstalment di, tvtaxdoc d
      where ds.document_id  = (select f.taxdoc_id_17
                              from  tvtaxdoc tvd , firm_1417 f
                              where tvd.tvtaxdoc_id = tvTaxDocId
                              and tvd.taxdoc_id = f.taxdoc_id_14)
   --     and d.taxdoc_id = ds.document_id
        and d.taxsubject_id = ds.taxsubject_id
        and ds.debtsubject_id = di.debtsubject_id
        and di.debtinstalment_id = bi.debtinstalment_id
        --and di.termpay_date <= CURRENT_TIMESTAMP ;
        and to_char(di.termpay_date, 'yyyy') < to_char(CURRENT_DATE,'yyyy');

  end if;

   if  coalesce(decl14to17,0) <> 1 then

  -- ������ ������
  select min(di.termpay_date) termpay_date1, sum(bbi.instsum) suma1
  into termpay_date1, suma1
      from debtsubject ds
      join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
      join tvtaxdoc d on d.taxdoc_id = ds.document_id and d.taxsubject_id = ds.taxsubject_id
      left outer join baldebtinst bbi on di.debtinstalment_id = bbi.debtinstalment_id
      where d.tvtaxdoc_id = tvTaxDocId
         and to_char(di.termpay_date, 'yyyy')= to_char(CURRENT_DATE,'yyyy');


  -- ����� �������
  select min(di.termpay_date) termpay_date, sum(bi.instsum) suma
  into termpay_date, suma
      from baldebtinst bi, debtsubject ds, debtinstalment di, tvtaxdoc d
      where d.tvtaxdoc_id = tvTaxDocId
        and d.taxdoc_id = ds.document_id
        and d.taxsubject_id = ds.taxsubject_id
        and ds.debtsubject_id = di.debtsubject_id
        and di.debtinstalment_id = bi.debtinstalment_id
       -- and di.termpay_date <= CURRENT_TIMESTAMP ;
        and to_char(di.termpay_date, 'yyyy') < to_char(CURRENT_DATE,'yyyy');

end if;


if coalesce(suma, 0) > 0 and termpay_date is not null then
     if CURRENT_TIMESTAMP <= to_date('30.06.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY')  then
        vdate := to_char(to_date('30.06.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY'),'DD.MM.YYYY') ;
     else
        vdate := to_char(to_date('31.12.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY'),'DD.MM.YYYY') ;
     end if;
else if coalesce(suma1, 0) > 0 and termpay_date1 is not null then
         if to_date(termpay_date1,'dd.mm.yyyy') <= to_date('30.06.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY')  then
            vdate := to_char(to_date('30.06.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY'),'DD.MM.YYYY') ;
         else
            vdate := to_char(to_date('31.12.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY'),'DD.MM.YYYY') ;
         end if;
      else  if taxper is  null then
           if CURRENT_TIMESTAMP <= to_date('30.06.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY')  then
              vdate := to_char(to_date('30.06.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY'),'DD.MM.YYYY') ;
           else
              vdate := to_char(to_date('30.12.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY'),'DD.MM.YYYY') ;
           end if;
        else
         vdate := to_char(to_date('31.12.'||to_char(CURRENT_DATE,'yyyy'),'DD.MM.YYYY'),'DD.MM.YYYY') ;
         end if;

end if;
        
 end if;       
  if result <> 'OK'
  then
    return null;
  end if;

  return vdate;
end;
$function$
; DROP FUNCTION public.add_date(timestamp without time zone, integer, character varying); 
CREATE OR REPLACE FUNCTION public.add_date(inputdate timestamp without time zone, incrementvalue integer, difftype character varying)
 RETURNS date
 LANGUAGE plpgsql
AS $function$
    DECLARE
    YEAR_CONST Char(15) := 'yyyy';
    MONTH_CONST Char(15) := 'mm';
    DAY_CONST Char(15) := 'dd';
     
    dateTemp Date;
    intervalValue varchar (100);
    BEGIN
    IF lower($1) = lower(YEAR_CONST) THEN
    dateTemp := inputDate + interval '$2 year';
    ELSEIF lower($1) = lower(MONTH_CONST) THEN
    dateTemp := inputDate + interval '$2 months';
    ELSEIF lower($1) = lower(DAY_CONST) THEN
    dateTemp := inputDate + interval '$2 day';
    END IF;
     
    RETURN dateTemp;
    END;
    $function$
; DROP FUNCTION public.numbertrim(numeric); 
CREATE OR REPLACE FUNCTION public.numbertrim(n numeric)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$ 
begin
  if(n is null)  then return 0; end if;
  if(rtrim(to_char(n),'0') = '')  then return 0; end if;  
  return to_number(rtrim(rtrim(to_char(n),'0'),'.'));
end;
$function$
; DROP FUNCTION public.ownerpart(integer, character varying, integer, date); 
CREATE OR REPLACE FUNCTION public.ownerpart(iptaxsubject_id integer, ipkindobj character varying, ipobj_id integer, ipenddate date)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
  DECLARE
  cr cursor  is
  select  ho.typedeclar, 
     case when nvl(ho.area,0.0) > 0.0 then ho.area/(case when nvl(h.objectarea,0.0) = 0.0 then 1.0 else h.objectarea end)
          when nvl(ho.part,0.0) > 0.0 then ho.part
          when nvl(ho.divisor,0.0) > 0.0 then ho.divident/ho.divisor
      else 0.0
     end
   from parthomeobj ho, homeobj h
   where ho.homeobj_id = ipobj_id and ho.homeobj_id = h.homeobj_id
   and ho.taxsubject_id = iptaxsubject_id
   and ((ho.end_date is null) or (ho.end_date > ipenddate))
   ;
   crl cursor  is
 select pl.typedeclar,
   case when pl.area > 0.0 then pl.area/(case when nvl(l.landarea,0.0) = 0.0 then 1.0 else l.landarea end)
    when pl.partland > 0.0 then pl.partland
    when nvl(pl.divisorland,0.0) > 0.0 then pl.dividentland/pl.divisorland
   else 0.0 
   end   from partland pl, land l
   where pl.land_id = ipobj_id and l.land_id = pl.land_id
   and pl.taxsubject_id = iptaxsubject_id
   and ((pl.end_date is null) or (pl.end_date > ipenddate))
   ;
  vusernum integer;
  userspart numeric;
  vuskoef numeric;
  ownerpart numeric; 
  res numeric;
  vtypedecl character varying (20);
  begin 
  res := 0.0;
 if ipkindobj = '2' then
  open cr;
   loop
   fetch cr into vtypedecl,ownerpart;
   exit when not FOUND;
   ownerpart := nvl(ownerpart,0.0);

   if vtypedecl = '2' then
    select sum((case when nvl(ph.part, 0.0) = 0.0 then nvl(ph.divident, 0.0) / (case when nvl(ph.divisor, 0.0) = 0.0 then 1.0 else ph.divisor end)
                 else ph.part 
                 end) * 
               (case when nvl(pho.part,0.0) > 0.0 then pho.part 
                else (case when nvl(pho.divisor,0.0) > 0.0 then pho.divident/pho.divisor else 0.0 end)  
                end)
               )
    into   userspart
    from   parthomeusers ph, parthomeobj h, parthomeobj pho
    where  h.homeobj_id = ipobj_id
    and h.taxsubject_id = iptaxsubject_id
    and  ph.userparthome_id = h.parthomeobj_id
    and pho.parthomeobj_id = ph.ownerparthome_id
     ;
    if nvl(userspart,0.0) = 0.0 then
      userspart := ownerpart;
    end if;
    res := res + round(userspart,3.0);
   else
    vuskoef := 1.0;
    select sum(
        (case when nvl(pp.area,0.0) > 0.0 then pp.area/(case when nvl(h.objectarea,0.0) > 0 then 1.0 else h.objectarea end)
              when nvl(pp.part,0.0) > 0.0 then pp.part
              when nvl(pp.divisor,0.0) <> 0.0 then pp.divident/pp.divisor
              else 0.0  end))
    into userspart
    from parthomeobj pp, homeobj h
    where pp.homeobj_id = ipobj_id
    and h.homeobj_id = pp.homeobj_id
    and pp.typedeclar = '2'
    and ((pp.end_date is null) or (pp.end_date > ipenddate))
    ;
    userspart := nvl(userspart,0.0);
    select count(*)
    into   vusernum
    from   parthomeusers ph, parthomeobj h
    where  ph.userparthome_id = h.parthomeobj_id
    and ((nvl(h.part,0.0) > 0.0) or (nvl(h.divident,0.0) > 0.0))
    and    h.homeobj_id = ipobj_id
    ;
    if vusernum > 0.0
    then
      select sum((case when nvl(ph.part, 0.0) = 0.0 then nvl(ph.divident, 0.0) /
                          (case when nvl(ph.divisor, 0.0) = 0.0 then 1.0 else ph.divisor end)
                        else ph.part end))
      into   userspart
      from   parthomeusers ph, parthomeobj h
      where  h.homeobj_id = ipobj_id
      and h.taxsubject_id = iptaxsubject_id
      and  ph.ownerparthome_id = h.parthomeobj_id
       ;
 --     userspart := nvl(userspart,0.0);
      vuskoef := nvl(userspart, 0.0);
    else
      vuskoef := 1.0 - nvl(userspart, 0.0);
    end if;
    res := res + round(vuskoef * nvl(ownerpart, 0.0),3);
   end if;
   end loop;
   close cr;
  else  --- Zemq
  open crl;
  loop
  fetch crl into vtypedecl,ownerpart;
   exit when not FOUND;
  ownerpart := nvl(ownerpart,0.0);
  if vtypedecl = '2' then
    select sum((case when nvl(ph.part, 0.0) = 0.0 then nvl(ph.divident, 0.0) /
                                                (case when nvl(ph.divisor, 0.0) =  0.0 then 1.0 else ph.divisor end)
               else ph.part end) * 
              (case when nvl(pho.partland,0.0)> 0.0 then pho.partland 
                 when nvl(pho.divisorland,0.0) > 0.0 then pho.dividentland/pho.divisorland else 0.0 end))
    into   userspart
    from   partlandusers ph, partland h, partland pho
    where  h.land_id = ipobj_id
    and h.taxsubject_id = iptaxsubject_id
    and  ph.userpartland_id = h.part_land_id
    and pho.part_land_id = ph.ownerpartland_id
     ;
    if nvl(userspart,0.0) = 0.0 then
    userspart := ownerpart;
    end if;
    res := res + round(userspart,3);
  else
  vuskoef := 1.0;
  select sum((case when nvl(pp.area,0.0) > 0.0 then pp.area / (case when nvl(l.landarea,0.0) = 0.0 then 1.0 else l.landarea end) 
   when nvl(pp.partland,0.0) > 0.0 then pp.partland 
   when nvl(pp.divisorland,0.0) > 0.0 then nvl(pp.dividentland,0.0) / pp.divisorland else 0.0 end))
  into userspart
  from partland pp, land l
  where pp.land_id = ipobj_id
  and l.land_id = pp.land_id
  and pp.typedeclar = '2'
  and ((pp.end_date is null) or (pp.end_date > ipenddate))
  ;
  userspart := nvl(userspart,0.0);

    select count(*)
    into   vusernum
    from   partlandusers pl, partland l
    where  pl.userpartland_id = l.part_land_id
    and ((nvl(l.partland,0.0) > 0.0) or (nvl(l.dividentland,0.0) > 0.0))
    and    l.land_id = ipobj_id
    ;
    if vusernum > 0 then
      select sum(case when nvl(pl.part, 0.0) = 0.0 then  nvl(pl.divident, 0.0) /
                             (case when nvl(pl.divisor, 0.0) = 0.0 then 1.0 else pl.divisor end) 
                  else pl.part end )
      into   userspart
      from   partlandusers pl, partland l
      where  l.land_id = ipobj_id
      and l.taxsubject_id = iptaxsubject_id
      and  pl.ownerpartland_id = l.part_land_id
       ;
--      userspart := nvl(userspart,0);
      vuskoef := nvl(userspart, 0.0);
    else
      vuskoef := 1 - nvl(userspart, 0.0);
    end if;
    res := res + vuskoef * nvl(ownerpart, 0.0);
   end if;
  end loop;
  close crl;
  end if;
    return(res);
 end;
$function$
; DROP FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone)
 RETURNS time without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone)
 RETURNS timestamp without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone)
 RETURNS timestamp with time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, text, anyelement, text, text); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, text, anyelement, text, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, character, anyelement, character, character); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, character, anyelement, character, character)
 RETURNS character
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.accval17(numeric, character varying); 
CREATE OR REPLACE FUNCTION public.accval17(iptd_id numeric, ipsn character varying, OUT opstr character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                                     
   cr cursor (sn varchar) is
    select a.arxdate, a.taxdocarx_id, a.docno, a.doc_date, a.change_date,
           (xpath('/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/ACCVALUE/text()', a.docdata))[1]::text::numeric ots,
           (xpath('/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/CIRCUMCHANGE_DATE/text()', a.docdata))[1]::text::date cdate,
           (xpath('/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/EARN_DATE/text()', a.docdata))::text::date edate
    from   taxdocarx a
    where  a.taxdoc_id = iptd_id
    union
    select a.arxdate, a.taxdocarx_id, a.docno, a.doc_date, a.change_date,
           (xpath('/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/ACCVALUE/text()', a.docdata))[1]::text::numeric ots,
           (xpath('/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/CIRCUMCHANGE_DATE/text()', a.docdata))[1]::text::date cdate,
           (xpath('/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/EARN_DATE/text()', a.docdata))[1]::text::date edate
    from   taxdocarx a
    where  a.taxdoc_id = iptd_id
    order  by 1;
  r     record;
  volds numeric;
  vstr  varchar(2000);
begin
  volds := 0;
  vstr  := '';
 
  open cr(ipsn);
  loop
    fetch cr
      into r;
    exit when not FOUND;		
    if r.ots is not null
    then
      if nvl(volds, 0.0) <> nvl(r.ots, 0.0)
      then
        opstr := (r.docno || ';' || r.edate::text || ';' || r.cdate::text || ';' || r.ots);
        vstr := vstr || opstr || '@';
      end if;
      volds := r.ots;
    end if;
  end loop;
   --zatvarya cursora na 20.09.2011
  close cr;
  opstr := vstr;
end;
$function$
; DROP FUNCTION public.add_months(timestamp without time zone, integer); 
CREATE OR REPLACE FUNCTION public.add_months(in_date timestamp without time zone, val integer)
 RETURNS date
 LANGUAGE plpgsql
AS $function$
declare
begin
 return add_months(in_date::date, val);
end;
$function$
; DROP FUNCTION public.address_delete(numeric); 
CREATE OR REPLACE FUNCTION public.address_delete(OUT return_val character varying, ipaddress_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
begin
  delete from address where address_id = ipAddress_Id;
  return_val := 'OK';

  exception
    when others
    then return_val := 'notRemoved';

end;
$function$
; DROP FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer, integer); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer, integer)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint, bigint); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint, bigint)
 RETURNS bigint
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.addrtext(character varying); 
CREATE OR REPLACE FUNCTION public.addrtext(ipaddr character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  vaddr varchar(400);
begin
  select a.country_id || ';' || 
	 nvl(m.province_id,0.0) || ';' || 
	 a.municipality_id || ';' || a.city_id || ';' || 
	 decode(ltrim(to_char(nvl(a.admregion_id,0.0),'999999999999999999999999999'),' '),'0','') || ';' || 
	 decode(ltrim(to_char(nvl(a.street_id,0.0),'999999999999999999999999999'),' '),'0','') || ';' ||
         nvl(a.nom,'') || ';' ||  nvl(a.block,'') || ';' ||  nvl(a.entry,'') || ';' ||  
	 nvl(a.floor,'') || ';' ||  nvl(a.apartment,'') || ';' aaa
  into   vaddr
  from   address a, municipality m
  
  where  a.address_id = to_number(ipaddr,'999999999999999999999999999')
  and    a.municipality_id = m.municipality_id;
  return(vaddr);
end;

$function$
; DROP FUNCTION public.adelete(anyelement, integer); 
CREATE OR REPLACE FUNCTION public.adelete(el anyelement, i integer)
 RETURNS anyelement
 LANGUAGE plpgsql
AS $function$
begin
  return nvl(el, cast(i as numerc));
end
$function$
; DROP FUNCTION public.anulate(numeric, numeric, date, character varying); 
CREATE OR REPLACE FUNCTION public.anulate(ippaydocument_id numeric, ipuser_id numeric, ipdatestorno date, ipnullreason character varying, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                                    
   cr cursor is
    select *
    from   paydebt pd
    where  pd.paydocument_id = ipPaydocument_Id;

   crkas cursor is
    select pdt.kinddebtreg_id kdrid, dis.debtsubject_id dsid,
           sum(nvl(pdt.payinstsum, 0.0) + nvl(pdt.payinterestsum, 0.0)) sumOv,
           max(pdt.kindparreg_id) kprid, sum(pdt.paydiscsum) discsum
    from   paydebt pdt, debtinstalment dis
    where  pdt.debtinstalment_id = dis.debtinstalment_id
    and    pdt.paydocument_id = ipPaydocument_Id
    group  by pdt.kinddebtreg_id, dis.debtsubject_id;

  rkas                 record;
  r                    record;
  vkindpaydoc          varchar(10);
  voverpaysum          numeric;
  voversubject_id      numeric;
  vsbid                numeric;
  vsb                  numeric;
  vtrtype              varchar(10);
  opid                 numeric;
  vmunicipality_Id     numeric;
  vosid                numeric;
  vpartidano           varchar(40);
  vtaxsubject_id       numeric;
  vdocsum              numeric;
  vdocumentno          varchar(20);
  vdocumentdate        date;
  vover_kinddebtreg_id numeric;
  vptr                 numeric;
  vbaccount_id         numeric;
  vbanksmetka          varchar(50);
  vbic                 varchar(50);
  vidn                 varchar(30);
  vname                varchar(200);
  vTSObstina           numeric;
  vdocnumber           varchar(20);
  vseries              varchar(20);
  vbdi                 numeric;
  vnull_date           date;
  vfinishday_id        numeric;
  visactive            numeric;
  vbank_id             numeric;
begin
  select pd.kindpaydoc, pd.overpaysum, pd.oversubject_id, ptr.trtype,
         ptr.finishday_id, ptr.municipality_id, pd.partidano, pd.taxsubject_id,
         pd.docsum, pd.documentno, pd.documentdate, pd.over_kinddebtreg_id,
         pd.null_date
  
  into   vkindpaydoc, voverpaysum, voversubject_id, vtrtype, vfinishday_id,
         vmunicipality_Id, vpartidano, vtaxsubject_id, vdocsum, vdocumentno,
         vdocumentdate, vover_kinddebtreg_id, vnull_date
  
  from   paydocument pd, paytransaction ptr
  where  pd.paytransaction_id = ptr.paytransaction_id
  and    pd.paydocument_id = ipPaydocument_Id;
  if vnull_date is not null
  then
    opStat := '1'; -- '�������� �������� � ���� ���������!'
    return;
  end if;
  ---Nadvneseni
  if (voverpaysum <> 0) and (vtrtype in ('4', '1', '33', '2'))
  then
    if vKindpaydoc in ('621', '622')
    then
      voverpaysum := -voverpaysum;
    end if;
  
    select max(bi.oversubject_id), max(bi.oversum)
    into   vsbid, vsb
    from   baloverinst bi
    where  bi.oversubject_Id = voversubject_Id;
  
    if (nvl(vsb, 0.0) < voverpaysum)
    then
      opStat := '2'; -- '������ � ���������� ����!'
      return;
    end if;
  
    if nvl(vsbid, 0.0) > 0
    then
      if (nvl(vsb, 0.0) - voverpaysum) > 0
      then
        update Baloverinst 
        set    oversum = nvl(oversum, 0.0) - voverpaysum
        where  oversubject_id = voversubject_Id;
      else
        delete from Baloverinst 
        where  oversubject_id = voversubject_Id;
      end if;
    else
      if (nvl(vsb, 0.0) - voverpaysum) > 0
      then
        insert into Baloverinst
          (OverSubject_Id, oversum)
        values
          (voversubject_Id, -voverpaysum);
      end if;
    end if;
  
  end if; -- Nadvneseni

  ---Kasovo plastane sled ezednevno prikliucvane - zapis na nadvneseni;
  if (vkindpaydoc = '600') and (vfinishday_id is not null)
  then
    open crkas;
    loop
      fetch crkas
        into rkas;
      exit when not FOUND;

      select nextval('s_oversubject') into vosid;
      
    
      insert into Oversubject
        (oversubject_id, kinddebtreg_id, taxsubject_id, overpaysum,
         overinterestsum, overcorsum, partidano, municipality_id, debtsubject_id)
      values
        (vosid, rkas.kdrid, vtaxsubject_id, rkas.sumOV, null, null, vpartidano,
         vmunicipality_id, rkas.dsid);
    
      insert into Baloverinst
        (OverSubject_Id, oversum)
      values
        (vosid, rkas.SumOv);
    
      select nextval('s_Operation')
      into   opid;
    
      insert into operation
        (operation_id, oper_date, operdocno, opercode, opersum, user_date,
         user_id, user_name, paytransaction_id, oversubject_id, municipality_id,
         cancel_Paydocument_Id)
      values
        (opid, ipDateStorno, opid, '17', rkas.SumOv, current_date, ipuser_Id,
         (select us.fullname
           from   users us
           where  us.user_Id = ipuser_Id), null, vosid, vmunicipality_id,
         ipPaydocument_Id);
    
      insert into operdebt
        (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
         operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
         balinstsum)
      values
        (nextval('s_operdebt'), opid, rkas.kdrid, null, rkas.sumOV, null,
         rkas.discsum, rkas.kprid, null, null);
    end loop;
    close crkas;
  
  end if; --kasovo plastane ��

  ----��� ���� ��������� �����������

  if (vKindpaydoc = '621') and (vfinishday_id is not null)
  then
  
    select nextval('s_Paytransaction')
    into   vptr
    from   dual;
  
    select b.baccount_id, b.iban, bk.bic, bk.bank_id
    into   vbaccount_id, vbanksmetka, vbic, vbank_id
    from   baccount b, bank bk
    where  b.municipality_id = vmunicipality_id
    and    b.isbase = 1
    and    b.isactive = 1
    and    b.bank_id = bk.bank_id;
  
    select ts.idn, ts.name
    into   vidn, vname
    from   taxsubject ts
    where  ts.taxsubject_id = vtaxsubject_id;
  
    select c.configvalue
    into   vTSObstina
    from   config c
    where  c.name = 'TAXSUBJECT_ID';
  
    perform  getdocnumber(vmunicipality_Id, '613', '6', vdocnumber, vseries);
  
    insert into paydocument
      (paydocument_id, baccount_id, taxsubject_id, kindpaydoc, regdocno,
       documentno, series, documentdate, paydate, docsum, bin, user_date,
       user_id, user_name, reason1, note, tsaccount, paytransaction_id,
       partidano, reason2, oversubject_id, overpaysum, over_kinddebtreg_id,
       from_kinddebtreg_id, tsbic, rcbic, rcaccount, receive_taxsubject_id,
       company_id, PARENT_PAYDOCUMENT_ID, rcbank_id)
    values
      (nextval('s_Paydocument'), vbaccount_id, vTSObstina, '613', null, vdocnumber,
       null, ipDateStorno, ipDateStorno, vdocsum, null, current_date, ipUser_Id,
       (select us.fullname
         from   users us
         where  us.user_Id = ipUser_Id),
       '������ ��� �' || vdocumentno || '/' ||
        To_Char(vdocumentdate, 'dd.mm.yyyy'), null, vbanksmetka, vptr, null,
       '�� ���/�������:' || VIDN || 'Ime:' || vName, voversubject_Id, vdocsum,
       vover_kinddebtreg_id, null, vbaccount_id, vbaccount_id, vbanksmetka, null,
       null, ipPaydocument_Id, vbank_id);
  
    insert into paytransaction
      (paytransaction_id, transactionno, trdate, trsuma, trtype, user_date,
       user_id, municipality_id)
    values
      (vptr, vptr, ipDateStorno, vdocsum, '35', current_date, ipuser_Id,
       Vmunicipality_Id);
    ----
  
  end if; --��� ���� ���������

  --vrastane na zadalzenia
  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
  
    select kd.isactive
    into   visactive
    from   kinddebtreg kd
    where  kd.kinddebtreg_id = r.kinddebtreg_id;
    if visactive <> 2
    then
      select max(bd.debtinstalment_id)
      into   vbdi
      from   baldebtinst bd
      where  bd.debtinstalment_id = r.debtinstalment_id;
    
      if vbdi is null
      then
      
        insert into BalDebtInst
          (debtinstalment_id, instsum, interestsum, discsum)
        values
          (r.debtinstalment_id, (nvl(r.payinstsum, 0.0) + nvl(r.paydiscsum, 0.0)),
           nvl(r.payinterestsum, 0.0), null);
      else
        update Baldebtinst 
        set    instsum = nvl(instsum, 0.0) + nvl(r.payinstsum, 0.0) +
                               nvl(r.paydiscsum, 0.0),
               interestsum = nvl(interestsum, 0.0) +
                                   nvl(r.payinterestsum, 0.0), discsum = null
        where  debtinstalment_id = r.debtinstalment_id;
      
      end if;
      -- nulirame otstapka
      if nvl(r.paydiscsum, 0.0) > 0
      then
        update debtsubject
        set    paydiscsum = null
        where  debtsubject_id =
               (select di.debtsubject_id
                from   debtinstalment di
                where  di.debtinstalment_id = r.debtinstalment_id);
      end if;
    end if; -- isactive
  
    if visactive = 2
    then
      -- storno na bezoblozni
    
      delete from baldebtinst
      where  debtinstalment_id = r.debtinstalment_id;
    
    
    
      update debtsubject
      set    totaltax = 0, totalval = 0,
             note = '���������� �������'
      where  debtsubject_id =
             (select di.debtsubject_id
              from   debtinstalment di
              where  di.debtinstalment_id = r.debtinstalment_id);
    
      update debtinstalment
      set    instsum = 0
      where  debtinstalment_id = r.debtinstalment_id;
    
    end if; -- isactive
  end loop;
  close cr;
  -- Storno platezen dokument
  update paydocument
  set    null_date = ipdateStorno, null_userdate = current_date,
         null_user_Id = ipUser_Id,
         null_user_Name =
          (select us.fullname
           from   users us
           where  us.user_Id = ipUser_Id), bin = '2',
         nullreason = ipnullreason
  where  paydocument_Id = ipPaydocument_Id;
  --commit;
  opStat := '0';
exception
  when others then
    --rollback;
    opStat := '3'; --'������!';


end;
$function$
; DROP FUNCTION public.anulategen(numeric, character varying, character varying, character varying, numeric, character varying, character varying, numeric); 
CREATE OR REPLACE FUNCTION public.anulategen(voversubject numeric, voversum character varying, vdatstor character varying, vuser character varying, pld_id numeric, vkindpaydoc character varying, vreason character varying, vbin numeric, OUT opresult character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                                       
  vsb        numeric;
  myvoversum numeric;
  ind        numeric;
  res 	     varchar(400);	
	
begin
  --if vOversum <> '0'
  --then
    select max(bi.oversum)
    into   vsb
    from   baloverinst bi
    where  bi.oversubject_Id = voversubject;
  
    if (nvl(vsb, 0.0) < vOversum::numeric)
    then
      if vKindpaydoc not in ('621', '622')
      then
        res        := '������ ���������� ����.����. ���. �� ���� �� �� ��������!';
        opResult := nvl(res, '');
        return;
      else
        if vKindpaydoc in ('621', '622')
        then
          myvoversum := vOversum;
        else
          myvoversum := -vOversum;
        end if;
        opResult := '';
      
        select max(bl.oversubject_id)
        into   ind
        from   baloverinst bl
        where  bl.oversubject_id = voversubject;
      
        if (ind is null)
        then
        
          insert into Baloverinst
            (OverSubject_Id, oversum)
          values
            (voversubject, myvoversum);
        else
          if (vsb + myvoversum) > 0
          then
            update Baloverinst
            set    oversum = nvl(oversum, 0.0) + myvoversum
            where  oversubject_id = voversubject;
          else
            delete from Baloverinst
            where  oversubject_id = voversubject;
          end if;

        
        end if;
      end if;
  --  end if;
  
  
    --oversubject
    update OverSubject
    set    overpaysum =
            (nvl(overpaysum, 0.0) - myvoversum)
    where  oversubject_id = voversubject;
  end if; --Nadvnesena
  -- Storno platezen dokument
  update paydocument
  set    null_date = to_date(vdatstor, 'dd/mm/yyyy'),
         null_userdate = current_date, null_user_Id = vuser::numeric,
         nullreason = vreason, bin = vbin,
         null_user_Name =
          (select us.fullname
           from   users us
           where  us.user_Id = vuser::numeric)
  where  paydocument_Id = pld_ID;
  opResult := nvl(res, 'OK');
--  return;
end;
$function$
; DROP FUNCTION public.anulategennew(numeric, character varying, character varying); 
CREATE OR REPLACE FUNCTION public.anulategennew(voversubject numeric DEFAULT 0, voversum character varying DEFAULT 0, vkindpaydoc character varying DEFAULT 600, OUT result character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  vOversumNum numeric;
  vsb numeric;
  res varchar(200);
begin
  result := 'OK';
  res:= 'OK';
  vOversumNum := to_number(voversum,'99999999999.99');
  if vOversumNum <> 0
  then
    select max(bi.oversum)
    into   vsb
    from   baloverinst bi
    where  bi.oversubject_Id = voversubject;
  
    if (nvl(vsb, 0.0) < vOversumNum) and (vKindpaydoc not in ('621', '622'))
    then
      result := '������ ���������� ����.����. ���. �� ���� �� �� ��������!';

    end if;
  end if;
  res := result;
  --return res;


end;
$function$
; DROP FUNCTION public.autopay(numeric, numeric, date, numeric, numeric, numeric, character varying, numeric, numeric, numeric, date, character varying, character varying, date, date, character varying, character varying, character varying, character varying, character varying, character varying, character varying, numeric, character varying, character varying); 
CREATE OR REPLACE FUNCTION public.autopay(ipuser_id numeric, ipmunicipality_id numeric, ippaydate date, ippaysum numeric, ipkinddebtreg numeric, iptaxsubject_id numeric, ippartidano character varying, OUT opdocno character varying, OUT opstatus character varying, ipbaccount_id numeric DEFAULT NULL::numeric, ipcompany_id numeric DEFAULT NULL::numeric, ipoffice_id numeric DEFAULT NULL::numeric, ipdocumentdate date DEFAULT NULL::date, ipregdocno character varying DEFAULT NULL::character varying, ipdocpay character varying DEFAULT NULL::character varying, ipdocfromdate date DEFAULT NULL::date, ipdoctodate date DEFAULT NULL::date, ipreason1 character varying DEFAULT NULL::character varying, ipreason2 character varying DEFAULT NULL::character varying, ipnote character varying DEFAULT NULL::character varying, iptsaccount character varying DEFAULT NULL::character varying, iptsbic character varying DEFAULT NULL::character varying, iprcbic character varying DEFAULT NULL::character varying, iprcaccount character varying DEFAULT NULL::character varying, ipreceive_taxsubject_id numeric DEFAULT NULL::numeric, ipextdocumentno character varying DEFAULT NULL::character varying, ipextseries character varying DEFAULT NULL::character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
   cr cursor is
    select di.debtinstalment_id, bdi.instsum,
           round(bdi.interestsum, 2) interestsum, bdi.discsum, ds.kindparreg_id,
           ds.kinddebtreg_id, ds.debtsubject_id
    from   debtsubject ds, debtinstalment di, baldebtinst bdi
    where  ds.debtsubject_id = di.debtsubject_id
    and    di.debtinstalment_id = bdi.debtinstalment_id
    and    ds.taxsubject_id = iptaxsubject_Id
    and    ds.municipality_id = ipmunicipality_Id
    and    ds.kinddebtreg_id = ipKinddebtreg
    and    nvl(ds.partidano, '*') =
           decode(ippartidano, null, nvl(ds.partidano, '*'), ippartidano)
    and    ((nvl(bdi.instsum, 0.0) > 0) or
          (nvl(round(bdi.interestsum, 2), 0.0) > 0))
    order  by di.termpay_date, ds.partidano;
  r            record;
  vost         numeric;
  pgl          numeric;
  plix         numeric;
  vdsc         numeric;
  vtransaction numeric;
  vpaydocument numeric;
  vtrtype      varchar(4);
  vdocnumber   varchar(20);
  vseries      varchar(8);
  voversubject numeric;
  vkindpaydoc  varchar(10);
  vStat        varchar(50);
begin
  if (ipTaxsubject_Id is null) or (ipKinddebtreg is null)
  then
    opstatus := '0'; -- Lipsva danacen subekt
    return;
  end if;

  vtrtype     := '4'; -- bankovo plastane na DS
  vkindpaydoc := '613';
  -- otstapka
  select Sanction_Pkg.calcdiscount(ipTaxSubject_id, null, ipPayDate) into vStat;
  if vStat <> 'OK'
  then
    opstatus := '1'; -- greska pri nacislenie na otstapka
    return;
  end if;
  -- olixvjavane
  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
    vStat := Sanction_Pkg.CalculateInt(r.debtinstalment_id, ipPaydate, ipuser_id);
    if vStat <> 'OK'
    then
      opstatus := '2'; -- greska pri nacislenie na lixva
      exit;
    end if;
  end loop;
  close cr;
  ---------------
  vdsc         := 0;
  vost         := ippaysum;
  voversubject := null;

  select nextval('s_paytransaction')
  into   vtransaction
;
  insert into paytransaction 
    (paytransaction_id, transactionno, trdate, trsuma, trtype, user_date,
     user_id, municipality_id, office_id)
  values
    (vtransaction, vtransaction, ippaydate, ippaysum, vtrtype, current_date,
     ipuser_Id, ipmunicipality_Id, null);
     
  select nextval('S_Paydocument')
  into   vpaydocument;
  
  select Getdocnumber(ipmunicipality_Id, vkindpaydoc, '1') into vdocnumber, vseries;

  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
    pgl  := 0;
    plix := 0;
    vdsc := 0;
    if vost <= 0
    then
      exit;
    end if;
    if (r.instsum > 0) and (vost > 0)
    then
      if vost >= (r.instsum - r.discsum)
      then
        pgl  := (r.instsum - r.discsum);
        vdsc := r.discsum;
        if vdsc > 0
        then
          update debtsubject 
          set    paydiscsum = vdsc
          where  debtsubject_id = r.debtsubject_id;
        end if;
      else
        pgl := vost;
      end if;
    
    
      vost := vost - pgl;
    end if;
  
    if (vost > 0) and (r.interestsum > 0)
    then
      if vost >= r.interestsum
      then
        plix := r.interestsum;
      else
        plix := vost;
      end if;
      vost := vost - plix;
    
    end if;
  
    ---- zapis plastane
    insert into PayDebt
      (paydebt_id, kinddebtreg_id, paydocument_id, debtinstalment_id,
       payinstsum, payinterestsum, paydiscsum, balinstsum, balinterestsum,
       kindparreg_id)
    values
      (nextval('S_PayDebt'), r.kinddebtreg_Id, vpaydocument, r.debtinstalment_id,
       pgl, plix, vdsc, r.instsum, r.interestsum, r.kindparreg_id) --*
    ;
  
    update Baldebtinst 
    set    instsum = instsum - pgl - vdsc,
           interestsum = interestsum - plix, discsum = null
    where  debtinstalment_id = r.DebtInstalment_Id;
  end loop;
  close cr;
  if vost < 0
  then
    vost := 0;
  end if;
  if vost > 0
  then
    --zapis nadvnesena
    select nextval('s_oversubject')
    into   voversubject;
  
    insert into OverSubject
      (oversubject_id, kinddebtreg_id, taxsubject_id, overpaysum, partidano,
       municipality_id, debtsubject_id)
    values
      (voversubject, ipkinddebtReg, iptaxsubject_id, vost, ipPartidano,
       ipMunicipality_id, null);
  
    insert into Baloverinst
      (oversubject_id, oversum)
    values
      (voversubject, vost);
  end if;

  insert into PayDocument
    (paydocument_id, baccount_id, taxsubject_id, kindpaydoc, regdocno,
     documentno, series, documentdate, paydate, docsum, bin, user_date, user_id,
     user_name, reason1, note, tsaccount, docpay, docfromdate, doctodate,
     paytime, paytransaction_id, partidano, taxobject_id, reason2,
     oversubject_id, overpaysum, over_kinddebtreg_id, from_kinddebtreg_id, tsbic,
     rcbic, rcaccount, receive_taxsubject_id, company_id, parent_paydocument_id,
     extdocumentno, extseries, act_id)
  values
    (vpaydocument, ipbaccount_id, iptaxsubject_id, vkindpaydoc, ipregdocno::numeric,
     vdocnumber, vseries, ipDocumentDate, ipPayDate, ipPaysum, null, current_date,
     ipUser_Id,
     (select u.fullname
       from   users u
       where  u.user_id = ipUser_Id), ipreason1, ipnote, iptsaccount, ipdocpay,
     ipdocfromdate, ipdoctodate, ipPayDate, vtransaction, ippartidano, null,
     ipreason2, voversubject, vost,
     decode(voversubject, null, null, ipKinddebtreg), null, iptsbic, iprcbic,
     iprcaccount, ipreceive_taxsubject_id, ipcompany_id, null, ipextdocumentno,
     ipextseries, null);
  --commit;
  opDocno  := vdocnumber;
  opStatus := 'OK';
exception
  when no_data_found then
    opStatus := '3'; --lipsvat danni
    --rollback;
  when others then
    --rollback;
    opStatus := '4'; --greska
end;
$function$
; DROP FUNCTION public.biddingea(numeric, character varying, timestamp without time zone, timestamp without time zone, timestamp without time zone, numeric, numeric, numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION public.biddingea(ipuser_id numeric, ipdocno character varying, ipdocdate timestamp without time zone, ipfromtermpaydate timestamp without time zone DEFAULT NULL::timestamp without time zone, iptotermpaydate timestamp without time zone DEFAULT NULL::timestamp without time zone, ipisperson numeric DEFAULT NULL::numeric, ipminsumdebt numeric DEFAULT NULL::numeric, ipmaxsumdebt numeric DEFAULT NULL::numeric, ipkinddebtreg numeric DEFAULT NULL::numeric, ipfromtaxyaer numeric DEFAULT NULL::numeric, iptotaxyear numeric DEFAULT NULL::numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE

  vfromtermpaydate timestamp;
  vtotermpaydate   timestamp;
  vminsumdebt      numeric;
  vmaxsumdebt      numeric;
  vfromtaxyaer     numeric;
  vtotaxyear       numeric;
  vgroupaction_Id  numeric;
  vdsid            numeric;
  vaction_Id       numeric;
  Lixva            varchar(50);

 cr CURSOR is
    select ds.debtsubject_id, ds.docno, ds.doc_date, di.debtinstalment_id,
           bdi.instsum, bdi.interestsum, ds.taxsubject_id
    from   debtsubject ds, debtinstalment di, baldebtinst bdi, taxsubject ts
    where  ds.debtsubject_id = di.debtsubject_id
    and    di.debtinstalment_id = bdi.debtinstalment_id
    and    ds.taxsubject_id = ts.taxsubject_id
    and    (coalesce(bdi.instsum, 0) + coalesce(bdi.interestsum, 0)) >= vminsumdebt
    and    (coalesce(bdi.instsum, 0) + coalesce(bdi.interestsum, 0)) <= vmaxsumdebt
    and    di.termpay_date > vfromtermpaydate
    and    di.termpay_date < vtotermpaydate
    and    (to_char(ds.tax_begidate,'yyyy'))::numeric >= vfromtaxyaer
    and    (to_char(ds.tax_begidate,'yyyy'))::numeric <= vtotaxyear
    and    ts.isperson = (CASE WHEN ipisperson=null THEN ts.isperson ELSE ipisperson END)
    and    ds.kinddebtreg_id =
           (CASE WHEN ipkinddebtreg=null THEN ds.kinddebtreg_id ELSE ipkinddebtreg END)
    and    exists
     (select *
            from   actionItem ai, action a
            where  ai.action_id = a.action_id
            and    a.kindaction = '20'
            and    ai.debtinstalment_id = di.debtinstalment_id
            and    (a.deliver_date IS NOT NULL AND a.deliver_date::text <> '')
            and date_trunc('day', LOCALTIMESTAMP) > a.deliver_date + '6 month'::interval
            )
    and    not exists 
         (select *
            from   actionItem ai, action a
            where  ai.action_id = a.action_id
            and    a.kindaction = '40'
            and    ai.debtinstalment_id = di.debtinstalment_id)     
    order  by ds.debtsubject_id;


   
  r record;
  i numeric;



BEGIN
  if coalesce(ipfromtermpaydate::text, '') = ''
  then
    vfromtermpaydate := to_date('01.01.1900','dd.mm.yyyy');
  else
    vfromtermpaydate := ipfromtermpaydate;
  end if;
  if coalesce(iptotermpaydate::text, '') = ''
  then
    vtotermpaydate := date_trunc('day', LOCALTIMESTAMP);
  else
    vtotermpaydate := iptotermpaydate;
  end if;
  if coalesce(ipminsumdebt::text, '') = ''
  then
    vminsumdebt := 0.01;
  else
    vminsumdebt := ipminsumdebt;
  end if;
  if coalesce(ipmaxsumdebt::text, '') = ''
  then
    vmaxsumdebt := 999999999999;
  else
    vmaxsumdebt := ipmaxsumdebt;
  end if;
  if coalesce(ipfromtaxyaer::text, '') = ''
  then
    vfromtaxyaer := 1990;
  else
    vfromtaxyaer := ipfromtaxyaer;
  end if;
  if coalesce(iptotaxyear::text, '') = ''
  then
    vtotaxyear := to_char(LOCALTIMESTAMP, 'yyyy')::integer;
  else
    vtotaxyear := iptotaxyear;
  end if;

  -- proverka na broj zapisi v cursora => zapisi!!!
  -- olixviavane do sysdate
  open cr;
  loop
    fetch cr
      into r;
    IF NOT FOUND THEN EXIT; END IF; -- apply on cr
    Lixva := Sanction_PKG.CalculateInt(r.debtinstalment_id, date_trunc('day', LOCALTIMESTAMP),
                                       ipuser_Id);
  end loop;
  close cr;
  if Lixva <> 'OK'
  then
    opStat := Lixva;
    return;
  end if;
  commit;


  select nextval('s_groupaction')
  into   vgroupaction_Id
  from   dual;

  insert into groupaction
    (groupaction_id, kindaction, dategroupaction, docno, docdate,
     fromtermpaydate, isperson, minsumdebt, maxsumdebt, kinddebtreg_id,
     fromtaxyaer, totaxyear, totermpaydate)
  values
    (vgroupaction_Id, '40', date_trunc('day', LOCALTIMESTAMP), ipdocno, ipdocdate,
     ipfromtermpaydate, ipisperson, ipminsumdebt, ipmaxsumdebt, ipkinddebtreg,
     ipfromtaxyaer, iptotaxyear, iptotermpaydate);
     
  i     := 1;
  vdsid := -1;
  begin
    open cr;
    loop
      fetch cr
        into r;
      IF NOT FOUND THEN EXIT; END IF; -- apply on cr
      if vdsid <> r.debtsubject_id
      then
        select nextval('s_action')
        into   vaction_id
        from   dual;
        insert into action
          (action_id, groupaction_id, taxdoc_id, taxsubject_id, kindaction,
           seqnom, docno, doc_date, action_date, exec_date, exec_user_date,
           exec_user_id)
        values
          (vaction_id, vgroupaction_id, null, r.taxsubject_id, '40', i, r.docno,
           r.doc_date, date_trunc('day', LOCALTIMESTAMP), date_trunc('day', LOCALTIMESTAMP), date_trunc('day', LOCALTIMESTAMP), ipuser_id);
           
         vdsid := r.debtsubject_id;
        i     := i + 1;
      end if;
      insert into actionitem
        (action_id, debtinstalment_id, instsum, interestsum)

      values
        (vaction_id, r.debtinstalment_id, r.instsum, r.interestsum);

    end loop;
    close cr;
  end;
  commit;
  opStat := 'OK';
  --close cr;
exception
  when others then
    rollback;
    opStat := 'errOrclDB' || dbms_utility.format_error_backtrace(); --'??????';

END;
$function$
; DROP FUNCTION public.bitand(bigint, bigint); 
CREATE OR REPLACE FUNCTION public.bitand(bigint, bigint)
 RETURNS bigint
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT $1 & $2; $function$
; DROP FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric, numeric); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric, numeric)
 RETURNS numeric
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, date, anyelement, date, date); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, date, anyelement, date, date)
 RETURNS date
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, time without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, time without time zone)
 RETURNS time without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.calcdiscount(numeric, numeric, date); 
CREATE OR REPLACE FUNCTION public.calcdiscount(iptaxsubject_id numeric, iptaxobject_id numeric, ippaydate date, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                                         
  cr cursor is
    select *
    from   debtsubject ds
    where  ds.taxsubject_id = ipTaxSubject_id
    -- and ds.taxobject_id =
    ;
  rdebt       record;
  vPaydate    date;
  vdoctype    numeric;
  vtermdisc   date;
  vpercent    numeric;
  vinstnumber numeric;
begin
  vPaydate := ipPayDate; --to_date(ipPayDate,'dd.mm.yyyy');
  open cr;
  loop
    fetch cr
      into rdebt;
    exit when not found;
    select d.termdisc, d.percent, ty.instnumber
    into   vtermdisc, vpercent, vinstnumber
    from   taxdoc td, discount d, taxperiod tp, documenttype ty
    where  td.taxdoc_id = rdebt.document_id
    and    d.documenttype_id = td.documenttype_id
    and    d.taxperiod_id = tp.taxperiod_id
    and    tp.taxperkind = '0'
    and    to_char(tp.begin_date, 'yyyy') =
           (select c.configvalue
             from   config c
             where  c.name = 'TAXYEAR'
             and    c.municipality_id = td.municipality_id)
    and    ty.documenttype_id = td.documenttype_id
    -- and td.municipality_id = ty.municipality_id
    ;
    if vPaydate <= vtermdisc
    then
      update baldebtinst
      set    discsum = round(vpercent * rdebt.totaltax / 100, 2)
      where  debtinstalment_id =
             (select di.debtinstalment_id
              from   debtinstalment di
              where  di.debtsubject_id = rdebt.debtsubject_id
              and    di.instno = vinstnumber);
    end if;
  end loop;
  close cr;
  
  opStat := 'OK';
exception
  when no_data_found then
    opStat := '��� ��������';
  when others then
    
    opStat := '������';
end;
$function$
; DROP FUNCTION public.center(character varying, numeric); 
CREATE OR REPLACE FUNCTION public.center(str character varying, len numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  res varchar(200);
begin
  res := rpadc(lpadc(' ', (len - length(trim(str))) / 2) || trim(str), len, ' ');
  return(res);
end;


$function$
; DROP FUNCTION public.center(character varying, integer); 
CREATE OR REPLACE FUNCTION public.center(str character varying, len integer)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  res varchar(200);
begin
  res := rpadc(lpadc(' ', (len - length(trim(str))) / 2) || trim(str), len, ' ');
  return(res);
end;


$function$
; DROP FUNCTION public.charspace(character varying, integer); 
CREATE OR REPLACE FUNCTION public.charspace(str character varying, space integer)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE

  res character varying(200);

BEGIN
  res := '';  
  for i in 1..length(str) loop
   if upper(substring(str,i,1)) in ('������������������������������ABCDEFGHIKLMNOPQRSTVXYZ') then
    res := res || substr(str,i , 1)|| case when space = 1 then ''
                                         when space = 2 then ' '
                                         when space = 3 then '  ' end;           
   else   
    res := res || substring(str,i , 1)|| case when space = 1 then ' '
                                         when space = 2 then '  '
                                         when space = 3 then '   ' end;      
   end if;                                      
  end loop;
  return(res);
END;
$function$
; DROP FUNCTION public.checkegn(character varying); 
CREATE OR REPLACE FUNCTION public.checkegn(idn character varying)
 RETURNS boolean
 LANGUAGE plpgsql
AS $function$
DECLARE
  tegla   numeric[];
  sm      numeric;
  control numeric;
begin
  sm    := 0;
  tegla := array[2, 4, 8, 5, 10, 9, 7, 3, 6];
  for i in 1 .. 9
  loop
    sm := sm + (to_number(substr(idn, i, 1)) * tegla[i]);
  end loop;
  begin
    control := substr(idn, 10, 1);
  exception
    when others then
      begin
        return(false);
      end;
  end;
  if control = mod(mod(sm, 11), 10)
  then
    return(true);
  end if;

  return(false);
end;


$function$
; DROP FUNCTION public.concat(text, text); 
CREATE OR REPLACE FUNCTION public.concat(text, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_concat$function$
; DROP FUNCTION public.concat(text, anyarray); 
CREATE OR REPLACE FUNCTION public.concat(text, anyarray)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$SELECT concat($1, $2::text)$function$
; DROP FUNCTION public.concat(anyarray, text); 
CREATE OR REPLACE FUNCTION public.concat(anyarray, text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$SELECT concat($1::text, $2)$function$
; DROP FUNCTION public.concat(anyarray, anyarray); 
CREATE OR REPLACE FUNCTION public.concat(anyarray, anyarray)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$SELECT concat($1::text, $2::text)$function$
; DROP FUNCTION public.concat(text, anynonarray); 
CREATE OR REPLACE FUNCTION public.concat(text, anynonarray)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$SELECT concat($1, $2::text)$function$
; DROP FUNCTION public.concat(anynonarray, text); 
CREATE OR REPLACE FUNCTION public.concat(anynonarray, text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$SELECT concat($1::text, $2)$function$
; DROP FUNCTION public.concat(anynonarray, anynonarray); 
CREATE OR REPLACE FUNCTION public.concat(anynonarray, anynonarray)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$SELECT concat($1::text, $2::text)$function$
; DROP FUNCTION public.correction(numeric, numeric, numeric, numeric, numeric, date, date, numeric, date, character varying, date, numeric, character varying, character varying, date, date, numeric, date, numeric, numeric, character varying, character varying); 
CREATE OR REPLACE FUNCTION public.correction(ipdebtsubject_id numeric, iptotalval numeric, iptotaltax numeric, ipfreesumsubj numeric, ipfreesumobj numeric, iptax_begindate_new date, iptax_enddate_new date, ipuser_id numeric, ipdoc_date_new date, ipdocno_new character varying, ipdatecorr date, ipinspector_id numeric, ipreason_corr character varying, ipprotocolnom character varying, ipprotdate date, iptermpay_date date, ipdebtsubject_new numeric, ipinterestbegdate date, iptaxsubject_id numeric, ipkinddebtreg_id numeric, ippartidano character varying, ipkindcorr character varying, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
   cr cursor is
    select di.debtinstalment_id, di.termpay_date,
           nvl(bi.interestsum, 0.0) interestsum, bi.instSum, ds.kinddebtreg_id,
           ds.debtsubject_id, ds.kindparreg_id
    from   debtsubject ds
    inner  join debtinstalment di
    on     ds.debtsubject_id = di.debtsubject_id
    left   outer join baldebtinst bi
    on     bi.debtinstalment_Id = di.debtinstalment_Id
    where  (ds.debtsubject_id = ipDebtsubject_Id or
           ds.parent_debtsubject_id = ipDebtsubject_Id)
    and    nvl(bi.instSum, 0.0) > 0.0 -- samo za neplateni otataci prispada po vnoski
    order  by di.termpay_date desc;

  --ind numeric;
  vdetsubject_ID_LastCorr numeric; -- �������� �������� ����� ����
  vTotalVal_Old           numeric;
  vtotaltax_Old           numeric;
  votstapka               numeric;
  vGlDalzima_Old          numeric;
  vKinddebtreg_Id         numeric;
  vtaxsubject_id          numeric;
  vpartidano              varchar(30);
  vmunicipality_Id        numeric;
  vdebtsubject_New        numeric;
  vdebtinstalment_Id      numeric;
  vdocument_Id            numeric;
  vkinddoc                numeric;
  vTaxperiod_Id           numeric;
  vdoccode                varchar(20);
  vtaxobject_id           numeric;
  vFreesumSubj_old        numeric;
  vFreeSumObj_old         numeric;
  Razlika                 numeric;
  Ost                     numeric;
  vOperation_Id           numeric;
  voversubject_Id         numeric;
  Voversum                numeric;
  vcorrno                 numeric;
  r                       record;
  vTAXYEAR                varchar(4);
  vKindparreg             numeric;
begin
  if nvl(iptotaltax, 0.0) < 0
  then
    opStat := 'errNewDuty'; --'���������� ���� ���� ����������!';
    return;
  end if;
  if ipdebtsubject_id is null
  then
    --ako e null, t.j. novo zadalzenie, vsicki tezi danni trjabva da sa vavedeni ot forma za korekciata
    if ipTaxsubject_Id is null or ipKinddebtreg_Id is null
      --or ipPartidano is null
       or iptax_begindate_new is null
    then
      opStat := 'errMissDuty'; --'������� ����� �� ������������!';
      return;
    end if;
    vTotalVal_Old   := 0;
    votstapka       := 0;
    vKinddebtreg_Id := ipKinddebtreg_Id;
    vtaxsubject_id  := ipTaxsubject_Id;
    vpartidano      := ipPartidano;
    vtotaltax_Old   := 0;
    vGlDalzima_Old  := 0;

    select u.municipality_id
    into   vmunicipality_id
    from   users u
    where  u.user_id = ipuser_id;

    select t.taxperiod_id
    into   vtaxperiod_id
    from   taxperiod t
    where  t.taxperkind = '0'
    and    To_Char(t.begin_date, 'yyyy') = To_char(iptax_begindate_new, 'yyyy');
    --end if;
  else
    select max(dss.debtsubject_id), nvl(max(dss.corrno), 0.0)
    into   vdetsubject_ID_LastCorr, vcorrno
    from   debtsubject dss
    where  nvl(dss.corrno, 0.0) =
           (select nvl(max(ds.corrno), 0.0)
            from   debtsubject ds
            where  ds.parent_debtsubject_id = ipdebtsubject_Id)
    and    dss.parent_debtsubject_id = ipdebtsubject_Id;
  
    if vdetsubject_ID_LastCorr is null
    then
      vdetsubject_ID_LastCorr := ipdebtsubject_id;
    end if;
  
    select c.configvalue
    into   vTAXYEAR
    from   config c
    where  upper(c.name) = 'TAXYEAR';
  
  
    -- opredelenie na sumi - staro
    select sum(nvl(ds.totalval, 0.0)), sum(nvl(ds.paydiscsum, 0.0)),
           max(ds.kinddebtreg_id), max(ds.taxsubject_id), max(ds.partidano),
           max(ds.municipality_id), sum(nvl(ds.totaltax, 0.0)),
           max(ds.document_id), max(ds.kinddoc), max(ds.taxperiod_id),
           max(ds.doccode), max(ds.taxobject_id), sum(ds.freesum_subj),
           sum(ds.freesum_obj)
    into   vTotalVal_Old, votstapka, vKinddebtreg_Id, vtaxsubject_id, vpartidano,
           vmunicipality_id, vtotaltax_Old, vdocument_Id, vkinddoc,
           vtaxperiod_id, vdoccode, vtaxobject_id, vfreesumsubj_Old,
           vfreesumobj_Old
    from   debtsubject ds
    where  ds.debtsubject_id in
           (select dsb.debtsubject_id
            from   debtsubject dsb
            where  dsb.debtsubject_id = ipDebtsubject_Id
            or     dsb.parent_debtsubject_id = ipDebtsubject_Id) --ipdebtsubject_Id
    ;
    select sum(nvl(bdi.instsum, 0.0))
    into   vGlDalzima_Old
    from   baldebtinst bdi, debtinstalment di
    where  bdi.debtinstalment_id = di.debtinstalment_id
    and    di.debtsubject_id in
           (select dsb.debtsubject_id
             from   debtsubject dsb
             where  dsb.debtsubject_id = ipDebtsubject_Id
             or     dsb.parent_debtsubject_id = ipDebtsubject_Id)
    
    
    ;
  end if;

  Razlika := ipTotalTax - vTotaltax_Old;
  -- ako razlika <0 => votstapka := 0;   ?????
  voversum    := null;
  vKindparreg := 3;
  if To_Char(iptax_begindate_new, 'yyyy') = vTAXYEAR
  then
    vKindparreg := 2;
  end if;
  if ipdebtsubject_New is null
  then
    select nextval('s_debtsubject')
    into   vdebtsubject_New
    from   dual;
    if vdetsubject_ID_LastCorr is null
    then
      vdetsubject_ID_LastCorr := vdebtsubject_New;
    end if;
  
  
  
    insert into debtsubject
      (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,
       taxperiod_id, doccode, TAX_BEGIDATE, tax_enddate, relief_id, totalval,
       totaltax, calcdate, freesum_subj, prtdate, inst_number, freesum_obj,
       corr_instnumber, codetbo, userdate, user_id, taxobject_id, partidano,
       municipality_id, kindparreg_id, doc_date, docno, paydiscsum,
       PARENT_DEBTSUBJECT_ID, corrno, typecorr)
    values
      (vdebtsubject_New, vtaxsubject_id, vdocument_id, vkinddoc,
       vkinddebtreg_id, vtaxperiod_id, vdoccode, iptax_begindate_new,
       iptax_enddate_new, null, (nvl(ipTotalval, 0.0) - nvl(vTotalval_Old, 0.0)),
       (nvl(ipTotaltax, 0.0) - nvl(vTotalTax_Old, 0.0)), ipDateCorr,
       nvl(ipFreesumSubj, 0.0) - nvl(vfreesumsubj_Old, 0.0), null, 1,
       nvl(ipFreesumobj, 0.0) - nvl(vfreesumobj_Old, 0.0), null, null, current_date,
       ipuser_Id, vtaxobject_id, vpartidano, vmunicipality_id, vKindparreg,
       ipdoc_date_new, ipdocno_new, (0.0 - nvl(votstapka, 0.0)), ipdebtsubject_id,
       vcorrno + 1, ipKindCorr);
  else
    vdebtsubject_New := ipdebtsubject_New;
    update debtsubject 
    set    TAX_BEGIDATE = iptax_begindate_new,
           tax_enddate = iptax_enddate_new, inst_number = 1,
           totaltax = nvl(ipTotaltax, 0.0) - nvl(vTotaltax_Old, 0.0),
           totalval = nvl(ipTotalval, 0.0) - nvl(vTotalval_Old, 0.0),
           doc_date = ipdoc_date_new, docno = ipdocno_new,
           paydiscsum =
            (0.0 - nvl(votstapka, 0.0)),
           parent_debtsubject_id = ipDebtsubject_Id,
           freesum_subj = nvl(ipFreesumsubj, 0.0) - nvl(vfreesumsubj_Old, 0.0),
           freesum_obj = nvl(ipFreesumobj, 0.0) - nvl(vfreesumobj_Old, 0.0),
           corrno = vcorrno + 1, typecorr = ipKindCorr,
           kindparreg_id = vKindparreg
    where  debtsubject_id = ipdebtsubject_New;
  end if;

  select nextval('s_debtinstalment')
  into   vdebtinstalment_Id
  from   dual;
  insert into debtinstalment
    (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
     intbegindate)
  values
    (vdebtinstalment_Id, vdebtsubject_New, 1, iptermpay_date,
     (nvl(ipTotaltax, 0.0) - nvl(vTotaltax_Old, 0.0)), ipInterestBegdate);
  if razlika <> 0
  then
    select nextval('s_operation')
    into   vOperation_Id
    from   dual;
  
    insert into operation
      (operation_id, oper_date, operdocno, opercode, opersum, user_date,
       user_id, user_name, baloversum, resolution_id, paytransaction_id,
       oversubject_id, municipality_id)
    values
      (voperation_id, ipDateCorr, voperation_id, '15', Razlika, trunc(current_date),
       ipuser_Id,
       (select u.fullname
         from   users u
         where  u.user_id = ipuser_Id), null, null, null, null, vmunicipality_Id);
  end if;
  if (Razlika > 0)
  then
    insert into operdebt
      (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
       operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
       balinstsum)
    values
      (nextval('s_operdebt'), vOperation_Id, vkinddebtreg_Id, vdebtinstalment_Id,
       (nvl(ipTotaltax, 0.0) - nvl(vTotaltax_Old, 0.0)), null, null, vKindparreg,
       null, null);
    insert into baldebtinst
      (debtinstalment_id, instsum, interestsum)
    values
      (vdebtinstalment_Id, (nvl(ipTotaltax, 0.0) - nvl(vTotaltax_Old, 0.0)), 0.0);
  end if;


  if (Razlika < 0)
  then
    Ost := -Razlika;
  
    open cr;
    loop
      fetch cr
        into r;
      exit when not FOUND;
    
      ost := ost - r.instsum;
      if ost >= 0
      then
        insert into operdebt
          (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
           operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
           balinstsum)
        values
          (nextval('s_operdebt'), vOperation_Id, r.kinddebtreg_Id,
           r.debtinstalment_Id, -r.instsum, null, null, r.kindparreg_Id, null,
           null);
        update baldebtinst
        set    instsum = 0
        where  debtinstalment_id = r.debtinstalment_Id;
      end if;
    
      if ost < 0
      then
        --prispada samo razlika
        insert into operdebt
          (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
           operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
           balinstsum)
        values
          (nextval(s_operdebt), vOperation_Id, r.kinddebtreg_Id,
           r.debtinstalment_Id, - (r.instsum + ost), null, null, r.kindparreg_Id,
           null, null);
        update baldebtinst
        set    instsum = -ost
        where  debtinstalment_id = r.debtinstalment_Id;
        exit; -- i izliza ot cikala
      end if;
    
    end loop;
    close cr;
    ost := ost - nvl(votstapka, 0.0);
    if ost < 0
    then
      ost := 0;
    end if;
    if ost > 0
    then
      -- prehvarlia na nadvnesena suma
      Voversum := ost;
      select nextval('s_oversubject')
      into   voversubject_Id
      from   dual;
    
      insert into oversubject
        (oversubject_id, kinddebtreg_id, taxsubject_id, overpaysum,
         overinterestsum, overcorsum, partidano, municipality_id, debtsubject_id)
      values
        (voversubject_Id, vkinddebtreg_id, vtaxsubject_id, null, null, Voversum,
         vpartidano, vmunicipality_Id, vdebtsubject_New);
      insert into baloverinst
        (oversubject_id, oversum)
      values
        (voversubject_Id, Voversum);
    end if;
    -- nakraja zapis na gornoto nivo v operation
    update operation
    set    oversubject_id = voversubject_Id, baloversum = Voversum
    where  operation_id = vOperation_Id;
  end if;
  --------
  insert into debtsubjectcorr
    (debtsubjectcorr_id, debtsubject_id, corr_date, totalval_old, totalval_new,
     totaltax_old, totaltax_new, paydiscsum_old, paydiscsum_new, user_date,
     user_id, user_name, protocolno, protocol_date, reason_corr,
     inspector_user_id, Parent_debtsubject_id, freesumobj_old, freesumobj_new,
     freesumsubj_old, freesumsubj_new, KindCorr, oversum, operation_Id)
    select nextval('s_Debtsubjectcorr'), vdebtsubject_New, ipDateCorr,
           vTotalVal_Old, ipTotalval, vtotaltax_old, iptotaltax, votstapka, 0,
           Trunc(current_date), ipuser_Id,
           (select u.fullname
             from   users u
             where  u.user_id = ipuser_Id), ipProtocolNom, ipProtDate,
           ipreason_corr, ipinspector_Id, ipDebtsubject_Id, vfreesumobj_old,
           ipfreesumobj, vfreesumsubj_old, ipfreesumsubj, ipKindCorr,
           decode(sign(ost), 1.0, ost, 0.0), vOperation_Id
    
    from   debtsubject ds
    where  ds.debtsubject_id = vdetsubject_ID_LastCorr;

  --commit;
  opStat := 'OK';
exception
  when others then
    --rollback;
    opStat := 'errOrclDB'; --'������';
end;
$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone)
 RETURNS timestamp without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone)
 RETURNS timestamp with time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, text, anyelement, text, anyelement, text); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, text, anyelement, text, anyelement, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, character, anyelement, character, anyelement, character); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, character, anyelement, character, anyelement, character)
 RETURNS character
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.cosh(double precision); 
CREATE OR REPLACE FUNCTION public.cosh(double precision)
 RETURNS double precision
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT (exp($1) + exp(-$1)) / 2; $function$
; DROP FUNCTION public.debtsum(numeric, numeric); 
CREATE OR REPLACE FUNCTION public.debtsum(iptaxdoc_id numeric, iptaxsubject_id numeric, OUT opdni numeric, OUT optbo numeric, OUT opdisc numeric, OUT opstat character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
begin
  select sum(dni), sum(tbo), sum(disc)
  into   opDNI, opTBO, opDisc
  from   (select ds.kinddebtreg_id, (decode(r.code, '2400', 0, bd.instsum)) dni,
                  (decode(r.code, '2400', bd.instsum, 0)) tbo,
                  (sanction_pkg.tempdiscount(di.debtinstalment_id, trunc(current_date))) disc
           from   baldebtinst bd, debtinstalment di, debtsubject ds, kinddebtreg r
           where  bd.debtinstalment_id = di.debtinstalment_id
           and    di.debtsubject_id = ds.debtsubject_id
           and    ds.document_id = iptaxdoc_id
           and    ds.kinddebtreg_id = r.kinddebtreg_id
           and    ds.taxsubject_id =
                  decode(iptaxsubject_id, null, ds.taxsubject_id, iptaxsubject_id)) as t;
  opstat := 'OK';
exception
  when no_data_found then
    opDNI  := 0;
    opTBO  := 0;
    opDisc := 0;
    opstat := '������� �����';
  when others then
    opDNI  := 0;
    opTBO  := 0;
    opDisc := 0;
    opstat := '������';
end;
$function$
; DROP FUNCTION public.debug(character varying); 
CREATE OR REPLACE FUNCTION public.debug(msg character varying)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
begin

insert into debugtable values (msg);
return;
end;
$function$
; DROP FUNCTION public.debugnote(character varying); 
CREATE OR REPLACE FUNCTION public.debugnote(msg character varying)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
begin
raise notice using message = msg;
return ;
end;
$function$
; DROP FUNCTION public.decode(anyelement, anyelement, text); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, character); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, character)
 RETURNS character
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, integer); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, integer)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, bigint); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, bigint)
 RETURNS bigint
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, numeric); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, numeric)
 RETURNS numeric
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, date); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, date)
 RETURNS date
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, time without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, time without time zone)
 RETURNS time without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp without time zone)
 RETURNS timestamp without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp with time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp with time zone)
 RETURNS timestamp with time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, text, text); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, text, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, character, character); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, character, character)
 RETURNS character
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, integer, integer); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, integer, integer)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, bigint, bigint); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, bigint, bigint)
 RETURNS bigint
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, numeric, numeric); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, numeric, numeric)
 RETURNS numeric
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, date, date); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, date, date)
 RETURNS date
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, time without time zone, time without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, time without time zone, time without time zone)
 RETURNS time without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, timestamp without time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, timestamp without time zone)
 RETURNS timestamp without time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, timestamp with time zone); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, timestamp with time zone)
 RETURNS timestamp with time zone
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, text, anyelement, text); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, text, anyelement, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, character, anyelement, character); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, character, anyelement, character)
 RETURNS character
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint)
 RETURNS bigint
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric)
 RETURNS numeric
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.decode(anyelement, anyelement, date, anyelement, date); 
CREATE OR REPLACE FUNCTION public.decode(anyelement, anyelement, date, anyelement, date)
 RETURNS date
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_decode$function$
; DROP FUNCTION public.getpartidano(numeric, numeric); 
CREATE OR REPLACE FUNCTION public.getpartidano(ipmun_id numeric, ipdoctype_id numeric, OUT opdocnumber character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                                         
  vdoccode varchar(20);
begin
  if ipdoctype_id = 9
  then
    select c.configvalue
    into   opdocnumber
    from   config c
    where  c.municipality_id = ipmun_id
    and    c.name = 'BEZOBLNO';
    opdocnumber := (opdocnumber::numeric + 1)::varchar;

    update config
    set    configvalue = opdocnumber
    where  municipality_id = ipmun_id
    and    name = 'BEZOBLNO';
    --commit;
  
  
    select m.ebk_code || 'B' || opdocnumber
    into   opdocnumber
    from   municipality m
    where  m.municipality_id = ipmun_id;
  
  else
  
    select d.doccode
    into   vdoccode
    from   documenttype d
    where  d.documenttype_id = ipdoctype_id;
    if substr(vdoccode, 1, 2) = '54'
    then
      vdoccode := substr(vdoccode, 1, 2);
    end if;
  
    select c.configvalue
    into   opdocnumber
    from   config c
    where  c.municipality_id = ipmun_id
    and    c.name = 'PARTIDANO' --|| vdoccode
    ;

    opdocnumber := (opdocnumber::numeric + 1)::varchar;

    update config
    set    configvalue = opdocnumber
    where  municipality_id = ipmun_id
    and    name = 'PARTIDANO' --|| vdoccode
    ;
    --commit;
    select m.ebk_code ||
            case vdoccode 
             when '14' then 'H'
              when '17' then 'F'
               when '54' then 'T'
                when '61' then 'P'
                 when '117'then 'D'
                  when '32' then 'N'
                   when '49' then 'G'
                    when '61R' then 'R'
             else ' '
            end
            || opdocnumber
    into   opdocnumber
    from   municipality m
    where  m.municipality_id = ipmun_id
    
    ;
  end if;
  --opstat := 'OK';

exception
  when others then
   -- rollback;
   --  opstat := 'OK';
    opdocnumber := '-1';

end;

$function$
; DROP FUNCTION public.getpaydocumentidarray(numeric, numeric, date, numeric, character varying, character varying, numeric); 
CREATE OR REPLACE FUNCTION public.getpaydocumentidarray(voper_id numeric, vuser numeric, vdatastorprih date, vobstina numeric, vuser_name character varying, vosn character varying, voversubject numeric, OUT res character varying, OUT pdocarray character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                                                  
  vpaytr       numeric;
  vsumstortr   numeric;
  vtransaction numeric;
  vbaccount_id numeric;
  vbanksmetka  varchar(50);
  vbic         varchar(50);
  vrgn         numeric;
  bidi         numeric;
  vregDocno    varchar(50);
  vseries      varchar(50);
  vcount       numeric;
   cr cursor (mypaytr numeric) is
    select *
    from   paydocument pd
    where  pd.paytransaction_id = mypaytr;

   crd cursor (myvoper_id numeric) is
    select *
    from   operdebt od
    where  od.operation_Id = myvoper_id;

begin
  begin
    select op.paytransaction_id, ptr.trsuma
    into   vpaytr, vsumstortr
    from   operation op, paytransaction ptr
    where  op.operation_Id = voper_id
    and    op.paytransaction_Id = ptr.paytransaction_Id;
  exception
    when others then
      begin
        res := 'err';
        return;
      end;
  end;

  select nextval('s_paytransaction')
  into   vtransaction
  from   dual;

  insert into paytransaction 
    (paytransaction_id, transactionno, trdate, trsuma, trtype, user_date,
     user_id, municipality_ID)
  values
    (vtransaction, nextval('s_paytransaction'), vdatastorPrih, vsumstortr, '3',
     current_date, vuser, vobstina);

  select b.baccount_id, b.iban, bk.bic
  into   vbaccount_id, vbanksmetka, vbic
  from   baccount b, bank bk
  where  b.municipality_id = vobstina
  and    b.isbase = 1
  and    b.isactive = 1
  and    b.bank_id = bk.bank_id;
  vcount    := 1;
  pdocArray := null;--'';
  for cr_r in cr(vpaytr)
  loop
  
    select getdocnumber(vobstina, '630', '1')
    into vregDocno, vseries;
  
    insert into PayDocument
      (paydocument_id, baccount_id, taxsubject_id, kindpaydoc, regdocno,
       documentno, series, documentdate, paydate, payTime, docsum, user_date,
       user_id, user_name, reason1, reason2, note, tsaccount, docpay,
       docfromdate, doctodate, paytransaction_id, partidano, taxobject_id,
       overPaySum, OverSubject_Id, over_kinddebtreg_id, From_kinddebtreg_id,
       tsbic, rcbic, rcaccount)
    values
      (nextval('s_paydocument'), vbaccount_id, cr_r.taxsubject_id, cr_r.kindpaydoc,
       null, vregDocno, vseries, trunc(current_date), vdatastorPrih, current_date,
       cr_r.docsum, current_date, vuser, vuser_name, '?????? ??????????e', vosn,
       cr_r.note, vbanksmetka, cr_r.docpay, cr_r.docfromdate, cr_r.doctodate,
       vtransaction, cr_r.partidano, cr_r.taxobject_id, cr_r.overPaySum,
       cr_r.OverSubject_Id, cr_r.From_kinddebtreg_id, cr_r.over_kinddebtreg_id,
       vbic, vbic, vbanksmetka);
    if (pdocArray is null)
    then
      pdocArray := cr_r.paydocument_id;
    else
      pdocArray := pdocArray || ';' || cr_r.paydocument_id;
      vcount    := vcount + 1;
    end if;
  end loop;

  update operation
  set    null_Date = vDatastorPrih, null_userDate = current_date,
         null_User_Id = vuser, null_user_name = vuser_name,
         null_PayTransaction_Id = vtransaction, null_reason = vosn
  where  operation_Id = voper_id;

  for cr_rd in crd(voper_id)
  loop
  
    select max(bi.debtinstalment_Id)
    into   bidi
    from   baldebtinst bi
    where  bi.debtinstalment_Id = cr_rd.debtinstalment_Id;
    if bidi is null
    then
      insert into baldebtinst
        (debtinstalment_Id, InstSum, interestSum)
      values
        (cr_rd.debtinstalment_Id, cr_rd.operoversum, cr_rd.operintsum);
    else
      update baldebtinst
      set    instsum =
              (nvl(instsum, 0.0) + nvl(cr_rd.operoversum, 0.0) +
              nvl(cr_rd.discsum, 0.0)),
             interestSum =
              (nvl(interestSum, 0.0) + nvl(cr_rd.operintsum, 0.0))
      where  debtinstalment_Id = cr_rd.debtinstalment_Id;
    end if;
    if nvl(cr_rd.discsum, 0.0) > 0
    then
      update debtsubject
      set    paydiscsum = null
      where  debtsubject_id =
             (select di.debtsubject_id
              from   debtinstalment di
              where  di.debtinstalment_id = cr_rd.debtinstalment_Id);
    end if;
  
  end loop;

  select max(bis.oversubject_Id)
  into   bidi
  from   baloverinst bis
  where  bis.oversubject_id = voversubject;

  if bidi is null
  then
    insert into baloverinst
      (oversubject_Id, oversum)
    values
      (voversubject, vsumstortr);
  else
    update baloverinst
    set    overSum = nvl(oversum, 0.0) + vsumstortr
    where  oversubject_Id = voversubject;
  end if;
  res := 'OK';
exception
  when others then
    begin
      res := 'err'||sqlerrm;
    end;
end;
$function$
; DROP FUNCTION public.getstringval(anyarray); 
CREATE OR REPLACE FUNCTION public.getstringval(arr anyarray)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
begin
return array_to_string(arr,'');
end;
$function$
; DROP FUNCTION public.getsubjno(); 
CREATE OR REPLACE FUNCTION public.getsubjno()
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  vdoccode    varchar(20);
  opsubjumber varchar(20);
begin

  select c.configvalue
  into   opsubjumber
  from   config c
  where  upper(c.name) = 'TAXSUBJNO';

 update config
  set    configvalue = trim(to_char(to_number(opsubjumber,'99999999999999999999') + 1,'99999999999999999999'),' ')
  where  upper(name) = 'TAXSUBJNO';
  --commit;
  return(opsubjumber);
exception
  when others then
    --rollback;
    return('-1');
end;

$function$
; DROP FUNCTION public.gettaxval(numeric, date); 
CREATE OR REPLACE FUNCTION public.gettaxval(ipfirm1417_obj_id numeric, ipyear date)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
DECLARE
  result varchar(200);

  vgroupe1 numeric;
  opmess1  varchar(2000);

  kindobj1      numeric;
  obj_id1       firm_1417_obj.firm1417_obj_id%type;
  kindfunction1 building.kindfunction%type;
  rec record;

begin
  select f.kindobj, f.obj_id, b.kindfunction
  into   kindobj1, obj_id1, kindfunction1
  from   firm_1417_obj f
  left   outer join building b
  on     b.building_id = f.building_id
  where  f.firm1417_obj_id = ipfirm1417_obj_id;


  if (kindobj1 = 1)
  then
    select into rec * from taxvaluation.taxvalland(obj_id1, ipyear);
    result := rec.return_val;
  else
    select into rec * from taxvaluation.taxvalhome(obj_id1, ipyear, kindfunction1);
    result := rec.return_val;    

  end if;


  if result <> 'OK'
  then
    return null;
  end if;

  return rec.vgroupe;
end;

$function$
; DROP FUNCTION public.gettaxval14(numeric, numeric, character varying, date); 
CREATE OR REPLACE FUNCTION public.gettaxval14(ipkindobj numeric, ipobjid numeric, ipkindfunction character varying, ipyear date)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
DECLARE
  result varchar(200);

  opmess1  varchar(2000);
  rec record;

begin
  if (ipKindObj = 1)
  then
    select into rec * from taxvaluation.taxvalland(ipObjId, ipyear);
    result := rec.return_val;    
  else
    if (ipKindObj = 2)
    then
    select into rec * from taxvaluation.taxvalhome(ipObjId, ipyear, ipKindFunction::varchar);
    result := rec.return_val;    
    else
      result := 'Bad kind object!';
    end if;
  end if;

  if result <> 'OK'
  then
    return null;
  end if;

  return rec.vgroupe;
exception
  when others then
    return null; --'������';
end;
$function$
; DROP FUNCTION public.getworkingday(date, numeric); 
CREATE OR REPLACE FUNCTION public.getworkingday(ipinputdate date, ipinputdayscount numeric)
 RETURNS date
 LANGUAGE plpgsql
AS $function$
DECLARE
  result       date;
  firstFreeDay date;
  inputDate    date;

begin

  if (ipInputDate is null)
  then
    inputDate := to_date(to_char(current_date, 'dd.mm.yyyy'), 'dd.mm.yyyy') +
                 ipInputDaysCount::integer;
  else
    inputDate := ipInputDate;
  end if;

  select min(c.freedate::date) + integer '1'
  into   firstFreeDay
  from   calendar c
  where  c.freedate::date + integer '1' not in (select cl.freedate::date
                                from   calendar cl)
  and    c.freedate::date >= inputDate;

  select case count(c.freedate)
		when 0 then inputDate
			else firstFreeDay
	 end
  into   result
  from   calendar c
  where  c.freedate = inputDate;

  return(result);
end;

$function$
; DROP FUNCTION public.getperioddays(character varying, character varying, date); 
CREATE OR REPLACE FUNCTION public.getperioddays(ifrom character varying, ito character varying, icorrdate date)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
DECLARE
   period cursor (vfrom varchar, vto varchar) is
    select *
    from   interestpct ip
    where  ip.begin_date between to_date(vFrom, 'dd.mm.yyyy') and
           to_date(vto, 'dd.mm.yyyy')
    order  by ip.begin_date;
  res        numeric;
  i          numeric;
  pfrom      date;
  pto        date;
  period_rec interestpct%rowtype;
begin
  res   := 1;
  i     := 0;
  pfrom := to_date(iFrom, 'dd.mm.yyyy');
  pto   := to_date(iTo, 'dd.mm.yyyy');
  --   for r in period(iFrom, ito) loop
  -- if not period%isopen
  -- then
    open period(iFrom, ito);
  -- end if;
  loop
    fetch period
      into period_rec;
    exit when not FOUND;
   /* if not FOUND
    then
      res := pto - period_rec.begin_date;
      exit;
    end if;
*/
  
    i := 1;--period.rowcount;
    if (period_rec.begin_date > icorrDate) and (icorrDate >= pfrom)
    then
      res := case extract('day' from period_rec.begin_date - icorrDate)::numeric
               when 0 then
                1
               else
                extract('day' from period_rec.begin_date - icorrDate)::numeric
             end;
      exit;
    elsif (period_rec.begin_date > icorrDate) and (icorrDate <= pfrom)
    then
      res := case extract('day' from period_rec.begin_date - pfrom)::numeric
               when 0 then
                1
               else
                extract('day' from period_rec.begin_date - pfrom)::numeric
             end;
      exit;
      --     elsif (period_rec.begin_date = icorrDate) and (icorrDate < pto) and (not FOUND) then
      --       res := pto - period_rec.begin_date;
      --       exit;
    end if;
  end loop;
 
  if (i = 0) and (pto > icorrDate)
	then
	 res := extract('day' from pto - pfrom)::numeric;
  elseif i = 0 
	then 
	 res := extract('day' from pto - period_rec.begin_date)::numeric;
  end if;
  close period;
  return(res);

end;
$function$
; DROP FUNCTION public.inscontainers(character varying); 
CREATE OR REPLACE FUNCTION public.inscontainers(ipyear character varying, OUT opcount integer)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
declare
  cr cursor is
    select c.*
    from   containernorm c, taxperiod tp
    where  c.taxperiod_id = tp.taxperiod_id
    and    tp.taxperkind = '0'
    and    tp.begin_date =
           (select max(p.begin_date)
             from   containernorm cn, taxperiod p
             where  p.taxperkind = '0'
             and    cn.taxperiod_id = p.taxperiod_id
             and    p.begin_date < to_date('01.01.' || ipyear, 'dd.mm.yyyy'));
  r                 record;
  vtaxper_id        numeric;
  vcontainernorm_id numeric;
begin
  select max(p.taxperiod_id)
  into   vtaxper_id
  from   taxperiod p
  where  p.taxperkind = '0'
  and    p.begin_date = to_date('01.01.' || ipyear, 'dd.mm.yyyy');
  opcount := 0;
  if vtaxper_id is null
  then
    return;
  end if;
  select count(*)
  into   opcount
  from   containernorm c
  where  c.taxperiod_id = vtaxper_id;
  if opcount > 0
  then
    opcount := 0;
    return;
  end if;
  opcount := 0;
  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
    select nextval('s_containernorm')
    into   vcontainernorm_id
    from   dual;
    insert into containernorm
      (containernorm_id, taxperiod_id, city_id, container_id, value,
       admregion_id, kindvalue)
    values
      (vcontainernorm_id, vtaxper_id, r.city_id, r.container_id, r.value,
       r.admregion_id, r.kindvalue);
    opcount := opcount + 1;
  end loop;
  --commit;
end;

$function$
; DROP FUNCTION public.inscontainers(numeric); 
CREATE OR REPLACE FUNCTION public.inscontainers(iptaxperiod_id numeric, OUT opcount integer)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
declare                                          
  vtaxper_id numeric;
   cr cursor is
    select c.*
      from containernorm c, taxperiod tp
     where c.taxperiod_id = tp.taxperiod_id
       and tp.taxperkind = '0'
       and tp.begin_date =
           (select max(p.begin_date)
              from containernorm cn, taxperiod p
             where p.taxperkind = '0'
               and cn.taxperiod_id = p.taxperiod_id
               and p.begin_date <
                   to_date('01.01.' ||
                           (select to_char(tp.begin_date, 'yyyy')
                              from taxperiod tp
                             where tp.taxperiod_id = ipTaxperiod_id),
                           'dd.mm.yyyy'));
  r record;

begin
  delete from containernorm where taxperiod_id = ipTaxperiod_id;
  select max(p.taxperiod_id)
    into vtaxper_id
    from taxperiod p
   where p.taxperkind = '0'
     and p.begin_date = to_date('01.01.' ||
                                (select to_char(tp.begin_date, 'yyyy')
                                   from taxperiod tp
                                  where tp.taxperiod_id = ipTaxperiod_id),
                                'dd.mm.yyyy');
  opcount := 0;
  if vtaxper_id is null then
    return;
  end if;
  select count(*)
    into opcount
    from containernorm c
   where c.taxperiod_id = vtaxper_id;
  if opcount > 0 then
    opcount := 0;
    return;
  end if;
  opcount := 0;
  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
    insert into containernorm
      (containernorm_id,
       taxperiod_id,
       city_id,
       container_id,
       value,
       admregion_id,
       kindvalue)
    values
      (nextval('s_containernorm'),
       vtaxper_id,
       r.city_id,
       r.container_id,
       r.value,
       r.admregion_id,
       r.kindvalue);
    opcount := opcount + 1;
  end loop;
  close cr;
  --commit;
end;

$function$
; DROP FUNCTION public.inspromtbo(character varying); 
CREATE OR REPLACE FUNCTION public.inspromtbo(ipyear character varying, OUT opcount integer)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
declare
  cr cursor is
    select t.*
    from   promtbo t, taxperiod tp
    where  t.taxperiod_id = tp.taxperiod_id
    and    tp.taxperkind = '0'
    and    tp.begin_date =
           (select max(p.begin_date)
             from   promtbo pt, taxperiod p
             where  p.taxperkind = '0'
             and    pt.taxperiod_id = p.taxperiod_id
             and    p.begin_date < to_date('01.01.' || ipyear, 'dd.mm.yyyy'));
  r           record;
  vtaxper_id  numeric;
  vpromtbo_id numeric;
begin
  select max(p.taxperiod_id)
  into   vtaxper_id
  from   taxperiod p
  where  p.taxperkind = '0'
  and    p.begin_date = to_date('01.01.' || ipyear, 'dd.mm.yyyy');
  opcount := 0;
  if vtaxper_id is null
  then
    return;
  end if;
  select count(*)
  into   opcount
  from   promtbo t
  where  t.taxperiod_id = vtaxper_id;
  if opcount > 0
  then
    opcount := 0;
    return;
  end if;
  opcount := 0;
  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
    select nextval('s_promtbo')
    into   vpromtbo_id
    from   dual;
    insert into promtbo
      (city_id, taxperiod_id, istbotax, sw_home, clean_home, depot_home, sw,
       clean, depot, tbo_code, pctfree_telk, calctype, code, fsw_home,
       fclean_home, fdepot_home, fsw, fclean, fdepot, municipality_id,
       promtbo_id, fromvalue, minvalue)
    values
      (r.city_id, vtaxper_id, r.istbotax, r.sw_home, r.clean_home, r.depot_home,
       r.sw, r.clean, r.depot, r.tbo_code, r.pctfree_telk, r.calctype, r.code,
       r.fsw_home, r.fclean_home, r.fdepot_home, r.fsw, r.fclean, r.fdepot,
       r.municipality_id, vpromtbo_id, r.fromvalue, r.minvalue);
    opcount := opcount + 1;
  end loop;
  --commit;
end ;

$function$
; DROP FUNCTION public.inspromtbo(numeric); 
CREATE OR REPLACE FUNCTION public.inspromtbo(iptaxperiod_id numeric, OUT opcount integer)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
declare                                       
  vtaxper_id numeric;
   cr cursor is
    select t.*
      from promtbo t, taxperiod tp
     where t.taxperiod_id = tp.taxperiod_id
       and tp.taxperkind = '0'
       and tp.begin_date =
           (select max(p.begin_date)
              from promtbo pt, taxperiod p
             where p.taxperkind = '0'
               and pt.taxperiod_id = p.taxperiod_id
               and p.begin_date <
                   to_date('01.01.' ||
                           (select to_char(tp.begin_date, 'yyyy')
                              from taxperiod tp
                             where tp.taxperiod_id = ipTaxperiod_id),
                           'dd.mm.yyyy'));
  r record;

begin
  delete from promtbo where taxperiod_id = ipTaxperiod_id;
  
  select max(p.taxperiod_id)
    into vtaxper_id
    from taxperiod p
   where p.taxperkind = '0'
     and p.begin_date = to_date('01.01.' ||
                                (select to_char(tp.begin_date, 'yyyy')
                                   from taxperiod tp
                                  where tp.taxperiod_id = ipTaxperiod_id),
                                'dd.mm.yyyy');
  opcount := 0;
  if vtaxper_id is null then
    return;
  end if;
  select count(*)
    into opcount
    from promtbo t
   where t.taxperiod_id = vtaxper_id;
  if opcount > 0 then
    opcount := 0;
    return;
  end if;
  opcount := 0;
  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
    insert into promtbo
      (city_id,
       taxperiod_id,
       istbotax,
       sw_home,
       clean_home,
       depot_home,
       sw,
       clean,
       depot,
       tbo_code,
       pctfree_telk,
       calctype,
       code,
       fsw_home,
       fclean_home,
       fdepot_home,
       fsw,
       fclean,
       fdepot,
       municipality_id,
       promtbo_id,
       fromvalue,
       minvalue)
    values
      (r.city_id,
       vtaxper_id,
       r.istbotax,
       r.sw_home,
       r.clean_home,
       r.depot_home,
       r.sw,
       r.clean,
       r.depot,
       r.tbo_code,
       r.pctfree_telk,
       r.calctype,
       r.code,
       r.fsw_home,
       r.fclean_home,
       r.fdepot_home,
       r.fsw,
       r.fclean,
       r.fdepot,
       r.municipality_id,
       nextval('s_promtbo'),
       r.fromvalue,
       r.minvalue);
    opcount := opcount + 1;
  end loop;
  close cr;
  --commit;
end;

$function$
; DROP FUNCTION public.inssaldo(); 
CREATE OR REPLACE FUNCTION public.inssaldo()
 RETURNS void
 LANGUAGE plpgsql
AS $function$
begin
  insert into saldoduty
    (saldoduty_id, debtinstalment_id, saldoinst, saldointerest, saldodate,
     kindparreg_id)
    select nextval('s_saldoduty'), i.debtinstalment_id, b.instsum, b.interestsum,
           trunc(current_date) - 1, ds.kindparreg_id
    from   baldebtinst b, debtinstalment i, debtsubject ds
    where  ds.debtsubject_id = i.debtsubject_id
    and    b.debtinstalment_id = i.debtinstalment_id;
  --commit;

end;

$function$
; DROP FUNCTION public.inssaldoover(); 
CREATE OR REPLACE FUNCTION public.inssaldoover()
 RETURNS void
 LANGUAGE plpgsql
AS $function$
begin

  insert into saldooverpay
    (saldooverpay_id, oversum, saldodate, oversubject_id, kindparreg_id)
    select nextval('s_saldooverpay'), b.oversum, trunc(current_date) - 1,
           o.oversubject_id, 2
    from   oversubject o, baloverinst b
    where  o.oversubject_id = b.oversubject_id;

  --commit;

end;

$function$
; DROP FUNCTION public.interestlist(numeric, integer); 
CREATE OR REPLACE FUNCTION public.interestlist(idebtsubject_id numeric, iuser_id integer, OUT vpdprt character varying[], OUT return_val character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                        
    crhead cursor (vDebtSubject_id numeric) is
      select distinct ds.debtsubject_id, max(ds.tax_begidate),
                      max('�������: ' || ds.partidano || ' ' || kdr.name) partidano,
                      max(kdr.code) kdrcode, max(kdr.name) kdrname,
                      max((select d.value
                            from   decode d
                            where  upper(d.columnname) = 'KIND_IDN'
                            and    d.code = ts.kind_idn) || ' ' || ts.idn) idn,
                      max(ts.name) tsname,
                      max('������ �������� ��: ' ||
                           to_char(ds.tax_begidate, 'dd.mm.yyyy') || ' ��: ' ||
                           to_char(ds.tax_enddate, 'dd.mm.yyyy')) period,
                      max('����������� ���.: ' || ds.docno || '/' ||
                           to_char(ds.doc_date, 'dd.mm.yyyy')) nodate,
                      sum(di.instsum) instsum, sum(idt.intdebtsum) intdebtsum
      from    kinddebtreg kdr, debtinstalment di,
             interestdebt idt, debtsubject ds left outer join taxsubject ts on  ds.taxsubject_id = ts.taxsubject_id
      where  ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    di.debtsubject_id = ds.debtsubject_id
      and    di.debtinstalment_id = idt.debtinstalment_id
      and    ds.debtsubject_id = vDebtSubject_id
    
      group  by ds.debtsubject_id
      order  by 2, 3;
    crIL cursor (vDebtSubject_id numeric) is
      select kdr.code kodpl, di.instno NomVn,
             to_char(i.oper_date, 'dd.mm.yyyy') srokPl,
             to_char(i.begin_date, 'dd.mm.yyyy') otdata,
             to_char(i.end_date, 'dd.mm.yyyy') dodata, i.intpct pct,
             i.instsum instsum, i.interestsum interestsum, null pllix,
             null DokNo,
             decode(i.kindoper, '1', '���.�����', '20', '��������') zab
      from   interestoper i, debtinstalment di, debtsubject ds, kinddebtreg kdr
      where  i.debtinstalment_id = di.debtinstalment_id
      and    di.debtsubject_id = ds.debtsubject_id
      and    ds.kinddebtreg_id = kdr.kinddebtreg_id
      and    ds.debtsubject_id = vDebtSubject_id --676552--:dsid
      union all
      select kdr.code kodpl, di.instno NomVn,
             to_char(pd.paydate, 'dd.mm.yyyy') srokPl, null otdata, null dodata,
             null pct, null instsum, null interestsum, pdt.payinterestsum pllix,
             (select d.value
               from   decode d
               where  upper(d.columnname) = 'KINDPAYDOC'
               and    d.code = pd.kindpaydoc) || '/' || pd.documentno DokNo,
             null zab
      from   paydocument pd, paydebt pdt, debtinstalment di, debtsubject ds,
             kinddebtreg kdr
      where  pd.paydocument_id = pdt.paydocument_id
      and    pdt.debtinstalment_id = di.debtinstalment_id
      and    di.debtsubject_id = ds.debtsubject_id
      and    kdr.kinddebtreg_id = ds.kinddebtreg_id
      and    pd.null_date is null
      and    nvl(pdt.payinterestsum, 0) > 0
      and    di.debtsubject_id = vDebtSubject_id --:dsid 
      union all
      select kdr.code kodpl, di.instno NomVn,
             to_char(di.termpay_date, 'dd.mm.yyyy') srokPl,
             to_char(op.oper_date, 'dd.mm.yyyy') otdata, null dodata, null pct,
             null instsum, null interestsum, opd.operintsum pllix,
             To_char(op.operdocno) DokNo, '����������' zab
      from   operation op, operdebt opd, debtinstalment di, debtsubject ds,
             kinddebtreg kdr
      where  op.operation_id = opd.operation_id
      and    opd.debtinstalment_id = di.debtinstalment_id
      and    di.debtsubject_id = ds.debtsubject_id
      and    kdr.kinddebtreg_id = ds.kinddebtreg_id
      and    nvl(opd.operintsum, 0) > 0
      and    di.debtsubject_id = vDebtSubject_id --:dsid 
      and    op.null_date is null
      order  by 1, 3, 4;
    ErrMsg        varchar(100);
    i             numeric;
    vRest         varchar(200);
    vRest1        varchar(200);
    vMunicipality varchar(100);
    vProvince     varchar(100);
    vtotalinstsum numeric(18, 2);
    vtotalpct     numeric(18, 2);
    vtotalintsum  numeric(18, 2);
    vtotalpllix   numeric(18, 2);
    vtotal        numeric(18, 2);
  begin
    i             := 1;
    vtotalinstsum := 0;
    vtotalpct     := 0;
    vtotalintsum  := 0;
    vtotalpllix   := 0;
    vtotal        := 0;
    select m.fullname, p.name
    into   vMunicipality, vProvince
    from   users u, municipality m, province p
    where  u.user_id = iUser_id
    and    u.municipality_id = m.municipality_id
    and    m.province_id = p.province_id;
    vPDPrt[i] := rpadc('������: ' || vProvince, 50) ||
                 lpadc('����: ' || to_char(current_date, 'dd.mm.yyyy'), 25);
    i := i + 1;
    vPDPrt[i] := rpadc('������: ' || vMunicipality, 50) ||
                 lpadc('      ' || to_char(current_date, 'hh24:mm:ss'), 25);
    i := i + 1;
    vPDPrt[i] := center('������ ����', 80);
    i := i + 1;
    for cr in crhead(iDebtSubject_id)
    loop
      vPDPrt[i] := center(cr.idn || ' - ' || cr.tsname, 80);
      i := i + 1;
      vPDPrt[i] := rpadc(cr.partidano, 60);
      i := i + 1;
      vPDPrt[i] := rpadc(cr.nodate, 60);
      i := i + 1;
      vPDPrt[i] := rpadc(cr.period, 60);
      exit;
    end loop;
    
    vPDPrt[i] := '----------------------------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := '��� ���|����� |  ����    |          |          |������� |        |���������|�������|           |         ';
    i := i + 1;
    vPDPrt[i] := '�������|������|  ������� | �� ����  | �� ����  |��������|������ %| �����   | ����� |��.��������|���������';
    i := i + 1;
    vPDPrt[i] := '----------------------------------------------------------------------------------------------------------';
    i := i + 1;
    for cr in crIL(iDebtSubject_id)
    loop
      vPDPrt[i] := rpadc(nvl(cr.kodpl, ' '), 7) || ' ' ||
                   lpadc(nvl(to_char(cr.nomvn), ' '), 6) || ' ' ||
                   lpadc(nvl(cr.srokpl, ' '), 10) || ' ' ||
                   lpadc(cr.otdata, 10) || ' ' ||
                   lpadc(nvl(cr.dodata, ' '), 10) || ' ' ||
                   lpadc(nvl(to_char(cr.instsum, '999990.99'), ' '), 8) || ' ' ||
                   lpadc(nvl(to_char(cr.pct, '999990.99'), ' '), 8) || ' ' ||
                   lpadc(nvl(to_char(cr.interestsum, '999990.99'), ' '), 8) || ' ' ||
                   lpadc(nvl(to_char(nvl(cr.pllix, 0), '999990.99'), ' '), 8) || ' ' ||
                   rpadc(nvl(cr.dokno, ' '), 11) || ' ' || rpadc(cr.zab, 20);
      i := i + 1;
      --vtotalinstsum := vtotalinstsum + nvl(cr.instsum,0);
      --vtotalpct := vtotalpct + nvl(cr.pct,0);    
      vtotalintsum := vtotalintsum + nvl(cr.interestsum, 0);
      vtotalpllix  := vtotalpllix + nvl(cr.pllix, 0);
    end loop;
    vPDPrt[i] := '----------------------------------------------------------------------------------------------------------';
    i := i + 1;
    vPDPrt[i] := rpadc(' ����: ', 66, ' ') ||
                --lpadc(to_char(vtotalinstsum,'9990.99'),8,' ')||' '||   
                --lpadc(to_char(vtotalpct,'9990.99'),8,' ')||' '||   
                 lpadc(to_char(vtotalintsum, '9990.99'), 8, ' ') || ' ' ||
                 lpadc(to_char(vtotalpllix, '9990.99'), 8, ' ');
    i := i + 1;
    vPDPrt[i] := '';
    i := i + 1;
    vPDPrt[i] := ' ��������� �����:    ' ||
                 lpadc(to_char(nvl(vtotalintsum, 0), '99990.99'), 12);
    i := i + 1;
    vPDPrt[i] := ' ������� �����:      ' ||
                 lpadc(to_char(nvl(vtotalpllix, 0), '99990.99'), 12);
    i := i + 1;
    vPDPrt[i] := ' ---------------------------------';
    i := i + 1;
    vtotal := vtotalintsum - vtotalpllix;
    vPDPrt[i] := ' ������� �����:      ' ||
                 lpadc(to_char(vtotal, '99990.99'), 12);
    i := i + 1;
    select sum(sanction_pkg.TempInt(i.debtinstalment_id, trim(current_date)))
    into   vtotalpct
    from   debtinstalment i
    where  i.debtsubject_id = iDebtSubject_id;
    vPDPrt[i] := ' ����������� �����:  ' ||
                 lpadc(to_char(vtotalpct, '99990.99'), 12);
    i := i + 1;
    vtotal := vtotal + vtotalpct;
    vPDPrt[i] := ' ���� ������� �����: ' ||
                 lpadc(to_char(nvl(vtotal, 0), '99990.99'), 12);
    i := i + 1;
    vPDPrt[i] := '';
  
    commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        rollback;
        execute NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;
      end;
  end;
  $function$
; DROP FUNCTION public.j_obekt_zemia(numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION public.j_obekt_zemia(ipkindobject numeric, iphomeobjid numeric, iptaxdocid numeric)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare
return_val Numeric;

begin
  if ipKindObject = 1 then
    select (case when count(*) > 0 then 1 else 0 end) j_obekt
    into   return_val
    from   ((select b.kindfunction br
             from   property p,
                    building b,
                    homeobj h
             where  p.taxdoc_id = ipTaxDocId
             and    p.property_id = b.property_id
             and    b.building_id = h.building_id
             and    h.taxenddate is null
             and b.kindfunction::integer < 5)

            union

            (select p.structurezone
             from   property p
             where  p.taxdoc_id = ipTaxDocId
             and    p.structurezone in ('1', '2', '4', '6'))
            ) a;
  else
    select (case when h.kindhomeobjreg_id between 1 and 5 then 1 else 0 end) j_obekt
    into   return_val
    from   homeobj h
    where  h.homeobj_id = ipHomeObjId;
  end if;

  Return return_val;

 exception
  when others then
   Return null; --'������';

end;
$function$
; DROP FUNCTION public.lpadc(numeric, integer); 
CREATE OR REPLACE FUNCTION public.lpadc(arg1 numeric, arg2 integer)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
begin
 return lpadc(to_char(arg1), arg2);
end
$function$
; DROP FUNCTION public.lpadc(character varying, numeric, character varying); 
CREATE OR REPLACE FUNCTION public.lpadc(str character varying, len numeric, app character varying DEFAULT ' '::character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  res varchar(400);
  s   varchar(400);
  
begin
  if(str is null) then  str:='';
  end if;
  s   := rpad(app, len, app) || str;
  res := substr(s, length(S) - len + 1, len);
  return(res);
end;
$function$
; DROP FUNCTION public.lpadc(character varying, integer, character varying); 
CREATE OR REPLACE FUNCTION public.lpadc(str character varying, len integer, app character varying DEFAULT ' '::character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  res varchar(400);
  s   varchar(400);
begin
 if(str is null)  then str:='';
 end if;
  s   := rpad(app, len, app) || str;
  res := substr(s, length(S) - len + 1, len);
  return(res);
end;
$function$
; DROP FUNCTION public.nanvl(real, real); 
CREATE OR REPLACE FUNCTION public.nanvl(real, real)
 RETURNS real
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT CASE WHEN $1 = 'NaN' THEN $2 ELSE $1 END; $function$
; DROP FUNCTION public.nanvl(double precision, double precision); 
CREATE OR REPLACE FUNCTION public.nanvl(double precision, double precision)
 RETURNS double precision
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT CASE WHEN $1 = 'NaN' THEN $2 ELSE $1 END; $function$
; DROP FUNCTION public.nanvl(numeric, numeric); 
CREATE OR REPLACE FUNCTION public.nanvl(numeric, numeric)
 RETURNS numeric
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT CASE WHEN $1 = 'NaN' THEN $2 ELSE $1 END; $function$
; DROP FUNCTION public.newyear(numeric, character varying); 
CREATE OR REPLACE FUNCTION public.newyear(ipmunicipality_id numeric, ipnewyear character varying, OUT stat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare        
 cr CURSOR(ipnewyear character varying) is
 select i.debtinstalment_id, b.instsum, b.interestsum
 from debtinstalment i left join baldebtinst b ON i.debtinstalment_id = b.debtinstalment_id
 where b.instsum > 0
 and months_between(to_date('01.01.' || ipnewyear, 'dd.mm.yyyy')-1,i.termpay_date::date)/12 >= 10 
 ;
  
  rowcr record; 
  i integer;
  vkindpr  integer;                             
  vcuryear         varchar(4);
  vnewyear         varchar(4);
  vmunicipality_id numeric;
  brz              numeric;
  vtaxperiod_id    numeric;
  vdisc_id         numeric;

begin
  --  select max(c.municipality_id) into vmunicipality_id from config c;
  vmunicipality_id := ipmunicipality_id;

  if vmunicipality_id is null
  then
    stat := '������ ������';
    return;
  end if;

  select to_char(current_date, 'yyyy')
  into   vcuryear
  from   dual;

  --- TAXYEAR
  select min(c.configvalue)
  into   vnewyear
  from   config c
  where  c.name = 'TAXYEAR'
  and    c.municipality_id = vmunicipality_id;

  if vnewyear is null
  then
    vnewyear := vcuryear;
    insert into config
      (municipality_id, name, configvalue)
    values
      (vmunicipality_id, 'TAXYEAR', vnewyear);
  else
    if to_number(vcuryear) >= (to_number(vnewyear) + 1)
    then
      vnewyear := to_char(to_number(vnewyear) + 1);
    end if;
    update config
    set    configvalue = vnewyear
    where  name = 'TAXYEAR'
    and    municipality_id = vmunicipality_id;
  end if;

  --- BEGINOBL1
  select count(c.name)
  into   brz
  from   config c
  where  c.name = 'BEGINOBL1'
  and    c.municipality_id = vmunicipality_id;

  if brz = 0
  then
    insert into config
      (municipality_id, name, configvalue)
    values
      (vmunicipality_id, 'BEGINOBL1', to_char(to_number(vnewyear) - 6));
  else
    update config
    set    configvalue = to_char(to_number(vnewyear) - 6)
    where  name = 'BEGINOBL1'
    and    municipality_id = vmunicipality_id;
  end if;
  update baldebtinst b
   set b.discsum = 0
  where b.discsum > 0
  ;

  --- TAXYEAR61  
  select count(c.name)
  into   brz
  from   config c
  where  c.name = 'TAXYEAR61'
  and    c.municipality_id = vmunicipality_id;

  if brz = 0
  then
    insert into config
      (municipality_id, name, configvalue)
    values
      (vmunicipality_id, 'TAXYEAR61', vnewyear);
  else
    update config
    set    configvalue = vnewyear
    where  name = 'TAXYEAR61'
    and    municipality_id = vmunicipality_id;
  end if;

  select min(tp.taxperiod_id)
  into   vtaxperiod_id
  from   taxperiod tp
  where  tp.begin_date = to_date('01.01.' || vnewyear, 'dd.mm.yyyy')
  and    tp.taxperkind = '0';

  if nvl(vtaxperiod_id, 0.0) = 0
  then
    select nextval('s_taxperiod')
    into   vtaxperiod_id
    from   dual;
  
    insert into taxperiod
      (taxperiod_id, begin_date, end_date, taxperkind)
    values
      (vtaxperiod_id, to_date('01.01.' || vnewyear, 'dd.mm.yyyy'),
       to_date('31.12.' || vnewyear, 'dd.mm.yyyy'), '0');
  end if;
 insert into taxobject  --- za patenta
   (taxobject_id, municipality_id, kindtaxobject, taxperiod_id)
   select nextval('s_taxobject'),vmunicipality_id,'3',vtaxperiod_id
   ;
  select count(p.taxperiodpay_id)
  into   brz
  from   taxperiodpay p
  where  p.taxperiod_id = vtaxperiod_id
  and    p.documenttype_id = 21;

  if brz = 0
  then
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 21, vtaxperiod_id, 1,
             to_date('30.06.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 21, vtaxperiod_id, 2,
             to_date('30.10.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
  end if;

  select count(p.taxperiodpay_id)
  into   brz
  from   taxperiodpay p
  where  p.taxperiod_id = vtaxperiod_id
  and    p.documenttype_id = 22;

  if brz = 0
  then
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 22, vtaxperiod_id, 1,
             to_date('30.06.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 22, vtaxperiod_id, 2,
             to_date('30.10.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
  end if;

  select count(p.taxperiodpay_id)
  into   brz
  from   taxperiodpay p
  where  p.taxperiod_id = vtaxperiod_id
  and    p.documenttype_id in (26, 27, 28, 29);

  if brz = 0
  then
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 26, vtaxperiod_id, 1,
             to_date('30.06.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 26, vtaxperiod_id, 2,
             to_date('30.10.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 27, vtaxperiod_id, 1,
             to_date('30.06.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 27, vtaxperiod_id, 2,
             to_date('30.10.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 28, vtaxperiod_id, 1,
             to_date('30.06.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 28, vtaxperiod_id, 2,
             to_date('30.10.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 29, vtaxperiod_id, 1,
             to_date('30.06.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 29, vtaxperiod_id, 2,
             to_date('30.10.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
  end if;

  select count(p.taxperiodpay_id)
  into   brz
  from   taxperiodpay p
  where  p.taxperiod_id = vtaxperiod_id
  and    p.documenttype_id = 30;

  if brz = 0
  then
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 30, vtaxperiod_id, 1,
             to_date('31.01.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 30, vtaxperiod_id, 2,
             to_date('30.04.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 30, vtaxperiod_id, 3,
             to_date('31.07.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
    insert into taxperiodpay
      (taxperiodpay_id, documenttype_id, taxperiod_id, instalmentnumber,
       termpaydate)
      select nextval('s_taxperiodpay'), 30, vtaxperiod_id, 4,
             to_date('31.10.' || vnewyear, 'dd.mm.yyyy')
      from   dual;
  end if;

  select count(d.discount_id)
  into   brz
  from   discount d
  where  d.taxperiod_id = vtaxperiod_id;

  if brz = 0
  then
    select max(d.discount_id)
    into   vdisc_id
    from   discount d;
    vdisc_id := vdisc_id + 1;
    insert into discount
      (discount_id, documenttype_id, taxperiod_id, termdisc, percent, condition)
    values
      (vdisc_id, 21, vtaxperioD_id, to_date('30.04.' || vnewyear, 'dd.mm.yyyy'),
       5, '1');
    vdisc_id := vdisc_id + 1;
    insert into discount
      (discount_id, documenttype_id, taxperiod_id, termdisc, percent, condition)
    values
      (vdisc_id, 22, vtaxperioD_id, to_date('30.04.' || vnewyear, 'dd.mm.yyyy'),
       5, '1');
    vdisc_id := vdisc_id + 1;
    insert into discount
      (discount_id, documenttype_id, taxperiod_id, termdisc, percent, condition)
    values
      (vdisc_id, 26, vtaxperioD_id, to_date('30.04.' || vnewyear, 'dd.mm.yyyy'),
       5, '1');
    vdisc_id := vdisc_id + 1;
    insert into discount
      (discount_id, documenttype_id, taxperiod_id, termdisc, percent, condition)
    values
      (vdisc_id, 27, vtaxperioD_id, to_date('30.04.' || vnewyear, 'dd.mm.yyyy'),
       5, '1');
    vdisc_id := vdisc_id + 1;
    insert into discount
      (discount_id, documenttype_id, taxperiod_id, termdisc, percent, condition)
    values
      (vdisc_id, 28, vtaxperioD_id, to_date('30.04.' || vnewyear, 'dd.mm.yyyy'),
       5, '1');
    vdisc_id := vdisc_id + 1;
    insert into discount
      (discount_id, documenttype_id, taxperiod_id, termdisc, percent, condition)
    values
      (vdisc_id, 29, vtaxperioD_id, to_date('30.04.' || vnewyear, 'dd.mm.yyyy'),
       5, '1');
    vdisc_id := vdisc_id + 1;
    insert into discount
      (discount_id, documenttype_id, taxperiod_id, termdisc, percent, condition)
    values
      (vdisc_id, 30, vtaxperiod_id, to_date('31.01.' || vnewyear, 'dd.mm.yyyy'),
       5, '1');
  
  end if;

  update debtsubject
  set    kindparreg_id = 3
  where  taxperiod_id <> vtaxperiod_id
  and    kindparreg_id = 2;

  -- sledvashta godina  
  select min(tp.taxperiod_id)
  into   vtaxperiod_id
  from   taxperiod tp
  where  tp.begin_date =
         to_date('01.01.' || to_char(to_number(vnewyear) + 1), 'dd.mm.yyyy')
  and    tp.taxperkind = '0';

  if nvl(vtaxperiod_id, 0.0) = 0
  then
    select nextval('s_taxperiod')
    into   vtaxperiod_id
    from   dual;
    insert into taxperiod
      (taxperiod_id, begin_date, end_date, taxperkind)
    values
      (vtaxperiod_id,
       to_date('01.01.' || to_char(to_number(vnewyear) + 1), 'dd.mm.yyyy'),
       to_date('31.12.' || to_char(to_number(vnewyear) + 1), 'dd.mm.yyyy'), '0');
  end if;
  --commit;
  ---- ��������� ���������� � ������� ��������� ����
  open cr(vnewyear);
  loop
   fetch cr into rowcr;
   IF NOT FOUND THEN EXIT; END IF; -- apply on cr
   select count(*), min(p.kindprescription) into i, vkindpr
   from prescription p
   where p.debtinstalment_id = rowcr.debtinstalment_id
--   and p.kindprescription = 2
   ;
   if i > 0 then
    if vkindpr = 1 then
     update prescription p
      set kindprescription = 2,
          dateprescription = to_date('01.01.' || vnewyear, 'dd.mm.yyyy'), 
          instsum = rowcr.instsum,
          interestsum = rowcr.interestsum
     where p.debtinstalment_id = rowcr.debtinstalment_id;
    end if; 
   else
     insert into prescription 
     (debtinstalment_id,kindprescription, dateprescription,instsum, interestsum)
     values(rowcr.debtinstalment_id,2,to_date('01.01.' || vnewyear, 'dd.mm.yyyy'),rowcr.instsum, rowcr.interestsum )
     ;
   end if; 
  end loop;
  stat := 'OK';
exception
  when others then
    stat := sqlerrm;
end;

$function$
; DROP FUNCTION public.numnormalize(character varying); 
CREATE OR REPLACE FUNCTION public.numnormalize(innum character varying)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
DECLARE

  res numeric;
  str character varying(10);
  tmpStr character varying(10);

BEGIN
  str := trim(inNum);
  res := to_number(str);

  return(res);
  
  exception
  when others then
    res := 0;
    tmpStr := '';
    
    for i in 1..length(str) loop
      tmpStr := substring(str, i, 1);
      if (tmpStr < '0' or tmpStr > '9') then
        res := to_number(substr(str, 1, i - 1));
        exit;
      end if;
    end loop;
    
    return res;
    
END;
$function$
; DROP FUNCTION public.nvl(anyelement, anyelement); 
CREATE OR REPLACE FUNCTION public.nvl(anyelement, anyelement)
 RETURNS anyelement
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_nvl$function$
; DROP FUNCTION public.nvl2(anyelement, anyelement, anyelement); 
CREATE OR REPLACE FUNCTION public.nvl2(anyelement, anyelement, anyelement)
 RETURNS anyelement
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$ora_nvl2$function$
; DROP FUNCTION public.osv_dzl_group(numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION public.osv_dzl_group(iptaxdocid numeric, iptaxsubjectid numeric, iptaxperiodid numeric)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare
return_val Numeric;

begin
  select (case when count(*) > 0 then 1 else 0 end) dzl_osv --sg.* ,grtbo.*
    into return_val
    from SUBJgrouptbo Sg, grouptbo grtbo
   where Sg.Grouptbo_Id = grtbo.grouptbo_id
     and sg.taxdoc_id = ipTaxDocId
     and sg.taxsubject_id = decode(ipTaxSubjectId, 0.0, sg.taxsubject_id, ipTaxSubjectId)
     and ((sg.enddate is null) or
         (sg.enddate >
         (select t.begin_date from taxperiod t where t.taxperiod_id = 22)))
     and sg.begindate =
         (select max(ss.begindate)
            from subjgrouptbo ss
           where Sg.Taxdoc_Id = ss.taxdoc_id
             and sg.taxsubject_id = ss.taxsubject_id
             and ss.begindate <=
                 (select t.begin_date
                    from taxperiod t
                   where t.taxperiod_id = ipTaxPeriodId))
     and (grtbo.isswh = 0 or grtbo.iscleanh = 0 or grtbo.isdepoth = 0 or
         grtbo.issw = 0 or grtbo.isclean = 0 or grtbo.isdepot = 0);

  Return return_val;

   exception when others then
  Return null; --'������';

end;
$function$
; DROP FUNCTION public.osv_pn_d19(numeric, numeric); 
CREATE OR REPLACE FUNCTION public.osv_pn_d19(iptaxdocid numeric, iptaxperiodid numeric)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
  declare
  return_val Numeric;

begin
  select (case when count(gt.garbtax_id) > 0 then 1 else 0 end) rez
    into return_val
    from garbtax gt, taxdoc td
   where gt.taxdoc_id = td.taxdoc_id
     and td.documenttype_id =
         (select t.documenttype_id
            from documenttype t
           where t.doccode = '19')
     and gt.proptaxdoc_id = ipTaxDocId
     and gt.taxperiod_id = ipTaxPeriodId;

  Return return_val;

exception
  when others then
    Return null; --'������';

end;
$function$
; DROP FUNCTION public.osv_pn_d71(numeric, numeric); 
CREATE OR REPLACE FUNCTION public.osv_pn_d71(iptaxdocid numeric, iptaxperiodid numeric)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare                                       
return_val Numeric;

begin
  select decode(((nvl(gg.sw_missing, 0.0) + nvl(gg.clean_missing, 0.0) +
                nvl(gg.depot_missing, 0.0))),
                0.0,
                0.0,
                1.0) rez
    into return_val
    from garbtax gg
   where gg.garbtax_id = (select max(gt.garbtax_id)
                            from garbtax gt, taxdoc td
                           where gt.taxdoc_id = td.taxdoc_id
                             and td.documenttype_id =
                                 (select t.documenttype_id
                                    from documenttype t
                                   where t.doccode = '71')
                             and gt.proptaxdoc_id = ipTaxDocId
                             and gt.taxperiod_id = ipTaxPeriodId);

  Return return_val;

   exception when others then
  Return 0; --'������';

end;
$function$
; DROP FUNCTION public.osv_pn_group(numeric, numeric); 
CREATE OR REPLACE FUNCTION public.osv_pn_group(iptaxdocid numeric, iptaxperiodid numeric)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare                                        

return_val Numeric;

begin
  select (case when count(*) > 0 then 1 else 0 end) dzl_osv --sg.* ,grtbo.*
  into return_val
    from propgrouptbo pg, grouptbo grtbo
   where Pg.Grouptbo_Id = grtbo.grouptbo_id
     and Pg.taxdoc_id = ipTaxDocId
     and ((pg.enddate is null) or
         (pg.enddate >
         (select t.begin_date from taxperiod t where t.taxperiod_id = 21)))
     and Pg.begindate =
         (select max(ss.begindate)
            from Propgrouptbo ss
           where Pg.Taxdoc_Id = ss.taxdoc_id
             and ss.begindate <=
                 (select t.begin_date
                    from taxperiod t
                   where t.taxperiod_id = ipTaxPeriodId))
     and (grtbo.isswh = 0 or grtbo.iscleanh = 0 or grtbo.isdepoth = 0 or
         grtbo.issw = 0 or grtbo.isclean = 0 or grtbo.isdepot = 0);

   Return return_val;

   exception when others then
  Return null; --'������';

end;
$function$
; DROP FUNCTION public.outdirectdebit(numeric, date, numeric, numeric, date, numeric, numeric, date); 
CREATE OR REPLACE FUNCTION public.outdirectdebit(ipuser_id numeric, ipdocdate date, ipkinddebtreg_id numeric, ipbaccount_id numeric, ipdateint date, ipsumfrom numeric, ipsumto numeric, OUT opstatus character varying, iptermpaydate date)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
cr cursor is
    select ts.taxsubject_id, max(ds.partidano) partidano,
           max(ac.tsaccno) tsaccno, sum(nvl(bdi.instsum, 0)) Sinstsum,
           sum(round(nvl(bdi.interestsum, 0), 2)) Sinterestsum,
           sum(nvl(bdi.discsum, 0)) Sdiscsum
    from   acceptdd ac
    inner join taxsubject ts on ac.idn = ts.idn
    inner join debtsubject ds on ts.taxsubject_id = ds.taxsubject_id
                             and ac.partidano = ds.partidano
    inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
    inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
    inner join users u on ac.municipality_id = u.municipality_id
    where  (nvl(bdi.instsum, 0) + round(nvl(bdi.interestsum, 0), 2)) >= 0
    and    ds.kinddebtreg_id = ipKinddebtreg_Id
    and    di.termpay_date <= nvl(iptermpaydate, To_Date('01.01.2100', 'dd.mm.yyyy'))
    and    u.user_id = ipuser_Id
    group  by ts.taxsubject_id;
cz cursor (tsid numeric) is
select ts.taxsubject_id, di.debtinstalment_id,
       nvl(bdi.instsum,0) instsum, round(nvl(bdi.interestsum,0),2) interestsum,
       nvl(bdi.discsum,0) discsum, ds.partidano
from acceptdd ac
inner join taxsubject ts on ac.idn = ts.idn
inner join debtsubject ds on ts.taxsubject_id = ds.taxsubject_id
                         and ac.partidano = ds.partidano
inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
inner join users u on ac.municipality_id = u.municipality_id
where (nvl(bdi.instsum,0)+ round(nvl(bdi.interestsum,0),2))>= 0
      and ds.kinddebtreg_id = ipKinddebtreg_Id
      and di.termpay_date <= nvl(iptermpaydate,To_Date('01.01.2100','dd.mm.yyyy'))
      and u.user_id = ipuser_Id
      and ts.taxsubject_id = tsid;

r record;
z record;
vStat varchar(200);
vbankfiletransfer numeric;
vdirectDebit numeric;
vsumFile numeric;
vbrzap numeric;
vmunicipality numeric;
viban varchar(50);
vbaccount numeric;
vVidpl varchar(500);

begin

select u.municipality_id into vmunicipality
from users u
where u.user_id = ipUser_Id;
  open cr;
    loop
      fetch cr into r;
      exit when cr%notfound;
      -- otstpka
       perform Sanction_Pkg.calcdiscount(r.TaxSubject_id,null,ipDocDate,vStat);
       if vStat <> 'OK' then
        opstatus := '1'; -- greska pri nacislenie na otstpka
        exit;
       end if; -- otstpka
      if ipDateInt is not null then
       open cz(r.taxsubject_Id);
       Fetch cz into z;
       exit when cz%notfound;
       loop
       -- olixvjavane
       vStat := Sanction_Pkg.CalculateInt ( z.debtinstalment_id, ipDateInt, ipuser_id );
       if vStat <> 'OK' then
       opstatus := '2'; -- greska pri nacislenie na lixva
       exit;
       end if;
      -- olixvjavane
       end loop;
       close cz;
      end if;
    end loop;
  close cr;

  select b.iban, b.baccount_id into viban,vbaccount
  from baccount b
  where b.baccount_id = ipBAccount_Id;
  select upper(kdr.fullname) into vVidpl
  from kinddebtreg kdr
  where kdr.kinddebtreg_id = ipKinddebtreg_Id;
  Select s_bankfiletransfer.nextval into vbankfiletransfer from dual;
  insert into bankfiletransfer
        (bankfiletransfer_id, municipality_id, filename, bae1,
        bankname, iban, filenom, baccount_id, user_id, user_date,
        codetransfer, statusbftransfer, recordnumber, sum, docdate,
        docdate2, payreason, kinddebtreg_id, summin, summax, dateint, termpaydate)
   values
        (vbankfiletransfer,vmunicipality,null,null,
        null,viban,0,vbaccount,ipuser_Id,sysdate,
        '10',1,null,null,ipDocDate,
        ipDocDate,vVidpl,ipKinddebtreg_Id,ipSumFrom,ipSumTo,ipDateInt,iptermpaydate);

  vsumFile := 0;
  vbrzap := 0;
  open cr;
  loop
    fetch cr into r;
    exit when cr%notfound;
    if (r.Sinstsum + r.Sinterestsum - r.Sdiscsum) between
        nvl(ipSumFrom,0.01) and nvl(ipSumTo,999999999999.99) then

      vsumFile := vsumFile + (r.Sinstsum + r.Sinterestsum - r.Sdiscsum);
      vbrzap := vbrzap + 1;

      select S_directDebit.Nextval into vdirectDebit from dual;

      insert into Directdebit
          (directdebit_id, tsaccountno, docdate,
          interestsum, reason1, reason2, bankfiletransfer_id,
          taxsubject_id, instsum)
      values
          (vdirectDebit, r.tsaccno,ipDocDate,
          r.Sinterestsum,vdirectDebit,r.partidano,vbankfiletransfer,
          r.taxsubject_id,(r.Sinstsum - r.Sdiscsum));
      open cz(r.taxsubject_id);
      loop
        fetch cz into z;
        exit when cz%notfound;
         insert into dditems
         (directdebit_id, debtinstalment_id, instsum, interestsum, discsum)
         Values
         (vdirectDebit,z.debtinstalment_id,z.instsum,z.interestsum,z.discsum);
      end loop;
      close cz;

    end if;

  end loop;
  close cr;

  select b.iban, b.baccount_id into viban,vbaccount
  from baccount b
  where b.baccount_id = ipBAccount_Id;
  select upper(kdr.fullname) into vVidpl
  from kinddebtreg kdr
  where kdr.kinddebtreg_id = ipKinddebtreg_Id;
  update bankfiletransfer bfsup
     set bfsup.recordnumber = vbrzap,
         bfsup.sum = vsumFile
    where bfsup.bankfiletransfer_id = vbankfiletransfer;

 commit;
opStatus := 'OK';
exception
  when others then
    rollback;
  opStatus :=  SQLErrM;--'3';--'������';

end;
$function$
; DROP FUNCTION public.outdirectdebit01(numeric, date, numeric, numeric, date, numeric, numeric, date); 
CREATE OR REPLACE FUNCTION public.outdirectdebit01(ipuser_id numeric, ipdocdate date, ipkinddebtreg_id numeric, ipbaccount_id numeric, ipdateint date, ipsumfrom numeric, ipsumto numeric, OUT opstatus character varying, iptermpaydate date)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                                           

   cr cursor is
    select ts.taxsubject_id, max(ds.partidano) partidano,
           max(ac.tsaccno) tsaccno, sum(nvl(bdi.instsum, 0)) Sinstsum,
           sum(round(nvl(bdi.interestsum, 0), 2)) Sinterestsum,
           sum(nvl(bdi.discsum, 0)) Sdiscsum
    from   acceptdd ac
    inner join taxsubject ts on ac.idn = ts.idn
    inner join debtsubject ds on ts.taxsubject_id = ds.taxsubject_id
                             and ac.partidano = ds.partidano
    inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
    inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
    inner join users u on ac.municipality_id = u.municipality_id
    where  (nvl(bdi.instsum, 0) + round(nvl(bdi.interestsum, 0), 2)) >= 0
    and    ds.kinddebtreg_id = ipKinddebtreg_Id
    and    di.termpay_date <= nvl(iptermpaydate, To_Date('01.01.2100', 'dd.mm.yyyy'))
    and    u.user_id = ipuser_Id
    group  by ts.taxsubject_id;
   cz cursor (tsid numeric) is
select ts.taxsubject_id, di.debtinstalment_id,
       nvl(bdi.instsum,0) instsum, round(nvl(bdi.interestsum,0),2) interestsum,
       nvl(bdi.discsum,0) discsum, ds.partidano
from acceptdd ac
inner join taxsubject ts on ac.idn = ts.idn
inner join debtsubject ds on ts.taxsubject_id = ds.taxsubject_id
                         and ac.partidano = ds.partidano
inner join debtinstalment di on ds.debtsubject_id = di.debtsubject_id
inner join baldebtinst bdi on di.debtinstalment_id = bdi.debtinstalment_id
inner join users u on ac.municipality_id = u.municipality_id
where (nvl(bdi.instsum,0)+ round(nvl(bdi.interestsum,0),2))>= 0
      and ds.kinddebtreg_id = ipKinddebtreg_Id
      and di.termpay_date <= nvl(iptermpaydate,To_Date('01.01.2100','dd.mm.yyyy'))
      and u.user_id = ipuser_Id
      and ts.taxsubject_id = tsid;

  r                 record;
  z                 record;
  vStat             varchar(200);
  vbankfiletransfer numeric;
  vdirectDebit      numeric;
  vsumFile          numeric;
  vbrzap            numeric;
  vmunicipality     numeric;
  viban             varchar(50);
  vbaccount         numeric;
  vVidpl            varchar(500);

begin

  select u.municipality_id
  into   vmunicipality
  from   users u
  where  u.user_id = ipUser_Id;
  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
    -- otstpka 
    perform Sanction_Pkg.calcdiscount(r.TaxSubject_id, null, ipDocDate, vStat);
    if vStat <> 'OK'
    then
      opstatus := '1'; -- greska pri nacislenie na otstpka
      exit;
    end if; -- otstpka
    if ipDateInt is not null
    then
      open cz(r.taxsubject_Id);
      fetch cz
        into z;
      exit when not FOUND;
      loop
        -- olixvjavane 
        vStat := Sanction_Pkg.CalculateInt(z.debtinstalment_id, ipDateInt,
                                           ipuser_id);
        if vStat <> 'OK'
        then
          opstatus := '2'; -- greska pri nacislenie na lixva
          exit;
        end if;
        -- olixvjavane 
      end loop;
      close cz;
    end if;
  end loop;
  close cr;

  select b.iban, b.baccount_id
  into   viban, vbaccount
  from   baccount b
  where  b.baccount_id = ipBAccount_Id;

  select upper(kdr.fullname)
  into   vVidpl
  from   kinddebtreg kdr
  where  kdr.kinddebtreg_id = ipKinddebtreg_Id;

  select nextval('s_bankfiletransfer')
  into   vbankfiletransfer
  from   dual;

  insert into bankfiletransfer
    (bankfiletransfer_id, municipality_id, filename, bae1, bankname, iban,
     filenom, baccount_id, user_id, user_date, codetransfer, statusbftransfer,
     recordnumber, sum, docdate, docdate2, payreason, kinddebtreg_id, summin,
     summax, dateint, termpaydate)
  values
    (vbankfiletransfer, vmunicipality, null, null, null, viban, 0, vbaccount,
     ipuser_Id, current_date, '10', 1, null, null, ipDocDate, ipDocDate, vVidpl,
     ipKinddebtreg_Id, ipSumFrom, ipSumTo, ipDateInt, iptermpaydate);
  vsumFile := 0;
  vbrzap   := 0;
  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
    if (r.Sinstsum + r.Sinterestsum - r.Sdiscsum) between nvl(ipSumFrom, 0.01) and
       nvl(ipSumTo, 999999999999.99)
    then
    
      vsumFile := vsumFile + (r.Sinstsum + r.Sinterestsum - r.Sdiscsum);
      vbrzap   := vbrzap + 1;
    
      select nextval('s_directdebit')
      into   vdirectDebit
      from   dual;
    
      insert into Directdebit
        (directdebit_id, tsaccountno, docdate, interestsum, reason1, reason2,
         bankfiletransfer_id, taxsubject_id, instsum)
      values
        (vdirectDebit, r.tsaccno, ipDocDate, r.Sinterestsum, vdirectDebit,
         r.partidano, vbankfiletransfer, r.taxsubject_id,
         (r.Sinstsum - r.Sdiscsum));
      open cz(r.taxsubject_id);
      loop
        fetch cz
          into z;
        exit when not FOUND;
        insert into dditems
          (directdebit_id, debtinstalment_id, instsum, interestsum, discsum)
        values
          (vdirectDebit, z.debtinstalment_id, z.instsum, z.interestsum,
           z.discsum);
      end loop;
      close cz;
    
    end if;
  
  end loop;
  close cr;

  select b.iban, b.baccount_id
  into   viban, vbaccount
  from   baccount b
  where  b.baccount_id = ipBAccount_Id;

  select upper(kdr.fullname)
  into   vVidpl
  from   kinddebtreg kdr
  where  kdr.kinddebtreg_id = ipKinddebtreg_Id;

  update bankfiletransfer
  set    recordnumber = vbrzap, sum = vsumFile
  where  bankfiletransfer_id = vbankfiletransfer;

  --commit;
  opStatus := 'OK';
exception
  when others then
    --rollback;
    opStatus := sqlerrm; --'3';--'������'; 

end;
$function$
; DROP FUNCTION public.paydocumentmpc_receipt(numeric, integer); 
CREATE OR REPLACE FUNCTION public.paydocumentmpc_receipt(OUT return_val character varying, vpdocument_id numeric, visoriginal integer, OUT vpd_lob text)
 RETURNS record
 LANGUAGE plpgsql
AS $function$                                   
declare
    vPDPrt varchar[];
    ErrMsg varchar(200);
  
    GetPD cursor(vPDocument_id paydocument.paydocument_id%type) is
      select tobj.kindtaxobject, pd.paydate, pd.null_date, tobj.taxobject_id,
             ('�����: ' || pd.series || '  �����: ' || pd.documentno || '/' ||
              to_char(nvl(pd.documentdate, pd.paydate), 'dd.mm.yyyy')) docno,
             ('������: ' || p.name) province,
             ('������: ' || m.fullname) municipality,
             
             ('������� ������: ' || ts.taxsubjectno) taxsubj,
             ('������� �����: ' || tobj.taxobjno) taxobj,
             ('�������: ' || pd.partidano ||
              decode(trim(nvl(tobj.registerno, '')), '', '',
                      '  ���.� ' || tobj.registerno)) partidano,
             
             (select d.value
               from   decode d
               where  upper(d.columnname) = 'KIND_IDN'
               and    d.code = ts.kind_idn) || ': ' || ts.idn idn,
             ('��� ��: ' || (select d.value
                              from   decode d
                              where  upper(d.columnname) = 'TYPE'
                              and    d.code = trreg.type)) kindpc,
             ('��� �� �����: ' ||
              (select d.value
                from   decode d
                where  upper(d.columnname) = 'KINDPROPERTY'
                and    d.code = tobj.kindproperty)) kindprop,
             
             ('���: ' || ts.name) tsname,
             ('�����: ' || cm.mark_name || ' �����: ' || cmd.model_name) crmark,
             ('�������� �: ' || tobj.kadastrno) kadastrno,
             
             -- ('��������: '||u.fullname) Employee,
             u.fullname,
              --('�������: '||u.username||' '||u.fullname) receiver,
             ('�����: ' || GetAddress(ts.present_clientaddr_id)) Address,
             ('� ��������: ' || tobj.motorno) motorno,
             ('� ����: ' || tobj.ramano) ramano,
             ('����� �� �����: ' || getaddress(tobj.address_id)) propaddr,
             pd.bin,
             decode(pd.reason1, null, null, '���������: ' || pd.reason1) pdreason
      
      from   Paydocument pd
      left   outer join Taxsubject ts
      on     pd.taxsubject_id = ts.taxsubject_id
      left   outer join Taxobject tobj
      on     pd.taxobject_id = tobj.taxobject_id
      left   outer join Debtsubject ds
      on     ts.taxsubject_id = ds.debtsubject_id
      left   outer join Transpmeansreg trreg
      on     tobj.transpmeansreg_id = trreg.transpmeansreg_id
      left   outer join Paytransaction pt
      on     pd.paytransaction_id = pt.paytransaction_id
      left   outer join Carreg cr
      on     tobj.carreg_id = cr.carreg_id
      left   outer join Carmodel cmd
      on     cr.carmodel_id = cmd.carmodel_id
      left   outer join Carmark cm
      on     cmd.carmark_id = cm.carmark_id
      left   outer join Municipality m
      on     pt.municipality_id = m.municipality_id
      left   outer join Province p
      on     m.province_id = p.province_id
      left   outer join Users u
      on     pd.user_id = u.user_id
      where  pd.paydocument_id = vPDocument_id
      order  by pd.paydate;

    GetPayments cursor(vPDocument_id paydocument.paydocument_id%type) is
      select 1 ord, kdreg.code kcode, to_char(ds.tax_begidate, 'yyyy') period,
             kdreg.code || kpr.parreg_code || (di.instno * 10) ordered,
             (ds.docno || decode(ds.doc_date, null, '', '/') ||
              to_char(ds.doc_date, 'dd.mm.yy')) dekl,
             to_char(di.termpay_date, 'dd.mm.yy') srok,
             to_char(di.instno) instno, di.debtsubject_id,
             to_char(pdt.balinstsum, '9999990.99') dyljimo,
             to_char(pdt.payinstsum, '9999990.99') plateno, pdt.payinstsum paid,
             kdreg.code || kpr.parreg_code code, kdreg.name kdregname,
             di.termpay_date sr, t.registerno
      from   Paydebt pdt
      left   outer join Debtinstalment di
      on     pdt.debtinstalment_id = di.debtinstalment_id
      inner  join Debtsubject ds
      on     di.debtsubject_id = ds.debtsubject_id
      left   outer join Kindparreg kpr
      on     pdt.kindparreg_id = kpr.kindparreg_id
      left   outer join Kinddebtreg kdreg
      on     pdt.kinddebtreg_id = kdreg.kinddebtreg_id
      left   outer join Taxobject t
      on     ds.taxobject_id = t.taxobject_id
      where  pdt.paydocument_id = vPDocument_id
      and    pdt.payinstsum > 0
      union
      select 2 ord, kdreg.code kcode, to_char(ds.tax_begidate, 'yyyy') period,
             kdreg.code || kpr.parreg_code || (di.instno * 10 + di.instno) ordered,
             (ds.docno || decode(ds.doc_date, null, '', '/') ||
              to_char(ds.doc_date, 'dd.mm.yy')) dekl,
             to_char(di.termpay_date, 'dd.mm.yy') srok,
             to_char(di.instno) instno, di.debtsubject_id,
             to_char(pdt.balinterestsum, '9999990.99') dyljimo,
             to_char(pdt.payinterestsum, '9999990.99') plateno,
             pdt.payinterestsum paid,
             (kdreg.code || (select kpr.parreg_code
                              from   kindparreg kpr
                              where  kpr.kindparreg_id = 1)) code,
             ('���. ') || kdreg.name kdregname, di.termpay_date sr, t.registerno
      from   Paydebt pdt
      left   outer join Debtinstalment di
      on     pdt.debtinstalment_id = di.debtinstalment_id
      inner  join Debtsubject ds
      on     di.debtsubject_id = ds.debtsubject_id
      left   outer join Kindparreg kpr
      on     pdt.kindparreg_id = kpr.kindparreg_id
      left   outer join Kinddebtreg kdreg
      on     pdt.kinddebtreg_id = kdreg.kinddebtreg_id
      left   outer join Taxobject t
      on     ds.taxobject_id = t.taxobject_id
      where  pdt.paydocument_id = vPDocument_id
      and    pdt.payinterestsum > 0
      union
      select 3 ord, kdreg.code kcode, ('- 5%') period,
             kdreg.code || kpr.parreg_code || (di.instno * 10 + di.instno) ordered,
             (ds.docno || decode(ds.doc_date, null, '', '/') ||
              to_char(ds.doc_date, 'dd.mm.yy')) dekl,
             to_char(di.termpay_date, 'dd.mm.yy') srok, ' ' instno,
             di.debtsubject_id,
             to_char(pdt.paydiscsum * -1, '9999990.99') dyljimo,
             to_char(pdt.payinterestsum, '9999990.99') plateno,
             pdt.payinterestsum paid, ' ' code, kdreg.name kdregname,
             di.termpay_date sr, t.registerno
      from   Paydebt pdt
      left   outer join Debtinstalment di
      on     pdt.debtinstalment_id = di.debtinstalment_id
      inner  join Debtsubject ds
      on     di.debtsubject_id = ds.debtsubject_id
      left   outer join Kindparreg kpr
      on     pdt.kindparreg_id = kpr.kindparreg_id
      left   outer join Kinddebtreg kdreg
      on     pdt.kinddebtreg_id = kdreg.kinddebtreg_id
      left   outer join Taxobject t
      on     ds.taxobject_id = t.taxobject_id
      where  pdt.paydocument_id = vPDocument_id
      and    pdt.paydiscsum > 0
      order  by sr, kcode, ord;
    i             integer;
    vRest         varchar(200);
    vRes          varchar(100);
    vTotalInstSum numeric(18, 2);
    --GetPD_rec  GetPD%ROWTYPE;
    r                record;
    d                varchar;

  begin
    i     := 1; -- ����� 
    vRest := '';
    vRes  := '';
    for GetPD_rec in GetPD(vPDocument_id)
    loop
      --  Open GetPD(vPDocument_id); 
      --  FETCH GetPD INTO GetPD_rec;     
      vTotalInstSum := 0;
      vPDPrt[ i ] := center('�������� ���������', 74) ||
                   lpadc('����: ' || to_char(sysdate, 'dd.mm.yyyy'), 20); -- �������     
      i := i + 1;
      vPDPrt[ i ] := center(GetPD_rec.docno, 74) ||
                   lpadc(to_char(sysdate, 'hh24:mi:ss'), 20); -- �������     
      i := i + 1;
      vPDPrt[ i ] := '';
      i := i + 1;
      if (vIsOriginal = 0)
      then
        if ((GetPD_rec.null_date is not null) and (GetPD_rec.bin = 1))
        then
          vPDPrt[ i ] := center('� � � � � � � �', 80);
          i := i + 1;
        elsif ((GetPD_rec.null_date is not null) and (GetPD_rec.bin = 2))
        then
          vPDPrt[ i ] := center('� � � � � � � � �', 80);
          i := i + 1;
        else
          vPDPrt[ i ] := center('� � � � � � � �', 80);
          i := i + 1;
        end if;
      end if;
      vPDPrt[ i ] := GetPD_rec.province;
      i := i + 1;
      vPDPrt[ i ] := GetPD_rec.municipality;
      i := i + 1;
      vPDPrt[ i ] := rpadc(GetPD_rec.taxsubj, 80);
      i := i + 1;
      vPDPrt[ i ] := rpadc(GetPD_rec.IDN, 80);
      i := i + 1;
      if (GetPD_rec.kindtaxobject = 2)
      then
        vPDPrt[ i ] := rpadc(GetPD_rec.tsname, 80);
        i := i + 1;
        r := wordwrap(GetPD_rec.Address, 35, 1);
        vPDPrt [ i ] := r.return_val;
        vRest := r.strrest;        
        i := i + 1;
        if length(vRest) > 0
        then
          vPDPrt[ i ] := rpadc(nvl(ltrim(vRest), ' '), 79);
          i := i + 1;
        end if;
      elsif (GetPD_rec.kindtaxobject = 1) and
            (nvl(GetPD_rec.taxobject_id, 0) > 0)
      then
        vPDPrt[ i ] := rpadc(GetPD_rec.tsname, 80);
        i := i + 1;
        r := wordwrap(GetPD_rec.Address, 79, 1);
        vPDPrt [ i ] := r.return_val;
        vRest := r.strrest;        
        i := i + 1;
        if length(vRest) > 0
        then
          vPDPrt[ i ] := rpadc(ltrim(vRest), 80);
          i := i + 1;
        end if;
      elsif (nvl(GetPD_rec.taxobject_id, 0) > 0)
      then
        vPDPrt[ i ] := rpadc(GetPD_rec.tsname, 40);
        i := i + 1;
        r := wordwrap(GetPD_rec.Address, 79, 1);
        vPDPrt [ i ] := r.return_val;
        vRest := r.strrest;        
        i := i + 1;
        if Length(vRest) > 0
        then
          vPDPrt[ i ] := rpadc(vRest, 80);
          i := i + 1;
        end if;
      else
        vPDPrt[ i ] := rpadc(GetPD_rec.tsname, 80);
        i := i + 1;
      end if;
      vPDPrt[ i ] := ' --------------------------------------------------------------------------------------------'; --94  
      i := i + 1;
      vPDPrt[ i ] := '|���    |��� ������. |���.|���.�     |���� ��.|�����/���� ����.    |��.|  ������� |  ������� |';
      i := i + 1;
      vPDPrt[ i ] := ' --------------------------------------------------------------------------------------------';
      i := i + 1;
      for GetPayments_rec in GetPayments(vPDocument_id)
      loop
        vPDPrt[ i ] := ' ' || lpadc(GetPayments_rec.Code, 7, ' ') || ' ' ||
                     rpadc(GetPayments_rec.Kdregname, 12, ' ') || ' ' ||
                     lpadc(GetPayments_rec.Period, 4, ' ') || ' ' ||
                     rpadc(GetPayments_rec.registerno, 10, ' ') || ' ' ||
                     lpadc(GetPayments_rec.Srok, 8, ' ') || ' ' ||
                     rpadc(nvl(GetPayments_rec.Dekl, ' '), 20, ' ') || ' ' ||
                     lpadc(nvl(GetPayments_rec.Instno, ' '), 3, ' ') || ' ' ||
                     lpadc(GetPayments_rec.Dyljimo, 10, ' ') || ' ' ||
                     lpadc(GetPayments_rec.Plateno, 10, ' ');
        vTotalInstSum := vTotalInstSum + GetPayments_rec.plateno;
        i := i + 1;
      end loop;
      vPDPrt[ i ] := ' ---------------------------------------------------------------------------------------------';
      i := i + 1;
      vPDPrt[ i ] := rpadc(' ���� �������:', 74, ' ') ||
                   lpadc(to_char(vTotalInstSum, '9999990.99'), 19, ' ');
      i := i + 1;
      vPDPrt[ i ] := ' ������: ' ||
                   rpadc(advance_pkg.Slovom(trim(to_char(vTotalInstSum,
                                                         '9999990.99'))), 93, ' ');
      i := i + 1;
      vPDPrt[ i ] := '';
      if (GetPD_rec.pdreason is not null)
      then
        i := i + 1;
        r := wordwrap(' ' || GetPD_rec.pdreason, 78, 1);
        vPDPrt [ i ] := r.return_val;
        vRest := r.strrest;        

        if (Length(vRest) > 1)
        then
          i := i + 1;
          vPDPrt[ i ] := rpadc(vRest, 80);
        end if;
      end if;
      i := i + 1;
      vPDPrt[ i ] := '';
      i := i + 1;
      vPDPrt[ i ] := ' ��������: .......................          ' ||
                   '������:........................';
      i := i + 1;
      vPDPrt[ i ] := lpadc(' ', 10) || center(GetPD_rec.fullname, 22);
      i := i + 1;
      vPDPrt[ i ] := '';
      i := i + 1;
      vPDPrt[ i ] := ' - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -';
      i := i + 1;
      --  Close GetPD;  
    end loop;
  
    vPD_lob :=  paydocument_pkg.tblToLob(vPDPrt);
  
    commit;
    return_val := 'OK';
    return;
  exception
    when others then
      begin
        rollback;
        perform NOM_PKG.ErrManage(ErrMsg);
        return_val := ErrMsg;
        return;
      end;
  end;
$function$
; DROP FUNCTION public.rpadc(numeric, integer); 
CREATE OR REPLACE FUNCTION public.rpadc(arg1 numeric, arg2 integer)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
begin
  return rpadc(to_char(arg1), arg2);
end
$function$
; DROP FUNCTION public.rpadc(character varying, numeric, character varying); 
CREATE OR REPLACE FUNCTION public.rpadc(str character varying, len numeric, app character varying DEFAULT ' '::character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  res varchar(200);
begin
 if(str is null ) then str:='';
 end if;
  res := substr(str || rpad(app, len, app), 1, len);
  return(res);
end;
$function$
; DROP FUNCTION public.rpadc(character varying, integer, character varying); 
CREATE OR REPLACE FUNCTION public.rpadc(str character varying, len integer, app character varying DEFAULT ' '::character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
  res varchar(200);
begin
	if(str is null)  then str:='';
    end if;
  res := substr(str || rpad(app, len, app), 1, len);
  return(res);
end;
$function$
; DROP FUNCTION public.secondpass(bigint, bigint); 
CREATE OR REPLACE FUNCTION public.secondpass(ipdocumenttype_id bigint, ipuser_id bigint, OUT opstat text, OUT operrn bigint, OUT opokn bigint)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
DECLARE

                       
    docs CURSOR(ipdate timestamp) is
      select *
      from   taxdoc td
      where  td.documenttype_id = ipdocumenttype_id
      and    (td.docstatus = '30')
      and ((coalesce(td.change_date::text, '') = '') or (td.change_date < ipdate))
      and td.begintaxdate <= ipdate + 1
      ;
    tdrow taxdoc%rowtype;
    cyear         varchar(10);
    ryear         varchar(10);
    msg           varchar(300);
    vbegintaxdate timestamp;
--    vtotalval     number;
--    vtotaltax     number;
--    vtbotax       number;
    countrec      bigint;
    vtaxper_id    bigint;
    vchangedate   timestamp;
    vsecdate      timestamp;
    r record;
BEGIN
    vsecdate := LOCALTIMESTAMP;
    opstat := 'OK';
    operrn := 0;
    opokn := 0;
    cyear  := null;
if ipdocumenttype_id = 21
    then
      select c.configvalue
      into   cyear
      from   config c
      where  c.name = 'TAXYEAR14';
    if coalesce(cyear::text, '') = ''
    then
      return;
    end if;
    select  c.configvalue into ryear
    from config c
    where  c.name = 'TAXYEAR14END';
    if ryear <> cyear then
       opstat := '��������� ��������� �� � ���������';
      return;
    end if;     

    vbegintaxdate := to_date('01.01.' || cyear , 'dd.mm.yyyy') - 1;
    select p.taxperiod_id
    into   vtaxper_id
    from   taxperiod p
    where  to_char(p.begin_date, 'yyyy') = cyear;
    select count(pp.taxperiodpay_id)
    into   countrec
    from   taxperiodpay pp
    where  pp.documenttype_id = ipdocumenttype_id
    and    to_char(pp.taxperiod_id) = vtaxper_id;
    if coalesce(countrec, 0) = 0
    then
      opstat := '������� ������� �� �������';
      return;
    end if;
      select count(pt.promtbo_id)
      into   countrec
      from   promtbo pt
      where  pt.taxperiod_id = vtaxper_id;
      if coalesce(countrec, 0) = 0
      then
        opstat := '������� ��������� �� �������';
        return;
      end if;
      select count(n.normdni_id)
      into   countrec
      from   normdni n
      where  n.taxperiod_id = vtaxper_id
      --  and n.municipality_id =
      ;
      if coalesce(countrec, 0) = 0
      then
        opstat := '������� ��������� �� �������';
        return;
      end if;
      open docs(vbegintaxdate);
      loop
        fetch docs
          into tdrow;
        IF NOT FOUND THEN EXIT; END IF; -- apply on docs
           if tdrow.begintaxdate <= vbegintaxdate + 1
            then
               update taxdoc td 
                 set td.change_date = vbegintaxdate,
                     td.secpassdate = vsecdate,
                     td.close_taxdoc_id = 1
               where td.taxdoc_id = tdrow.taxdoc_id
               ;
            else 
               update taxdoc td 
                 set td.change_date = tdrow.begintaxdate -1,
                     td.secpassdate = vsecdate,
                     td.close_taxdoc_id = 1
               where td.taxdoc_id = tdrow.taxdoc_id
               ;               
           end if;
           if coalesce(tdrow.decl14to17, 0) <> 1
            then
              
              r := taxvaluation.TaxDocVal(tdrow.taxdoc_Id, ipuser_id, 0,
                      msg, 1, null, null);
             -- commit;
             msg = r.return_val;
              if msg <> 'OK'
              then
                --dbms_output.put_line(tdrow.taxdoc_id || ' ' || msg);
                operrn := operrn + 1;
              else 
               opokn := opokn + 1;  
              end if;
            end if;
      end loop;
      close docs;
  /*    if operrn = 0
      then
          update config c
          set    c.configvalue = cyear
          where  c.name = 'TAXYEAR14END';
      else
          update config c
          set    c.configvalue = null
          where  c.name = 'TAXYEAR14END';
      end if;*/
end if; 
if ipdocumenttype_id = 22
    then
      select c.configvalue
      into   cyear
      from   config c
      where  c.name = 'TAXYEAR17';
    if coalesce(cyear::text, '') = ''
    then
      return;
    end if;
    select  c.configvalue into ryear
    from config c
    where  c.name = 'TAXYEAR17END';
    if ryear <> cyear then
      opstat := '��������� ��������� �� � ���������';
      return;
    end if;     

    vbegintaxdate := to_date('01.01.' || cyear , 'dd.mm.yyyy') - 1;
    select p.taxperiod_id
    into   vtaxper_id
    from   taxperiod p
    where  to_char(p.begin_date, 'yyyy') = cyear;
    select count(pp.taxperiodpay_id)
    into   countrec
    from   taxperiodpay pp
    where  pp.documenttype_id = ipdocumenttype_id
    and    to_char(pp.taxperiod_id) = vtaxper_id;
    if coalesce(countrec, 0) = 0
    then
      opstat := '������� ������� �� �������';
      return;
    end if;
      select count(pt.promtbo_id)
      into   countrec
      from   promtbo pt
      where  pt.taxperiod_id = vtaxper_id;
      if coalesce(countrec, 0) = 0
      then
        opstat := '������� ��������� �� �������';
        return;
      end if;
      select count(n.normdni_id)
      into   countrec
      from   normdni n
      where  n.taxperiod_id = vtaxper_id
      --  and n.municipality_id =
      ;
      if coalesce(countrec, 0) = 0
      then
        opstat := '������� ��������� �� �������';
        return;
      end if;
      open docs(vbegintaxdate);
      loop
        fetch docs
          into tdrow;
        IF NOT FOUND THEN EXIT; END IF; -- apply on docs
           if tdrow.begintaxdate <= vbegintaxdate + 1
            then
               update taxdoc td 
                 set td.change_date = vbegintaxdate,
                     td.secpassdate = vsecdate,
                     td.close_taxdoc_id = 1
               where td.taxdoc_id = tdrow.taxdoc_id
               ;
            else 
               update taxdoc td 
                 set td.change_date = tdrow.begintaxdate -1,
                     td.secpassdate = vsecdate,
                     td.close_taxdoc_id = 1
               where td.taxdoc_id = tdrow.taxdoc_id
               ;               
           end if;
           if coalesce(tdrow.decl14to17, 0) <> 1
            then
              
              r:=taxvaluation.TaxDocVal(tdrow.taxdoc_Id, ipuser_id, 0,
                      msg, 1, null, null);
              --commit;
              msg:=r.return_val;
              if msg <> 'OK'
              then
                --dbms_output.put_line(tdrow.taxdoc_id || ' ' || msg);
                operrn := operrn + 1;
              else
                opokn := opokn + 1;  
              end if;
            end if;
      end loop;
      close docs;
  /*    if operrn = 0
      then
          update config c
          set    c.configvalue = cyear
          where  c.name = 'TAXYEAR14END';
      else
          update config c
          set    c.configvalue = null
          where  c.name = 'TAXYEAR14END';
      end if;*/
end if;      
     
END;
$function$
; DROP FUNCTION public.show_xml(xml, numeric); 
CREATE OR REPLACE FUNCTION public.show_xml(p_xml xml, p_line_length numeric DEFAULT 100)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE

l_loops numeric;
l_mod   numeric;
l_xml text;

BEGIN
l_xml := p_xml.getClobVal();
l_loops := floor(length(l_xml)/50);
l_mod   := mod(length(l_xml),50);
     PERFORM  dbms_output.enable(1000000);
     for l_index in 1..l_loops loop
     PERFORM   dbms_output.put_line (substr (l_xml,1 + ((l_index - 1) * p_line_length),p_line_length));
     end loop;
     PERFORM  dbms_output.put_line (substr (l_xml,1 + ((l_loops) * p_line_length),l_mod));
END;
$function$
; DROP FUNCTION public.sinh(double precision); 
CREATE OR REPLACE FUNCTION public.sinh(double precision)
 RETURNS double precision
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT (exp($1) - exp(-$1)) / 2; $function$
; DROP FUNCTION public.snextval(text); 
CREATE OR REPLACE FUNCTION public.snextval(seq text)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$ 
begin
  return nextval(seq);
end;
$function$
; DROP FUNCTION public.spraccval17(numeric, character varying); 
CREATE OR REPLACE FUNCTION public.spraccval17(iptd_id numeric, ipsn character varying, OUT opstr text, OUT stat character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                                        
   cr cursor (sn varchar) is
    select a.arxdate, a.taxdocarx_id, a.docno, a.doc_date, a.change_date,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/TYPEPROP') kindp,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/SEQNO') seqno,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/ACCVALUE') ots,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/CIRCUMCHANGE_DATE') cdate,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/EARN_DATE') edate,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/TAXBEGINDATE') tbdate,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJNODE/FIRMOBJ[@FON = ' || sn ||
                          ']/TAXENDDATE') tedate
    from   taxdocarx a
    where  a.taxdoc_id = iptd_id
    --order by 1
    union
    select a.arxdate, a.taxdocarx_id, a.docno, a.doc_date, a.change_date,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/TYPEPROP') kindp,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/SEQNO') seqno,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/ACCVALUE') ots,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/CIRCUMCHANGE_DATE') cdate,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/EARN_DATE') edate,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/TAXBEGINDATE') tbdate,
           extractvalue(a.docdata,
                         '/TAXDOC/PROPERTY/FIRMOBJ/FIRMOBJ[@FON = ' || sn ||
                          ']/TAXENDDATE') tedate
    from   taxdocarx a
    where  a.taxdoc_id = iptd_id
    order  by 1
    
    ;
  r record;
   cro cursor (tdid numeric) is
    select o.seqno, o.firmpropobj_id
    from   firmproperty p, firmpropobj o
    where  p.taxdoc_id = tdid
    and    p.firmprop_id = o.firmproperty_id
    order  by to_number(trim(o.seqno));
  rr record;

  volds numeric;
  --vstr varchar(500);
  vstr varchar[];
  i    integer;
  j    integer;
begin
  i := 1;
  if nvl(ipsn, '0') <> '0'
  then
    volds := 0;
    --    vstr := '';
    open cr(ipsn);
    loop
      fetch cr
        into r;
      exit when not found;
      if r.ots is not null
      then
        if nvl(volds, 0.0) <> nvl(r.ots::numeric, 0.0)
        then
          vstr[i] := (rpad(r.docno, 12) || ' ~' ||
                     to_char(r.doc_date, 'dd.mm.yyyy') || ' ~' ||
                     rpad(r.seqno, 3) || ' ~' || r.kindp || ' ~' || r.edate || ' ~' ||
                     r.cdate || ' ~' ||
                     lpad(to_char(to_number(r.ots), '999999990.00'), 14) || ' ~' ||
                     r.tbdate || ' ~' || r.tedate || '@');
          --   dbms_output.put_line(opstr);
          --    vstr := vstr  || opstr || '@';
          i := i + 1;
        end if;
        volds := r.ots;
      end if;
    end loop;
    close cr;
  else
    open cro(iptd_id);
    loop
      fetch cro
        into rr;
      exit when not FOUND;
      volds := 0;
      --   dbms_output.put_line(rr.seqno);
      open cr(rr.seqno);
      loop
        fetch cr
          into r;
        exit when not FOUND;
        if r.ots is not null
        then
          if nvl(volds, 0.0) <> nvl(r.ots::numeric, 0.0)
          then
            vstr[i] := (rpad(r.docno, 12) || ' ~' ||
                       to_char(r.doc_date, 'dd.mm.yyyy') || ' ~' ||
                       rpad(r.seqno, 3) || ' ~' || r.kindp || ' ~' || r.edate || ' ~' ||
                       r.cdate || ' ~' ||
                       lpad(to_char(to_number(r.ots), '999999990.00'), 14) || ' ~' ||
                       r.tbdate || ' ~' || r.tedate || '@');
            --    vstr := vstr  || opstr || '@';
            i := i + 1;
          end if;
          volds := r.ots;
        end if;
      end loop;
      close cr;
      --    dbms_output.put_line(vstr[i]);
    end loop;
    close cro;
  end if;
  j := 1;
  if i > 1
  then
    loop
      opstr := concat(opstr, vstr[j]);
      j     := j + 1;
      exit when j = i;
    end loop;
  end if;
  -- opstr := vstr;
  stat := 'OK';
  --return;
exception
  when others then
    opstr := null;
    stat  := 'Error';
end;
$function$
; DROP FUNCTION public.str_gr(numeric); 
CREATE OR REPLACE FUNCTION public.str_gr(iptaxdocid numeric)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare
bz property.builder_zone%Type;
seez property.seezone_cat%Type;
conb property.constructionbound%Type;

return_val Numeric;

begin
  select p.builder_zone,
         p.seezone_cat,
         p.constructionbound
  into   bz, seez, conb
  from   property p
  where  p.taxdoc_id = ipTaxDocId;

  if (nvl(bz, 0.0) + nvl(seez, 0.0)) <> 0 then return_val := 1;
  else if conb = '1' then return_val := 1;
  else return_val := 2;
  end if;
  end if;

  Return return_val;

  exception
  when others then
    Return null; --'������';

end;
$function$
; DROP FUNCTION public.tanh(double precision); 
CREATE OR REPLACE FUNCTION public.tanh(double precision)
 RETURNS double precision
 LANGUAGE sql
 IMMUTABLE STRICT
AS $function$ SELECT sinh($1) / cosh($1); $function$
; DROP FUNCTION public.tax17obj(numeric); 
CREATE OR REPLACE FUNCTION public.tax17obj(ipfirmpropobj_id numeric, OUT opdnig numeric, OUT opdni numeric, OUT opstat character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
--- ����� ���������� ����� �� ����� �� ��.17
begin

  select po.taxvalue_calc, po.earntaxvalue_calc
  into   opDNI, opDNIG
  from   firmpropobj po
  where  po.firmpropobj_id = ipfirmpropobj_id;
  opstat := 'OK';
exception
  when no_data_found then
    opDNI  := 0;
    opDNIG := 0;
    opstat := '������� �����';
  when others then
    opDNI  := 0;
    opDNIG := 0;
    opstat := '������';
end;
$function$
; DROP FUNCTION public.tax61obj(numeric); 
CREATE OR REPLACE FUNCTION public.tax61obj(ippatentactivityobj_id numeric, OUT opdni numeric, OUT opstat character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
begin

select po.taxvalue_calc
 into opDNI
 from Patentactivityobj po
 where po.patentactivityobj_id = ippatentactivityobj_id
 ;
 opstat := 'OK';
  exception
  when no_data_found then
   opDNI := 0;
   opstat := '������� �����';
  when others then
   opDNI := 0;
   opstat := '������';
end;

$function$
; DROP FUNCTION public.taxtbo(numeric, numeric); 
CREATE OR REPLACE FUNCTION public.taxtbo(iptaxdoc_id numeric, iptaxperiod_id numeric, OUT optbo numeric, OUT opstat character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
--- ����� ���������� ����� �� ����� �� ��.17
begin

select sum(ds.totaltax)
 into opTBO
 from debtsubject ds, kinddebtreg r
 where ds.document_id = ipTaxDoc_id
 and ds.taxperiod_id = ipTaxPeriod_id
 and ds.kinddebtreg_id = r.kinddebtreg_id
 and r.code = '2400'
 ;
 opstat := 'OK';
  exception
  when no_data_found then
   opTBO := 0;
   opstat := '������� �����';
  when others then
   opTBO := 0;
   opstat := '������';
end;
$function$
; DROP FUNCTION public.tempdiscount(numeric, date); 
CREATE OR REPLACE FUNCTION public.tempdiscount(ipdebtinstalment numeric, ipto date)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare
 vdisc numeric;
 vtotaltax numeric;
 vpercent numeric;
 vinstno numeric;
 vtermdisc date;
 vinstnumber numeric;
 vper_id numeric;
 vdoctype_id numeric;
 vparend_id numeric;
begin
    select d.termdisc, d.percent, ty.instnumber, 
           (select sum(dd.totaltax) from debtsubject dd where dd.document_id = td.taxdoc_id
               and dd.taxperiod_id = ds.taxperiod_id
               and dd.taxsubject_id = ds.taxsubject_id
               and dd.kinddebtreg_id = ds.kinddebtreg_id), 
           di.instno, td.documenttype_id, ds.taxperiod_id, ds.parent_debtsubject_id
    into vtermdisc, vpercent, vinstnumber, vtotaltax, vinstno,
         vdoctype_id,vper_id,vparend_id
    from taxdoc td, discount d, debtinstalment di, debtsubject ds,
     documenttype ty -- taxperiod tp,
    where d.documenttype_id = td.documenttype_id
    and d.taxperiod_id = ds.taxperiod_id --tp.taxperiod_id

    and ty.documenttype_id = td.documenttype_id
  --  and td.municipality_id = ty.municipality_id
    and di.debtsubject_id = ds.debtsubject_id
    and ds.document_id = td.taxdoc_id
    and di.debtinstalment_id = ipdebtinstalment
    ;
    select count(tp.taxperiodpay_id) into vinstnumber
     from taxperiodpay tp
     where tp.taxperiod_id = vper_id
     and tp.documenttype_id = vdoctype_id
     ;

if (ipto <= vtermdisc) and (vinstno = vinstnumber) and (vparend_id is null) then
 vdisc := round(vpercent * vtotaltax / 100,2);
 else 
  vdisc := 0;
end if;
return (vdisc);
end;

$function$
; DROP FUNCTION public.to_multi_byte(text); 
CREATE OR REPLACE FUNCTION public.to_multi_byte(str text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$orafce_to_multi_byte$function$
; DROP FUNCTION public.tourist(numeric, numeric, numeric, integer); 
CREATE OR REPLACE FUNCTION public.tourist(iptaxperiod_id numeric, iptaxdoc_id numeric, ipmonth numeric, OUT opstatus character varying, ipconfirmcalc integer DEFAULT 0)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare

 cr cursor (iptouristtax_id numeric, pmonth numeric) is

 select *

  from monthlytouristtax mtt

  where mtt.touristtax_id = iptouristtax_id

  and mtt.month >= pmonth

 ;

reccr record;

  

rectaxdoc record;

rectourist  record; 

vtaxvalue numeric;

bmonth numeric;

vdebtsuject_id numeric;

vdebtinstalment_id numeric;

vtax numeric;

vpartno varchar(50);

vtermdate date;

vstoreMonthlytourisId numeric;   --����������� �� �� - �� �� ��������� ������



begin

opStatus := 'ERROR';

select * into rectaxdoc

from taxdoc td

where td.taxdoc_id = iptaxdoc_id

;

select * into rectourist

from touristtax tt 

where tt.taxdoc_id = iptaxdoc_id

;

if rectaxdoc.give_reasonreg_id = 58 then

 bmonth := to_number(to_char(rectaxdoc.begintaxdate,'MM'));

 open cr(rectourist.touristtax_id, bmonth);

 loop

 fetch cr into reccr;

 exit when not FOUND;

 vstoreMonthlytourisId := reccr.monthlytouristtax_id;

 

 vtermdate := to_date('15'|| lpad(to_char(reccr.month::integer),2,'0') ||to_char(rectaxdoc.begintaxdate,'yyyy'),'ddmmyyyy');

 vtermdate := add_months(vtermdate,1);



select max(tp.taxvalue) into vtaxvalue 
 from touristtaxprice tp, address a, municipality m
 where m.municipality_id = rectourist.location_municipality_id
 and tp.municipality_id = coalesce(m.parentmunicipality_id, m.municipality_id)

 and a.address_id = rectourist.address_id

 and  ((tp.city_id is null) or (tp.city_id = a.city_id))

 and tp.taxperiod_id = rectourist.taxperiod_id

 and tp.category_of_property = rectourist.category_of_property

 and tp.begin_date = (select max(ttp.begin_date) from touristtaxprice ttp

                      where ttp.municipality_id = tp.municipality_id

                      and  ((ttp.city_id is null) or (ttp.city_id = a.city_id))

                      and ttp.taxperiod_id = rectourist.taxperiod_id

                      and ttp.category_of_property = rectourist.category_of_property

                      and ttp.begin_date::date <= 

                      to_date('01'|| lpad(to_char(reccr.month::integer),2,'0') ||to_char(rectaxdoc.begintaxdate,'yyyy'),'ddmmyyyy')                      

                --      to_date(to_char(rectaxdoc.begintaxdate,'yyyy') || lpad(to_char(reccr.month::integer),2,'0') || '01','yyyymmdd')

                      )                    

 ;

 if vtaxvalue is null then

   --rollback;

   return;

 end if;

 vtax := round(nvl(vtaxvalue,0.0) * nvl(reccr.sleepnumber,0.0),2);

 

--isprocessed �� � ���������� �� ���� �� ����������� � Oracle, ��� ������ �� � � ���� update

 update monthlytouristtax

  set taxvalue_calc = vtax 

where monthlytouristtax_id = reccr.monthlytouristtax_id;

 

  if(ipConfirmCalc = 0) 

        then  begin

	      opStatus:='Confirm';

	      --commit;

		return;

              --exit;        --exit from loop

         end;

        end if;

 
 if vtax > 0 then

 select max(ds.debtsubject_id) into vdebtsuject_id 

  from debtsubject ds

  where ds.document_id = rectaxdoc.taxdoc_id

  ;

   if vdebtsuject_id is null then

    select nextval('s_debtsubject') into vdebtsuject_id from dual;

    insert into debtsubject 

    (debtsubject_id, taxsubject_id, document_id, kinddoc, 

    kinddebtreg_id, taxperiod_id, doccode, tax_begidate, 

    tax_enddate, relief_id, totalval, totaltax, calcdate, 

    inst_number, freesum_obj, userdate, user_id, 

    municipality_id, kindparreg_id, partidano,

    docno, doc_date)

    values

    (vdebtsuject_id, rectourist.taxsubject_id, rectaxdoc.taxdoc_id,1,

     (select k.kinddebtreg_id from kinddebtreg k where trim(k.code)='2800'),

     rectourist.taxperiod_id,'61R', rectaxdoc.begintaxdate,

    to_date('31.12.'||to_char(rectaxdoc.begintaxdate,'yyyy'),'dd.mm.yyyy'),

    null,vtax,vtax,trunc(current_date),12,0,current_date, rectaxdoc.user_id,

    rectourist.location_municipality_id, 2,rectaxdoc.partidano,rectaxdoc.docno,

    rectaxdoc.doc_date);

   else

    update debtsubject

     set totaltax = nvl(totaltax,0.0) +  vtax

    where debtsubject_id = vdebtsuject_id

    ;

   end if; 

   select nextval('s_debtinstalment') into vdebtinstalment_id from dual;

   insert into debtinstalment

   (debtinstalment_id, debtsubject_id, instno, termpay_date, 

   instsum, intbegindate, paysum) 

   values

   (vdebtinstalment_id,vdebtsuject_id,reccr.month,vtermdate,

    vtax,vtermdate+1,0)

   ;

   insert into baldebtinst

   (debtinstalment_id, instsum, interestsum, discsum)

   values

   (vdebtinstalment_id, vtax, 0, 0)

   ;
  end if;
 end loop;

 close cr;

else  -- dobawq mesec

 bmonth := ipmonth;

 open cr(rectourist.touristtax_id, bmonth);

 loop

 fetch cr into reccr;

 exit when not FOUND;



 vtermdate :=  to_date('15'|| lpad(to_char(reccr.month::integer),2,'0') ||to_char(rectaxdoc.begintaxdate,'yyyy'),'ddmmyyyy');

 vtermdate := add_months(vtermdate,1);

select max(tp.taxvalue) into vtaxvalue 

 from touristtaxprice tp, address a, municipality m
 where m.municipality_id = rectourist.location_municipality_id
 and tp.municipality_id = coalesce(m.parentmunicipality_id, m.municipality_id)

 and a.address_id = rectourist.address_id

 and  ((tp.city_id is null) or (tp.city_id = a.city_id))

 and tp.taxperiod_id = rectourist.taxperiod_id

 and tp.category_of_property = rectourist.category_of_property

 and tp.begin_date = (select max(ttp.begin_date) from touristtaxprice ttp

                      where ttp.municipality_id = tp.municipality_id

                      and  ((ttp.city_id is null) or (ttp.city_id = a.city_id))

                      and ttp.taxperiod_id = rectourist.taxperiod_id

                      and ttp.category_of_property = rectourist.category_of_property

                      and ttp.begin_date::date <=

                      to_date('01'|| lpad(to_char(reccr.month::integer),2,'0') ||to_char(rectaxdoc.begintaxdate,'yyyy'),'ddmmyyyy')

                      -- to_date(to_char(rectaxdoc.begintaxdate,'yyyy') || lpad(to_char(reccr.month::integer),2,'0') || '01','yyyymmdd')

                      );

 vtax := round(vtaxvalue * reccr.sleepnumber,2);

--isprocessed �� � ���������� �� ���� �� ����������� � Oracle, ��� ������ �� � � ���� update

 update monthlytouristtax

 set taxvalue_calc = vtax  

 where monthlytouristtax_id = reccr.monthlytouristtax_id;

 

 if(ipConfirmCalc = 0) then

  opStatus:='Confirm';

  --commit;

  return;

  --exit;        --exit from loop

 end if;

 
 if vtax > 0 then

 select max(ds.debtsubject_id) into vdebtsuject_id 

  from debtsubject ds

  where ds.document_id = rectaxdoc.taxdoc_id

  ;

  if vdebtsuject_id is null then

  select nextval('s_debtsubject') into vdebtsuject_id ;
    insert into debtsubject
    (debtsubject_id, taxsubject_id, document_id, kinddoc,
    kinddebtreg_id, taxperiod_id, doccode, tax_begidate,
    tax_enddate, relief_id, totalval, totaltax, calcdate,
    inst_number, freesum_obj, userdate, user_id,
    municipality_id, kindparreg_id, partidano,
    docno, doc_date)
    values
    (vdebtsuject_id, rectourist.taxsubject_id, rectaxdoc.taxdoc_id,1,
     (select k.kinddebtreg_id from kinddebtreg k where trim(k.code)='2800'),
     rectourist.taxperiod_id,'61R', rectaxdoc.begintaxdate,
    to_date('31.12.'||to_char(rectaxdoc.begintaxdate,'yyyy'),'dd.mm.yyyy'),
    null,vtax,vtax,trunc(sysdate),12,0,sysdate, rectaxdoc.user_id,
    rectourist.location_municipality_id, 2,rectaxdoc.partidano,rectaxdoc.docno,
    rectaxdoc.doc_date);


  else

    update debtsubject

     set totaltax = nvl(totaltax,0.0) +  vtax

    where debtsubject_id = vdebtsuject_id

    ;



   select nextval('s_debtinstalment') into vdebtinstalment_id from dual;



   insert into debtinstalment

   (debtinstalment_id, debtsubject_id, instno, termpay_date, 

   instsum, intbegindate, paysum) 

   values

   (vdebtinstalment_id,vdebtsuject_id,reccr.month,vtermdate,

   vtax,vtermdate + 1,0)

   ;

   insert into baldebtinst

   (debtinstalment_id, instsum, interestsum, discsum)

   values

   (vdebtinstalment_id, vtax, 0, 0)

   ;

  end if; 
  end if; 
 end loop;

  close cr;

  end if; 

 -- ask for confiramation for calculated values in month

if( ipConfirmCalc = 0)   then  

   begin

       opStatus:='Confirm';

       --commit;

       return;     --return from function

   end;

   end if;

 ----------------------

   if rectaxdoc.docstatus <> '30' then

      update taxdoc

       set docstatus = '30'

       where taxdoc_id = iptaxdoc_id;

   end if; 

   

    if rectaxdoc.partidano is null then



     select getpartidano(rectaxdoc.municipality_id, rectaxdoc.documenttype_id) into vpartno;

     

     if vpartno <> '-1' then

       update taxdoc

       set partidano = vpartno

       where taxdoc_id = iptaxdoc_id;

       

       update debtsubject

        set partidano = vpartno

       where document_id = iptaxdoc_id

       and partidano is null

       ;

     end if;

  end if;

 ----------------------

--marked the month as processed

--���� � �������� �� ��� 66 � ��� 144, ������ ��� reccr �� � ����...

 update monthlytouristtax

 set isprocessed = 1

 where monthlytouristtax_id = vstoreMonthlytourisId;

--commit;

opStatus:='OK';

exception 

 when others then

 --rollback;

 opStatus:='ERROR'||sqlerrm;

end;
$function$
; DROP FUNCTION public.trunc(timestamp without time zone); 
CREATE OR REPLACE FUNCTION public.trunc(tmpstamp timestamp without time zone DEFAULT now())
 RETURNS date
 LANGUAGE plpgsql
AS $function$
BEGIN
  return to_date(to_char(tmpstamp,'YYYY-MM-DD'),'YYYY-MM-DD');
END;
$function$
; DROP FUNCTION public.user_ver(character varying, character varying); 
CREATE OR REPLACE FUNCTION public.user_ver(OUT return_val character varying, ipusername character varying, ippassword character varying, OUT opfullname character varying, OUT opbegindate date, OUT openddate date, OUT opothernotes character varying, OUT opuser_id character varying, OUT opmunicipality_id numeric, OUT opparentmunicipality_id numeric, OUT opmunicipalityname character varying, OUT opmunicipalitycode numeric, OUT opdepartment_id numeric, OUT opcompany_id numeric, OUT opoffice_id numeric, OUT opcreatedbyid numeric, OUT opskin character varying, OUT opmunicipalityurl character varying, OUT opmustchangepass numeric, OUT opprovinceid numeric, OUT opprovincename character varying, OUT opprovincecode numeric, OUT opusername character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare   
  cnt              numeric;
  User_ID          Users.User_ID%type;
  UserName         Users.Username%type;
  Municipality_ID  Users. Municipality_ID%type;
  ParentMunicipality_ID Municipality.Parentmunicipality_Id%type;
  Department_ID    Users.Department_ID%type;
  Company_ID       Users.Company_ID%type;
  Office_ID        Users.Office_ID%type;
  MunicipalityName Municipality.FullName%type;
  MunicipalityCode Municipality.Ebk_Code%type;
  MunicipalityUrl  Municipality.Url%type;
  ProvinceId       province.province_id%type;
  ProvinceName     province.name%type;
  ProvinceCode     province.code%type;
  BeginDate        Users.Begin_Date%type;
  EndDate          Users.End_Date%type;
  PssWrd           Users.Password%type;
  FullName         Users.FullName%type;
  Other            Users.Other%type;
  FaultCounter     Users.FaultCounter%type;
  Logged           Users.Logged%type;
  AccessDenied     Users.Accessdenied%type;
  CreatedByID      Users.Createdby_Id%type;
  Skin             Users.Skin%type;
  MustChangePass   Users.Mustchangepass%type;

begin
  --???????? ?? ?????????? ?? ??????????????? ???
  select count(*)
  into   cnt
  from   Users u
  where  upper(u.username) = upper(ipUserName);

  if cnt < 1
  then
    return_val := 'noUser';
    return;
  elsif cnt > 1
  then
    return_val := 'manyUsers';
    return;
  else
  
    select u.user_id, u.username, u.municipality_id, u.department_id,
           u.company_id, u.office_id, mu.fullname, mu.ebk_code, mu.url, nvl(mu.parentmunicipality_id, -1.0),
           p.province_id, p.name, p.code, u.begin_date, u.end_date, u.password,
           u.fullname, u.other, u.faultcounter, u.logged, u.accessdenied,
           u.createdby_id, u.skin, nvl(u.mustchangepass, 0.0)
    into   User_ID, UserName, Municipality_ID, Department_ID, Company_ID,
           Office_ID, MunicipalityName, MunicipalityCode, MunicipalityUrl,ParentMunicipality_ID,
           ProvinceId, ProvinceName, ProvinceCode, BeginDate, EndDate, PssWrd,
           FullName, Other, FaultCounter, Logged, AccessDenied, CreatedByID,
           skin, MustChangePass
    from   Users u, Municipality mu, Province p
    where  upper(u.username) = upper(ipUserName)
    and    u.municipality_id = mu.municipality_id
    and    mu.province_id = p.province_id;
  
  
  
    if nvl(AccessDenied, 0.0) > 0
    then
      return_val := 'accessDenied';
      return;
    else
    
      --???????? ?? ???????? ??????
      if nvl(FaultCounter, 0.0) > 4
      then
        return_val := 'blocked';
        return;
      else
      
        --???????? ?? ?????????? ?? ?????????? ??????
        if (upper(ipPassWord) <> upper(PssWrd) or (ipPassWord is null))
        then
          update Users u
          set    faultcounter = nvl(u.faultcounter, 0.0) + 1,
                 faultdate = localtimestamp
          where  upper(u.username) = upper(ipUserName);
          return_val := 'badPassword';
          return;
        else
        
          --???????? ?? ?????????? ?? login-a
          --        if nvl(Logged, 0) > 0 then
          --            Return('logged');
          --        else
        
          --???????? ?? ????????? ?? ???????
          if opBeginDate > current_date
          then
            return_val := 'stillUnactive';
            return;
          elsif opEndDate < current_date
          then
            return_val := 'alreadyUnactive';
            return;
          else
            opUserName         := UserName;
            opFullName         := FullName;
            opBeginDate        := BeginDate;
            opEndDate          := EndDate;
            opOtherNotes       := Other;
            opUser_ID          := User_ID;
            opMunicipality_ID  := Municipality_ID;
            opParentMunicipality_ID := ParentMunicipality_ID;
            opMunicipalityName := MunicipalityName;
            opMunicipalityCode := MunicipalityCode;
            opDepartment_ID    := Department_ID;
            opCompany_ID       := Company_ID;
            opOffice_ID        := Office_ID;
            opCreatedByID      := CreatedByID;
            opSkin             := Skin;
            opMunicipalityUrl  := MunicipalityUrl;
            opMustChangePass   := MustChangePass;
            opProvinceId       := ProvinceId;
            opProvinceName     := ProvinceName;
            opProvinceCode     := ProvinceCode;
          
            --???????? ?? ????????
            update Users u
            set    faultcounter = 0, logged = 1
            where  upper(u.username) = upper(ipUserName);
          	return_val :='OK';
            return;
          end if;
          -- end if;
        end if;
      end if;
    end if;
  end if;
end ;
$function$
; DROP FUNCTION public.wordwrap(character varying, integer, integer); 
CREATE OR REPLACE FUNCTION public.wordwrap(OUT return_val character varying, str character varying, ipos integer, nl integer, OUT strrest character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare                                    
  i   integer;
  j   integer;
  s   varchar(32767);
  Res varchar[];
begin
  i := 0;
  if Length(trim(Str)) > ipos
  then
    s := trim(' ' from Str);
    for i in 1 .. nl
    loop
      j := 1;
      if (Length(s) > ipos)
      then
        while (instr(s, ' '::varchar, 1, j) < ipos) and (instr(s, ' ', 1, j) > 0)
        loop
          j := j + 1;
        end loop;
      else
        Res[i] := s;
        StrRest := '';
        return_val := Res[i];
        return;
      end if;
      Res[i] := SubStr(s, 1, instr(s, ' ', 1, j - 1));
      if Length(s) > 1
      then
        s := SubStr(s, instr(s, ' ', 1, j - 1), Length(s)); -->> s = �������� �� Str
      else
        s := '';
      end if;
    end loop;
    StrRest := s;
    return_val := Res[nl]
    return;
  else
    StrRest := '';
    return_val := Str;
    return;
  end if;
end ;
$function$
; DROP FUNCTION public.firmprop14(numeric, date, date, numeric, integer, integer); 
CREATE OR REPLACE FUNCTION public.firmprop14(iptaxdoc_id numeric, ipfromdate date, iptodate date, ipuser_id numeric, ipoblwr integer, OUT ipstatus character varying, ipflrec integer)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  crfirmprop cursor  is
    select p.*
    from   property p
    where  p.taxdoc_id = iptaxdoc_Id;

  rfirmprop record;

  crfirmbuiding cursor (ipproperty_id numeric) is
    select *
    from   building b
    where  b.property_id = ipproperty_id;
  rfirmbuilding record;

 crfirmobj cursor (ipbuilding_id numeric) is
    select ho.*, t.firmobj14_id, t.kindobj, t.typeprop, t.kindowner,
           t.function firmfunc, t.seqnoobject seqno, t.taxfreereason, t.accvalue,
           t.accvalue accvalueTBO
    from   homeobj ho left outer join  firmobj14 t on ho.homeobj_id = t.homeobj_id
    where   ho.building_id = ipbuilding_id;
  rowfirmobj record;

  rowtaxdoc              taxdoc%rowtype;
  rfirmobj14             firmobj14%rowtype;
  rfirmobj14_accvalueTBO numeric;
  rland                  Land%rowtype;

  rgrouptbo          grouptbo%rowtype;
  vcity_id           numeric;
  vcity0_id          numeric;
  flfree             integer;
  vtaxperiod_id      numeric;
  vhomeprom          numeric;
  vnohomeprom        numeric;
  i                  integer;
  vgrouptbo_id       numeric;
  rprtbo             promtbo%rowtype;
  vtaxdoc71_id       numeric;
  vtaxdoc19_id       numeric;
  vtaxtbo            numeric;
  vodateb            date;
  vodatee            date;
  brmes              integer;
  brmesfree          integer;
  vtaxvalobj         numeric;
  vearntaxvalobj     numeric;
  vtaxtboobj         numeric;
  vtaxval            numeric;
  vearntaxval        numeric;
  vdoccode           varchar(20);
  vinst_number       integer;
  vtbodebtsubject_id numeric;
  vdebtsubject_id    numeric;
  vdpproperty_id     numeric;
  vdptbo_id          numeric;
  nv                 integer;
  sumzad             numeric;
  vfreesumobj        numeric;
  vtaxtbofree        numeric;
  vtbofreeobj        numeric;
  vtaxvalfree        numeric;
  vearnval           numeric;
  vearnvalobj        numeric;
  vearnvalTBO        numeric;
  vearnvalTBOobj     numeric;
  vearntboobj        numeric;
  perbdate           date;
  peredate           date;
  vtaxyear           numeric;
 -- flfirsy            numeric;
  vsw_missing        numeric;
  vclean_missing     numeric;
  vdepot_missing     numeric;
  oldds_id           numeric;
  oldtbods_id        numeric;
  vmindo             numeric;
  vCurYear           varchar(10);
  vparreg            numeric;
  vaccvalueo         numeric;
  vdecltbo           numeric;
  vmunicipality_id   numeric;
  vsumacc            numeric;
  vgarbtax19         numeric;
  vgarbtax71         numeric;
  vdocst             varchar(20);
  vadmregion_id      numeric;
  invsumtbo          numeric;
  sumtbo             numeric;
  invsum             numeric;
  vminp              integer;
  --vho_kindobj        varchar(10);
  --vho_obj_id         numeric;
  errmess            varchar(200);
  vbuildkf           varchar(10);
  vDOhomeobj         numeric;
  XX                 varchar(200);
  --vnocorect          numeric;
  vnorminst          numeric;
  vdiv               numeric;
  kindcalTBO         varchar(2);
  vsumaccTBO         numeric;
  vaccvalueTBO       numeric;
  vownerp          numeric;
  vtypedeclar      integer;
  vSUBJPARTVAL     numeric;
  vdebtinst_id     numeric;
  vlanddeclar      integer;
  vfsw             numeric;
  vfclean          numeric;
  vfdepot          numeric;
  r record;
  ----------- MAIN -----------------
begin
if ipoblwr is null then ipoblwr := 0;
end if;
  select c.configvalue
  into   vCurYear
  from   config c
  where  name = 'TAXYEAR14'; ---- ?????

  select *
  into   rowtaxdoc
  from   taxdoc td
  where  td.taxdoc_id = iptaxdoc_Id;
  select min(ds.debtsubject_id)
  into   vdebtsubject_id
  from   debtsubject ds, taxdoc td
  where  ds.document_id = iptaxdoc_Id
  and    ds.document_id = td.taxdoc_id
  and    COALESCE(ds.docno, '*') = COALESCE(td.docno, '*')
  and    COALESCE(ds.doc_date, current_date) = COALESCE(td.doc_date, current_date)
  and    ds.doc_date = td.doc_date
  and    ds.taxperiod_id =
         (select tp.taxperiod_id
           from   taxperiod tp
           where  to_char(tp.begin_date, 'yyyy') = to_char(ipFromDate::date, 'yyyy')
           and    tp.taxperkind = '0');

  if (vdebtsubject_id is not null) and (COALESCE(rowtaxdoc.close_taxdoc_id, 0.0) <> 1.0)
  then
    ipStatus := 'errEndProcess'; --'���� �������� �������� ' || iptaxdoc_Id ;
    return;
  end if;

  vTaxYear := to_number(to_char(ipFromDate, 'yyyy'));
  if vtaxyear > vCurYear::numeric
  then
    ipStatus := 'errNoDuty';
    return;
  end if;
  select c.configvalue
  into   vCurYear
  from   config c
  where  name = 'TAXYEAR';

  while vTaxYear <= to_number(to_char(ipToDate, 'yyyy'))
  loop
    select min(c.configvalue)
    into   kindcalTBO
    from   config c
    where  c.name = 'TBO17OTCHET' || to_char(vTaxYear);
    select min(tp.taxperiod_id)
    into   vtaxperiod_id
    from   taxperiod tp
    where  to_char(tp.begin_date, 'yyyy') = vTaxYear::varchar;
    vtaxval     := 0.0;
    vearntaxval := 0.0;
    vtaxtbo     := 0.0;
    vtaxvalfree := 0.0;
    vtaxtbofree := 0.0;
    vearnval    := 0.0;
    vearnvalTBO := 0.0; --- 18.07
  
    if vTaxYear < to_number(vcuryear)
    then
      vparreg := 3;
    else
      vparreg := 2;
    end if;
  
    perbdate := to_date('01.01.' || to_char(vTaxYear), 'dd.mm.yyyy');
    if perbdate < ipFromDate
    then
      perbdate := ipFromDate;
    end if;
    peredate := to_date('31.12.' || to_char(vTaxYear), 'dd.mm.yyyy');
    if peredate > ipToDate
    then
      peredate := ipToDate;
    end if;
  
    select dt.doccode
    into   vdoccode
    from   documenttype dt
    where  dt.documenttype_id = rowtaxdoc.documenttype_id
    -- and dt.municipality_id = rowtaxdoc.municipality_id
    ;
	vdebtsubject_id := nextval('s_debtsubject');
    vtbodebtsubject_id := nextval('s_debtsubject');
    /*select s_debtsubject.nextval
    into   vtbodebtsubject_id
    from   dual;*/
    ------------------
    insert into debtsubject
      (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,
       taxperiod_id, doccode, tax_begidate, tax_enddate, relief_id, Totalval,
       Totaltax, calcdate, FreeSum_obj, prtdate, inst_number, FreeSum_Subj,
       corr_instnumber, codetbo, corr_sumtotal, userdate, user_id, TAXOBJECT_ID,
       PARTIDANO, MUNICIPALITY_ID, KINDPARREG_ID, PAYDISCSUM, DOCNO, DOC_DATE,
       PARENT_DEBTSUBJECT_ID)
    values
      (vdebtsubject_id, rowtaxdoc.taxsubject_id, iptaxdoc_Id, 1, 2,
       vtaxperiod_id, vdoccode, perbdate, peredate, null, null, null,
       current_date, null, null, null, null, null, null, null, current_timestamp,
       ipuser_id, rowtaxdoc.taxobject_id, rowtaxdoc.partidano,
       rowtaxdoc.municipality_id, vparreg, null, rowtaxdoc.docno,
       rowtaxdoc.doc_date, null);
    insert into debtsubject
      (debtsubject_id, taxsubject_id, document_id, kinddoc, kinddebtreg_id,
       taxperiod_id, doccode, tax_begidate, tax_enddate, relief_id, Totalval,
       Totaltax, calcdate, FreeSum_obj, prtdate, inst_number, FreeSum_Subj,
       corr_instnumber, codetbo, corr_sumtotal, userdate, user_id, TAXOBJECT_ID,
       PARTIDANO, MUNICIPALITY_ID, KINDPARREG_ID, PAYDISCSUM, DOCNO, DOC_DATE,
       PARENT_DEBTSUBJECT_ID)
    values
      (vtbodebtsubject_id, rowtaxdoc.taxsubject_id, iptaxdoc_Id, 1, 5,
       vtaxperiod_id, vdoccode, perbdate, peredate, null, null, null,
       current_date, null, null, null, null, null, null, null, current_timestamp,
       ipuser_id, rowtaxdoc.taxobject_id, rowtaxdoc.partidano,
       rowtaxdoc.municipality_id, vparreg, null, rowtaxdoc.docno,
       rowtaxdoc.doc_date, null);
  
  
    ------------------
    open crfirmprop;
    loop
      -- firmprop
      fetch crfirmprop
        into rfirmprop;
      exit when not FOUND;
      select a.city_id, a.admregion_id
      into   vcity_id, vadmregion_id
      from   address a, property p
      where  a.address_id = p.property_address_id
      and    p.property_id = rfirmprop.property_id;
      ---------------------   danni za DNI
      select COALESCE(m.parentmunicipality_id, m.municipality_id)
      into   vmunicipality_id
      from   municipality m
      where  m.municipality_id = rowtaxdoc.municipality_id;
      select min(pp.typedeclar) into vtypedeclar
      from partproperty pp
      where pp.property_id = rfirmprop.property_id
      and pp.taxsubject_id = rowtaxdoc.taxsubject_id
      ;
      select min(homeprom), min(nohomeprom)
      into   vhomeprom, vnohomeprom
      from   (select nd.homeprom, nd.nohomeprom
               from   normdni nd
               where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id
               and    nd.city_id = vcity_id
               and    nd.code = '99'
               and    nd.calctype = '1'
               and    nd.taxperiod_id = vtaxperiod_id
               union
               select nd.homeprom, nd.nohomeprom
               from   normdni nd
               where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id
               and    nd.city_id = vcity_id
               and    nd.code = '99'
               and    nd.calctype = '0'
               and    nd.taxperiod_id = vtaxperiod_id
               union
               select nd.homeprom, nd.nohomeprom
               from   normdni nd
               where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id
               and    nd.city_id = vcity_id
               and    nd.code = '99'
               and    nd.calctype = '2'
               and    nd.taxperiod_id = vtaxperiod_id) a;
      if vhomeprom is null
      then
        select min(homeprom), min(nohomeprom)
        into   vhomeprom, vnohomeprom
        from   (select nd.homeprom, nd.nohomeprom
                 from   normdni nd, city c
                 where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id
                 and    nd.city_id = 0
                 and    nd.code = '99'
                 and    nd.calctype = '1'
                 and    nd.taxperiod_id = vtaxperiod_id
                 union
                 select nd.homeprom, nd.nohomeprom
                 from   normdni nd
                 where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id
                 and    nd.city_id = 0
                 and    nd.code = '99'
                 and    nd.calctype = '0'
                 and    nd.taxperiod_id = vtaxperiod_id
                 union
                 select nd.homeprom, nd.nohomeprom
                 from   normdni nd
                 where  nd.municipality_id = vmunicipality_id --rowtaxdoc.municipality_id
                 and    nd.city_id = 0
                 and    nd.code = '99'
                 and    nd.calctype = '2'
                 and    nd.taxperiod_id = vtaxperiod_id) a;
      end if;
      vtaxtbo    := 0.0;
      vsumaccTBO := 0.0;
      vsumacc    := 0.0;
      open crfirmbuiding(rfirmprop.property_id);
      vaccvalueo := 0.0;
      loop
        -- firmobj
        fetch crfirmbuiding
          into rfirmbuilding;
        exit when not found;
        open crfirmobj(rfirmbuilding.building_id);
        loop
          fetch crfirmobj
            into rowfirmobj;
          exit when not found;
          if ((rowfirmobj.taxenddate is null) or
             (rowfirmobj.taxenddate > perbdate)) and
             (COALESCE(rowfirmobj.taxbegindate,
                  to_date('01.' ||
                           to_char(add_months(COALESCE(rowfirmobj.earn_date, ipFromDate),
                                              1), 'mm.yyyy'), 'dd.mm.yyyy')) <
             peredate)
          then
            --              if rowfirmobj.firm1417_obj_id is not null
            --              then
            select min(fo.firmobj14_id)
            into   rfirmobj14.firmobj14_id
            from   firmobj14 fo
            where  fo.homeobj_id = rowfirmobj.homeobj_id;
            if rfirmobj14.firmobj14_id is not null
            then
              select *
              into   rfirmobj14
              from   firmobj14 fo
              where  fo.homeobj_id = rowfirmobj.homeobj_id;
              XX := null;
              select max(b.kindfunction)
                  into   vbuildkf
                  from   homeobj h left join  building b on  h.building_id = b.building_id
                  where  h.homeobj_id = rowfirmobj.homeobj_id
                  ;
                  if to_number(to_char(perbdate, 'yyyy')) > 2010
                  then
                  /* taxvaluation.TaxValHome(errmess, rowfirmobj.homeobj_id,
                             to_date('01.01.' || to_char(perbdate, 'yyyy'),
                                      'dd.mm.yyyy'), vbuildkf, vDOhomeobj, XX); */
                   r := taxvaluation.TaxValHome(/*errmess,*/  rowfirmobj.homeobj_id,
                             to_date('01.01.' || to_char(perbdate, 'yyyy'),
                                      'dd.mm.yyyy'), vbuildkf/*, vDOhomeobj, XX*/);
		  errmess := r.return_val;
		  vDOhomeobj := r.vgroupe;
		  XX := r.opmess;                    
                 if errmess <> 'OK'
                  then
                    vDOhomeobj := 0;
                  end if;
                  vownerp :=  ownerpart(rowtaxdoc.taxsubject_id::integer,'2',rowfirmobj.homeobj_id::integer,peredate);
                  vDOhomeobj := vDOhomeobj * vownerp;
                  if vownerp = 0 then rfirmobj14.accvalue := 0; end if;  --- 15.05.2012
                  if vDOhomeobj > rfirmobj14.accvalue
                  then
                    rfirmobj14.accvalue := vDOhomeobj;
                  end if;
                end if;
--              end if;
              vsumacc := vsumacc + rfirmobj14.accvalue;
              if COALESCE(kindcalTBO, '0') = '1' then
                vsumaccTBO := vsumaccTBO + rowfirmobj.accvaluetbo;
              else
                vsumaccTBO := vsumaccTBO + rowfirmobj.accvalue;
              end if;
            end if;
           end if;
          --------------------------------         
        end loop;
        close crfirmobj;
      end loop; --- Building
      close crfirmbuiding;
      select min(l.land_id)
      into   rland.land_id
      from   land l
      where  l.property_id = rfirmprop.property_id;
      if rland.land_id is not null
      then
        select *
        into   rland
        from   land l
        where  l.property_id = rfirmprop.property_id;
        select min(fo.firmobj14_id)
        into   rfirmobj14.firmobj14_id
        from   firmobj14 fo
        where  fo.land_id = rland.land_id;
        if rfirmobj14.firmobj14_id is not null
        then
          select *
          into   rfirmobj14
          from   firmobj14 fo
          where  fo.land_id = rland.land_id;
          xx := null;  
            if to_char(perbdate, 'yyyy')::integer > 2010
                then
                  r := taxvaluation.TaxValLand(/*errmess,*/  rland.land_id,
                                 to_date('01.01.' || to_char(perbdate, 'yyyy'),
                                          'dd.mm.yyyy')/*, vDOhomeobj, XX*/);
		  errmess := r.return_val;
		  vDOhomeobj := r.vgroupe;
		  XX := r.opmess;          
                  if errmess <> 'OK'
                  then
                    vDOhomeobj := 0;
                  end if;
                 vownerp :=  ownerpart(rowtaxdoc.taxsubject_id::integer,'1',rland.land_id::integer,peredate); 
                 vDOhomeobj := vDOhomeobj * vownerp;
                  if vownerp = 0.0 then rfirmobj14.accvalue := 0.0; end if;  --- 15.05.2012
                  if vDOhomeobj > rfirmobj14.accvalue
                  then
                    rfirmobj14.accvalue := vDOhomeobj;
                  end if;
            end if;           
           rfirmobj14_accvaluetbo := rfirmobj14.accvalue;
            end if;
            vsumacc := vsumacc + rfirmobj14.accvalue;
            if coalesce(kindcalTBO, '0') = '1' then
              vsumaccTBO := vsumaccTBO + rfirmobj14_accvaluetbo;
            else
              vsumaccTBO := vsumaccTBO + rfirmobj14.accvalue;
            end if;
     end if;
      ------------------------------
      ------------  ���� -- ����� �� ��� 
      select max(gt.garbtax_id), max(td.taxdoc_id),
             (case when max(gt.sw_missing) =  1.0 then 0.0 else 1.0 end),
             (case when max(gt.clean_missing)=  1.0 then 0.0 else 1.0 end),
             (case when max(gt.depot_missing)=  1.0 then 0.0 else 1.0 end)
      into   vgarbtax71, vtaxdoc71_id, vsw_missing, vclean_missing,
             vdepot_missing
      from   garbtax gt, taxdoc td
      where  td.taxdoc_id = gt.taxdoc_id
      and    td.documenttype_id =
             (select t.documenttype_id
               from   documenttype t
               where  t.doccode = '71')
      and    gt.proptaxdoc_id = iptaxdoc_Id
      and    gt.taxperiod_id = vtaxperiod_id
      and    td.docstatus <> '70' and td.docstatus <> '90'
      and    COALESCE(gt.isforobject,0) <> 1
      ;
      if vtaxdoc71_id is not null
      then
        select td.docstatus
        into   vdocst
        from   taxdoc td
        where  td.taxdoc_id = vtaxdoc71_id;
        if vdocst = '10'
        then
          update taxdoc 
          set    docstatus = '30'
          where  taxdoc_id = vtaxdoc71_id;
          execute taxvaluation.arxdoc(vtaxdoc71_id);
        end if;
      end if;
      select max(gt.garbtax_id), max(td.taxdoc_id)
      into   vgarbtax19, vtaxdoc19_id
      from   garbtax gt, taxdoc td
      where  td.taxdoc_id = gt.taxdoc_id
      and    td.documenttype_id =
             (select t.documenttype_id
               from   documenttype t
               where  t.doccode = '19')
      and    gt.proptaxdoc_id = iptaxdoc_Id
      and    gt.taxperiod_id = vtaxperiod_id
      and    td.docstatus <> '90';
      if vtaxdoc19_id is not null
      then
        select td.docstatus
        into   vdocst
        from   taxdoc td
        where  td.taxdoc_id = vtaxdoc19_id;
        if vdocst = '10'
        then
          update taxdoc 
          set    docstatus = '30'
          where  taxdoc_id = vtaxdoc19_id;
         perform taxvaluation.arxdoc(vtaxdoc19_id);
        end if;
      end if;
    
      select max(g.grouptbo_id)
      into   vgrouptbo_id
      from   propgrouptbo g
      where  g.taxdoc_id = rowtaxdoc.taxdoc_id
            --- ?????? ------
      and    COALESCE(g.enddate, perbdate) >= perbdate
      and    g.begindate =
             (select max(pg.begindate)
               from   propgrouptbo pg
               where  pg.begindate <= perbdate
               and    pg.taxdoc_id = rowtaxdoc.taxdoc_id)
      
      ;
      select count(*)
      into   i
      from   promtbo t
      where  t.municipality_id = vmunicipality_id
      and    t.taxperiod_id = vtaxperiod_id
      and    t.city_id = 0;
      vcity0_id := vcity_id;
      if i > 0
      then
        vcity0_id := 0;
      end if;
      select pt.*
      into   rprtbo
      from   promtbo pt
      where  pt.city_id = vcity0_id
      and    pt.taxperiod_id = vtaxperiod_id
      and    pt.calctype = '0'
      and    pt.code = '1'
      union
      select pt.*
      from   promtbo pt
      where  pt.city_id = vcity0_id
      and    pt.taxperiod_id = vtaxperiod_id
      and    pt.calctype in ('6')
      and    pt.code = '1'
      and    (vgarbtax19 is not null or (vsumaccTBO <= 0.01)) --- 18.07
      union
      select pt.*
      from   promtbo pt
      where  pt.city_id = vcity0_id
      and    pt.taxperiod_id = vtaxperiod_id
      and    pt.calctype in ('6')
      and    pt.code = (select max(pp.code)
                        from   promtbo pp
                        where  pp.city_id = vcity0_id
                        and    pp.taxperiod_id = vtaxperiod_id
                        and    pp.calctype in ('6')
                        and    pp.fromvalue < vsumaccTBO) --- 18.07
      and    vgarbtax19 is null
      
      union
      --- ���������/�����������
      select pt.*
      from   promtbo pt
      where  pt.city_id = vcity0_id
      and    pt.taxperiod_id = vtaxperiod_id
      and    pt.calctype in ('1', '2')
      and    pt.code::integer =
            (select (CASE WHEN vgrouptbo_id is null THEN 2 - count(l.land_id) ELSE 2 END)
                 from   land l, property p
                 where  coalesce(l.builtuparea, 0.0) = 0.0
                 and    l.property_id = p.property_id
                 and    p.taxdoc_id = iptaxdoc_Id
                 and    p.kindproperty = '1')
   union
      select pt.*
      from   promtbo pt
      where  pt.city_id = vcity0_id
      and    pt.taxperiod_id = vtaxperiod_id
      and    pt.calctype in ('4', '7')
      and    pt.code::integer =
           (select (CASE WHEN vgrouptbo_id is null THEN 2 - count(l.land_id) ELSE 2 END)
                 from   land l, property p
                 where  coalesce(l.builtuparea, 0) = 0
                 and    l.property_id = p.property_id
                 and    p.taxdoc_id = iptaxdoc_Id
                 and    p.kindproperty = '1')
      and    (vgarbtax19 is not null or (vsumaccTBO <= 0.01)) --- 18.07
      union
      select pt.*
      from   promtbo pt
      where  pt.city_id = vcity0_id
      and    pt.taxperiod_id = vtaxperiod_id
      and    pt.calctype in ('4', '7')
      and    pt.code = (select max(pp.code)
                        from   promtbo pp
                        where  pp.city_id = vcity0_id
                        and    pp.taxperiod_id = vtaxperiod_id
                        and    pp.calctype in ('4', '7')
                        and    pp.fromvalue < vsumaccTBO) --- 18.07
      and    vgarbtax19 is null
      union
      --- � ��������� / ����� ���������
      select pt.*
      from   promtbo pt
      where  pt.city_id = vcity0_id
      and    pt.taxperiod_id = vtaxperiod_id
      and    pt.calctype in ('3')
      and    pt.code = '1'
      and    (vgarbtax19 is not null or (vsumaccTBO <= 0.01)) --- 18.07
       union
      select pt.*
      from   promtbo pt
      where  pt.city_id = vcity0_id
      and    pt.taxperiod_id = vtaxperiod_id
      and    pt.calctype in ('5')
      and    pt.code = (case when vgarbtax19 is null then (case when rfirmprop.constructionbound = '2' then '2' else '1' end) else '1' end)
     union
      select pt.*
      from   promtbo pt
      where  pt.city_id = vcity0_id
      and    pt.taxperiod_id = vtaxperiod_id
      and    pt.calctype in ('3')
      and    pt.code = (select max(pp.code)
                        from   promtbo pp
                        where  pp.city_id = vcity0_id
                        and    pp.taxperiod_id = vtaxperiod_id
                        and    pp.calctype in ('3')
                        and    pp.fromvalue < vsumaccTBO) --- 18.07
            and    vgarbtax19 is null
            union
            select pt.*
            from   promtbo pt
            where  pt.city_id = vcity0_id
            and    pt.taxperiod_id = vtaxperiod_id
            and    pt.calctype in ('8')
            and    pt.code =
           (select (case when ((count(l.land_id) = 1) and ( rfirmprop.constructionbound = '2')) then '4'  --  nezastroen
                     when count(l.land_id) <> 1 and  rfirmprop.constructionbound = '2' then '3'         -- v izvan regulaciq            
                     when count(l.land_id) = 1 and rfirmprop.constructionbound <> '2' then '2' 
                     when count(l.land_id) <> 1 and rfirmprop.constructionbound <> '2' then '1' end) 
                 from   land l, property p
                 where  COALESCE(l.builtuparea, 0) = 0
                 and    l.property_id = p.property_id
                 and    p.taxdoc_id = iptaxdoc_Id
                 and    p.kindproperty = '1')
            ;
      
      if rprtbo.calctype = '4' and vgrouptbo_id is null and
         rfirmprop.kindproperty = '1'
      then
        rprtbo.sw_home  := 0;
        rprtbo.sw       := 0;
        rprtbo.fsw_home := 0;
        rprtbo.fsw      := 0;
      end if;
      if rprtbo.calctype = '7' and vgrouptbo_id is null and
         rfirmprop.kindproperty = '1'
      then
        select (case when pt.fsw = 0 then 0 else rprtbo.fsw end),
               (case when pt.fclean = 0 then 0 else rprtbo.fclean end),
               (case when pt.fdepot = 0 then 0 else rprtbo.fdepot end)
        into   rprtbo.fsw, rprtbo.fclean, rprtbo.fdepot
        from   promtbo pt
        where  pt.city_id = vcity0_id
        and    pt.taxperiod_id = vtaxperiod_id
        and    pt.calctype in ('7')
        and    pt.code = 1;
      end if;
      /*  select sum(COALESCE(o.accvalue,0)) into vaccvalue
      from firmpropobj o
      where o.firmproperty_id = rfirmprop.firmprop_id
       ; */
      if (COALESCE(rprtbo.minvalue, 0.0) > 0) and
         (((rprtbo.minvalue / vsumaccTBO) * 1000) - rprtbo.fsw - --- 18.07
         rprtbo.fclean - rprtbo.fdepot > 0)
      then
        rprtbo.fsw := ((rprtbo.minvalue / vsumaccTBO) * 1000) - --- 18.07
                      rprtbo.fclean - rprtbo.fdepot;
      end if;
      if vgrouptbo_id is not null
      then
        select *
        into   rgrouptbo
        from   grouptbo gt
        where  gt.grouptbo_id = vgrouptbo_id;
        if COALESCE(rgrouptbo.tbo_code, '0') <> '9'
        then
          rprtbo.fsw      := rprtbo.fsw * coalesce(rgrouptbo.issw, 0);
          rprtbo.fclean   := rprtbo.fclean * coalesce(rgrouptbo.isclean, 0);
          rprtbo.fdepot   := rprtbo.fdepot * coalesce(rgrouptbo.isdepot, 0);
          rprtbo.tbo_code := rgrouptbo.tbo_code;
        else
          rprtbo.fsw      := coalesce(rgrouptbo.issw, 0);
          rprtbo.fclean   := coalesce(rgrouptbo.isclean, 0);
          rprtbo.fdepot   := coalesce(rgrouptbo.isdepot, 0);
          rprtbo.tbo_code := rgrouptbo.tbo_code;
        end if;
      end if;
      ----------------------
      if vgarbtax71 is not null
      then
        rprtbo.fsw    := rprtbo.fsw * coalesce(vsw_missing, 0);
        rprtbo.fclean := rprtbo.fclean * coalesce(vclean_missing, 0);
        rprtbo.fdepot := rprtbo.fdepot * coalesce(vdepot_missing, 0);
        --    rprtbo.fsw_home := 0;
        --    rprtbo.fsw := 0;
      end if;
      --   vtaxtbo := 0;
      if vgarbtax19 is not null
      then
        select sum(gt.container_number * coalesce(gt.frequency, 1) *
                    (select coalesce(min(cn.value), 0) *
                             (case when min(cn.kindvalue) = '2' then 12 else 1 end)
                     from   containernorm cn
                     where  cn.containernorm_id = gt.containernorm_id
                     /*          and cn.taxperiod_id = vtaxperiod_id
                     and cn.city_id = vcity_id
                     and ((cn.admregion_id is null) or (cn.admregion_id = vadmregion_id))
                     */
                     ))
        into   vdecltbo
        from   garbtax gt
        where  gt.taxdoc_id = vtaxdoc19_id;
        if ((vgrouptbo_id is null) or (COALESCE(rgrouptbo.tbo_code, '0') <> '9'))
        then
          rprtbo.fsw    := 0;
          rprtbo.fdepot := 0;
        end if;
      end if;
      ---------------------  end danni za TBO
      -- opDNI := round(vnohomeprom * rowfirmobj.accvalue/1000,2);
	if rprtbo.calctype in ('2', '4')
      then
        if rfirmobj14.kindowner = '2' and rfirmprop.kindproperty = '1'
        --- and  COALESCE(rfirmobj14.ispublic, 0) <> 1
        then
          select pt.*
          into   rprtbo
          from   promtbo pt
          where  pt.city_id = vcity0_id
          and    pt.taxperiod_id = vtaxperiod_id
          and    pt.calctype in ('2', '4')
          and    pt.code = '3';
        end if;
        if rfirmobj14.kindowner = '2'
        -- and COALESCE(rfirmobj14.ispublic, 0) = 1
        then
          select pt.*
          into   rprtbo
          from   promtbo pt
          where  pt.city_id = vcity0_id
          and    pt.taxperiod_id = vtaxperiod_id
          and    pt.calctype in ('2', '4')
          and    pt.code = '4';
        end if;
      end if;
    
      ------------  ����� �� ���
      ------------------------------
      --open crfirmbuiding(rfirmprop.property_id);
      ipstatus := rfirmprop.property_id::varchar;
     -- open crfirmbuiding(rfirmprop.property_id::numeric);
     for rfirmbuilding in (select * from building b where b.property_id = rfirmprop.property_id)
      loop
        -- firmobj
    --    fetch crfirmbuiding
    --      into rfirmbuilding;
   --     exit when not found;
--        open crfirmobj(rfirmbuilding.building_id);
for rowfirmobj in (select ho.*, t.firmobj14_id, t.kindobj, t.typeprop, t.kindowner,
           t.function firmfunc, t.seqnoobject seqno, t.taxfreereason, t.accvalue,
           t.accvalue accvalueTBO
    from   homeobj ho left outer join  firmobj14 t on ho.homeobj_id = t.homeobj_id
    where   ho.building_id = rfirmbuilding.building_id)
        loop
--          fetch crfirmobj
--            into rowfirmobj;
--          exit when  not found;
          -- firmobj
          if ((rowfirmobj.taxenddate is null) or
             (rowfirmobj.taxenddate > perbdate)) and
             (COALESCE(rowfirmobj.taxbegindate,
                  to_date('01.' ||
                           to_char(add_months(COALESCE(rowfirmobj.earn_date, ipFromDate),
                                              1), 'mm.yyyy'), 'dd.mm.yyyy')) <
             peredate)
          then
  ------------------   20.04.0212 Osvobojdavane po obekti
          vfsw    := rprtbo.fsw;
          vfclean := rprtbo.fclean;
          vfdepot := rprtbo.fdepot;
          
          if vgarbtax71 is null then
            select max(gt.garbtax_id), max(td.taxdoc_id),
                   (case when max(o.sw_missing) = 1 then 0 else 1 end),
                   (case when max(o.clean_missing) = 1 then 0 else 1 end),
                   (case when max(o.depot_missing) = 1 then 0 else 1 end)
            into   vgarbtax71, vtaxdoc71_id, vsw_missing, vclean_missing,
                   vdepot_missing
            from   garbtax gt, taxdoc td, garbobject o
            where  td.taxdoc_id = gt.taxdoc_id
            and    td.documenttype_id =
                   (select t.documenttype_id
                     from   documenttype t
                     where  t.doccode = '71')
            and    gt.proptaxdoc_id = iptaxdoc_Id
            and    gt.taxperiod_id = vtaxperiod_id
            and    td.docstatus <> '70' and td.docstatus <> '90'
            and    o.garbtax_id = gt.garbtax_id and o.homeobj_id = rowfirmobj.homeobj_id
            ;
            if vtaxdoc71_id is not null
            then
              rprtbo.fsw    := rprtbo.fsw * COALESCE(vsw_missing, 0);
              rprtbo.fclean := rprtbo.fclean * COALESCE(vclean_missing, 0);
              rprtbo.fdepot := rprtbo.fdepot * COALESCE(vdepot_missing, 0);
              
              select td.docstatus
              into   vdocst
              from   taxdoc td
              where  td.taxdoc_id = vtaxdoc71_id;
              if vdocst = '10'
              then
                update taxdoc td
                set    td.docstatus = '30'
                where  td.taxdoc_id = vtaxdoc71_id;
                perform taxvaluation.arxdoc(vtaxdoc71_id);
             end if;
            end if;
          end if;
  ------------------  end  20.04.0212 Osvobojdavane po obekti    
           xx := null;  
            if to_number(to_char(perbdate, 'yyyy')) > 2010
            then
            r := taxvaluation.TaxValHome(/*errmess,*/ rowfirmobj.homeobj_id,
                                      to_date('01.01.' ||
                                               to_char(perbdate, 'yyyy'),
                                               'dd.mm.yyyy'),
                                      rfirmbuilding.kindfunction/*, vDOhomeobj, XX*/);
          errmess := r.return_val;
          vDOhomeobj := r.vgroupe;
          XX := r.opmess;
              if errmess <> 'OK'
              then
                vDOhomeobj := 0;
              end if;
              vownerp := ownerpart(rowtaxdoc.taxsubject_id::integer,'2',rowfirmobj.homeobj_id::integer,peredate);
              vDOhomeobj := vDOhomeobj * vownerp; 
              if vownerp = 0.0 then rowfirmobj.accvalue := 0.0; end if;  --- 15.05.2012
              if vDOhomeobj > rowfirmobj.accvalue
              then
                rowfirmobj.accvalue := vDOhomeobj;
              end if;
            end if;
            -------------- ???????????????///
            i      := 1;
            flfree := 0;
            while i < 13 --15
            loop
              if substr(rowfirmobj.taxfreereason, i, 1) = '1'
              then
                if (i in (6, 8, 11, 12)) and
                   (trim(coalesce(rowfirmobj.isbusiness, 0)) <> '1')
                then
                  flfree := 1;
                elsif (i in (3, 4, 10, 5, 9, 7))
                then
                  flfree := 1;
                elsif (i in (1, 2)) and
                      (trim(coalesce(rowfirmobj.isbusiness, 0)) <> '1') and
                      (trim(coalesce(rowfirmobj.KindOwner, 0)) <> '1')
                then
                  flfree := 1;
                end if;
              end if;
              i := i + 1;
            end loop;
            if substr(rowfirmobj.taxfreereason, 13, 1) = '1' and flfree <> 1
            then
              flfree := 1; ---- ?????
              if (rfirmbuilding.Zeecategory = 'A') or
                 (rfirmbuilding.Zeecategory = '�')
              then
                if (to_number(coalesce(rowfirmobj.builddate, 0)) < 2005) and
                 (rfirmbuilding.zeeactivity = 1) and 
                   perbdate between
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rfirmbuilding.Zeesertdate::date - interval '1 day',
                                                     'yyyy')) + 1), 'dd.mm.yyyy') and
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rfirmbuilding.Zeesertdate::date - interval '1 day',
                                                     'yyyy')) + 10), 'dd.mm.yyyy')
                then
                  flfree := 1;
                end if;
                if (to_number(coalesce(rowfirmobj.builddate, 0)) < 2005) and
                   (coalesce(rfirmbuilding.zeeactivity,0) <> 1) and
                   perbdate between
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rfirmbuilding.Zeesertdate::date - interval '1 day',
                                                     'yyyy')) + 1), 'dd.mm.yyyy') and
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rfirmbuilding.Zeesertdate::date - interval '1 day',
                                                     'yyyy')) + 7), 'dd.mm.yyyy')
                then
                  flfree := 1;
                end if;
              end if;
              if (rfirmbuilding.Zeecategory = 'B') or
                 (rfirmbuilding.Zeecategory = '�')
              then
                if (to_number(coalesce(rowfirmobj.builddate, 0)) < 2005) and
                  (rfirmbuilding.zeeactivity = 1) and
                   perbdate between
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rfirmbuilding.Zeesertdate::date - interval '1 day',
                                                     'yyyy')) + 1), 'dd.mm.yyyy') and
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rfirmbuilding.Zeesertdate::date - interval '1 day',
                                                     'yyyy')) + 5), 'dd.mm.yyyy')
                then
                  flfree := 1;
                end if;
                if (to_number(coalesce(rowfirmobj.builddate, 0)) < 2005) and
                  (coalesce(rfirmbuilding.zeeactivity,0) <> 1) and
                   perbdate between
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rfirmbuilding.Zeesertdate::date - interval '1 day',
                                                     'yyyy')) + 1), 'dd.mm.yyyy') and
                   to_date('01.01.' ||
                           to_char(to_number(to_char(rfirmbuilding.Zeesertdate::date - interval '1 day',
                                                     'yyyy')) + 5), 'dd.mm.yyyy')
                then
                  flfree := 1;
                end if;
              end if;
            end if;
            vodateb := COALESCE(rowfirmobj.taxbegindate,
                           to_date('01.' ||
                                    to_char(add_months(rowfirmobj.earn_date, 1),
                                            'mm.yyyy'), 'dd.mm.yyyy'));
            if vodateb < perbdate
            then
              vodateb := perbdate;
            end if;
            if (rowfirmobj.taxenddate is null) or
               (rowfirmobj.taxenddate > peredate)
            then
              vodatee := peredate;
            else
              --vodatee := last_day(rowfirmobj.taxenddate::date) + interval '1 day';
              vodatee := rowfirmobj.taxenddate;
            end if;
            if vodatee >= vodateb
            then
              brmes := round(months_between(vodatee, vodateb));
              /*else
                brmes := 0;
              end if;*/
              brmesfree := 0;
              if flfree = 1
              then
                --opfreedni := opDNI; opDNI := 0;
                brmesfree := brmes;
              end if;
              vtaxvalobj     := round(rowfirmobj.accvalue * vnohomeprom / 1000,
                                      2);
              vearntaxvalobj := round(vtaxvalobj * brmes / 12, 2);
              vfreesumobj    := round(vtaxvalobj * brmesfree / 12, 2);
              vearntaxvalobj := vearntaxvalobj - vfreesumobj;
              if vearntaxvalobj = 0
              then
                vtaxvalobj := 0;
              end if;
              --- 18.07
              if COALESCE(kindcalTBO, '0') = '1'
              then
                vearntboobj := round((rprtbo.fsw + rprtbo.fclean +
                                     rprtbo.fdepot) * rowfirmobj.accvalueTBO *
                                     brmes / 12000, 2);
                vtbofreeobj := 0;
                vtaxtboobj  := round((rprtbo.fsw + rprtbo.fclean +
                                     rprtbo.fdepot) * rowfirmobj.accvalueTBO / 1000,
                                     2);
                vearnvalTBOobj := round(rowfirmobj.accvalueTBO * brmes / 12, 2); ---18.07
            else
                vearntboobj := round((rprtbo.fsw + rprtbo.fclean +
                                     rprtbo.fdepot) * rowfirmobj.accvalue *
                                     brmes / 12000, 2);
                vtbofreeobj := 0;
                vtaxtboobj  := round((rprtbo.fsw + rprtbo.fclean +
                                     rprtbo.fdepot) * rowfirmobj.accvalue / 1000,
                                     2);
		vearnvalTBOobj := round(rowfirmobj.accvalue * brmes / 12, 2); ---18.07
              end if;
              --  vtbofreeobj := round((rprtbo.fsw + rprtbo.fclean + rprtbo.fdepot) * rowfirmobj.accvalue * brmesfree /12000,1);
              --  vtaxtboobj := vtaxtboobj - vtbofreeobj;
              vearnvalobj    := round(rowfirmobj.accvalue * brmes / 12, 2); ------------------------------
            --  vearnvalTBOobj := round(rowfirmobj.accvalueTBO * brmes / 12, 2); ---18.07
            
              vtaxval     := COALESCE(vtaxval, 0.0) + vtaxvalobj;
              vearntaxval := COALESCE(vearntaxval, 0.0) + vearntaxvalobj;
              vtaxtbo     := COALESCE(vtaxtbo, 0.0) + vearntboobj;
              vtaxtbofree := COALESCE(vtaxtbofree, 0.0) + vtbofreeobj;
              vtaxvalfree := COALESCE(vtaxvalfree, 0.0) + vfreesumobj;
              vearnval    := COALESCE(vearnval, 0.0) + vearnvalobj;
              vearnvalTBO := COALESCE(vearnvalTBO, 0.0) + vearnvalTBOobj; --- 18.07
              vaccvalueo  := vaccvalueo + rowfirmobj.accvalue;
            
              -- debtpartproperty
              if COALESCE(ipflrec, 0) <> 1
              then
               /* select s_debtpartproperty.nextval
                into   vdpproperty_id
                from   dual;
                */
                xx := xx || ' = DO*' || vownerp || ' = ' || to_char(round(vDOhomeobj, 2));
                vSUBJPARTVAL := round(vDOhomeobj, 2);  -- round(rowfirmobj.accvalue, 2);
                if vtypedeclar = 2 then
                  vSUBJPARTVAL := 0;
                end if;
                vdpproperty_id := nextval('s_debtpartproperty');
                insert into debtpartproperty 
                  (debtpartproperty_id, debtsubject_id, taxperiod_id,
                   kindproperty, seqnots, typedeclar, isbasehome, isrelief,
                   relief_id, divident, divisor, part, sumval, sumtax,
                   taxbegindate, taxenddate, totalval, totaltax, userdate,
                   user_id, homeobj_id, freefrom, freemonths, codetbo, promiltbo,
                   freesuma_obj, freesuma_subj, parentdebtprop_id, SUBJPARTVAL, koeff)
                values
                  (vdpproperty_id, vdebtsubject_id, vtaxperiod_id, 2,
                   rowfirmobj.seqno, null, null, null, null, 1, 1, 1,
                   round(rowfirmobj.accvalue, 2), round(vtaxvalobj, 2), vodateb,
                   vodatee, vearnvalobj, round(vearntaxvalobj, 2), current_timestamp,
                   ipuser_id, rowfirmobj.homeobj_id, vodateb, brmesfree, null,
                   null, vfreesumobj, null, null, vSUBJPARTVAL, XX);  
                ----  TBO  
                --- 18.07
                if COALESCE(kindcalTBO, '0') = '1'
                then
                  vaccvalueTBO := round(rowfirmobj.accvalueTBO, 2);
                else
                  vaccvalueTBO := round(rowfirmobj.accvalue, 2);
                end if;
                /*
                select s_debtpartproperty.nextval
                into   vdptbo_id
                from   dual;
                */
                vdptbo_id := nextval('s_debtpartproperty');
                insert into debtpartproperty 
                  (debtpartproperty_id, debtsubject_id, taxperiod_id,
                   kindproperty, seqnots, typedeclar, isbasehome, isrelief,
                   relief_id, divident, divisor, part, sumval, sumtax,
                   taxbegindate, taxenddate, totalval, totaltax, userdate,
                   user_id, homeobj_id, freefrom, freemonths, codetbo, promiltbo,
                   freesuma_obj, freesuma_subj, parentdebtprop_id, SUBJPARTVAL,
                   FSW, FCLEAN, FDEPOT)
                values
                  (vdptbo_id, vtbodebtsubject_id, vtaxperiod_id, 2,
                   rowfirmobj.seqno,vtypedeclar, null, null, null, 0, 1, vownerp,
                   vaccvalueTBO, round(vtaxtboobj, 2), vodateb,
                    ---- 18.07
                   vodatee, vearnvalTBOobj, round(vearntboobj, 2), current_timestamp,
                   ipuser_id, rowfirmobj.homeobj_id, vodateb, brmesfree,
                   rprtbo.tbo_code,
                   (coalesce(rprtbo.fsw, 0) + coalesce(rprtbo.fclean, 0) +
                    coalesce(rprtbo.fdepot, 0)), vtbofreeobj, null, null,
                   vSUBJPARTVAL,
                   (rprtbo.fsw * rowfirmobj.accvalue / 1000),
                   (rprtbo.fclean * rowfirmobj.accvalue / 1000),
                   (rprtbo.fdepot * rowfirmobj.accvalue / 1000));
              end if;
              --    vsumdni := COALESCE(vsumdni,0) + vearntaxval;
              --    vsumtbo := COALESCE(vsumtbo,0) + vtaxtbo;
            end if;
          end if;
  ---- 20.04.2012
          rprtbo.fsw    := vfsw;
          rprtbo.fclean := vfclean;
          rprtbo.fdepot := vfdepot;
  --------------------------       
        end loop; --- firmobj
       -- close crfirmobj;
      end loop;
     -- close crfirmbuiding;
      ---------------- ����     ---------------
      select min(l.land_id)
      into   rland.land_id
      from   land l
      where  l.property_id = rfirmprop.property_id;
      if COALESCE(rland.land_id, 0.0) > 0
      then
        select *
        into   rland
        from   land l
        where  l.property_id = rfirmprop.property_id;
        select min(f.firmobj14_id)
        into   rfirmobj14.firmobj14_id
        from   firmobj14 f
        where  f.land_id = rland.land_id;
        if COALESCE(rfirmobj14.firmobj14_id, 0.0) > 0
        then
          select f.*
          into   rfirmobj14
          from   firmobj14 f
          where  f.land_id = rland.land_id;
          select f.accvalue
          into   rfirmobj14_accvalueTBO
          from   firmobj14 f
          where  f.land_id = rland.land_id;
     ------------------   20.04.0212 Osvobojdavane po obekti
          vfsw    := rprtbo.fsw;
          vfclean := rprtbo.fclean;
          vfdepot := rprtbo.fdepot;
          
          if vgarbtax71 is null then
            select max(gt.garbtax_id), max(td.taxdoc_id),
                   (case when max(o.sw_missing) = 1 then 0 else 1 end),
                   (case when max(o.clean_missing) = 1 then 0 else 1 end),
                   (case when max(o.depot_missing) = 1 then 0 else 1 end)
            into   vgarbtax71, vtaxdoc71_id, vsw_missing, vclean_missing,
                   vdepot_missing
            from   garbtax gt, taxdoc td, garbobject o
            where  td.taxdoc_id = gt.taxdoc_id
            and    td.documenttype_id =
                   (select t.documenttype_id
                     from   documenttype t
                     where  t.doccode = '71')
            and    gt.proptaxdoc_id = iptaxdoc_Id
            and    gt.taxperiod_id = vtaxperiod_id
            and    td.docstatus <> '70' and td.docstatus <> '90'
            and    o.garbtax_id = gt.garbtax_id and o.homeobj_id = rland.land_id
            ;
            if vtaxdoc71_id is not null
            then
              rprtbo.fsw    := rprtbo.fsw * COALESCE(vsw_missing, 0);
              rprtbo.fclean := rprtbo.fclean * COALESCE(vclean_missing, 0);
              rprtbo.fdepot := rprtbo.fdepot * COALESCE(vdepot_missing, 0);
              
              select td.docstatus
              into   vdocst
              from   taxdoc td
              where  td.taxdoc_id = vtaxdoc71_id;
              if vdocst = '10'
              then
                update taxdoc td
                set    td.docstatus = '30'
                where  td.taxdoc_id = vtaxdoc71_id;
                perform taxvaluation.arxdoc(vtaxdoc71_id);
              end if;
            end if;
          end if;
  ------------------  end  20.04.0212 Osvobojdavane po obekti    
          XX := null;
	  if to_number(to_char(perbdate, 'yyyy')) > 2010
          then
            r := taxvaluation.TaxValLand(/*errmess, */ rland.land_id,
                                  to_date('01.01.' || to_char(perbdate, 'yyyy'),
                                           'dd.mm.yyyy')/*, vDOhomeobj, XX*/);
            errmess := r.return_val;
            vDOhomeobj := r.vgroupe;
            XX := r.opmess;

            if errmess <> 'OK'
            then
              vDOhomeobj := 0;
            end if;
            vownerp := ownerpart(rowtaxdoc.taxsubject_id::integer,'1',rland.land_id::integer,peredate);
            vDOhomeobj := vDOhomeobj * vownerp; 
            if vownerp = 0.0 then rfirmobj14.accvalue := 0.0; end if;  --- 15.05.2012
            if vDOhomeobj > rfirmobj14.accvalue
            then
              rfirmobj14.accvalue := vDOhomeobj;
            end if;
          end if; 
          ------------------------------
          --------------------------------
          i      := 1;
          flfree := 0;
          while i < 13 --15
          loop
            if substr(rfirmobj14.taxfreereason, i, 1) = '1'
            then
              if (i in (6, 8, 11, 12)) and
                 ( coalesce(rland.isbusiness::integer, 0) <> 1)
              then
                flfree := 1;
              elsif (i in (3, 4, 10, 5, 9, 7))
              then
                flfree := 1;
              elsif (i in (1, 2)) and (coalesce(rland.isbusiness::integer, 0) <> 1) and
                    ( coalesce(rfirmobj14.KindOwner::integer, 0) <> 1)
              then
                flfree := 1;
              end if;
            end if;
            i := i + 1;
          end loop;
          rland.earn_date := COALESCE(rland.earn_date, ipFromDate);
          vodateb := COALESCE(rland.taxbegindate,
                         to_date('01.' || to_char(add_months(rland.earn_date, 1),
                                                   'mm.yyyy'), 'dd.mm.yyyy'));
          if vodateb < perbdate
          then
            vodateb := perbdate;
          end if;
          if (rland.taxenddate is null) or (rland.taxenddate > peredate)
          then
            vodatee := peredate;
          else
            vodatee := last_day(rland.taxenddate::date) + interval '1 day';
          end if;
          if vodatee >= vodateb
          then
            brmes := round(months_between(vodatee, vodateb));
            /*else
              brmes := 0;
            end if;*/
            brmesfree := 0;
            if flfree = 1
            then
              --opfreedni := opDNI; opDNI := 0;
              brmesfree := brmes;
            end if;
            vtaxvalobj     := round(rfirmobj14.accvalue * vnohomeprom / 1000, 2);
            vearntaxvalobj := round(vtaxvalobj * brmes / 12, 2);
            vfreesumobj    := round(vtaxvalobj * brmesfree / 12, 2);
            vearntaxvalobj := vearntaxvalobj - vfreesumobj;
            if vearntaxvalobj = 0
            then
              vtaxvalobj := 0;
            end if;
            --- 18.07
            if COALESCE(kindcalTBO, '0') = '1'
            then
              vearntboobj := round((rprtbo.fsw + rprtbo.fclean + rprtbo.fdepot) *
                                   rfirmobj14_accvalueTBO * brmes / 12000, 2);
              vtbofreeobj := 0;
              vtaxtboobj  := round((rprtbo.fsw + rprtbo.fclean + rprtbo.fdepot) *
                                   rfirmobj14_accvalueTBO / 1000, 2);
              vearnvalTBOobj := round(rfirmobj14_accvalueTBO * brmes / 12, 2); ---18.07
            else
              vearntboobj := round((rprtbo.fsw + rprtbo.fclean + rprtbo.fdepot) *
                                   rfirmobj14.accvalue * brmes / 12000, 2);
              vtbofreeobj := 0;
              vtaxtboobj  := round((rprtbo.fsw + rprtbo.fclean + rprtbo.fdepot) *
                                   rfirmobj14.accvalue / 1000, 2);
              vearnvalTBOobj := round(rfirmobj14.accvalue * brmes / 12, 2); ---18.07                     
            end if;
            --  vtbofreeobj := round((rprtbo.fsw + rprtbo.fclean + rprtbo.fdepot) * rowfirmobj.accvalue * brmesfree /12000,1);
            --  vtaxtboobj := vtaxtboobj - vtbofreeobj;
            vearnvalobj    := round(rfirmobj14.accvalue * brmes / 12, 2); ------------------------------
          --  vearnvalTBOobj := round(rfirmobj14_accvalueTBO * brmes / 12, 2); ---18.07
          
            vtaxval     := COALESCE(vtaxval, 0.0) + vtaxvalobj;
            vearntaxval := COALESCE(vearntaxval, 0.0) + vearntaxvalobj;
            vtaxtbo     := COALESCE(vtaxtbo, 0.0) + vearntboobj;
            vtaxtbofree := COALESCE(vtaxtbofree, 0.0) + vtbofreeobj;
            vtaxvalfree := COALESCE(vtaxvalfree, 0.0) + vfreesumobj;
            vearnval    := COALESCE(vearnval, 0.0) + vearnvalobj;
            vearnvalTBO := COALESCE(vearnvalTBO, 0.0) + vearnvalTBOobj; --- 18.07
            --vaccvalueo  := vaccvalueo + rowfirmobj.accvalue;
            vaccvalueo  := vaccvalueo + rfirmobj14.accvalue;
          
            -- debtpartproperty
            if coalesce(ipflrec, 0) <> 1
            then
              /*select s_debtpartproperty.nextval
              into   vdpproperty_id
              from   dual;*/
              select pl.typedeclar into vlanddeclar
                  from land pl
                  where pl.land_id = rland.land_id
                  ;                  
                XX := XX || ' = DO*' || vownerp || ' = ' || to_char(round(vDOhomeobj, 2));
                vSUBJPARTVAL := round(vDOhomeobj, 2); -- round(rowfirmobj.accvalue, 2);
                if ((vtypedeclar = 2) or (vlanddeclar = 2)) then
                  vSUBJPARTVAL := 0;
                end if;        
              vdpproperty_id := nextval('s_debtpartproperty');
              insert into debtpartproperty 
                (debtpartproperty_id, debtsubject_id, taxperiod_id,
                 kindproperty, seqnots, typedeclar, isbasehome, isrelief,
                 relief_id, divident, divisor, part, sumval, sumtax,
                 taxbegindate, taxenddate, totalval, totaltax, userdate, user_id,
                 homeobj_id, freefrom, freemonths, codetbo, promiltbo,
                 freesuma_obj, freesuma_subj, parentdebtprop_id, SUBJPARTVAL, koeff)
              values
                (vdpproperty_id, vdebtsubject_id, vtaxperiod_id, 1,
                '1', vtypedeclar, null, null, null, 0, 0, vownerp,
                 round(rfirmobj14.accvalue, 2), round(vtaxvalobj, 2), vodateb,
                 vodatee, vearnvalobj, round(vearntaxvalobj, 2), current_timestamp,
                 ipuser_id, rland.land_id, vodateb, brmesfree, null, null,
                 vfreesumobj, null, null, vSUBJPARTVAL,XX);
              ----  TBO  
              --- 18.07
              if COALESCE(kindcalTBO, '0') = '1'
              then
                vaccvalueTBO := round(rfirmobj14_accvalueTBO, 2);
                vownerp := 1;
              else
                vaccvalueTBO := round(rfirmobj14.accvalue, 2);
              end if;
              /*
              select s_debtpartproperty.nextval
              into   vdptbo_id
              from   dual;
              */
              vdptbo_id := nextval('s_debtpartproperty');
              insert into debtpartproperty 
                (debtpartproperty_id, debtsubject_id, taxperiod_id,
                 kindproperty, seqnots, typedeclar, isbasehome, isrelief,
                 relief_id, divident, divisor, part, sumval, sumtax,
                 taxbegindate, taxenddate, totalval, totaltax, userdate, user_id,
                 homeobj_id, freefrom, freemonths, codetbo, promiltbo,
                 freesuma_obj, freesuma_subj, parentdebtprop_id, SUBJPARTVAL,
                 FSW, FCLEAN, FDEPOT)
              values
                (vdptbo_id, vtbodebtsubject_id, vtaxperiod_id, 1,
                 '1', vtypedeclar, null, null, null, 0, 0, vownerp,
                 round(vtaxtboobj, 2), round(vearntboobj, 2), vodateb,
                  ---- 18.07
                 vodatee, vearnvalTBOobj, round(vearntboobj, 2), current_timestamp,
                 ipuser_id, rland.land_id, vodateb, brmesfree, rprtbo.tbo_code,
                 (coalesce(rprtbo.fsw, 0) + coalesce(rprtbo.fclean, 0) +
                  coalesce(rprtbo.fdepot, 0)), vtbofreeobj, null, null,
                  vSUBJPARTVAL,
                 (rprtbo.fsw * vaccvalueTBO / 1000),
                 (rprtbo.fclean * vaccvalueTBO / 1000),
                 (rprtbo.fdepot * vaccvalueTBO / 1000));
            end if;
            --    vsumdni := COALESCE(vsumdni,0) + vearntaxval;
            --    vsumtbo := COALESCE(vsumtbo,0) + vtaxtbo;
          end if;
        end if;
      
  ---- 20.04.2012
          rprtbo.fsw    := vfsw;
          rprtbo.fclean := vfclean;
          rprtbo.fdepot := vfdepot;

        ------------------------------
        ------------------------------
      end if;
      -------------------------------
      if (vgarbtax19 is not null) and (coalesce(ipflrec, 0) <> 1)
      then
      
       /* select s_debtpartproperty.nextval
        into   vdptbo_id
        from   dual;
        */
        vdptbo_id := nextval('s_debtpartproperty');
        insert into debtpartproperty 
          (debtpartproperty_id, debtsubject_id, taxperiod_id, kindproperty,
           seqnots, typedeclar, isbasehome, isrelief, relief_id, divident,
           divisor, part, sumval, sumtax, taxbegindate, taxenddate, totalval,
           totaltax, userdate, user_id, homeobj_id, freefrom, freemonths,
           codetbo, promiltbo, freesuma_obj, freesuma_subj, parentdebtprop_id,
           SUBJPARTVAL, FSW, FCLEAN, FDEPOT)
        values
           (vdptbo_id, vtbodebtsubject_id, vtaxperiod_id, 1, 0, vtypedeclar, null,
            null, null, 0, 0, vownerp, 0, round(vdecltbo, 2), perbdate, peredate, 0,
           round(vdecltbo * round(months_between(peredate, vodateb)) / 12, 2),
           current_timestamp, ipuser_id, 0, vodateb, brmesfree, rprtbo.tbo_code, 0,
           vtbofreeobj, null, null, 0, 0, 0, 0);       
        vdecltbo := vdecltbo * round(months_between(peredate, vodateb)) / 12;
        vtaxtbo  := vtaxtbo + round(vdecltbo, 2);
      end if;
      select COALESCE(min(n.minvalue), 0.0)
      into   vmindo
      from   legalnorm n
      where  n.name = 'mindo'
      and    n.begindate = (select max(nn.begindate)
                            from   legalnorm nn
                            where  to_char(nn.begindate, 'yyyy') <= vTaxYear::varchar
                            and    nn.name = 'mindo');
      --  vinst_number := trunc(round(months_between(peredate, perbdate))/3);
      ---------------
      --    optotalval   := vearnval;   ---- 18.07 ??????
      if vaccvalueo < vmindo
      then
        vfreesumobj := vfreesumobj + vearntaxval;
        --  optotaltax  := 0;
        vearntaxval := 0;
      
        update debtpartproperty 
        set    freesuma_obj = freesuma_obj + totaltax, totaltax = 0
        where  debtsubject_id in
               (select ds.debtsubject_id
                from   debtsubject ds
                where  ds.debtsubject_id = vdebtsubject_id);
      
        --     else
        --      optotaltax := vearntaxval;
      end if;
      --     optbototaltax := vtaxtbo;
      if coalesce(ipflrec, 0) = 1
      then
        ipStatus := 'OK';
        --   rollback;
        return;
      end if;
      if (ipoblwr <> 2)
      then
        --   if true then
        -- debtsubject
        select count(*)
        into   vnorminst
        from   taxperiodpay p
        where  p.documenttype_id = 22
        and    p.taxperiod_id = vtaxperiod_id
        and ((p.kinddebtreg_id = 2) or (p.kinddebtreg_id is null));
        if vnorminst = 0
        then
          vdiv := 1;
        else
          vdiv := round(12 / vnorminst);
        end if;
        ---------------
        vminp        := round(months_between(peredate, perbdate) + 0.5);
        vinst_number := round((vminp / vdiv) + 0.4); --/ 3)+ 0.3);
        update debtsubject 
        set    Totalval = vearnval, totaltax = vearntaxval,
               FreeSum_obj = vfreesumobj, inst_number = vinst_number
        where  debtsubject_id = vdebtsubject_id;
      
      
        -- debtinstalment
        select min(ds.debtsubject_id)
        into   oldds_id
        from   debtsubject ds, kinddebtreg dr
        where  ds.debtsubject_id <> vdebtsubject_id
        and    ds.kinddebtreg_id = dr.kinddebtreg_id
        and    dr.code = '2100'
        and    ds.taxperiod_id = vtaxperiod_id
        and    ds.document_id = iptaxdoc_Id;
        
          if vinst_number = 0
          then
            vinst_number := 1;
          end if;
          i         := vinst_number;
          invsum    := 0;
          invsumtbo := 0;
          while i > 0
          loop
            nv := vnorminst - vinst_number + i;
            /*
               if nv= 4 then
                 sumzad := round(vearntaxval - ((vinst_number - 1) * round(vearntaxval / vinst_number,2)),2);
               else
                 sumzad := round(vearntaxval / vinst_number,2);
               end if;
            */
            if i = vinst_number
            then
    --          sumzad := vearntaxval - invsum;
              sumzad := vearntaxval - ((vinst_number - 1) * round(vearntaxval / vinst_number, 2));
              invsum := invsum + sumzad;
            else
              sumzad := round(vearntaxval / vinst_number, 2);
              invsum := invsum + sumzad;
            end if;
            i  := i - 1;
      
       
          if coalesce(ipflrec, 0) <> 1 and oldds_id is null
          then
            vdebtinst_id := nextval('s_debtinstalment');
            insert into debtinstalment
              (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
               intbegindate)
              select vdebtinst_id, vdebtsubject_id,
                     tp.instalmentnumber, getWorkingDay(tp.termpaydate::date, 1.0),
                     sumzad, getWorkingDay(tp.termpaydate::date, 1.0) + 1
              from   taxperiodpay tp, documenttype dt
              where  tp.taxperiod_id = vtaxperiod_id
              and    tp.instalmentnumber = nv
              and    tp.documenttype_id = dt.documenttype_id
              and ((tp.kinddebtreg_id = 2) or (tp.kinddebtreg_id is null))
              and    dt.doccode = '17'
              --    and dt.municipality_id = rowtaxdoc.municipality_id
              ;
            -- baldebtinstall
            insert into baldebtinst
              (debtinstalment_id, instsum, interestsum, discsum)
            values
              (vdebtinst_id, sumzad, 0, 0);  --- currval('s_debtinstalment')
          end if;
          end loop;
        
          --- TBO
        select count(*)
        into   vnorminst
        from   taxperiodpay p
        where  p.documenttype_id = 22
        and    p.taxperiod_id = vtaxperiod_id
        and ((p.kinddebtreg_id = 5) or (p.kinddebtreg_id is null));
        if vnorminst = 0
        then
          vdiv := 1;
        else
          vdiv := round(12 / vnorminst);
        end if;
        ---------------
        vminp        := round(months_between(peredate, perbdate) + 0.5);
        vinst_number := round((vminp / vdiv) + 0.4); --/ 3)+ 0.3);
          update debtsubject
          set    Totalval = vearnvalTBO, totaltax = vtaxtbo,   ---- 18.07
                 FreeSum_obj = vtaxtbofree, inst_number = vinst_number
          where  debtsubject_id = vtbodebtsubject_id;

          select min(ds.debtsubject_id)
          into   oldtbods_id
          from   debtsubject ds, kinddebtreg dr
          where  ds.debtsubject_id <> vtbodebtsubject_id
          and    ds.kinddebtreg_id = dr.kinddebtreg_id
          and    dr.code = '2400'
          and    ds.taxperiod_id = vtaxperiod_id
          and    ds.document_id = iptaxdoc_Id;
          /*
          if nv= 4 then
            sumzad := round(vtaxtbo - ((vinst_number - 1) * round(vtaxtbo / vinst_number,2)),2);
          else
            sumzad := round(vtaxtbo / vinst_number,2);
          end if;
          */
           if vinst_number = 0
          then
            vinst_number := 1;
          end if;
          i         := vinst_number;
          invsum    := 0;
          invsumtbo := 0;
          while i > 0
          loop
            nv := vnorminst - vinst_number + i;
            if i = vinst_number
            then
              sumtbo := vtaxtbo - ((vinst_number - 1) * round(vtaxtbo / vinst_number, 2));
              invsumtbo := invsumtbo + sumtbo;
            else
              sumtbo    := round(vtaxtbo / vinst_number, 2);
              invsumtbo := invsumtbo + sumtbo;
            end if;

            i  := i - 1;        
          if (coalesce(ipflrec, 0) <> 1 and oldtbods_id is null)
          then
            vdebtinst_id := nextval('s_debtinstalment');
            insert into debtinstalment
              (debtinstalment_id, debtsubject_id, instno, termpay_date, instsum,
               intbegindate)
              select vdebtinst_id, vtbodebtsubject_id,
                     tp.instalmentnumber, getWorkingDay(tp.termpaydate::date, 1.0),
                     sumtbo, getWorkingDay(tp.termpaydate::date, 1.0) + 1
              from   taxperiodpay tp, documenttype dt
              where  tp.taxperiod_id = vtaxperiod_id
              and    tp.instalmentnumber = nv
              and    tp.documenttype_id = dt.documenttype_id
              and ((tp.kinddebtreg_id = 5) or (tp.kinddebtreg_id is null))
              and    dt.doccode = '17'
              --   and dt.municipality_id = rowtaxdoc.municipality_id
              ;
           -- baldebtinst
            insert into baldebtinst
              (debtinstalment_id, instsum, interestsum, discsum)
            values
              (vdebtinst_id, sumtbo, 0, 0);
          end if;
        end loop;
        ipStatus := 'OK';
       return;
      else
        delete from debtpartproperty pp
        where  pp.debtsubject_id in (vdebtsubject_id, vtbodebtsubject_id);
        delete from debtsubject ds
        where  ds.debtsubject_id in (vdebtsubject_id, vtbodebtsubject_id);
        ipStatus := 'errDiferData'; -- '������� � ����������� � ���������';
        
        return;
      end if;
    
      --------------------------------
    end loop; --- property 
    close crfirmprop;
    vTaxYear := vTaxYear + 1;
  end loop;

exception
  when others then
    ipStatus := sqlerrm;
  
end;
$function$
; DROP FUNCTION public.dsaproc_delete(character varying, character varying); 
CREATE OR REPLACE FUNCTION public.dsaproc_delete(OUT return_val character varying, idsanom character varying, iinyear character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare  
ErrMsg Varchar(200);
dsareq cursor is
    select d.dsarequest_id
      from dsarequest d
     where d.dsanom = IDSANOM
       and to_char(d.indate,'yyyy') = iinyear;

begin
   if coalesce(IDSANOM,'') = '' or coalesce(iinyear,'') = '' then
     return;
   end if;
   for r in dsareq loop
      return_val := '^';
      delete from dsalist d where d.dsarequest_id = r.dsarequest_id;
      commit;
   end loop;
   for r in dsareq loop
     delete from dsarequest d where d.dsarequest_id = r.dsarequest_id;
     commit;
   end loop;

   if return_val = '^' then
    return_val := 'OK';
   else
    return_val := 'MISSING';
   end if;

   exception
    when others then
      begin
        perform NOM_PKG.ErrManage(ErrMsg, SqlErrM);
        return_val := ErrMsg;
        return;

      end;

end;
$function$
; DROP FUNCTION public.dspnproc(numeric); 
CREATE OR REPLACE FUNCTION public.dspnproc(OUT return_val character varying, idspnhead_id numeric)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
 missed cursor (vdspnhead_id numeric) is
   select h.*
     from dspnhead h 
    where not exists(select *
                       from dspnhead d inner join dspnlist l on d.dspnhead_id = l.dspnhead_id
                       where d.dspnhead_id = h.dspnhead_id)
      and h.dspnhead_id = vdspnhead_id;
 dspn cursor (vdspnhead_id numeric) is
   select distinct dl.dspnhead_id, dl.idn, dl.name, dl.kdrcode, dl.partidano   
     from dspnlist dl 
    where dl.dspnhead_id = vdspnhead_id
    order by dl.name;
 subj cursor (vidn varchar) is
   select ts.taxsubject_id, nvl(ts.idn,'') idn, nvl(ts.name,'') name1
     from taxsubject ts 
    where ts.idn = vidn;
ErrMsg    varchar(400) := 'OK';    
vidn      varchar(30);
vtsname   varchar(60);
vtsId     numeric;
vkdrId    numeric;
vnote     varchar(20) := null;
vstatus   varchar(1) := null;
begin
 -- Check for missed list rows   
   for rec in missed(iDSPNHEAD_ID) loop 
       ErrMsg := '���������� ������ �� �� ��� �������';
       delete from dspnlist l where l.dspnhead_id = iDSPNHEAD_ID; 
       delete from dspnhead h where h.dspnhead_id = iDSPNHEAD_ID;
   end loop;    

   for r in dspn(iDSPNHEAD_ID) loop
     vtsId := null;
     vidn := '';
     vtsname := '';
     vnote := null;
     vstatus := null;
     for s in subj(r.idn) loop
       vtsId := s.taxsubject_id;
       vidn := s.idn;
       vtsname := s.name;       
     end loop;
     if (vtsId is null or nvl(vidn,'') != r.idn) then
       vnote := '������ ���';
       vstatus := '2';    
    /* elsif (vtsId is null) then
        vnote := '���� �����';  
        vstatus := '2'; */
     elsif (nvl(vtsname,'') != r.name) then
        vnote := '������ ���';  
     end if;  
     
     select kdr.kinddebtreg_id
       into vkdrId
       from kinddebtreg kdr
      where kdr.code = r.kdrcode; 
     
     update dspnlist dsl set dsl.taxsubject_id = vtsId,
                             dsl.kinddebtreg_id = vkdrId, 
                             dsl.status = vstatus,
                             note = vnote
      where dsl.dspnhead_id = r.dspnhead_id
        and dsl.partidano = r.partidano
        and dsl.idn = r.idn
        and dsl.kdrcode = r.kdrcode;

   end loop; 

   commit;
   return_val := ErrMsg;
   return; 
   
   exception
    when others then
      begin
        ErrMsg := '';
        perform NOM_PKG.ErrManage(ErrMsg, SqlErrM);
        return_val := ErrMsg;
        return;
      end;
  
end;
$function$
; DROP FUNCTION public.decltourist(numeric, integer); 
CREATE OR REPLACE FUNCTION public.decltourist(iptaxdoc_id numeric DEFAULT 30981, ipconfirm integer DEFAULT 1, OUT opfulltax numeric, OUT opduty numeric, OUT opdifer numeric, OUT errstat character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  cr cursor (iptouristtax_id integer) is
 select *
 from monthlytouristtax mt
 where mt.touristtax_id = iptouristtax_id
 order by mt.month
 ;
 crbal cursor is
  select b.*
  from baldebtinst b,debtsubject ds , debtinstalment i
  where ds.document_id = iptaxdoc_id
  and ds.debtsubject_id = i.debtsubject_id
  and b.debtinstalment_id = i.debtinstalment_id
  and b.instsum > 0
  order by i.instno
  ;
 rcrbal baldebtinst%rowtype;
 rcr monthlytouristtax%rowtype;
 tdrow taxdoc%rowtype;
 ttax touristtax%rowtype;
 vperdate date;
 vcapacity integer;
 vmm integer;
 vsleepnumber integer;
 vtaxobl numeric;
 vtaxcalc numeric;
 vnotpaysum numeric;
 vcategory numeric;
 vmesprice numeric;
 vdebtinstalment_id numeric;
 vdebtsubject_id numeric;
 vpartno varchar(50);
 vOperation_Id numeric;
 reminder numeric;
 voversubject_Id  numeric;
 fulltax numeric;
 vsrok date;
 vtaxdecl numeric;
 vmm_c  varchar(10);
 mdate date;
begin
errstat := 'OK';
select * into tdrow
 from taxdoc td
 where td.taxdoc_id = iptaxdoc_id
 ;
select * into ttax
from touristtax tt
where tt.taxdoc_id = iptaxdoc_id
;

 select tp.begin_date into vperdate
  from taxperiod tp where tp.taxperiod_id = ttax.taxperiod_id
 ;
-- vcapacity := ttax.bednumeric * (coalesce(ttax.category_enddate,to_date('31.12.' || to_char(vperdate,'yyyy'),'dd.mm.yyyy'))
--  - coalesce(ttax.begindate,vperdate) + 1)
--  ;
 vcapacity := ttax.bednumber;
-- * (to_date('31.12.' || to_char(vperdate,'yyyy'),'dd.mm.yyyy')
--                                   - to_date('01.01.' || to_char(vperdate,'yyyy'),'dd.mm.yyyy') + 1);

 if ttax.category_chgdate is not null then
  vmm := to_number(to_char(ttax.category_chgdate,'mm'));
 else  vmm := 0;
 end if;
for i in 1..12
loop
 vmm_c := '00' || to_char(i); vmm_c := substr(vmm_c,length(vmm_c)- 1 ,2);
 mdate := last_day(to_date(to_char(vperdate,'yyyy') || vmm_c, 'yyyymm'));
  if i > vmm then
   vcategory := ttax.category_of_property;
  else
   vcategory := ttax.category_old;
  end if;
  select (min(tp.taxvalue) * vcapacity * to_number(to_char(last_day(mdate),'dd')))
    into vmesprice
   from touristtaxprice tp, address a
    where tp.taxperiod_id = ttax.taxperiod_id
    and tp.category_of_property = vcategory
    and a.address_id = ttax.address_id
    and  ((tp.city_id is null) or (tp.city_id = a.city_id))
    and tp.begin_date = (select max(t.begin_date)
                         from touristtaxprice t
                         where t.taxperiod_id = ttax.taxperiod_id
                         and t.category_of_property = vcategory
                         and t.begin_date <= last_day(mdate));
  fulltax := coalesce(fulltax,0) + coalesce(vmesprice,0);

end loop;
 vtaxobl := 0;
 vsleepnumber := 0;
 vtaxdecl := 0;
open cr(ttax.touristtax_id);
loop
 fetch cr into rcr;
 exit when not found;
  if rcr.month > vmm then
   vcategory := ttax.category_of_property;
  else
   vcategory := ttax.category_old;
  end if;
 --  vdayofmonth := to_numeric(to_char(last_day(substr('0' || to_char(rcr.month)),'mm'))
 vmm_c := '00' || to_char(rcr.month); vmm_c := substr(vmm_c,length(vmm_c)- 1 ,2);
 mdate := last_day(to_date(to_char(vperdate,'yyyy') || vmm_c, 'yyyymm'));
   select (min(tp.taxvalue) * rcr.sleepnumber_decl)
   --, (tp.taxvalue * ttax.bednumber * to_numeric(to_char(last_day(rcr.month),'mm')))
   into vmesprice
    from touristtaxprice tp, address a
    where tp.taxperiod_id = ttax.taxperiod_id
    and tp.category_of_property = vcategory
    and a.address_id = ttax.address_id
    and  ((tp.city_id is null) or (tp.city_id = a.city_id))
    and tp.begin_date = (select max(t.begin_date)
                         from touristtaxprice t
                         where t.taxperiod_id = ttax.taxperiod_id
                         and t.category_of_property = vcategory
                         and t.begin_date <= last_day(mdate));
  vsleepnumber := vsleepnumber + rcr.sleepnumber_decl;
  vtaxobl := vtaxobl + vmesprice;
  vtaxdecl := vtaxdecl + coalesce(rcr.taxvalue_decl,0);
 end loop;
 opdifer := round(vtaxobl - vtaxdecl,2);
 if vtaxdecl < (30 * fulltax / 100) then
  vtaxdecl := (30 * fulltax / 100);
 end if;
 select sum(ds.totaltax), min(ds.debtsubject_id) into vtaxcalc, vdebtsubject_id
   from debtsubject ds
   where ds.document_id = ttax.taxdoc_id
   ;
 vtaxdecl := round(coalesce(vtaxdecl,0),2);
 vtaxcalc := round(coalesce(vtaxcalc,0), 2);
 opfulltax := round(fulltax,2);
 opduty := vtaxdecl - vtaxcalc;
  if  ipConfirm = 1 then
  if vtaxcalc <> vtaxdecl then
    select nextval('s_operation') into voperation_id;

    insert into operation
     (operation_id, oper_date, operdocno, opercode, opersum, user_date,
      user_id, user_name, baloversum, resolution_id, paytransaction_id,
      oversubject_id, municipality_id)
    values
     (voperation_id, trunc(current_date), voperation_id, '15', opduty,
      trunc(current_date), tdrow.user_id,
      (select u.fullname
       from   users u
       where  u.user_id = tdrow.user_id), null, null, null, null,
      tdrow.municipality_Id);
  vsrok := last_day(to_date('01.02.' || to_char(add_months(vperdate,12),'yyyy'),'dd.mm.yyyy'));

  if vtaxcalc < vtaxdecl then
  if vdebtsubject_id is null then
    select nextval('s_debtsubject') into vdebtsubject_id;
   insert into debtsubject
    (debtsubject_id, taxsubject_id, document_id, kinddoc,
    kinddebtreg_id, taxperiod_id, doccode, tax_begidate,
    tax_enddate, relief_id, totalval, totaltax, calcdate,
    inst_number, freesum_obj, userdate, user_id,
    municipality_id, kindparreg_id, partidano,
    docno, doc_date)
    values
    (vdebtsubject_id, tdrow.taxsubject_id, tdrow.taxdoc_id,1,
     (select k.kinddebtreg_id from kinddebtreg k where trim(k.code)='2800'),
     ttax.taxperiod_id,'61R', tdrow.begintaxdate,
    to_date('31.12.'||to_char(tdrow.begintaxdate,'yyyy'),'dd.mm.yyyy'),
    null,vtaxdecl,vtaxdecl,trunc(current_date),12,0,current_date, tdrow.user_id,
    ttax.location_municipality_id, 2,tdrow.partidano,tdrow.docno,
    tdrow.doc_date);
  else
  update debtsubject ds
    set totaltax = vtaxdecl
   where ds.debtsubject_id = vdebtsubject_id;
  end if;
  select nextval('s_debtinstalment') into vdebtinstalment_id;
  insert into debtinstalment  -- razlikata vtaxdecl - vtaxcalc
  (debtinstalment_id, debtsubject_id, instno, termpay_date,
   instsum, intbegindate)
  values
  (vdebtinstalment_id,vdebtsubject_id,13,vsrok, opduty, vsrok + 1);
  insert into baldebtinst 
  (debtinstalment_id, instsum, interestsum, discsum)
  values
  (vdebtinstalment_id,opduty,0,0);
  insert into operdebt
    (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
     operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
     balinstsum)
   values
    (nextval('s_operdebt'), vOperation_Id, 51,
     vdebtinstalment_id, opduty, null, null, 2, null, null);

 elsif vtaxcalc > vtaxdecl then
  -- nadvzeta ????
 /* insert into debtsubject -- korekcia s razlikata (-)
  ()
  ;*/
    reminder := opduty;
    select nextval('s_debtsubject') into vdebtsubject_id;
      insert into debtsubject
    (debtsubject_id, taxsubject_id, document_id, kinddoc,
    kinddebtreg_id, taxperiod_id, doccode, tax_begidate,
    tax_enddate, relief_id, totalval, totaltax, calcdate,
    inst_number, freesum_obj, userdate, user_id,
    municipality_id, kindparreg_id, partidano,
    docno, doc_date)
    values
    (vdebtsubject_id, tdrow.taxsubject_id, tdrow.taxdoc_id,1,
     (select k.kinddebtreg_id from kinddebtreg k where trim(k.code)='2800'),
     ttax.taxperiod_id,'61R', tdrow.begintaxdate,
    to_date('31.12.'||to_char(tdrow.begintaxdate,'yyyy'),'dd.mm.yyyy'),
    null,reminder,reminder,trunc(current_date),12,0,current_date, tdrow.user_id,
    ttax.location_municipality_id, 2,tdrow.partidano,tdrow.docno,
    tdrow.doc_date);

  select nextval('s_debtinstalment') into vdebtinstalment_id;
  insert into debtinstalment
   (debtinstalment_id, debtsubject_id, instno, termpay_date,
   instsum, intbegindate)
   values
   (vdebtinstalment_id,vdebtsubject_id,13,vsrok,
   reminder,vsrok + 1);
/*
  select sum(b.instsum) into vnotpaysum
   from debtsubject ds, debtinstalment i, baldebtinst b
   where i.debtsubject_id = ds.debtsubject_id
   and b.debtinstalment_id = i.debtinstalment_id
   and ds.document_id = ttax.taxdoc_id
   ;
   */
   reminder := -reminder;
   open crbal;
   loop
    fetch crbal into rcrbal;
    exit when not found;
     if reminder > rcrbal.instsum then
     reminder := reminder - rcrbal.instsum;
     update baldebtinst b
       set instsum = 0
     where b.debtinstalment_id = rcrbal.debtinstalment_id;
     else
     update baldebtinst b
       set instsum = b.instsum - reminder
     where b.debtinstalment_id = rcrbal.debtinstalment_id;
     reminder := 0;
     end if;
     insert into operdebt
    (operdebt_id, operation_id, kinddebtreg_id, debtinstalment_id,
     operoversum, operintsum, discsum, kindparreg_id, balinterestsum,
     balinstsum)
   values
    (nextval('s_operdebt'), vOperation_Id, 51,
     rcrbal.debtinstalment_id, -reminder, null, null, 2, null, null);
    if reminder = 0 then exit; end if;
   end loop;
   if reminder > 0 then
     select nextval('s_oversubject') into voversubject_Id  from dual;
     insert into oversubject
      (oversubject_id, kinddebtreg_id, taxsubject_id, overpaysum,
       overinterestsum, overcorsum, partidano, municipality_id,
       debtsubject_id)
     values
      (voversubject_Id, 51, tdrow.taxsubject_id, null, null,
       reminder, tdrow.partidano, tdrow.municipality_Id, vdebtsubject_id);
     insert into baloverinst
      (oversubject_id, oversum)
     values
      (voversubject_Id, reminder);

      -- nakraja zapis na gornoto nivo v operation
      update operation opup
      set    oversubject_id = voversubject_Id, baloversum = reminder
      where  opup.operation_id = vOperation_Id;
   end if;
   -------   operations ????????
   --- namalenie ot neplatenite ????
   --- ostataka v nadvnesena ???
  end if;
 end if;
  update taxdoc td
   set docstatus = '30'
  where td.taxdoc_id = iptaxdoc_id;
  if tdrow.partidano is null then
  vpartno := public.getpartidano(tdrow.municipality_id, 40);
  errstat := 'OK';
  if vpartno <> '-1' then
  update taxdoc td
   set partidano  = vpartno
  where td.taxdoc_id = iptaxdoc_id;
  update debtsubject ds
   set partidano = vpartno
  where ds.document_id = iptaxdoc_id
  and ds.partidano is null;
  else
     errstat := '������ �������� ����� !';
  end if;
  end if;
  else
    errstat := 'OK';
  end if;
-- commit;
 exception
  when others then
 ---  rollback;
   errstat := '������';
 end;
$function$
; DROP FUNCTION public.pldbg_abort_target(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_abort_target(session integer)
 RETURNS SETOF boolean
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_abort_target$function$
; DROP FUNCTION public.pldbg_attach_to_port(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_attach_to_port(portnumber integer)
 RETURNS integer
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_attach_to_port$function$
; DROP FUNCTION public.pldbg_continue(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_continue(session integer)
 RETURNS breakpoint
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_continue$function$
; DROP FUNCTION public.pldbg_create_listener(); 
CREATE OR REPLACE FUNCTION public.pldbg_create_listener()
 RETURNS integer
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_create_listener$function$
; DROP FUNCTION public.pldbg_deposit_value(integer, text, integer, text); 
CREATE OR REPLACE FUNCTION public.pldbg_deposit_value(session integer, varname text, linenumber integer, value text)
 RETURNS boolean
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_deposit_value$function$
; DROP FUNCTION public.pldbg_drop_breakpoint(integer, oid, integer); 
CREATE OR REPLACE FUNCTION public.pldbg_drop_breakpoint(session integer, func oid, linenumber integer)
 RETURNS boolean
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_drop_breakpoint$function$
; DROP FUNCTION public.pldbg_get_breakpoints(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_get_breakpoints(session integer)
 RETURNS SETOF breakpoint
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_get_breakpoints$function$
; DROP FUNCTION public.pldbg_get_source(integer, oid); 
CREATE OR REPLACE FUNCTION public.pldbg_get_source(session integer, func oid)
 RETURNS text
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_get_source$function$
; DROP FUNCTION public.pldbg_get_stack(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_get_stack(session integer)
 RETURNS SETOF frame
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_get_stack$function$
; DROP FUNCTION public.pldbg_get_proxy_info(); 
CREATE OR REPLACE FUNCTION public.pldbg_get_proxy_info()
 RETURNS proxyinfo
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_get_proxy_info$function$
; DROP FUNCTION public.pldbg_get_variables(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_get_variables(session integer)
 RETURNS SETOF var
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_get_variables$function$
; DROP FUNCTION public.pldbg_select_frame(integer, integer); 
CREATE OR REPLACE FUNCTION public.pldbg_select_frame(session integer, frame integer)
 RETURNS breakpoint
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_select_frame$function$
; DROP FUNCTION public.pldbg_set_breakpoint(integer, oid, integer); 
CREATE OR REPLACE FUNCTION public.pldbg_set_breakpoint(session integer, func oid, linenumber integer)
 RETURNS boolean
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_set_breakpoint$function$
; DROP FUNCTION public.pldbg_set_global_breakpoint(integer, oid, integer, integer); 
CREATE OR REPLACE FUNCTION public.pldbg_set_global_breakpoint(session integer, func oid, linenumber integer, targetpid integer)
 RETURNS boolean
 LANGUAGE c
AS '$libdir/pldbgapi', $function$pldbg_set_global_breakpoint$function$
; DROP FUNCTION public.pldbg_step_into(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_step_into(session integer)
 RETURNS breakpoint
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_step_into$function$
; DROP FUNCTION public.pldbg_step_over(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_step_over(session integer)
 RETURNS breakpoint
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_step_over$function$
; DROP FUNCTION public.pldbg_wait_for_breakpoint(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_wait_for_breakpoint(session integer)
 RETURNS breakpoint
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_wait_for_breakpoint$function$
; DROP FUNCTION public.pldbg_wait_for_target(integer); 
CREATE OR REPLACE FUNCTION public.pldbg_wait_for_target(session integer)
 RETURNS integer
 LANGUAGE c
 STRICT
AS '$libdir/pldbgapi', $function$pldbg_wait_for_target$function$
; DROP FUNCTION public.bidding(numeric, character varying, date, date, date, numeric, numeric, numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION public.bidding(ipuser_id numeric, ipdocno character varying, ipdocdate date, ipfromtermpaydate date DEFAULT NULL::date, iptotermpaydate date DEFAULT NULL::date, ipisperson numeric DEFAULT NULL::numeric, ipminsumdebt numeric DEFAULT NULL::numeric, ipmaxsumdebt numeric DEFAULT NULL::numeric, ipkinddebtreg numeric DEFAULT NULL::numeric, ipfromtaxyaer numeric DEFAULT NULL::numeric, iptotaxyear numeric DEFAULT NULL::numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare                                    
  r record;
  i numeric;
/*  vfromtermpaydate date;
  vtotermpaydate   date;
  vminsumdebt      numeric;
  vmaxsumdebt      numeric;
  vfromtaxyaer     numeric;
  vtotaxyear       numeric;*/
  vgroupaction_Id  numeric;
  vdsid            numeric;
  vaction_Id       numeric;
  Lixva            varchar(50);

  cr cursor for
    select ds.debtsubject_id, ds.docno, ds.doc_date, di.debtinstalment_id,
           bdi.instsum, bdi.interestsum, ds.taxsubject_id
    from   debtsubject ds, debtinstalment di, baldebtinst bdi, taxsubject ts
    where  ds.debtsubject_id = di.debtsubject_id
    and    di.debtinstalment_id = bdi.debtinstalment_id
    and    ds.taxsubject_id = ts.taxsubject_id
    and    (nvl(bdi.instsum, 0.0) + nvl(bdi.interestsum, 0.0)) >= ipminsumdebt
    and    (nvl(bdi.instsum, 0.0) + nvl(bdi.interestsum, 0.0)) <= ipmaxsumdebt
    and    di.termpay_date > ipfromtermpaydate
    and    di.termpay_date < iptotermpaydate
    and    To_Number(To_char(ds.tax_begidate, 'yyyy')) >= ipfromtaxyaer
    and    To_number(To_Char(ds.tax_begidate, 'yyyy')) <= iptotaxyear
    and    ts.isperson = nvl(ipisperson, ts.isperson)
    and    ds.kinddebtreg_id = nvl(ipkinddebtreg, ds.kinddebtreg_id)
    and    not exists
     (select *
            from   actionItem ai, action a
            where  ai.action_id = a.action_id
            and    a.kindaction = '20'
            and    ai.debtinstalment_id = di.debtinstalment_id)
    order  by ds.debtsubject_id;

 


begin

  if ipfromtermpaydate is null
  then
    ipfromtermpaydate := to_date('01.01.1900', 'dd.mm.yyyy');
 /* else
    vfromtermpaydate := ipfromtermpaydate;*/
  end if;
  if iptotermpaydate is null
  then
    iptotermpaydate := current_date;
  /*else
    vtotermpaydate := iptotermpaydate; */
  end if;
  if ipminsumdebt is null
  then
    ipminsumdebt := 0.01;
 /* else
    vminsumdebt := ipminsumdebt;*/
  end if;
  if ipmaxsumdebt is null
  then
    ipmaxsumdebt := 999999999999;
  /*else
    vmaxsumdebt := ipmaxsumdebt;*/
  end if;
  if ipfromtaxyaer is null
  then
    ipfromtaxyaer := 1990;
  /*else
    vfromtaxyaer := ipfromtaxyaer;*/
  end if;
  if iptotaxyear is null
  then
    iptotaxyear := To_number(To_char(current_date, 'yyyy'));
/*  else
    vtotaxyear := iptotaxyear;*/
  end if;

  -- proverka na broj zapisi v cursora => zapisi!!!
  -- olixviavane do current_date
  open cr;
  loop
    fetch cr
      into r;
    exit when not FOUND;
    Lixva := Sanction_PKG.CalculateInt(r.debtinstalment_id, current_date,
                                       ipuser_Id);
  end loop;
 -- close cr;
  if Lixva <> 'OK'
  then
    opStat := Lixva;
    return;
  end if;
  --commit;


  select nextval('s_groupaction')
  into   vgroupaction_Id
  from   dual;

  insert into groupaction
    (groupaction_id, kindaction, dategroupaction, docno, docdate,
     fromtermpaydate, isperson, minsumdebt, maxsumdebt, kinddebtreg_id,
     fromtaxyaer, totaxyear, totermpaydate)
  values
    (vgroupaction_Id, '20', current_date, ipdocno, ipdocdate,
     ipfromtermpaydate, ipisperson, ipminsumdebt, ipmaxsumdebt, ipkinddebtreg,
     ipfromtaxyaer, iptotaxyear, iptotermpaydate);

  i     := 1;
  vdsid := -1;
  begin
  --  open cr;
    loop
      fetch cr
        into r;
      exit when not FOUND;
      if vdsid <> r.debtsubject_id
      then
        select nextval('s_action')
        into   vaction_id
        from   dual;
        insert into action
          (action_id, groupaction_id, taxdoc_id, taxsubject_id, kindaction,
           seqnom, docno, doc_date, action_date, exec_date, exec_user_date,
           exec_user_id)
        values
          (vaction_id, vgroupaction_id, null, r.taxsubject_id, '20', i, r.docno,
           r.doc_date, current_date, current_date, current_date, ipuser_id);
      
        vdsid := r.debtsubject_id;
        i     := i + 1;
      end if;
      insert into actionitem
        (action_id, debtinstalment_id, instsum, interestsum)
      
      values
        (vaction_id, r.debtinstalment_id, r.instsum, r.interestsum);
    
    end loop;
    close cr;
  end;
  --commit;
  opStat := 'OK';  
exception
  when others then
    --rollback;
    opStat := 'errOrclDB'||sqlerrm; --'������'; 

end;
$function$
;
