DROP FUNCTION tvservices.deltvtaxdoc(numeric); 
CREATE OR REPLACE FUNCTION tvservices.deltvtaxdoc(iptvtaxdoc_id numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
begin
  ---- tvpartland ----
  delete from tvpartland pl
  where  pl.tvland_id in
         (select l.tvland_id
          from   tvland l
          where  l.tvproperty_id in
                 (select p.tvproperty_id
                  from   tvproperty p
                  where  p.tvtaxdoc_id = iptvtaxdoc_id));
  --- tvland ---
  delete from tvland l
  where  l.tvproperty_id in
         (select p.tvproperty_id
          from   tvproperty p
          where  p.tvtaxdoc_id = iptvtaxdoc_id);
  --- tvparthomeobj ---
  delete from tvparthomeobj po
  where  po.tvhomeobj_id in
         (select ho.tvhomeobj_id
          from   tvhomeobj ho
          where  ho.tvbuilding_id in
                 (select b.tvbuilding_id
                  from   tvbuilding b
                  where  b.tvproperty_id in
                         (select p.tvproperty_id
                          from   tvproperty p
                          where  p.tvtaxdoc_id in
                                 (select td.tvtaxdoc_id
                                  from   tvtaxdoc td
                                  where  td.tvtaxdoc_id = iptvtaxdoc_id))));
  --- tvhomeobj ---
  delete from tvhomeobj ho
  where  ho.tvbuilding_id in
         (select b.tvbuilding_id
          from   tvbuilding b
          where  b.tvproperty_id in
                 (select p.tvproperty_id
                  from   tvproperty p
                  where  p.tvtaxdoc_id in
                         (select td.tvtaxdoc_id
                          from   tvtaxdoc td
                          where  td.tvtaxdoc_id = iptvtaxdoc_id)));
  --- tvbuilding --- 
  delete from tvbuilding b
  where  b.tvproperty_id in
         (select p.tvproperty_id
          from   tvproperty p
          where  p.tvtaxdoc_id in
                 (select td.tvtaxdoc_id
                  from   tvtaxdoc td
                  where  td.tvtaxdoc_id = iptvtaxdoc_id));
  --- tvpartproperty ---
  delete from tvpartproperty pp
  where  pp.tvproperty_id in
         (select p.tvproperty_id
          from   tvproperty p
          where  p.tvtaxdoc_id in
                 (select td.tvtaxdoc_id
                  from   tvtaxdoc td
                  where  td.tvtaxdoc_id = iptvtaxdoc_id));
  --- tvproperty ---
  delete from tvproperty p
  where  p.tvtaxdoc_id in
         (select td.tvtaxdoc_id
          from   tvtaxdoc td
          where  td.tvtaxdoc_id = iptvtaxdoc_id);
  --- tvtaxdoc ---
  delete from tvtaxdoc td
  where  td.tvtaxdoc_id = iptvtaxdoc_id;
  --commit;
  opstat := 'OK';
exception
  when others then
    --rollback;
    opstat := sqlerrm;
end;
$function$
; DROP FUNCTION tvservices.instvdoc(numeric, numeric, numeric, numeric); 
CREATE OR REPLACE FUNCTION tvservices.instvdoc(iptaxdoc_id numeric, iptaxsubject_id numeric, ipuser_id numeric, ipcertreq_id numeric, OUT optvtaxdoc_id numeric, OUT opstat character varying)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare

  crprop cursor(ptaxdoc_id numeric) is
    select *
    from   property p
    where  p.taxdoc_id = ptaxdoc_id;

  rp     record;

  crbuilding cursor(ipprop_id numeric) is
    select *
    from   building b
    where  b.property_id = ipprop_id;

  rb         record;

  crhomeobj cursor(ipbuild_id numeric) is
    select h.*
    from   homeobj h
    where  h.building_id = ipbuild_id
    and ((h.taxenddate is null) or (h.taxenddate > trunc(sysdate)));
  rho       record;

  crland cursor(ipproperty_id numeric) is
    select *
    from   land l
    where  l.property_id = ipproperty_id
    and    l.taxenddate is null;

  rl     record;

  vtvtaxdoc_id   numeric;
  vtvprop_id     numeric;
  vtvbuilding_id numeric;
  vtvhomeobj_id  numeric;
  vtvland_id     numeric;
  vdoctype_id    numeric;

begin
  opstat := 'OK';
  select nextval('s_tvtaxdoc')
  into   vtvtaxdoc_id;
  insert into tvtaxdoc
    (tvtaxdoc_id, municipality_id, taxsubject_id, kinddecl, partidano,
     documenttype_id, taxdocdate, docno, doc_date, user_id, note, user_date,
     user_name, property_address_id, taxdoc_id)
    select vtvtaxdoc_id, td.municipality_id, td.taxsubject_id, td.kinddecl,
           td.partidano, td.documenttype_id, td.taxdocdate, td.docno,
           td.doc_date, ipuser_id, null, CURRENT_TIMESTAMP,
           (select u.fullname
             from   users u
             where  u.user_id = ipuser_id),
           (select t.address_id
             from   taxobject t
             where  t.taxobject_id = td.taxobject_id), td.taxdoc_id
    from   taxdoc td
    where  td.taxdoc_id = iptaxdoc_id;

  optvtaxdoc_id := vtvtaxdoc_id;
  select td.documenttype_id
  into   vdoctype_id
  from   taxdoc td
  where  td.taxdoc_id = iptaxdoc_id;

  if vdoctype_id = 22
  then
    select nextval('s_tvproperty')
    into   vtvprop_id;
    insert into tvproperty
      (tvproperty_id, tvtaxdoc_id, property_address_id, kindproperty)
      select vtvprop_id, vtvtaxdoc_id, fp.PROPERTY_ADDRESS_ID, fp.kindproperty
      from   firmproperty fp
      where  fp.taxdoc_id = iptaxdoc_id;
  end if;

  open crprop(iptaxdoc_id);
  loop
    fetch crprop
      into rp;
    exit when not found;
  
    select nextval('s_tvproperty')
    into   vtvprop_id;
    insert into tvproperty
      (tvproperty_id, tvtaxdoc_id, property_address_id, kindproperty, kindland,
       iselectro, iswater, kadastrno, kadastr_year, issewer, istec, isroad,
       category_city, isnationalresort, islocalresort, isseezone,
       isnationalroadnet, isisolatedzone, builder_zone, zrpno_district,
       zrpno_parcel, zrp_date, seezone_cat, note, constructionbound, user_id,
       user_date, CITY_CATEGORY1, CITY_CATEGORY2, structurezone)
    values
      (vtvprop_id, vtvtaxdoc_id, rp.property_address_id, rp.kindproperty,
       rp.kindland, rp.iselectro, rp.iswater, rp.kadastrno, rp.kadastr_year,
       rp.issewer, rp.istec, rp.isroad, rp.category_city, rp.isnationalresort,
       rp.islocalresort, rp.isseezone, rp.isnationalroadnet, rp.isisolatedzone,
       rp.builder_zone, rp.zrpno_district, rp.zrpno_parcel, rp.zrp_date,
       rp.seezone_cat, null, rp.constructionbound, ipuser_id, current_timestamp,
       rp.CITY_CATEGORY1, rp.CITY_CATEGORY2, rp.structurezone);
  
    insert into tvpartproperty
      (tvpartproperty_id, tvproperty_id, seqnots, taxsubject_id, typedeclar)
      select nextval('s_tvpartproperty'), vtvprop_id, pp.seqnots,
             pp.taxsubject_id, pp.typedeclar
      from   partproperty pp
      where  pp.property_id = rp.property_id;
  
    if ipcertreq_id = 3
    then
      exit;
    end if;
  
    open crbuilding(rp.property_id);
    loop
      fetch crbuilding
        into rb;
      exit when not found;
    
      select nextval('s_tvbuilding')
      into   vtvbuilding_id;
      insert into tvbuilding
        (tvbuilding_id, seqnobuilding, kindfunction, floornumber, tvproperty_id,
         floornumover, elevator, user_id, userdate, note)
      values
        (vtvbuilding_id, rb.seqnobuilding, rb.kindfunction, rb.floornumber,
         vtvprop_id, rb.floornumover, rb.elevator, ipuser_id, current_timestamp,
         rb.note);
    
      open crhomeobj(rb.building_id);
      loop
        fetch crhomeobj
          into rho;
        exit when not found;
      
        select nextval('s_tvhomeobj')
        into   vtvhomeobj_id;
        insert into tvhomeobj
          (tvhomeobj_id, seqnoobj, tvbuilding_id, function, objectarea,
           kindhomeobjreg_id, cellerarea, atticarea, totalarea, height,
           builddate, floor, kindconstruction, iselectro, iswater, issewer,
           istec, istelefon, isbusiness, repairdate, isheating, isaircondition,
           luxwindow, soundinsulation, specialroof, luxdecorate,
           -- dividend,  divisor, part, usearea, taxvalue,
           user_id, user_date)
        values
          (vtvhomeobj_id, rho.seqnoobj, vtvbuilding_id, rho.function,
           rho.objectarea, rho.kindhomeobjreg_id, rho.cellerarea, rho.atticarea,
           rho.totalarea, rho.height, rho.builddate, rho.floor,
           rho.kindconstruction, rho.iselectro, rho.iswater, rho.issewer,
           rho.istec, rho.istelefon, rho.isbusiness, rho.repairdate,
           rho.isheating, rho.isaircondition, rho.luxwindow, rho.soundinsulation,
           rho.specialroof, rho.luxdecorate,
           -- dividend,  divisor, part, usearea, taxvalue,
           ipuser_id, current_date);
      
        ----------------
        insert into tvparthomeobj
          (tvparthomeobj_id, seqnots, tvhomeobj_id, taxsubject_id, typedeclar,
           isbasehome, divident, divisor, part, taxvalue)
          select nextval('s_tvparthomeobj'), pho.seqnots, vtvhomeobj_id,
                 pho.taxsubject_id, pho.typedeclar, pho.isbasehome, pho.divident,
                 pho.divisor,
                 case nvl(pho.area, 0.0)
                   when 0 then
                    pho.part
                   else
                    (select pho.area / nvl(min(h.totalarea), pho.area)
                     from   homeobj h
                     where  h.homeobj_id = pho.homeobj_id)
                 end, 0
          from   parthomeobj pho
          where  pho.homeobj_id = rho.homeobj_id;
        ----------------
      
      end loop; --- homeobj;
      close crhomeobj;
    
    end loop; --- building
    close crbuilding;
  
    open crland(rp.property_id);
    loop
      fetch crland
        into rl;
      exit when not found;
    
      select nextval('s_tvland')
      into   vtvland_id;
      insert into tvland
        (tvland_id, typedeclar, buildingowner, tvproperty_id, landarea,
         builtuparea, fenceheight, fencelength, isfence, coveringarea, sportarea,
         iscovering, poolcapacity, greenparking, parkingarea, issportcovering,
         ispool, isgreenparking, kindland, isparking, isbusiness,
         --userightdate, userightterm, age, divident,
         user_id, user_date
         --, divisor, part, note, usearea, taxvalue
         )
      values
        (vtvland_id, rl.typedeclar, rl.buildingowner, vtvprop_id, rl.landarea,
         rl.builtuparea, rl.fenceheight, rl.fencelength, rl.isfence,
         rl.coveringarea, rl.sportarea, rl.iscovering, rl.poolcapacity,
         rl.greenparking, rl.parkingarea, rl.issportcovering, rl.ispool,
         rl.isgreenparking, null, rl.isparking, rl.isbusiness, ipuser_id,
         current_timestamp);
    
      --------------
      insert into tvpartland
        (tvpartland_id, taxsubject_id, tvland_id, seqnots, typedeclar,
         dividentland, divisorland, partland, taxvalue)
        select nextval('s_tvpartland'), pl.taxsubject_id, vtvland_id,
               pl.seqnots, pl.typedeclar, pl.dividentland, pl.divisorland,
               decode(nvl(pl.area, 0.0), 0.0, pl.partland,
                         round(nvl(pl.area, 0.0) / rl.landarea, 2)), 0
        from   partland pl
        where  pl.land_id = rl.land_id;
      -----------------
    
    end loop; -- land
    close crland;
  
  end loop; --- propertyend instvdoc;

  opstat := 'OK';

  --perform tvservices.counttax(optvtaxdoc_id,opstat);
  select into opstat *
  from   tvservices.counttax(optvtaxdoc_id);
exception
  when others then
    --rollback;
    opstat := sqlerrm;
end;
$function$
; DROP FUNCTION tvservices.tvhomebuild(numeric, date); 
CREATE OR REPLACE FUNCTION tvservices.tvhomebuild(OUT return_val character varying, iphomeobj_id numeric, ipyear date, OUT vgroupe numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  RowHomeObj  tvHomeobj%rowtype;
  rowBuilding tvBuilding%rowtype;
  RowProperty tvProperty%rowtype;
  rowtaxdoc   tvtaxdoc%rowtype;
  vBS1        numeric;
  vBS         numeric;
  vKM         numeric;
  vKI         numeric;
  vKX         numeric;
  vKB         numeric;
  vKO         numeric;
  vPL         numeric;
  vgr         varchar(10);
  vekatte     varchar(10);
  vki1        numeric;
  vki2        numeric;
  vki3        numeric;
  vkZav       numeric;
  vObjGroup   numeric;
  --   vGroupe numeric;
  vkzone   numeric [ ];
  vcitycat numeric;
  vYear    date;
begin
  vYear := to_date('01.01.' || to_char(ipYear, 'yyyy'), 'dd.mm.yyyy');
  select *
  into   RowHomeObj
  from   tvhomeobj h
  where  h.tvhomeobj_id = ipHomeobj_Id;
  select *
  into   rowBuilding
  from   tvbuilding b
  where  b.tvbuilding_id = rowhomeobj.tvbuilding_id;
  select *
  into   RowProperty
  from   tvproperty p
  where  p.tvproperty_id = rowBuilding.tvProperty_Id;
  select *
  into   rowtaxdoc
  from   tvtaxdoc td
  where  td.tvtaxdoc_id = RowProperty.Tvtaxdoc_Id;
  -------  BS
  select min(kh.objgroup)
  into   vObjGroup
  from   kindhomeobjreg kh
  where  kh.kindhomeobjreg_id = RowHomeObj.Kindhomeobjreg_Id;
  select case rowBuilding.kindfunction
           when '2' then
            nb.apartmentvalue
           when '1' then
            nb.housevalue
           when '3' then
            nb.housevalue
           when '4' then
            nb.housevalue
           else
            nb.nohousevalue
         end
  -- decode(rowBuilding.kindfunction, '2', nb.apartmentvalue, '1', nb.housevalue,'3', nb.housevalue,'4', nb.housevalue, nb.nohousevalue)
  into   vBS
  from   normbs nb
  where  nb.kindconstruction = RowHomeObj.Kindconstruction
  and    nb.normyear = (select max(n.normyear)
                        from   normbs n
                        where  n.normyear <= ipYear);
  vBS1 := 100;
  if rowBuilding.kindfunction in ('1', '3', '4')
  then
    if vObjGroup in (3, 4)
    then
      vBS1 := 60;
    end if;
    if vObjGroup = 5
    then
      vBS1 := 40;
    end if;
    if vObjGroup = 2
    then
      vBS1 := 85;
    end if;
    if vObjGroup = 10
    then
      vBS1 := 80;
    end if;
  elsif rowBuilding.kindfunction = '2'
  then
    if vObjGroup in (2, 10)
    then
      vBS1 := 80;
    end if;
  else
    if vObjGroup in (3, 4)
    then
      vBS1 := 60;
    end if;
    if vObjGroup = 5
    then
      vBS1 := 40;
    end if;
    if vObjGroup in (10)
    then
      vBS1 := 80;
    end if;
    --    if vObjGroup in (2) then vBS1 := 85; end if;
  end if;
  vBS := vBS * vBS1 / 100;
  ---------- KM

  select min(c.ekatte)
  into   vekatte
  from   address a, city c
  where  a.address_id = RowProperty.Property_address_id
  and    c.city_id = a.city_id;
  select min(c.citycat), min(c.citygroup)
  into   vcitycat, vgr
  from   CITYCAT_NORMKM3 c
  where  c.ekatte = vekatte
  and    c.begindate = (select max(cc.begindate)
                        from   CITYCAT_NORMKM3 cc
                        where  cc.ekatte = vekatte
                        and    cc.begindate <= ipYear);
  if vcitycat is null
  then
    vcitycat := rowproperty.category_city;
    if rowproperty.category_city = 0
    then
      vgr := vekatte;
    elsif rowproperty.category_city > 1
    then
      vgr := '0';
    elsif rowproperty.category_city = 1
    then
      vgr := '2';
    end if;
  end if;
  vKM := 1;
  if (rowBuilding.Kindfunction = '6') or (rowBuilding.Kindfunction = '7')
  then
    select array [ min(n.productionbuildingbm), min(n.productionbuildingnbm),
           min(n.farmbuildingbm), min(n.farmbuildingnbm) ]
    into   vkzone
    from   normkm4 n
    where  n.normyear = (select max(nn.normyear)
                         from   normkm4 nn
                         where  nn.normyear <= ipYear)
    and    n.category_city = vcitycat
    and    n.groupe = vgr;
    if (rowBuilding.Kindfunction = '6')
    then
      if ((2 - nvl(RowProperty.Constructionbound, '2') ::integer) +
         nvl(RowProperty.Isnationalroadnet, 0.0) +
         nvl(RowProperty.Isisolatedzone, 0.0)) > 1
      then
        vKM := nvl(vkzone [ 1 ], 0.0);
      else
        vKM := nvl(vkzone [ 2 ], 0.0);
      end if;
    end if;
    if (rowBuilding.Kindfunction = '7')
    then
      if ((2 - nvl(RowProperty.Constructionbound, '2') ::integer) +
         nvl(RowProperty.Isnationalroadnet, 0.0) +
         nvl(RowProperty.Isisolatedzone, 0.0)) > 1
      then
        vKM := nvl(vkzone [ 3 ], 0.0);
      else
        vKM := nvl(vkzone [ 4 ], 0.0);
      end if;
    end if;
  else
    select array [ min(n.kzone1), min(n.kzone2), min(n.kzone3), min(n.kzone4),
           min(n.kzone5), min(n.inbound), min(n.outbound), min(n.villazone1),
           min(n.villazone2) ]
    into   vkzone
    from   normkm3 n
    where  n.normyear = (select max(nn.normyear)
                         from   normkm3 nn
                         where  nn.normyear <= ipYear)
    and    n.category_city ::numeric = vcitycat
    and    n.groupe = vgr;
    --- Stroitelni granici
    if nvl(RowProperty.Builder_Zone, 0.0) > 0
    then
      vKM := vkzone [ RowProperty.Builder_Zone ];
    else
      if nvl(RowProperty.Seezone_Cat, 0.0) > 0
      then
        vKM := vkzone [ RowProperty.Seezone_Cat + 7 ];
      end if;
    end if;
    if (nvl(RowProperty.Builder_Zone, 0.0) = 0) and
       (nvl(RowProperty.Seezone_Cat, 0.0) = 0)
    then
      vKM := vkzone [ nvl(RowProperty.Constructionbound, '0') ::numeric + 5 ];
    end if;
    if RowHomeObj.Kindhomeobjreg_Id in (6, 10, 14, 18, 22)
    then
      vKM := nvl(vKM, 0.0) * 140 / 100;
    end if;
  end if;
  ---- Zavishenie na KM
  vkZav := 1;
  if (RowProperty.Isnationalresort = 1) or (RowProperty.Isseezone = 1)
  then
    if vekatte not in ('10135', '07079') -- and vcitycat <> 1  ???????
       and ((nvl(RowProperty.Constructionbound, '0') <> '2') or
       (nvl(RowProperty.Builder_Zone, 0.0) <> 0) or
       (nvl(RowProperty.Seezone_Cat, 0.0) <> 0))
    then
      if extract(year from ipYear) < 2006
      then
        vkZav := vkZav * 1.20;
      else
        if vcitycat <> 1
        then
          vkZav := vkZav * 1.50;
        end if;
      end if;
    end if;
  end if;
  if RowProperty.Islocalresort = 1 -- and vcitycat <> 1   ?????
     and ((nvl(RowProperty.Constructionbound, '0') <> '2') or
     (nvl(RowProperty.Builder_Zone, 0.0) <> 0) or
     (nvl(RowProperty.Seezone_Cat, 0.0) <> 0))
  then
    if extract(year from ipYear) < 2006
    then
      vkZav := vkZav * 1.10;
    else
      if vcitycat <> 1
      then
        vkZav := vkZav * 1.20;
      end if;
    end if;
  end if;
  vkm := nvl(vkm, 0.0) * vkzav; --(100 + vkzav)/ 100;
  ---------- KI
  vKI := 1;
  if nvl(RowProperty.Iswater, 0.0) > 0
  then
    select k.havevalue, k.haventvalue, k.haveregionvalue
    into   vki1, vki2, vki3
    from   Normki k
    where  k.normyear = (select max(n.normyear)
                         from   Normki n
                         where  n.normyear <= ipYear)
    and    k.kindelement = 1;
    if RowProperty.Iswater = 1
    then
      vKI := vKI + vki1;
    end if;
    if RowProperty.Iswater = 2
    then
      vKI := vKI + vki3;
    end if;
    if RowProperty.Iswater = 3
    then
      vKI := vKI + vki2;
    end if;
  end if;
  if nvl(RowProperty.Issewer, 0.0) > 0
  then
    select k.havevalue, k.haventvalue, k.haveregionvalue
    into   vki1, vki2, vki3
    from   Normki k
    where  k.normyear = (select max(n.normyear)
                         from   Normki n
                         where  n.normyear <= ipYear)
    and    k.kindelement = 2;
    if RowProperty.Issewer = 1
    then
      vKI := vKI + vki1;
    end if;
    if RowProperty.Issewer = 2
    then
      vKI := vKI + vki3;
    end if;
    if RowProperty.Issewer = 3
    then
      vKI := vKI + vki2;
    end if;
  end if;
  if nvl(RowProperty.Iselectro, 0.0) > 0
  then
    select k.havevalue, k.haventvalue, k.haveregionvalue
    into   vki1, vki2, vki3
    from   Normki k
    where  k.normyear = (select max(n.normyear)
                         from   Normki n
                         where  n.normyear <= ipYear)
    and    k.kindelement = 3;
    if RowProperty.Iselectro = 1
    then
      vKI := vKI + vki1;
    end if;
    if RowProperty.Iselectro = 2
    then
      vKI := vKI + vki3;
    end if;
    if RowProperty.Iselectro = 3
    then
      vKI := vKI + vki2;
    end if;
  end if;
  --if nvl(RowProperty.Isroad,0) > 0 then
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 6;
  if nvl(RowProperty.Isroad, 0.0) = 0
  then
    vKI := vKI + vki2;
  end if;
  if RowProperty.Isroad = 1
  then
    vKI := vKI + vki1;
  end if;
  --  if  RowProperty.Isroad = 3 then  vKI := vKI + vki3; end if;
  --end if;
  vKI := round(vKI, 2);
  --------- PL
  vPL := coalesce(RowHomeObj.Objectarea,0);
  if RowHomeObj.Kindhomeobjreg_Id < 6
  then
    --  if rowBuilding.Kindfunction < 3 then
    -- ??????? if RowHomeObj.kindhomeobj < 3 then
    vPL := vPL +
           (nvl(RowHomeObj.Cellerarea, 0.0) + nvl(RowHomeObj.Atticarea, 0.0)) * 30 / 100;
  else
    vPL := vPL +
           (nvl(RowHomeObj.Cellerarea, 0.0) + nvl(RowHomeObj.Atticarea, 0.0)) * 60 / 100;
  end if;

  vGroupe := nvl(vBS, 0.0) * nvl(vKM, 0.0) * nvl(vKI, 0.0) * nvl(vPL, 0.0);
  vGroupe := round(vGroupe, 1);
  update tvhomeobj h
  set    taxvalue = vGroupe,
         koeff = ' BS=' || vBS || ' * KM=' || vKM || ' * KI=' || vKI || ' * KX=' || vKX ||
                  ' * KB=' || vKB || ' * KO=' || vKO || ' * PL=' || vPL
  where  h.tvhomeobj_id = RowHomeObj.Tvhomeobj_Id;
  --commit;
  --dbms_output.put_line(RowHomeObj.tvhomeobj_id ||' BS=' || vBS ||' * KM='|| vKM ||' * KI='|| vKI ||' * KX='|| vKX ||' * KB='|| vKB ||' * KO='|| vKO ||' * PL='|| vPL);
  return_val := 'OK';
  return;
  --   return(vBS ||' * '|| vKM ||' * '|| vKI ||' * '  || vPL);

end;
$function$
; DROP FUNCTION tvservices.tvhomesert(numeric, date); 
CREATE OR REPLACE FUNCTION tvservices.tvhomesert(OUT return_val character varying, iphomeobj_id numeric, ipyear date, OUT vgroupe numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  RowHomeObj  tvHomeobj%rowtype;
  rowBuilding tvBuilding%rowtype;
  RowProperty tvProperty%rowtype;
  rowtaxdoc   tvtaxdoc%rowtype;
  vBS1        numeric;
  vBS         numeric;
  vKM         numeric;
  vKI         numeric;
  vKX         numeric;
  vKB         numeric;
  vKO         numeric;
  vPL         numeric;
  vgr         varchar(10);
  vekatte     varchar(10);
  vki1        numeric;
  vki2        numeric;
  vki3        numeric;
  vKO1        numeric;
  vKX1        numeric;
  vKX2        numeric;
  vKX3        numeric;
  vkZav       numeric;
  vObjGroup   numeric;
 -- vGroupe numeric;
  vkzone   numeric [ ];
  vcitycat numeric;
  vYear    date;
  voFloor  numeric;
begin
  vYear := to_date('01.01.' || to_char(ipYear, 'yyyy'), 'dd.mm.yyyy');
  select *
  into   RowHomeObj
  from   tvhomeobj h
  where  h.tvhomeobj_id = ipHomeobj_Id;
  select *
  into   rowBuilding
  from   tvbuilding b
  where  b.tvbuilding_id = rowhomeobj.tvbuilding_id;
  select *
  into   RowProperty
  from   tvproperty p
  where  p.tvproperty_id = rowBuilding.tvProperty_Id;
  select *
  into   rowtaxdoc
  from   tvtaxdoc td
  where  td.tvtaxdoc_id = RowProperty.Tvtaxdoc_Id;
  -------  BS
  select min(kh.objgroup)
  into   vObjGroup
  from   kindhomeobjreg kh
  where  kh.kindhomeobjreg_id = RowHomeObj.Kindhomeobjreg_Id;
  select case rowBuilding.kindfunction
           when '2' then
            nb.apartmentvalue
           when '1' then
            nb.housevalue
           when '3' then
            nb.housevalue
           when '4' then
            nb.housevalue
           else
            nb.nohousevalue
         end
  --decode(rowBuilding.kindfunction, '2', nb.apartmentvalue, '1', nb.housevalue,'3', nb.housevalue,'4', nb.housevalue, nb.nohousevalue)
  into   vBS
  from   normbs nb
  where  nb.kindconstruction = RowHomeObj.Kindconstruction
  and    nb.normyear = (select max(n.normyear)
                        from   normbs n
                        where  n.normyear <= ipYear);
  vBS1 := 100;
  if rowBuilding.kindfunction in ('1', '3', '4')
  then
    if vObjGroup in (3, 4)
    then
      vBS1 := 60;
    end if;
    if vObjGroup = 5
    then
      vBS1 := 40;
    end if;
    if vObjGroup = 2
    then
      vBS1 := 85;
    end if;
    if vObjGroup = 10
    then
      vBS1 := 80;
    end if;
  elsif rowBuilding.kindfunction = '2'
  then
    if vObjGroup in (2, 10)
    then
      vBS1 := 80;
    end if;
  else
    if vObjGroup in (3, 4)
    then
      vBS1 := 60;
    end if;
    if vObjGroup = 5
    then
      vBS1 := 40;
    end if;
    if vObjGroup in (10)
    then
      vBS1 := 80;
    end if;
    --    if vObjGroup in (2) then vBS1 := 85; end if;
  end if;
  vBS := vBS * vBS1 / 100;
  ---------- KM

  select min(c.ekatte)
  into   vekatte
  from   address a, city c
  where  a.address_id = RowProperty.Property_address_id
  and    c.city_id = a.city_id;
  select min(c.citycat), min(c.citygroup)
  into   vcitycat, vgr
  from   CITYCAT_NORMKM3 c
  where  c.ekatte = vekatte
  and    c.begindate = (select max(cc.begindate)
                        from   CITYCAT_NORMKM3 cc
                        where  cc.ekatte = vekatte
                        and    cc.begindate <= ipYear);
  if vcitycat is null
  then
    vcitycat := rowproperty.category_city;
    if rowproperty.category_city = 0
    then
      vgr := vekatte;
    elsif rowproperty.category_city > 1
    then
      vgr := '0';
    elsif rowproperty.category_city = 1
    then
      vgr := '2';
    end if;
  end if;
  vKM := 1;
  if (rowBuilding.Kindfunction = '6') or (rowBuilding.Kindfunction = '7')
  then
    select array [ min(n.productionbuildingbm), min(n.productionbuildingnbm),
           min(n.farmbuildingbm), min(n.farmbuildingnbm) ]
    into   vkzone
    from   normkm4 n
    where  n.normyear = (select max(nn.normyear)
                         from   normkm4 nn
                         where  nn.normyear <= ipYear)
    and    n.category_city = vcitycat
    and    n.groupe = vgr;
    if (rowBuilding.Kindfunction = '6')
    then
      if ((2 - nvl(RowProperty.Constructionbound, '2') ::integer) +
         nvl(RowProperty.Isnationalroadnet, 0.0) +
         nvl(RowProperty.Isisolatedzone, 0.0)) > 1
      then
        vKM := nvl(vkzone [ 1 ], 0.0);
      else
        vKM := nvl(vkzone [ 2 ], 0.0);
      end if;
    end if;
    if (rowBuilding.Kindfunction = '7')
    then
      if ((2 - nvl(RowProperty.Constructionbound, '2') ::integer) +
         nvl(RowProperty.Isnationalroadnet, 0.0) +
         nvl(RowProperty.Isisolatedzone, 0.0)) > 1
      then
        vKM := nvl(vkzone [ 3 ], 0.0);
      else
        vKM := nvl(vkzone [ 4 ], 0.0);
      end if;
    end if;
  else
    select array [ min(n.kzone1), min(n.kzone2), min(n.kzone3), min(n.kzone4),
           min(n.kzone5), min(n.inbound), min(n.outbound), min(n.villazone1),
           min(n.villazone2) ]
    into   vkzone
    from   normkm3 n
    where  n.normyear = (select max(nn.normyear)
                         from   normkm3 nn
                         where  nn.normyear <= ipYear)
    and    n.category_city ::numeric = vcitycat
    and    n.groupe = vgr;
    --- Stroitelni granici
    if nvl(RowProperty.Builder_Zone, 0.0) > 0
    then
      vKM := vkzone [ RowProperty.Builder_Zone ];
    else
      if nvl(RowProperty.Seezone_Cat, 0.0) > 0
      then
        vKM := vkzone [ RowProperty.Seezone_Cat + 7 ];
      end if;
    end if;
    if (nvl(RowProperty.Builder_Zone, 0.0) = 0) and
       (nvl(RowProperty.Seezone_Cat, 0.0) = 0)
    then
      vKM := vkzone [ nvl(RowProperty.Constructionbound, '0') ::numeric + 5 ];
    end if;
    if RowHomeObj.Kindhomeobjreg_Id in (6, 10, 14, 18, 22)
    then
      vKM := nvl(vKM, 0.0) * 140 / 100;
    end if;
  end if;
  ---- Zavishenie na KM
  vkZav := 1;
  if (RowProperty.Isnationalresort = 1) or (RowProperty.Isseezone = 1)
  then
    if vekatte not in ('10135', '07079') -- and vcitycat <> 1  ???????
       and ((nvl(RowProperty.Constructionbound, '0') <> '2') or
       (nvl(RowProperty.Builder_Zone, 0.0) <> 0) or
       (nvl(RowProperty.Seezone_Cat, 0.0) <> 0))
    then
      if extract(year from ipYear) < 2006
      then
        vkZav := vkZav * 1.20;
      else
        if vcitycat <> 1
        then
          vkZav := vkZav * 1.50;
        end if;
      end if;
    end if;
  end if;
  if RowProperty.Islocalresort = 1 -- and vcitycat <> 1   ?????
     and ((nvl(RowProperty.Constructionbound, '0') <> '2') or
     (nvl(RowProperty.Builder_Zone, 0.0) <> 0) or
     (nvl(RowProperty.Seezone_Cat, 0.0) <> 0))
  then
    if extract(year from ipYear) < 2006
    then
      vkZav := vkZav * 1.10;
    else
      if vcitycat <> 1
      then
        vkZav := vkZav * 1.20;
      end if;
    end if;
  end if;
  --   if RowHomeObj.Kindhomeobjreg_Id in (6,10,14,18,22) then
  --     vkZav := vkZav + 40;
  --   end if;
  vkm := nvl(vkm, 0.0) * vkzav; --(100 + vkzav)/ 100;
  ---------- KI
  vKI := 1;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 1; --- isWoter
  if ((RowHomeObj.Iswater = 1) or (RowProperty.Iswater = 1))
  then
    vKI := vKI + vKi1;
  else
    if RowProperty.Iswater = 3
    then
      vKI := vKI + vKi2;
    else
      vKI := vKI + vKi3;
    end if;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 2; --- isSewer
  if ((RowHomeObj.Issewer = 1) or (RowProperty.Issewer = 1))
  then
    vKI := vKI + vKi1;
  else
    if RowProperty.Issewer = 3
    then
      vKI := vKI + vKi2;
    else
      vKI := vKI + vKi3;
    end if;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 3; --- isElectro
  if ((RowHomeObj.Iselectro = 1) or (RowProperty.Iselectro = 1))
  then
    vKI := vKI + vKi1;
  else
    if RowProperty.Iselectro = 3
    then
      vKI := vKI + vKi2;
    else
      vKI := vKI + vKi3;
    end if;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 4; --- Istelefon
  if RowHomeObj.Istelefon = 1
  then
    vKI := vKI + vKi1;
  else
    vKI := vKI + vKi3;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 5; --- isTEC
  --   if ((RowHomeObj.Istec = 1) or (RowProperty.Istec = 1)) then vKI := vKI + vKi1;
  if (RowHomeObj.Istec = 1)
  then
    vKI := vKI + vKi1;
  else
    if RowProperty.Istec = 3
    then
      vKI := vKI + vKi2;
    else
      vKI := vKI + vKi3;
    end if;
  end if;
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 6; --- isRoad
  if RowProperty.Isroad = 1
  then
    vKI := vKI + vKi1;
  else
    vKI := vKI + vKi3;
  end if;
  ---------- KX
  vKX     := 1;
  vkx1    := 0;

  if RowHomeObj.Floor = ''
  then
	RowHomeObj.Floor := NULL;
  end if;
  
  voFloor := to_number(substring(coalesce(RowHomeObj.Floor, '0'),'\d+'));
  if rowBuilding.Kindfunction = '2'
  then
    if voFloor > 6
    then
      RowHomeObj.Floor := '6';
    end if;
    if voFloor > 0
    then
    
      if rowBuilding.Floornumover > 5 and rowBuilding.Elevator <> 1
      then
        select ne.noelevatornohome, ne.noelevatorapartment
        into   vkx1, vKX2
        from   normet ne
        where  ne.normyear = (select max(n.normyear)
                              from   normet n
                              where  n.normyear <= ipYear)
        and    ne.floor = RowHomeObj.Floor ::numeric;
        --    if RowHomeObj.Isbusiness <> 1 then  vkx1 := vKX2; end if;
        if RowHomeObj.Kindhomeobjreg_Id = 1
        then
          vkx1 := vKX2;
        end if;
      else
        select ne.nohouse, ne.apartment
        into   vkx1, vKX2
        from   normet ne
        where  ne.normyear = (select max(n.normyear)
                              from   normet n
                              where  n.normyear <= ipYear)
        and    ne.floor = RowHomeObj.Floor ::numeric;
        --    if RowHomeObj.Isbusiness <> 1 then  vkx1 := vKX2; end if;
        if RowHomeObj.Kindhomeobjreg_Id = 1
        then
          vkx1 := vKX2;
        end if;
      end if;
      if RowHomeObj.Kindhomeobjreg_Id in (2, 3, 4, 5)
      then
        vkx1 := 0;
      end if;
      --    if RowHomeObj.Floor = rowBuilding.Floornumover and RowHomeObj.Floor > 1 then
      if voFloor = rowBuilding.Floornumover and voFloor > 1
      then
        vkx1 := vkx1 - 0.05;
      end if;
    end if;
    if vObjGroup in (2, 10)
    then
      vkx1 := 0;
    end if;
    if coalesce(RowHomeObj.objectArea,0) = 0
    then
      vkx1 := 0;
    end if;
  end if;
  vKX2 := 0;
  if extract(year from ipyear) -
     nvl(RowHomeObj.Repairdate, nvl(RowHomeObj.Builddate, '1900'))
   ::numeric > 20
  then
    vKX2 := -0.05;
  end if;
  vKX3 := 0;
  select vKX3 + case rowhomeobj.isheating
            when 1 then
             np.have
            else
             np.havenot
          end
  into   vKX3
  from   normpod np
  where  np.kindchange = 1
  and    extract(year from np.normyear) =
         (select to_char(max(nn.normyear), 'yyyy') ::numeric
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + case rowhomeobj.isaircondition
            when 1 then
             np.have
            else
             np.havenot
          end
  into   vKX3
  from   normpod np
  where  np.kindchange = 2
  and    extract(year from np.normyear) =
         (select to_char(max(nn.normyear), 'yyyy') ::numeric
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + case rowhomeobj.luxwindow
            when 1 then
             np.have
            else
             np.havenot
          end
  into   vKX3
  from   normpod np
  where  np.kindchange = 3
  and    extract(year from np.normyear) =
         (select to_char(max(nn.normyear), 'yyyy') ::numeric
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + case rowhomeobj.soundinsulation
            when 1 then
             np.have
            else
             np.havenot
          end
  into   vKX3
  from   normpod np
  where  np.kindchange = 4
  and    extract(year from np.normyear) =
         (select to_char(max(nn.normyear), 'yyyy') ::numeric
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + case rowhomeobj.specialroof
            when 1 then
             np.have
            else
             np.havenot
          end
  into   vKX3
  from   normpod np
  where  np.kindchange = 5
  and    extract(year from np.normyear) =
         (select to_char(max(nn.normyear), 'yyyy') ::numeric
           from   normpod nn
           where  nn.normyear <= ipYear);
  select vKX3 + case rowhomeobj.luxdecorate
            when 1 then
             np.have
            else
             np.havenot
          end
  into   vKX3
  from   normpod np
  where  np.kindchange = 6
  and    extract(year from np.normyear) =
         (select to_char(max(nn.normyear), 'yyyy') ::numeric
           from   normpod nn
           where  nn.normyear <= ipYear);
  vKX := vKX + vkx1 + vKX2 + vkx3;
  --------- KB
  vKB := 1;
  --    if ((rowBuilding.Kindfunction = 5) or (rowBuilding.Kindfunction = 6) or
  --        (rowBuilding.Kindfunction = 7)) and RowHomeObj.Height > 4 then
  if (RowHomeObj.Kindhomeobjreg_Id in
     (6, 7, 8, 10, 11, 12, 14, 15, 16, 18, 19, 20, 22, 23, 24)) and
     RowHomeObj.Height > 4
  then
    vKB := power((RowHomeObj.Height - 3), 0.05);
    vKb := round(vKB, 3);
  end if;
  --------- KO
  vKO := 1;
  if extract(year from ipYear) - nvl(RowHomeObj.Builddate, '0') ::numeric > 5
  then
    select (100 - (extract(year from ipYear) - nvl(RowHomeObj.Builddate, '0')
             ::numeric - 5) * n.pctwornout) / 100, n.wornoutlimit
    into   vKO, vKO1
    from   normbs n
    where  n.kindconstruction = RowHomeObj.Kindconstruction
    and    n.normyear = (select max(nn.normyear)
                         from   Normki nn
                         where  nn.normyear <= ipYear);
    if vKO < vKo1
    then
      vKO := vKo1;
    end if;
  end if;
  --------- PL
  vPL := coalesce(RowHomeObj.Objectarea,0);
  if RowHomeObj.Kindhomeobjreg_Id < 6
  then
    --  if rowBuilding.Kindfunction < 3 then
    -- ??????? if RowHomeObj.kindhomeobj < 3 then
    vPL := vPL +
           (nvl(RowHomeObj.Cellerarea, 0.0) + nvl(RowHomeObj.Atticarea, 0.0)) * 30 / 100;
  else
    vPL := vPL +
           (nvl(RowHomeObj.Cellerarea, 0.0) + nvl(RowHomeObj.Atticarea, 0.0)) * 60 / 100;
  end if;

  vGroupe := nvl(vBS, 0.0) * nvl(vKM, 0.0) * nvl(vKI, 0.0) * nvl(vKX, 0.0) *
             nvl(vKB, 0.0) * nvl(vKO, 0.0) * nvl(vPL, 0.0);
  vGroupe := round(vGroupe, 1);

  update tvhomeobj h
  set    taxvalue = vGroupe,
         koeff = ' BS=' || vBS || ' * KM=' || vKM || ' * KI=' || vKI || ' * KX=' || vKX ||
                  ' * KB=' || vKB || ' * KO=' || vKO || ' * PL=' || vPL
  where  h.tvhomeobj_id = RowHomeObj.Tvhomeobj_Id;
  --commit;
  --dbms_output.put_line(RowHomeObj.tvhomeobj_id ||' BS=' || vBS ||' * KM='|| vKM ||' * KI='|| vKI ||' * KX='|| vKX ||' * KB='|| vKB ||' * KO='|| vKO ||' * PL='|| vPL);
  return_val := 'OK';
  return;
  --   return(vBS ||' * '|| vKM ||' * '|| vKI ||' * '|| vKX ||' * '|| vKB ||' * '|| vKO ||' * '|| vPL);

end;
$function$
; DROP FUNCTION tvservices.tvlandsert(numeric, date); 
CREATE OR REPLACE FUNCTION tvservices.tvlandsert(OUT return_val character varying, ipland_id numeric, ipyear date, OUT vgroupe numeric)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
  RowLand     tvLand%rowtype;
  RowProperty tvProperty%rowtype;
  vPct        numeric;
  vBS0        numeric;
  vBS         numeric;
  vKM         numeric;
  vKI         numeric;
  vKU         numeric;
  vKZ         numeric;
  vDP         numeric;
  vgr         varchar(10);
  vekatte     varchar(10);
  vki1        numeric;
  vki2        numeric;
  vki3        numeric;
  vcitycat    numeric;
  --   vGroupe numeric;
  vkzone numeric [ ];
  vYear  date;
begin
  --  vGroupe := 999;
  vYear := to_date('01.01.' || to_char(ipYear, 'yyyy'), 'dd.mm.yyyy');
  select *
  into   RowLand
  from   tvland l
  where  l.tvland_id = ipLand_id;
  select *
  into   RowProperty
  from   tvproperty p
  where  p.tvproperty_id = rowLand.tvproperty_id;
  select min(c.ekatte)
  into   vekatte
  from   address a, city c
  where  a.address_id = RowProperty.Property_address_id
  and    c.city_id = a.city_id;
  select min(c.citycat), min(c.citygroup)
  into   vcitycat, vgr
  from   CITYCAT_NORMKM3 c
  where  c.ekatte = vekatte
  and    c.begindate = (select max(cc.begindate)
                        from   CITYCAT_NORMKM3 cc
                        where  cc.ekatte = vekatte
                        and    cc.begindate <= vYear);
  if vcitycat is null
  then
    vcitycat := rowproperty.category_city;
    if rowproperty.category_city = 0
    then
      vgr := vekatte;
    elsif rowproperty.category_city > 1
    then
      vgr := '0';
    elsif rowproperty.category_city = 1
    then
      vgr := '2';
    end if;
  end if;
  -----  BS
  vPct := 1;
  if (nvl(RowProperty.Constructionbound, '0') <> '2') or
     (nvl(RowProperty.Builder_Zone, 0.0) <> 0) or
     (nvl(RowProperty.Seezone_Cat, 0.0) <> 0)
  then
    if RowLand.Builtuparea = 0 --and rowproperty.kadastrno is not null
    then
      vPct := vPct * 1.25;
    end if;
    if RowProperty.City_Category1 = 1
    then
      vPct := vPct * 1.10;
    end if;
    if RowProperty.City_Category2 = 1
    then
      vPct := vPct * 1.05;
    end if;
  end if;
  if (RowProperty.Isseezone = 1) or (RowProperty.Isnationalresort = 1)
  then
    --   if RowProperty.Category_City > 2 then
    if vekatte not in ('10135', '07079') and vcitycat <> 1
    then
      vPct := vPct * 1.50;
    end if;
  end if;
  if RowProperty.Islocalresort = 1 and vcitycat <> 1
  then
    vPct := vPct * 1.20;
  end if;
  --  end if;
  select min(nbs.apartmentvalue)
  into   vBS0
  from   normbs nbs
  where  nbs.normyear = (select max(n.normyear)
                         from   normbs n
                         where  n.normyear <= ipYear)
  and    nbs.kindconstruction = '0';

  vBS := (vBS0 * vPct);
  ---------  KM

  select array [ n.kzone1, n.kzone2, n.kzone3, n.kzone4, n.kzone5, n.inbound,
         n.outbound, n.villazone1, n.villazone2 ]
  into   vkzone
  from   normkm3 n
  where  n.normyear = (select max(nn.normyear)
                       from   normkm3 nn
                       where  nn.normyear <= ipYear)
  and    n.category_city ::numeric = vcitycat
  and    n.groupe = vgr;
  vKM := 1;
  if nvl(RowProperty.Builder_Zone, 0.0) > 0
  then
    vKM := vkzone [ nvl(RowProperty.Builder_Zone, 0.0) ];
  else
    if nvl(RowProperty.Seezone_Cat, 0.0) > 0
    then
      vKM := vkzone [ nvl(RowProperty.Seezone_Cat, 0.0) + 7 ];
    end if;
  end if;
  if ((nvl(RowProperty.Builder_Zone, 0.0) = 0) and
     (nvl(RowProperty.Seezone_Cat, 0.0) = 0))
  then
    vKM := vkzone [ nvl(RowProperty.Constructionbound, '0') ::numeric + 5 ];
  end if;
  vkm := nvl(vkm, 0.0);
  ------- KI
  vKI := 1;
  if nvl(RowProperty.Iswater, 0.0) > 0
  then
    select k.havevalue, k.haventvalue, k.haveregionvalue
    into   vki1, vki2, vki3
    from   Normki k
    where  k.normyear = (select max(n.normyear)
                         from   Normki n
                         where  n.normyear <= ipYear)
    and    k.kindelement = 1;
    if RowProperty.Iswater = 1
    then
      vKI := vKI + vki1;
    end if;
    if RowProperty.Iswater = 2
    then
      vKI := vKI + vki3;
    end if;
    if RowProperty.Iswater = 3
    then
      vKI := vKI + vki2;
    end if;
  end if;
  if nvl(RowProperty.Issewer, 0.0) > 0
  then
    select k.havevalue, k.haventvalue, k.haveregionvalue
    into   vki1, vki2, vki3
    from   Normki k
    where  k.normyear = (select max(n.normyear)
                         from   Normki n
                         where  n.normyear <= ipYear)
    and    k.kindelement = 2;
    if RowProperty.Issewer = 1
    then
      vKI := vKI + vki1;
    end if;
    if RowProperty.Issewer = 2
    then
      vKI := vKI + vki3;
    end if;
    if RowProperty.Issewer = 3
    then
      vKI := vKI + vki2;
    end if;
  end if;
  if nvl(RowProperty.Iselectro, 0.0) > 0
  then
    select k.havevalue, k.haventvalue, k.haveregionvalue
    into   vki1, vki2, vki3
    from   Normki k
    where  k.normyear = (select max(n.normyear)
                         from   Normki n
                         where  n.normyear <= ipYear)
    and    k.kindelement = 3;
    if RowProperty.Iselectro = 1
    then
      vKI := vKI + vki1;
    end if;
    if RowProperty.Iselectro = 2
    then
      vKI := vKI + vki3;
    end if;
    if RowProperty.Iselectro = 3
    then
      vKI := vKI + vki2;
    end if;
  end if;
  --if nvl(RowProperty.Isroad,0) > 0 then
  select k.havevalue, k.haventvalue, k.haveregionvalue
  into   vki1, vki2, vki3
  from   Normki k
  where  k.normyear = (select max(n.normyear)
                       from   Normki n
                       where  n.normyear <= ipYear)
  and    k.kindelement = 6;
  if nvl(RowProperty.Isroad, 0.0) = 0
  then
    vKI := vKI + vki2;
  end if;
  if RowProperty.Isroad = 1
  then
    vKI := vKI + vki1;
  end if;
  --  if  RowProperty.Isroad = 3 then  vKI := vKI + vki3; end if;
  --end if;
  vKI := round(vKI, 2);
  --------- KU
  vKU := 1;
  if RowProperty.Structurezone = '1'
  then
    vKU := 1.1;
  end if; -- KONSTANTI ????
  if RowProperty.Structurezone = '3'
  then
    vKU := 0.9;
  end if;
  if RowProperty.Structurezone = '5'
  then
    vKU := 0.8;
  end if;

  --------- KZ
  vKZ := 1;
  if nvl(RowLand.Landarea, 0.0) <> 0
  then
    if RowLand.Builtuparea / RowLand.Landarea <= 0.40
    then
      vKZ := 1;
    else
      if RowLand.Builtuparea / RowLand.Landarea >= 1
      then
        vKZ := 0.1;
      else
        vKZ := 2 -
               power(1.01, ((RowLand.Builtuparea / RowLand.Landarea) * 100 - 35));
      end if;
    end if;
  end if;
  vKZ := round(vKZ, 2);
  ---------  D
  vDP := 0;
  if RowLand.Isfence = 1
  then
    vDP := vDP +
           (nvl(RowLand.Fenceheight, 0.0) * nvl(RowLand.Fencelength, 0.0) * 8);
  end if;
  if RowLand.Iscovering = 1
  then
    vDP := vDP + (nvl(RowLand.Coveringarea, 0.0) * 35);
  end if;
  if RowLand.Issportcovering = 1
  then
    vDP := vDP + (nvl(RowLand.Sportarea, 0.0) * 15);
  end if;
  if RowLand.Ispool = 1
  then
    vDP := vDP + (nvl(RowLand.Poolcapacity, 0.0) * 23);
  end if;
  if RowLand.Isgreenparking = 1
  then
    vDP := vDP + (nvl(RowLand.Greenparking, 0.0) * 8);
  end if;
  if RowLand.Isparking = 1
  then
    vDP := vDP + (nvl(RowLand.Parkingarea, 0.0) * 15);
  end if;
  ---------
  vGroupe := vBS * vKM * vKI * vKU * vKZ * nvl(RowLand.Landarea, 0.0) + vDP;
  vGroupe := round(vGroupe, 1);
  update tvland l
  set    taxvalue = vGroupe,
         koeff = ' BS=' || vBS || ' * KM=' || vKM || ' * KI=' || vKI || ' * KU=' || vKU ||
                  ' * KZ=' || vKZ || ' * PL=' || nvl(RowLand.Landarea, 0.0) ||
                  ' + DP = ' || vDP
  where  l.tvland_id = RowLand.Tvland_Id;
  --commit;

  return_val := 'OK';
  return;
end;
$function$
; DROP FUNCTION tvservices.buildright(numeric); 
CREATE OR REPLACE FUNCTION tvservices.buildright(iptvtaxdoc_id numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  cr1 cursor is
 select *
  from tvproperty p
  where p.tvtaxdoc_id = iptvtaxdoc_id
  ;
 r1 record;

  cr2 cursor (ipprop_id numeric) is
  select *
  from tvbuilding b
  where b.tvproperty_id = ipprop_id
  ;
 r2 record;

  cr3 cursor (ipbuild_id numeric) is
 select *
 from tvhomeobj h
 where h.tvbuilding_id = ipbuild_id
 ;
 r3 record;


 rowdoc record;

 errStat varchar(200);
 vtaxval numeric;
 vyear date;
 vtotalval numeric;
 vkc numeric;
 tvHomeBuildRec record;

begin
 select to_date(c.configvalue,'yyyy') into vyear
  from config c
  where c.name = 'TAXYEAR'
  ;
  select * into rowdoc
  from tvtaxdoc td
  where td.tvtaxdoc_id = iptvtaxdoc_id
  ;

vtotalval := 0;

 open cr1;
 loop
  fetch cr1 into r1;
  exit when not FOUND;
  open cr2(r1.tvproperty_id);
  loop
    fetch cr2 into r2;
    exit when not FOUND;
    open cr3(r2.tvbuilding_id);
    loop
      fetch cr3 into r3;
      exit when not FOUND;
 --- KI kato na zemq
        select into tvHomeBuildRec * from tvservices.TVHomebuild(r3.tvhomeobj_id,vyear);
        --perform tvservices.TVHomebuild(errStat,r3.tvhomeobj_id,vyear,vtaxval);
--      errStat := tvservices.TVHomeSert(r3.tvhomeobj_id,vyear,vtaxval);
       opstat := tvHomeBuildRec.return_val;
      if opstat <> 'OK' then
       --rollback;
--       opstat := errStat;
       exit;
      end if;
     vtaxval := tvHomeBuildRec.vgroupe;
     if  nvl(rowdoc.buildrightterm,101.0) > 100 then
       vkc := 1;
     else
       vkc := 1 - power(1.05,- rowdoc.buildrightterm);
     end if;
      vkc := round(vkc,3);
      vtaxval := 0.25 * vtaxval * vkc;
      vtotalval := vtotalval + vtaxval;
      update tvhomeobj ho
        set taxvalue = round(vtaxval ,1), 
            koeff = ho.koeff || ' *KC = ' || vkc || ' *0.25'
      where ho.tvhomeobj_id = r3.tvhomeobj_id
      ;
      --commit;
   opstat := 'OK';
  end loop; --- 3
    close cr3;
  end loop; --- 2
  close cr2;
 end loop; --- 1
 close cr1;
end;

$function$
; DROP FUNCTION tvservices.clandval(numeric); 
CREATE OR REPLACE FUNCTION tvservices.clandval(iptaxdoc_id numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  rtd         tvtaxdoc%rowtype;
  vzzbs       numeric [ ];
  vbuildbound numeric;
  vroudnet    numeric;
  vcitykat    numeric;
  vbasevalue  numeric;
  vkm         numeric;
  vkc         numeric;
  vobjarea    numeric;
  optaxvalue  numeric;
begin
  select *
  into   rtd
  from   tvtaxdoc td
  where  td.tvtaxdoc_id = iptaxdoc_id;
  select array [ zbs.category1, zbs.category2, zbs.category3, zbs.category4,
         zbs.category5, zbs.category6, zbs.category7, zbs.category8,
         zbs.category9, zbs.category10 ]
  into   vzzbs
  from   normzzbs zbs
  where  zbs.normyear = (select max(z.normyear)
                         from   normzzbs z
                         where  z.normyear <= rtd.doc_date)
  and    zbs.kindusing = rtd.kinduse ::numeric;
  select nvl(zr.buildbound, 0.0)
  into   vbuildbound
  from   normzzraz zr
  where  zr.normyear = (select max(z.normyear)
                        from   normzzraz z
                        where  z.normyear <= rtd.doc_date)
  and    zr.codedistance = rtd.constrbounddistance;
  select nvl(zr.roudnet, 0.0)
  into   vroudnet
  from   normzzraz zr
  where  zr.normyear = (select max(z.normyear)
                        from   normzzraz z
                        where  z.normyear <= rtd.doc_date)
  and    zr.codedistance = rtd.roaddistance;
  select distinct min(zk.value)
  into   vcitykat
  from   normzzkat zk, tvproperty p, address a, city c, citycat_normkm3 k
  where  zk.category_city = k.citycat
  and    k.begindate = (select max(kk.begindate)
                        from   citycat_normkm3 kk
                        where  kk.begindate <= rtd.doc_date
                        and    kk.ekatte = k.ekatte)
  and    k.ekatte = c.ekatte
  and    c.city_id = a.city_id
  and    p.property_address_id = a.address_id
  and    p.tvtaxdoc_id = iptaxdoc_id
  and    zk.normyear = (select max(z.normyear)
                        from   normzzkat z
                        where  z.normyear <= rtd.doc_date);
  -- vcitykat := nvl(vcitykat,0);
  select min(p.objectarea)
  into   vobjarea
  from   tvproperty p
  where  p.tvtaxdoc_id = iptaxdoc_id;
  if rtd.category ::integer between 1 and 10
  then
    vbasevalue := vzzbs [ rtd.category ::integer ];
  end if;
  if rtd.conditions = '1'
  then
    vbasevalue := vbasevalue * 1.2;
  end if;
  vkm := 1 + vbuildbound + vroudnet + vcitykat;

  optaxvalue := vbasevalue * vkm * vobjarea;

    ------------------ 06.07.2011
    vkc := 1;
    if nvl(rtd.kindtaxval, 0.0) > 0
    then
      if nvl(rtd.userightterm, 0.0) = 0
      then
        if nvl(rtd.age, 0) = 0
        then
          vkc := 0.9;
        else
          if rtd.age >= 70
          then
            rtd.userightterm := 5;
          else
            rtd.userightterm := 70 - rtd.age;
          end if;
        end if;
        vkc := 1 - power(1.05, -rtd.userightterm);
        vkc := round(vkc, 3);
      else
        vkc := 1 - power(1.05, -rtd.userightterm);
        vkc := round(vkc, 3);
      end if;
      if vkc > 0.9
      then
        vkc := 0.9;
      end if;
    end if;
    if (nvl(rtd.kindtaxval, 0.0) = 2) and (vkc <> 1)
    then
      vkc := 1 - vkc;
    end if;
    ----------------- 06.07.2011
    update tvland
    set    taxvalue =
            (optaxvalue * vkc),
           koeff = 'BS = ' || vbasevalue || ' KM = ' || vkm || ' Pl =  ' ||
                      vobjarea || decode(nvl(rtd.kindtaxval, 0.0)::text, '0', '',
                                         ' VKC = ' || to_char(vkc))
    where  tvproperty_id in
           (select p.tvproperty_id
            from   tvproperty p
            where  p.tvtaxdoc_id = iptaxdoc_id);
    -------------
  --commit;
  opStat := 'OK';

end;
$function$
; DROP FUNCTION tvservices.counttax(numeric); 
CREATE OR REPLACE FUNCTION tvservices.counttax(iptvtaxdoc_id numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  cr1 cursor is
    select *
    from   tvproperty p
    where  p.tvtaxdoc_id = iptvtaxdoc_id;

  r1  record;

  cr2 cursor(ipprop_id numeric) is
    select *
    from   tvbuilding b
    where  b.tvproperty_id = ipprop_id;

  r2  record;

  cr3 cursor(ipbuild_id numeric) is
    select *
    from   tvhomeobj h
    where  h.tvbuilding_id = ipbuild_id;

  r3  record;

  cr4 cursor(ipprop_id numeric) is
    select *
    from   tvland l
    where  l.tvproperty_id = ipprop_id;

  r4  record;

  errStat       varchar(200);
  vtaxval       numeric;
  vyear         date;
  tvHomeSertRec record;
  tvLandSertRec record;
begin
  opstat := 'OK';
  select to_date(c.configvalue, 'yyyy')
  into   vyear
  from   config c
  where  c.name = 'TAXYEAR';
  open cr1;
  loop
    fetch cr1
      into r1;
    exit when not found;
    open cr2(r1.tvproperty_id);
    loop
      fetch cr2
        into r2;
      exit when not found;
      open cr3(r2.tvbuilding_id);
      loop
        fetch cr3
          into r3;
        exit when not found;
        select into tvHomeSertRec *
        from   tvservices.TVHomeSert(r3.tvhomeobj_id, vyear);
        -- perform tvservices.TVHomeSert(errStat,r3.tvhomeobj_id,vyear,vtaxval);
        opstat := tvHomeSertRec.return_val;
        if opstat <> 'OK'
        then
          --rollback;
          --opstat := tvHomeSertRec.return_val;
          --exit;
          raise exception 'Error: %', opstat;
        end if;
        vtaxval := tvHomeSertRec.vgroupe;
        update tvparthomeobj ho
        set    taxvalue = round(vtaxval * (case ho.part
                                   when 0 then
                                    case ho.divisor
                                      when 0 then
                                       0
                                      else
                                       ho.divident / ho.divisor
                                    end
                                   else
                                    ho.part
                                 end), 2)
        where  ho.tvhomeobj_id = r3.tvhomeobj_id;
      end loop; --- 3
      close cr3;
    end loop; --- 2
    close cr2;
    open cr4(r1.tvproperty_id);
    loop
      fetch cr4
        into r4;
      exit when not found;
      select into tvLandSertRec *
      from   tvservices.TVLandSert(r4.tvland_id, vyear);
      -- perform tvservices.TVLandSert(errStat,r4.tvland_id,vyear,vtaxval);
      opstat := tvLandSertRec.return_val;
      if opstat <> 'OK'
      then
        --rollback;
        --opstat := tvLandSertRec.return_val;
        --exit;
        raise exception 'Error: %', opstat;
      end if;
      vtaxval := tvLandSertRec.vgroupe;
      update tvpartland pl
      set    taxvalue = round(vtaxval * (case pl.partland
                                 when 0 then
                                  case pl.divisorland
                                    when 0 then
                                     0
                                    else
                                     pl.dividentland / pl.divisorland
                                  end
                                 else
                                  pl.partland
                               end), 2)
      where  pl.tvland_id = r4.tvland_id;
    end loop; --- 4
    close cr4;
  end loop; --- 1
  close cr1;
exception
  when others then
    --rollback;
    opstat := sqlerrm;
end;
$function$
; DROP FUNCTION tvservices.tvpropsert(numeric, date, numeric); 
CREATE OR REPLACE FUNCTION tvservices.tvpropsert(iptaxdoc_id numeric, ipyear date, iptaxsubject_id numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  crhobj     cursor is
    select ho.tvhomeobj_id
    from   tvproperty p, tvbuilding b, tvhomeobj ho
    where  p.tvtaxdoc_id = iptaxdoc_id
    and    b.tvproperty_id = p.tvproperty_id
    and    ho.tvbuilding_id = b.tvbuilding_id;

  vtvhobj_id numeric;

  crland     cursor is
    select l.tvland_id
    from   tvproperty p, tvland l
    where  p.tvtaxdoc_id = iptaxdoc_id
    and    l.tvproperty_id = p.tvproperty_id;

  vtvland_id numeric;

  --rowpartho tvparthomeobj%rowtype;

  verr          varchar(200);
  vobjtaxval    numeric;
  tvHomeSertRec record;
  tvLandSertRec record;

begin
  open crhobj;
  loop
    fetch crhobj
      into vtvhobj_id;
    exit when not found;
    select into tvHomeSertRec *
    from   tvservices.TVHomeSert(vtvhobj_id, ipyear);
    --perform tvservices.TVHomeSert(verr,vtvhobj_id,ipyear,vobjtaxval);
    verr := tvHomeSertRec.return_val;
    if verr <> 'OK'
    then
      exit;
    end if;
    vobjtaxval := tvHomeSertRec.vgroupe;
    update tvparthomeobj ph
    set    taxvalue = vobjtaxval * case nvl(ph.part, 0.0)
                         when 0 then
                          (ph.divident / ph.divisor)
                         else
                          ph.part
                       end
    where  ph.tvhomeobj_id = vtvhobj_id
    and    ph.taxsubject_id = iptaxsubject_id;
  end loop; -- homeobj
  if verr <> 'OK'
  then
    opstat := 'homeobj: ' || verr;
    return;
  end if;
  open crland;
  loop
    fetch crland
      into vtvland_id;
    exit when not found;
    select into tvLandSertRec *
    from   tvservices.TVLandSert(vtvland_id, ipyear);
    --perform tvservices.TVLandSert(verr,vtvland_id,ipyear,vobjtaxval);
    verr := tvLandSertRec.return_val;
    if verr <> 'OK'
    then
      exit;
    end if;
    vobjtaxval := tvLandSertRec.vgroupe;
    update tvpartland l
    set    taxvalue = vobjtaxval * case nvl(l.partland, 0.0)
                         when 0 then
                          (l.dividentland / l.divisorland)
                         else
                          l.partland
                       end
    where  l.tvland_id = vtvland_id
    and    l.taxsubject_id = iptaxsubject_id;
  end loop; -- land
  if verr <> 'OK'
  then
    opstat := 'Land: ' || verr;
    return;
  end if;
  opstat := 'OK';
  --commit;
end;
$function$
; DROP FUNCTION tvservices.unfinishtax(numeric); 
CREATE OR REPLACE FUNCTION tvservices.unfinishtax(iptvtaxdoc_id numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  cr1 cursor is
 select *
  from tvproperty p
  where p.tvtaxdoc_id = iptvtaxdoc_id
  ;
 r1 record;

  cr2 cursor (ipprop_id numeric) is
  select *
  from tvbuilding b
  where b.tvproperty_id = ipprop_id
  ;
 r2 record;

  cr3 cursor (ipbuild_id numeric) is
 select *
 from tvhomeobj h
 where h.tvbuilding_id = ipbuild_id
 ;
 r3 record;

 errStat varchar(200);
 vtaxval numeric;
 vyear date;
 vpct numeric;
 vtotalval numeric;
 tvHomeCertRec record;
begin
 select to_date(c.configvalue,'yyyy') into vyear
  from config c
  where c.name = 'TAXYEAR'
  ;
vtotalval := 0;

 open cr1;
 loop
  fetch cr1 into r1;
  exit when not FOUND;
  open cr2(r1.tvproperty_id);
  loop
    fetch cr2 into r2;
    exit when not FOUND;
    open cr3(r2.tvbuilding_id);
    loop
      fetch cr3 into r3;
      exit when not FOUND;
      select into tvHomeCertRec * from tvservices.TVHomeSert(r3.tvhomeobj_id,vyear);
     -- perform tvservices.TVHomeSert(errStat,r3.tvhomeobj_id,vyear,vtaxval);
      if tvHomeCertRec.return_val <> 'OK' then
       --rollback;
       opstat := tvHomeCertRec.return_val;
       exit;
      end if;
      vtaxval := tvHomeCertRec.vgroupe; 
-------- ???????????????
      select (case de.code
              when '0' then 0.37
               when '1' then 0.63
                else 1.0
             end)  
      into vpct
      from decode de
      where de.columnname = 'RecDOFIN'
      and de.code = to_char(r3.pctfinished)
      ;
      vtaxval := vpct * vtaxval;
      vtotalval := vtotalval + vtaxval;
      update tvhomeobj ho
        set taxvalue = round(vtaxval ,1),
            koeff = ho.koeff || ' ' || vpct || '%'
      where ho.tvhomeobj_id = r3.tvhomeobj_id
      ;
    end loop; --- 3
    close cr3;
  end loop; --- 2
  close cr2;
 end loop; --- 1
end;

$function$
; DROP FUNCTION tvservices.useright(numeric); 
CREATE OR REPLACE FUNCTION tvservices.useright(iptvtaxdoc_id numeric, OUT opstat character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
declare
  cr1 cursor is
    select *
    from   tvproperty p
    where  p.tvtaxdoc_id = iptvtaxdoc_id;

  r1  record;

  cr2 cursor(ipprop_id numeric) is
    select *
    from   tvbuilding b
    where  b.tvproperty_id = ipprop_id;

  r2  record;

  cr3 cursor(ipbuild_id numeric) is
    select *
    from   tvhomeobj h
    where  h.tvbuilding_id = ipbuild_id;

  r3  record;

  cr4 cursor(ipprop_id numeric) is
    select *
    from   tvland l
    where  l.tvproperty_id = ipprop_id;

  r4  record;

  cr5 cursor(iphomeobj_id numeric) is
    select *
    from   tvparthomeobj h
    where  h.tvhomeobj_id = iphomeobj_id;

  r5  record;

  cr6 cursor(ipland_id numeric) is
    select *
    from   tvpartland l
    where  l.tvland_id = ipland_id;

  r6  record;

  rowdoc record;

  errStat       varchar(200);
  vtaxval       numeric;
  vyear         date;
  vtotalval     numeric;
  vkc           numeric;
  tvHomeSertRec record;
  tvLandSertRec record;


begin
  select to_date(c.configvalue, 'yyyy')
  into   vyear
  from   config c
  where  c.name = 'TAXYEAR';
  select *
  into   rowdoc
  from   tvtaxdoc td
  where  td.tvtaxdoc_id = iptvtaxdoc_id;

  vtotalval := 0;

  open cr1;
  loop
    fetch cr1
      into r1;
    exit when not found;
    open cr2(r1.tvproperty_id);
    loop
      fetch cr2
        into r2;
      exit when not found;
      open cr3(r2.tvbuilding_id);
      loop
        fetch cr3
          into r3;
        exit when not found;
        select into tvHomeSertRec *
        from   tvservices.TVHomeSert(r3.tvhomeobj_id, vyear);
        --perform tvservices.TVHomeSert(errStat,r3.tvhomeobj_id,vyear,vtaxval);
        if tvHomeSertRec.return_val <> 'OK'
        then
          --rollback;
          opstat := tvHomeSertRec.return_val;
          exit;
        end if;
        vtaxval := tvHomeSertRec.vgroupe;
        if nvl(rowdoc.userightterm, 0.0) = 0
        then
          if nvl(rowdoc.age, 0.0) = 0
          then
            vkc := 0.9;
          else
            if rowdoc.age >= 70
            then
              rowdoc.userightterm := 5;
            else
              rowdoc.userightterm := 70 - rowdoc.age;
            end if;
          end if;
          vkc := 1 - power(1.05, -rowdoc.userightterm);
          vkc := round(vkc, 3);
        else
          vkc := 1 - power(1.05, -rowdoc.userightterm);
          vkc := round(vkc, 3);
        end if;
        if vkc > 0.9
        then
          vkc := 0.9;
        end if;
      
        vtaxval := vtaxval * vkc;
        open cr5(r3.tvhomeobj_id);
        loop
          fetch cr5
            into r5;
          exit when not found;
          update tvparthomeobj ph
          set    taxvalue = vtaxval * case nvl(ph.part, 0.0)
                               when 0 then
                                (ph.divident / case ph.divisor
                                  when 0 then
                                   1
                                  else
                                   ph.divisor
                                end)
                               else
                                ph.part
                             end
          -- set ph.taxvalue = vtaxval * decode(nvl(ph.part,0.0),0,(ph.divident/decode(ph.divisor,0,1,ph.divisor)),ph.part)
          where  ph.tvparthomeobj_id = r5.tvparthomeobj_id;
        end loop;
        close cr5;
        vtotalval := vtotalval + vtaxval;
        update tvhomeobj ho
        set    taxvalue = round(vtaxval, 1),
               koeff = ho.koeff || ' *KC = ' || vkc
        where  ho.tvhomeobj_id = r3.tvhomeobj_id;
      end loop; --- 3
      close cr3;
    end loop; --- 2
    close cr2;
    open cr4(r1.tvproperty_id);
    loop
      fetch cr4
        into r4;
      exit when not found;
      select into tvLandSertRec *
      from   tvservices.TVlandSert(r4.tvland_id, vyear);
      --perform tvservices.TVlandSert(errStat,r4.tvland_id,vyear,vtaxval);
      if tvLandSertRec.return_val <> 'OK'
      then
        --rollback;
        opstat := tvLandSertRec.return_val;
        exit;
      end if;
      vtaxval := tvLandSertRec.vgroupe;
      if nvl(rowdoc.userightterm, 0.0) = 0
      then
        if nvl(rowdoc.age, 0.0) = 0
        then
          vkc := 0.9;
        else
          if rowdoc.age >= 70
          then
            rowdoc.userightterm := 5;
          else
            rowdoc.userightterm := 70 - rowdoc.age;
          end if;
        end if;
        vkc := 1 - power(1.05, -rowdoc.userightterm);
        vkc := round(vkc, 3);
      else
        vkc := 1 - power(1.05, -rowdoc.userightterm);
        vkc := round(vkc, 3);
      end if;
      if vkc > 0.9
      then
        vkc := 0.9;
      end if;
    
      vtaxval   := vtaxval * vkc;
      vtotalval := vtotalval + vtaxval;
      update tvland l
      set    taxvalue = round(vtaxval, 1), koeff = l.koeff || ' *KC = ' || vkc
      where  l.tvland_id = r4.tvland_id;
      open cr6(r4.tvland_id);
      loop
        fetch cr6
          into r6;
        exit when not found;
        update tvpartland pl
        set    taxvalue = vtaxval * case nvl(pl.partland, 0.0)
                             when 0 then
                              (pl.dividentland / case pl.divisorland
                                when 0 then
                                 1
                                else
                                 pl.divisorland
                              end)
                             else
                              pl.partland
                           end
        --set pl.taxvalue = vtaxval * decode(nvl(pl.partland,0.0),0,(pl.dividentland/decode(pl.divisorland,0,1,pl.divisorland)),pl.partland)
        where  pl.tvland_id = r6.tvland_id;
      end loop;
      close cr6;
    end loop; -- 4
    close cr4;
  end loop; --- 1
  --commit;
  opstat := 'OK';
end;
$function$
;
