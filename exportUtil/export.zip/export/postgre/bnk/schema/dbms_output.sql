DROP FUNCTION dbms_output.disable(); 
CREATE OR REPLACE FUNCTION dbms_output.disable()
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_output_disable$function$
; DROP FUNCTION dbms_output.enable(); 
CREATE OR REPLACE FUNCTION dbms_output.enable()
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_output_enable_default$function$
; DROP FUNCTION dbms_output.enable(integer); 
CREATE OR REPLACE FUNCTION dbms_output.enable(buffer_size integer)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_output_enable$function$
; DROP FUNCTION dbms_output.get_line(); 
CREATE OR REPLACE FUNCTION dbms_output.get_line(OUT line text, OUT status integer)
 RETURNS record
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_output_get_line$function$
; DROP FUNCTION dbms_output.get_lines(integer); 
CREATE OR REPLACE FUNCTION dbms_output.get_lines(OUT lines text[], INOUT numlines integer)
 RETURNS record
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_output_get_lines$function$
; DROP FUNCTION dbms_output.new_line(); 
CREATE OR REPLACE FUNCTION dbms_output.new_line()
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_output_new_line$function$
; DROP FUNCTION dbms_output.put(text); 
CREATE OR REPLACE FUNCTION dbms_output.put(a text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_output_put$function$
; DROP FUNCTION dbms_output.put_line(text); 
CREATE OR REPLACE FUNCTION dbms_output.put_line(a text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_output_put_line$function$
; DROP FUNCTION dbms_output.serveroutput(boolean); 
CREATE OR REPLACE FUNCTION dbms_output.serveroutput(boolean)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_output_serveroutput$function$
;
