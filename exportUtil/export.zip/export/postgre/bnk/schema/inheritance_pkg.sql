DROP FUNCTION inheritance_pkg.inheritanceupdate(numeric, date, character varying, numeric, date, numeric); 
CREATE OR REPLACE FUNCTION inheritance_pkg.inheritanceupdate(iptaxdoc_id numeric, ipinheritancedate date, ipinheritancecertificateno character varying, ipmunicipality_id numeric, ipuserdate date, ipuser_id numeric, OUT opresult numeric)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
declare                            
  inhscount   numeric(12) := 0;
  inhscntHelp numeric(12) := 0;
  inhidout    numeric(12) := -2;
begin
  select count(inheritance_id)
    into inhscount
    from inheritance 
   where taxdoc_id = ipTaxdoc_id;
  if inhscount > 1 then
      inhidout := -1;
  elsif inhscount = 0 then
      inhidout := nextval('s_inheritance');
      
      insert into inheritance
        (inheritance_id,
         taxdoc_id,
         inheritcertif_date,
         inheritcertifno,
         inheritcertif_municipality_id,
         user_id,
         user_date)
      values
        (inhidout,
         ipTaxdoc_id,
         ipInheritancedate,
         ipInheritancecertificateno,
         ipMunicipality_id,
         ipUser_id,
         ipUserdate);
 select count(inheritance_id)
      into   inhscntHelp
      from   inheritance
      where  taxdoc_id = ipTaxdoc_id;
      if inhscount <> inhscntHelp - 1
      then
        inhidout := -1;
        rollback;

      end if;     
  else
      select inheritance_id
        into inhidout
        from inheritance 
       where taxdoc_id = ipTaxdoc_id;
      update inheritance 
         set taxdoc_id                     = ipTaxdoc_id,
             inheritcertif_date            = ipInheritancedate,
             inheritcertifno               = ipInheritancecertificateno,
             inheritcertif_municipality_id = ipMunicipality_id,
             user_id                       = ipUser_id,
             user_date                     = ipUserdate
       where inheritance_id = inhidout;
select count(inheritance_id)
      into   inhscntHelp
      from   inheritance 
      where  taxdoc_id = ipTaxdoc_id;
      if inhscount <> inhscntHelp
      then
        inhidout := -1;
        rollback;
     end if;     
  end if;
  opresult := inhidout;
end;
$function$
;
