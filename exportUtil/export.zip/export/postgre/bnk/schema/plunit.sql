DROP FUNCTION plunit.assert_equals(anyelement, anyelement); 
CREATE OR REPLACE FUNCTION plunit.assert_equals(expected anyelement, actual anyelement)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_equals$function$
; DROP FUNCTION plunit.assert_equals(anyelement, anyelement, character varying); 
CREATE OR REPLACE FUNCTION plunit.assert_equals(expected anyelement, actual anyelement, message character varying)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_equals_message$function$
; DROP FUNCTION plunit.assert_equals(double precision, double precision, double precision); 
CREATE OR REPLACE FUNCTION plunit.assert_equals(expected double precision, actual double precision, range double precision)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_equals_range$function$
; DROP FUNCTION plunit.assert_equals(double precision, double precision, double precision, character varying); 
CREATE OR REPLACE FUNCTION plunit.assert_equals(expected double precision, actual double precision, range double precision, message character varying)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_equals_range_message$function$
; DROP FUNCTION plunit.assert_false(boolean); 
CREATE OR REPLACE FUNCTION plunit.assert_false(condition boolean)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_false$function$
; DROP FUNCTION plunit.assert_false(boolean, character varying); 
CREATE OR REPLACE FUNCTION plunit.assert_false(condition boolean, message character varying)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_false_message$function$
; DROP FUNCTION plunit.assert_not_equals(anyelement, anyelement); 
CREATE OR REPLACE FUNCTION plunit.assert_not_equals(expected anyelement, actual anyelement)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_not_equals$function$
; DROP FUNCTION plunit.assert_not_equals(anyelement, anyelement, character varying); 
CREATE OR REPLACE FUNCTION plunit.assert_not_equals(expected anyelement, actual anyelement, message character varying)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_not_equals_message$function$
; DROP FUNCTION plunit.assert_not_equals(double precision, double precision, double precision); 
CREATE OR REPLACE FUNCTION plunit.assert_not_equals(expected double precision, actual double precision, range double precision)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_not_equals_range$function$
; DROP FUNCTION plunit.assert_not_equals(double precision, double precision, double precision, character varying); 
CREATE OR REPLACE FUNCTION plunit.assert_not_equals(expected double precision, actual double precision, range double precision, message character varying)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_not_equals_range_message$function$
; DROP FUNCTION plunit.assert_not_null(anyelement); 
CREATE OR REPLACE FUNCTION plunit.assert_not_null(actual anyelement)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_not_null$function$
; DROP FUNCTION plunit.assert_not_null(anyelement, character varying); 
CREATE OR REPLACE FUNCTION plunit.assert_not_null(actual anyelement, message character varying)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_not_null_message$function$
; DROP FUNCTION plunit.assert_null(anyelement); 
CREATE OR REPLACE FUNCTION plunit.assert_null(actual anyelement)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_null$function$
; DROP FUNCTION plunit.assert_null(anyelement, character varying); 
CREATE OR REPLACE FUNCTION plunit.assert_null(actual anyelement, message character varying)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_null_message$function$
; DROP FUNCTION plunit.assert_true(boolean); 
CREATE OR REPLACE FUNCTION plunit.assert_true(condition boolean)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_true$function$
; DROP FUNCTION plunit.assert_true(boolean, character varying); 
CREATE OR REPLACE FUNCTION plunit.assert_true(condition boolean, message character varying)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_assert_true_message$function$
; DROP FUNCTION plunit.fail(); 
CREATE OR REPLACE FUNCTION plunit.fail()
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_fail$function$
; DROP FUNCTION plunit.fail(character varying); 
CREATE OR REPLACE FUNCTION plunit.fail(message character varying)
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$plunit_fail_message$function$
;
