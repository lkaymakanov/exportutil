DROP FUNCTION dbms_random.initialize(integer); 
CREATE OR REPLACE FUNCTION dbms_random.initialize(integer)
 RETURNS void
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$dbms_random_initialize$function$
; DROP FUNCTION dbms_random.normal(); 
CREATE OR REPLACE FUNCTION dbms_random.normal()
 RETURNS double precision
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_random_normal$function$
; DROP FUNCTION dbms_random.random(); 
CREATE OR REPLACE FUNCTION dbms_random.random()
 RETURNS integer
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_random_random$function$
; DROP FUNCTION dbms_random.seed(integer); 
CREATE OR REPLACE FUNCTION dbms_random.seed(integer)
 RETURNS void
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$dbms_random_seed_int$function$
; DROP FUNCTION dbms_random.seed(text); 
CREATE OR REPLACE FUNCTION dbms_random.seed(text)
 RETURNS void
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/orafunc', $function$dbms_random_seed_varchar$function$
; DROP FUNCTION dbms_random.string(text, integer); 
CREATE OR REPLACE FUNCTION dbms_random.string(opt text, len integer)
 RETURNS text
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$dbms_random_string$function$
; DROP FUNCTION dbms_random.terminate(); 
CREATE OR REPLACE FUNCTION dbms_random.terminate()
 RETURNS void
 LANGUAGE c
 IMMUTABLE
AS '$libdir/orafunc', $function$dbms_random_terminate$function$
; DROP FUNCTION dbms_random.value(); 
CREATE OR REPLACE FUNCTION dbms_random.value()
 RETURNS double precision
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_random_value$function$
; DROP FUNCTION dbms_random.value(double precision, double precision); 
CREATE OR REPLACE FUNCTION dbms_random.value(low double precision, high double precision)
 RETURNS double precision
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_random_value_range$function$
;
