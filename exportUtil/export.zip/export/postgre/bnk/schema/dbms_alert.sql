DROP FUNCTION dbms_alert._signal(text, text); 
CREATE OR REPLACE FUNCTION dbms_alert._signal(name text, message text)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_alert_signal$function$
; DROP FUNCTION dbms_alert.defered_signal(); 
CREATE OR REPLACE FUNCTION dbms_alert.defered_signal()
 RETURNS trigger
 LANGUAGE c
 SECURITY DEFINER
AS '$libdir/orafunc', $function$dbms_alert_defered_signal$function$
; DROP FUNCTION dbms_alert.register(text); 
CREATE OR REPLACE FUNCTION dbms_alert.register(name text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_alert_register$function$
; DROP FUNCTION dbms_alert.remove(text); 
CREATE OR REPLACE FUNCTION dbms_alert.remove(name text)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/orafunc', $function$dbms_alert_remove$function$
; DROP FUNCTION dbms_alert.removeall(); 
CREATE OR REPLACE FUNCTION dbms_alert.removeall()
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_alert_removeall$function$
; DROP FUNCTION dbms_alert.set_defaults(double precision); 
CREATE OR REPLACE FUNCTION dbms_alert.set_defaults(sensitivity double precision)
 RETURNS void
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_alert_set_defaults$function$
; DROP FUNCTION dbms_alert.signal(text, text); 
CREATE OR REPLACE FUNCTION dbms_alert.signal(_event text, _message text)
 RETURNS void
 LANGUAGE c
 SECURITY DEFINER
AS '$libdir/orafunc', $function$dbms_alert_signal$function$
; DROP FUNCTION dbms_alert.waitany(double precision); 
CREATE OR REPLACE FUNCTION dbms_alert.waitany(OUT name text, OUT message text, OUT status integer, timeout double precision)
 RETURNS record
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_alert_waitany$function$
; DROP FUNCTION dbms_alert.waitone(text, double precision); 
CREATE OR REPLACE FUNCTION dbms_alert.waitone(name text, OUT message text, OUT status integer, timeout double precision)
 RETURNS record
 LANGUAGE c
AS '$libdir/orafunc', $function$dbms_alert_waitone$function$
;
